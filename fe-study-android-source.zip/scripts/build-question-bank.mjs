import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const sourceDir = path.join(root, 'app', 'src', 'main', 'assets', 'questions');
const outputFile = path.join(root, 'app', 'src', 'main', 'assets', 'questions.js');
const files = fs.readdirSync(sourceDir).filter(name => name.endsWith('.json')).sort();
// Transcribed independently from IPA's answer PDFs, in question-number order.
const officialAnswers = {
  '2023-A': ['ウ','ウ','エ','エ','イ','ウ','イ','エ','ウ','ウ','エ','ウ','エ','ウ','エ','イ','ウ','ウ','エ','ア'],
  '2024-A': ['ウ','エ','イ','エ','ウ','ア','ウ','ウ','ウ','エ','ウ','エ','ウ','ウ','エ','エ','ア','エ','エ','ア'],
  '2025-A': ['エ','イ','イ','ウ','ア','ウ','エ','エ','ウ','ア','ウ','エ','エ','エ','ウ','エ','イ','エ','エ','イ'],
  '2023-B': ['ア','ク','エ','エ','エ','ア'],
  '2024-B': ['イ','エ','エ','イ','オ','ウ'],
  '2025-B': ['カ','ア','イ','ク','オ','ク'],
  '2026-A': ['イ','ウ','イ','イ','イ','イ','エ','ア','ウ','ウ','ア','ウ','ア','エ','ウ','ア','イ','ア','ア','イ'],
  '2026-B': ['エ','カ','ア','エ','イ','ケ']
};
const all = files.flatMap(name => {
  const parsed = JSON.parse(fs.readFileSync(path.join(sourceDir, name), 'utf8'));
  if (!Array.isArray(parsed)) throw new Error(`${name}: root must be an array`);
  return parsed;
});
const ids = new Set();
for (const q of all) {
  if (!q.id || ids.has(q.id)) throw new Error(`Duplicate or missing ID: ${q.id}`);
  ids.add(q.id);
  if (!['official', 'original'].includes(q.kind)) throw new Error(`${q.id}: invalid kind`);
  if (!['A', 'B'].includes(q.section)) throw new Error(`${q.id}: invalid section`);
  if (!q.stemJa || !q.topicZh || !q.explanationZh || q.explanationZh.length < 80) throw new Error(`${q.id}: incomplete text/explanation`);
  if (!Array.isArray(q.options) || q.options.length < 4) throw new Error(`${q.id}: missing options`);
  const labels = new Set(q.options.map(o => o.label));
  if (labels.size !== q.options.length || !labels.has(q.answer)) throw new Error(`${q.id}: answer/options mismatch`);
  if (q.options.some(o => !o.textJa)) throw new Error(`${q.id}: empty option`);
  if (q.kind === 'official') {
    if (!Number.isInteger(q.year) || !Number.isInteger(q.number) || !Number.isInteger(q.page)) throw new Error(`${q.id}: missing source coordinates`);
    if (!/^https:\/\/www\.ipa\.go\.jp\/.*\.pdf$/.test(q.questionUrl) || !/^https:\/\/www\.ipa\.go\.jp\/.*\.pdf$/.test(q.answerUrl)) throw new Error(`${q.id}: source must be IPA PDFs`);
    if (q.id !== `FE-${q.year}-${q.section}-${String(q.number).padStart(2, '0')}`) throw new Error(`${q.id}: ID does not match source fields`);
    const answers = officialAnswers[`${q.year}-${q.section}`];
    if (!answers || answers[q.number - 1] !== q.answer) throw new Error(`${q.id}: answer differs from IPA key`);
  }
}
all.sort((a, b) => (a.kind === b.kind ? (b.year || 0) - (a.year || 0) || a.section.localeCompare(b.section) || a.number - b.number : a.kind === 'official' ? -1 : 1));
fs.writeFileSync(outputFile, `// Generated from reviewed question JSON. Do not edit directly.\nwindow.FE_QUESTIONS = ${JSON.stringify(all, null, 2)};\n`, 'utf8');
console.log(`Validated ${all.length} questions (${all.filter(q=>q.kind==='official').length} official, ${all.filter(q=>q.kind==='original').length} original) from ${files.length} files.`);
