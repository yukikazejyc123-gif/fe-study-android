import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const assets = path.join(root, 'app', 'src', 'main', 'assets');
const questionFiles = fs.readdirSync(path.join(assets, 'questions')).filter(name => name.endsWith('.json'));
const questions = questionFiles.flatMap(name => JSON.parse(fs.readFileSync(path.join(assets, 'questions', name), 'utf8')));
const listeners = {};
const nav = ['learn', 'quiz', 'wrong', 'daily'].map(tab => ({ dataset: { tab }, classList: { toggle() {} }, addEventListener(type, callback) { this.click = callback; } }));
const screen = {
  innerHTML: '',
  addEventListener(type, callback) { listeners[type] = callback; },
  querySelector() { return { after() {} }; }
};
const storage = new Map();
const document = {
  getElementById() { return screen; },
  querySelectorAll() { return nav; },
  querySelector() { return { scrollIntoView() {} }; },
  createElement() { return { className: '', textContent: '' }; }
};
const context = vm.createContext({
  window: { FE_QUESTIONS: questions, scrollTo() {} },
  document,
  localStorage: { getItem(key) { return storage.get(key) ?? null; }, setItem(key, value) { storage.set(key, value); } }
});
vm.runInContext(fs.readFileSync(path.join(assets, 'lessons.js'), 'utf8'), context);
vm.runInContext(fs.readFileSync(path.join(assets, 'app.js'), 'utf8'), context);

const click = (action, props = {}) => listeners.click({ target: { closest() { return { dataset: { action, ...props } }; } } });
const go = tab => nav.find(item => item.dataset.tab === tab).click();
const state = () => JSON.parse(storage.get('fe-study-state-v1'));
const firstOriginal = questions.find(q => q.kind === 'original');
const wrongOption = firstOriginal.options.find(o => o.label !== firstOriginal.answer).label;

assert.match(screen.innerHTML, /知识点学习/);
go('quiz');
assert.match(screen.innerHTML, /刷题练习/);
listeners.change({ target: { dataset: { filter: 'kind' }, value: 'original' } });
assert.match(screen.innerHTML, /原创练习 4 道/);
click('start-filtered');
assert.match(screen.innerHTML, /原创练习 · 非真题/);
click('select-option', { option: wrongOption });
click('submit-answer');
assert.match(screen.innerHTML, /再看一遍思路/);
assert.equal(state().attempts[0].correct, false);
assert.match(state().attempts[0].date, /^\d{4}-\d{2}-\d{2}$/);
go('wrong');
assert.match(screen.innerHTML, /待复习 1 道/);

for (let i = 0; i < 2; i++) {
  click('start-wrong');
  click('select-option', { option: firstOriginal.answer });
  click('submit-answer');
  click('next-question');
  click('close-result');
  assert.match(screen.innerHTML, i === 0 ? /待复习 1 道/ : /目前没有待复习错题/);
}

go('daily');
const firstDaily = state().daily[Object.keys(state().daily)[0]];
assert.equal(firstDaily.length, 5);
go('learn');
go('daily');
assert.deepEqual(state().daily[Object.keys(state().daily)[0]], firstDaily);
click('start-daily');
const dailyQuestion = questions.find(q => q.id === firstDaily[0]);
click('select-option', { option: dailyQuestion.answer });
click('submit-answer');
click('leave-session');
assert.match(screen.innerHTML, /今天已完成 1 \/ 5 道/);

go('quiz');
listeners.change({ target: { dataset: { filter: 'kind' }, value: 'official' } });
click('start-filtered');
assert.match(screen.innerHTML, /IPA 官方公开题/);
assert.equal(context.window.FE_goBack(), true);
assert.match(screen.innerHTML, /刷题练习/);
assert.equal(context.window.FE_goBack(), true);
assert.match(screen.innerHTML, /知识点学习/);
assert.equal(context.window.FE_goBack(), false);
console.log('Smoke test passed: learning, filters, quiz feedback, wrong review, daily persistence and official labeling.');
