// Generated from reviewed question JSON. Do not edit directly.
window.FE_QUESTIONS = [
  {
    "id": "FE-2026-A-02",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 2,
    "topicZh": "算法与排序",
    "stemJa": "クイックソートの処理方法を説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "既に整列済みのデータ列の正しい位置に，データを追加する操作を繰り返していく方法である。"
      },
      {
        "label": "イ",
        "textJa": "データ中の最小値を求め，次にそれを除いた部分の中から最小値を求める。この操作を繰り返していく方法である。"
      },
      {
        "label": "ウ",
        "textJa": "適当な基準値を選び，それよりも小さな値のグループと大きな値のグループにデータを分割する。同様にして，グループの中で基準値を選び，それぞれのグループを分割する。この操作を繰り返していく方法である。"
      },
      {
        "label": "エ",
        "textJa": "隣り合ったデータの比較と入替えを繰り返すことによって，小さな値のデータを次第に端の方に移していく方法である。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "快速排序的核心是选一个基准值，把数据分成比它小和比它大的两组，再对各组重复这一过程，所以选ウ。这里要抓住“基准值”和“分组后递归处理”。ア是插入排序：把新元素放入已排好序的部分；イ是选择排序：反复从未排序部分选出最小值；エ是冒泡排序：反复比较并交换相邻元素。四种算法都能排序，但分组依据与处理顺序不同。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 4
  },
  {
    "id": "FE-2026-A-03",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 3,
    "topicZh": "计算机硬件",
    "stemJa": "プロセッサの一つである GPU の特徴として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "OS 及び他のハードウェアから独立して機能し，暗号キーなどの情報を安全に管理する。"
      },
      {
        "label": "イ",
        "textJa": "並列に動作する多数の浮動小数点演算ユニットによって，高速な 3D 演算ができる。"
      },
      {
        "label": "ウ",
        "textJa": "目的に応じて半導体デバイス内部の論理回路を再構成できる。"
      },
      {
        "label": "エ",
        "textJa": "量子ビットによって 0 と 1 を重ね合わせた状態を計算に使うことができる。"
      }
    ],
    "answer": "イ",
    "explanationZh": "GPU 有大量可并行工作的运算单元，适合同时处理图形中许多顶点、像素等数值计算，因此イ所说的高速 3D 浮点运算是其典型特点。ア描述的是用于保护密钥等信息的安全硬件（如 TPM），不是 GPU 的主要功能。ウ描述可重新配置内部逻辑电路的 FPGA。エ描述使用量子比特叠加态的量子计算设备。题目问的是 GPU，应以大量并行运算单元为识别点。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2026-A-04",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 4,
    "topicZh": "云计算服务模型",
    "stemJa": "クラウドコンピューティングのサービスモデルとしての PaaS の説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "OS やアプリケーションを含む任意のソフトウェアを実行可能にするリソースが，利用者に提供される。OS などのプラットフォームへの限定的な設定や制御を行うことができる。"
      },
      {
        "label": "イ",
        "textJa": "アプリケーションの開発や運用に必要となるミドルウェアなどが利用者に提供されるので，これらを利用して，アプリケーションを開発して運用することができる。利用者は，プラットフォームを直接変更することはできない。"
      },
      {
        "label": "ウ",
        "textJa": "利用者は，ハードウェア，OS などのプラットフォームとアプリケーションを自ら準備して，それらの運用を依頼する。利用者は，プラットフォームの構成を決めることができるなど，環境構築の自由度が高い。"
      },
      {
        "label": "エ",
        "textJa": "利用者は，用意されたアプリケーションをそのまま又はカスタマイズして利用するが，OS などのプラットフォームからアプリケーションまで全てを自ら準備する必要はない。利用者は，プラットフォームを直接変更することはできない。"
      }
    ],
    "answer": "イ",
    "explanationZh": "PaaS 是“平台即服务”：服务方提供运行应用所需的平台和中间件，使用者在这个平台上开发、部署、运行自己的应用，但通常不能直接改动平台内部，所以イ正确。ア强调提供运行任意软件的底层计算资源，并允许一定程度控制 OS，更接近 IaaS。ウ要求使用者自行准备硬件、OS 与应用，再委托他人运维，属于委托运维场景。エ直接提供可使用或定制的成品应用，是 SaaS。区分三者时看交付层级：资源、开发运行平台、成品应用。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2026-A-05",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 5,
    "topicZh": "虚拟内存",
    "stemJa": "仮想記憶方式のコンピュータシステムにおいて，処理の多重度を増やしたところ，ページイン，ページアウトが多発して，システムの応答速度が急激に遅くなった。このような現象を何というか。",
    "options": [
      {
        "label": "ア",
        "textJa": "オーバレイ"
      },
      {
        "label": "イ",
        "textJa": "スラッシング"
      },
      {
        "label": "ウ",
        "textJa": "メモリコンパクション"
      },
      {
        "label": "エ",
        "textJa": "ロールアウト"
      }
    ],
    "answer": "イ",
    "explanationZh": "并发处理增多后，物理内存不足以容纳各进程当前需要的页面，系统频繁把页面换入、换出，时间大量耗在分页而非实际计算上，响应速度骤降。这叫“抖动”（スラッシング），选イ。ア“覆盖”是让程序不同部分分时使用同一内存区域；ウ“内存紧缩”是整理分散的空闲空间；エ“换出”是把进程等从主存移往辅助存储的一种动作。题干描述的是频繁分页造成的系统性性能恶化，不是单次换出。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2026-A-08",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 8,
    "topicZh": "无线网络",
    "stemJa": "無線 LAN では，複数の端末から送信された同じ周波数の電波が衝突した場合，電波が干渉するのでそれらを受信すると信号を復調できないことがある。この問題を回避するためのものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "CSMA/CA"
      },
      {
        "label": "イ",
        "textJa": "SSID"
      },
      {
        "label": "ウ",
        "textJa": "キャリアアグリゲーション"
      },
      {
        "label": "エ",
        "textJa": "テザリング"
      }
    ],
    "answer": "ア",
    "explanationZh": "无线设备不能可靠地像有线网络那样边发边检测冲突，因此 Wi‑Fi 用 CSMA/CA：发送前先侦听信道，尽量避免同时发射，必要时通过等待等机制降低碰撞概率，选ア。SSID 是无线网络名称，用于识别网络，不负责处理信号冲突。载波聚合（ウ）组合多个载波以增加传输能力。网络共享（エ）让其他设备借用终端的网络连接，也不能解决同频发送冲突。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 7
  },
  {
    "id": "FE-2026-A-09",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 9,
    "topicZh": "身份认证",
    "stemJa": "2 要素認証に該当する組みはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "クライアント証明書，ハードウェアトークン"
      },
      {
        "label": "イ",
        "textJa": "静脈認証，指紋認証"
      },
      {
        "label": "ウ",
        "textJa": "パスワード認証，静脈認証"
      },
      {
        "label": "エ",
        "textJa": "パスワード認証，秘密の質問の答え"
      }
    ],
    "answer": "ウ",
    "explanationZh": "双因素认证要求使用两种不同类别的凭据。常见类别是“知道的事”（密码、秘密问题答案）、“持有的物”（证书、硬件令牌）和“自身特征”（指纹、静脉）。ウ把密码的知识因素与静脉的生物因素组合，故正确。ア的客户端证书与硬件令牌都属于持有因素；イ的静脉与指纹都属于生物因素；エ的密码与秘密问题答案都属于知识因素。使用两个凭据不等于使用两个因素。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2026-A-11",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 11,
    "topicZh": "软件开发规范",
    "stemJa": "あるシステムにおいて，“プログラムの記述方法が統一されていないので保守がしづらい”という問題が発生している。今後の新規開発プロジェクトにおけるこの問題の低減策として，最も適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "コーディング規約を見直し，教育する。"
      },
      {
        "label": "イ",
        "textJa": "セキュアプログラミングを採用する。"
      },
      {
        "label": "ウ",
        "textJa": "単体テストでの命令網羅度を上げる。"
      },
      {
        "label": "エ",
        "textJa": "プロジェクト管理レビューに全プログラマーが参加する。"
      }
    ],
    "answer": "ア",
    "explanationZh": "问题的原因是写法不统一，直接措施是制定或修订编码规范，并培训开发人员按规范执行，所以选ア。规范能统一命名、格式、结构等做法，让后续人员更容易阅读和维护。イ的安全编程侧重减少漏洞，不能直接解决风格不一致；ウ提高语句覆盖率用于检验测试执行范围，也不能统一代码写法；エ扩大项目管理评审的参会人员，既不针对代码规范，也未必有助于维护性。选措施时要对应题干给出的根因。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2026-A-12",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 12,
    "topicZh": "敏捷项目管理",
    "stemJa": "バーンダウンチャートの使い方として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "縦軸を完成した成果物の総量，横軸を時間とし，プロジェクトが進むに従って完成した成果物の総量が増加する様子を確認する。"
      },
      {
        "label": "イ",
        "textJa": "縦軸を残課題の総数，横軸を時間とし，プロジェクトが進むに従って残課題の総量が増減する様子を確認する。"
      },
      {
        "label": "ウ",
        "textJa": "縦軸を残作業の量，横軸を時間とし，プロジェクトが進むに従って残作業の量が減少する様子を確認する。"
      },
      {
        "label": "エ",
        "textJa": "縦軸を延べ工数，横軸を時間とし，プロジェクトが進むに従って延べ工数が増加する様子を確認する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "燃尽图以时间为横轴、剩余工作量为纵轴。随着任务完成，剩余工作量逐渐“燃尽”并趋向零，因此ウ正确。ア画的是已完成成果物总量，方向向上，更接近燃起图。イ虽然也在观察“剩余”，但它写的是课题总数随时间增减；本题考查的是剩余工作量下降的趋势，课题数也不一定能体现各项任务的工作量差异。エ统计累计投入工时，随时间增加，不能显示还有多少工作待做。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 9
  },
  {
    "id": "FE-2026-A-13",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 13,
    "topicZh": "项目进度控制",
    "stemJa": "あるシステム開発プロジェクトの進捗が遅延したので，クリティカルパス上の作業への投入工数を増やすことによって遅延の解消を図った。このとき適用した，所要期間を短縮するための手法を何と呼ぶか。",
    "options": [
      {
        "label": "ア",
        "textJa": "クラッシング"
      },
      {
        "label": "イ",
        "textJa": "コーチング"
      },
      {
        "label": "ウ",
        "textJa": "ファストトラッキング"
      },
      {
        "label": "エ",
        "textJa": "メンタリング"
      }
    ],
    "answer": "ア",
    "explanationZh": "关键路径上的任务决定项目最短完工时间。向这些任务追加人力或其他资源，以缩短工期，叫赶工（クラッシング），选ア。ウ“快速跟进”是把原本顺序执行的工作部分并行，改变的是工作安排；本题明确说增加投入工数，属于赶工。イ“教练式辅导”和エ“导师辅导”都是人员培养方式，不是压缩进度计划的专门手法。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 9
  },
  {
    "id": "FE-2026-A-15",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 15,
    "topicZh": "系统审计",
    "stemJa": "内部監査部門が，情報システム部門に対するシステム監査を経営者から指示されたとき，システム監査人の行為として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "監査報告書に記載した改善提案に対して改善計画を策定した上で，実行する。"
      },
      {
        "label": "イ",
        "textJa": "基幹システムを開発し，保守を行っている外部事業者に，当該システム監査を委託する。"
      },
      {
        "label": "ウ",
        "textJa": "経営者がどのようなニーズを有しているかを十分に把握した上で，システム監査の目的と対象範囲を決定する。"
      },
      {
        "label": "エ",
        "textJa": "情報システム部門の在籍者を監査メンバとして選定する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "审计应先弄清委托方经营者希望解决什么问题，再据此确定审计目的和范围，所以选ウ。ア把审计报告中的改善建议变为计划并执行，是被审计部门或管理层的职责；审计人员执行自己提出的改善措施会损害后续评价的独立性。イ把审计交给开发、维护该系统的同一外部公司，存在自我审查。エ让被审计的信息系统部门人员参加审计，同样影响独立性。辨题关键是审计范围与独立性。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 10
  },
  {
    "id": "FE-2026-A-16",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 16,
    "topicZh": "零售与全渠道",
    "stemJa": "小売事業者が，オムニチャネル戦略を実現するための IT 活用事例はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "実店舗，オンライン店舗，コールセンタなど複数の顧客接点で，顧客情報や在庫情報などを一元的に管理・共有して接客することによって，顧客の利便性を高める。"
      },
      {
        "label": "イ",
        "textJa": "複数店舗からネットワークを経由して，受発注，出荷，請求，支払などの取引情報を電子的に交換することによって，卸売業者とメーカとの間の受発注業務の効率を高める。"
      },
      {
        "label": "ウ",
        "textJa": "複数店舗に設置した監視カメラの画像データを本部に集め，本部が各店舗の状況をリアルタイムに把握することによって，店舗運営業務の効率を高める。"
      },
      {
        "label": "エ",
        "textJa": "複数店舗の POS データを本部に集め，本部が日次で売れ筋商品の抽出，複数の商品の併売率の分析を行うことによって，商品計画や棚割計画を最適化する。"
      }
    ],
    "answer": "ア",
    "explanationZh": "全渠道的重点是打通实体店、网店、呼叫中心等不同顾客接点，让顾客无论从哪个渠道接触企业，都能获得衔接一致的服务。ア把顾客与库存信息统一共享，正好实现这一点。イ是企业间交易信息的电子交换，重点在供应链业务效率；ウ是门店监控与运营效率；エ是汇总 POS 数据辅助选品和陈列。后三项虽都用到 IT，但没有把顾客渠道连接成连续体验。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 11
  },
  {
    "id": "FE-2026-A-19",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 19,
    "topicZh": "创意与会议方法",
    "stemJa": "ブレーンストーミングの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "あるテーマの検討において，複数のメンバーで，各自が思いつくままに自由奔放にできるだけ多くのアイディアを出し合うことによって，創造的思考を喚起し，アイディアを開発しようとする会議方法"
      },
      {
        "label": "イ",
        "textJa": "研修を始める前に行う簡単なゲームや，商談や面接の本題に入る前に行う雑談など，参加者の緊張をほぐすためのコミュニケーション方法"
      },
      {
        "label": "ウ",
        "textJa": "情報を，決められた枠組みに従って整理・分析するスキルや方法を利用し，複雑なものごとを明快に把握したり，問題に対する解決策を導き出したりするような思考方法"
      },
      {
        "label": "エ",
        "textJa": "ポイントを繰り返したり，言い換えたりすることによって，お互いの理解する意味合いが一致していることを確認したり，意見・評価を伝えたりする方法"
      }
    ],
    "answer": "ア",
    "explanationZh": "头脑风暴是围绕主题让多人自由提出尽量多的想法，先扩大创意数量，再进一步整理和评价；ア描述的就是这种会议方法。イ是开场破冰，作用是缓解紧张；ウ是按既定框架整理、分析信息的结构化思考；エ是重复或改述对方要点以确认理解、传达反馈的沟通方法。识别头脑风暴要看“多人自由发想”和“尽量多的点子”，而非单纯有讨论或交流。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 12
  },
  {
    "id": "FE-2026-B-01",
    "kind": "official",
    "year": 2026,
    "section": "B",
    "number": 1,
    "topicZh": "数组与循环",
    "stemJa": "次のプログラム中の［ a ］に入れる正しい答えを，解答群の中から選べ。ここで，配列の要素番号は 1 から始まる。\n\n次のプログラムは，整数型の配列 data の末尾の要素の値を先頭の要素に移動する。この際，末尾以外の各要素の値は，一つずつ後ろの要素に移動する。\n\n〔プログラム〕\n整数型の配列: data ← {1, 2, 3, 4, 5, 6, 7, 8, 9}\n整数型: top, i\n整数型: len ← dataの要素数\ntop ← data[len]\nfor (i を［ a ］)\n    data[i] ← data[i － 1]\nendfor\ndata[1] ← top",
    "options": [
      {
        "label": "ア",
        "textJa": "2 から len － 1 まで 1 ずつ増やす"
      },
      {
        "label": "イ",
        "textJa": "2 から len まで 1 ずつ増やす"
      },
      {
        "label": "ウ",
        "textJa": "len － 1 から 2 まで 1 ずつ減らす"
      },
      {
        "label": "エ",
        "textJa": "len から 2 まで 1 ずつ減らす"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。先把原末尾9保存到top，再从i=len倒数到2，依次执行data[i]←data[i－1]，最后令data[1]←top。这样结果是{9,1,2,3,4,5,6,7,8}。若按ア或イ从左往右移动，刚写入的值会被后续步骤反复复制，覆盖原值；ウ虽从右往左，但从len－1开始，最后一个位置没有被更新。题目规定下标从1开始，因此循环终点必须是2。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_b_ans.pdf",
    "page": 4,
    "transcriptionNoteZh": "原 PDF 的方框空栏在文字版中以［ a ］标记；请用下方原题链接核对版式。"
  },
  {
    "id": "FE-2026-B-02",
    "kind": "official",
    "year": 2026,
    "section": "B",
    "number": 2,
    "topicZh": "位运算与补码",
    "stemJa": "次のプログラム中の［ a ］に入れる正しい答えを，解答群の中から選べ。\n\n関数 complement は，引数として渡された 8 ビット型の値 x について，x に加算すると 00000000 になる値を返す。8 ビット型の加算は，値を符号なし 2 進数とみなしたときの加算とし，桁あふれが発生したときのあふれた桁は無視する。演算子∧，∨，▽は，それぞれビット単位の論理積，論理和，排他的論理和を表す。\n\n〔プログラム〕\n○8ビット型: complement(8ビット型: x)\n    8ビット型: y\n    y ← ［ a ］\n    y ← y ＋ 00000001\n    return y",
    "options": [
      {
        "label": "ア",
        "textJa": "x ∧ 01111111"
      },
      {
        "label": "イ",
        "textJa": "x ∧ 11111111"
      },
      {
        "label": "ウ",
        "textJa": "x ∨ 01111111"
      },
      {
        "label": "エ",
        "textJa": "x ∨ 11111111"
      },
      {
        "label": "オ",
        "textJa": "x ▽ 01111111"
      },
      {
        "label": "カ",
        "textJa": "x ▽ 11111111"
      }
    ],
    "answer": "カ",
    "explanationZh": "正确答案是カ。8位加法丢弃第9位进位，要求x＋返回值≡0（模256），所以返回值是－x的8位表示。求法是先把x的每一位取反，再加1；与11111111逐位异或恰好能逐位取反，因此选カ。ア仅清掉最高位，イ保持原值；ウ把低7位置1，エ把全部位置1；オ只翻转低7位、保留最高位，都不能对所有x得到所需的负数。例：x=00000001，取反加1得11111111，与x相加后只剩被丢弃的第9位。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_b_ans.pdf",
    "page": 5,
    "transcriptionNoteZh": "原 PDF 的方框空栏在文字版中以［ a ］标记；请用下方原题链接核对版式。"
  },
  {
    "id": "FE-2026-B-03",
    "kind": "official",
    "year": 2026,
    "section": "B",
    "number": 3,
    "topicZh": "递归与动态规划",
    "stemJa": "次のプログラム中の［ a ］に入れる正しい答えを，解答群の中から選べ。ここで，配列の要素番号は 1 から始まる。\n\n関数 func1 に与える引数と，関数 func2 に与える引数とが同じとき，二つの関数は同じ値を返す。プログラムでは，配列の領域外を参照してはならないものとする。\n\n〔プログラム〕\n○整数型: func1(整数型: n)\n    if (nが2以下)\n        return 1\n    endif\n    return 2 × func1(n － 2) ＋ func1(n － 1)\n○整数型: func2(整数型: n)\n    整数型の配列: data ← {1, 1, 1}\n    整数型: i\n    /* nが3より小さいときは繰返し処理を実行しない */\n    for (iを3からnまで1ずつ増やす)\n        data[1] ← data[2]\n        data[2] ← data[3]\n        data[3] ← ［ a ］\n    endfor\n    return data[3]",
    "options": [
      {
        "label": "ア",
        "textJa": "2 × data[1] ＋ data[2]"
      },
      {
        "label": "イ",
        "textJa": "2 × data[2] ＋ data[1]"
      },
      {
        "label": "ウ",
        "textJa": "2 × data[i － 1] ＋ data[i － 2]"
      },
      {
        "label": "エ",
        "textJa": "2 × data[i － 2] ＋ data[i － 1]"
      },
      {
        "label": "オ",
        "textJa": "data[3] ＋ 2 × data[1] ＋ data[2]"
      },
      {
        "label": "カ",
        "textJa": "data[3] ＋ 2 × data[2] ＋ data[1]"
      },
      {
        "label": "キ",
        "textJa": "data[3] ＋ 2 × data[i － 1] ＋ data[i － 2]"
      },
      {
        "label": "ク",
        "textJa": "data[3] ＋ 2 × data[i － 2] ＋ data[i － 1]"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。递归式为f(n)=2f(n－2)＋f(n－1)。在循环中，先执行data[1]←data[2]、data[2]←data[3]，此时data[1]保存上一轮的f(n－2)，data[2]保存f(n－1)，应写入2×data[1]＋data[2]。例如i=3时三项是1、1、1，得到f(3)=3；i=4时数组变为1、3、3，得到f(4)=2×1＋3=5。イ交换了两个系数；オ、カ多加了旧data[3]；ウ、エ、キ、ク用循环变量作数组下标，i较大时会访问只有3个元素的数组之外。",
    "transcriptionNoteZh": "原卷空栏以方框标示；纯文本中用［ a ］表示。保留了伪代码的逐行顺序和缩进。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_b_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2025-A-01",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 1,
    "topicZh": "人工智能与模型微调",
    "stemJa": "大規模言語モデルを用いた自然言語処理において，事前学習済みのモデルに対して行う，ファインチューニングに関する記述として，最も適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "強化学習を行い，最適な結果が得られるようにする。"
      },
      {
        "label": "イ",
        "textJa": "事前学習と同じデータを繰り返し用いて学習を行い，モデルの精度を高めるようにする。"
      },
      {
        "label": "ウ",
        "textJa": "大量のテキストデータを用いて学習を行い，モデルの精度を高めるようにする。"
      },
      {
        "label": "エ",
        "textJa": "特定のデータを用いて追加で学習を行い，目的とするタスクに適用できるようにする。"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。微调的起点是已经完成预训练的模型，再用面向特定任务的数据继续训练，使模型适应该任务。ア只说采用强化学习：强化学习可以用于某些训练阶段，但它并不是这里所问的微调定义。イ只是重复预训练数据，没有体现面向目标任务的适配。ウ描述用大量文本建立通用能力，更接近预训练。抓住“先有预训练模型，再用特定数据追加训练”即可判断。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 2
  },
  {
    "id": "FE-2025-A-02",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 2,
    "topicZh": "浮点数与误差",
    "stemJa": "浮動小数点形式で表現された数値の演算結果における丸め誤差の説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "演算結果がコンピュータの扱える最大値を超えることによって生じる誤差である。"
      },
      {
        "label": "イ",
        "textJa": "数表現のけた数に限度があるので，最下位けたより小さい部分について四捨五入や切上げ，切捨てを行うことによって生じる誤差である。"
      },
      {
        "label": "ウ",
        "textJa": "乗除算において，指数部が小さい方の数値の仮数部の下位部分が失われることによって生じる誤差である。"
      },
      {
        "label": "エ",
        "textJa": "絶対値がほぼ等しい数値の加減算において，上位の有効数字が失われることによって生じる誤差である。"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。浮点数可保存的有效位数有限，结果多出的低位需要四舍五入、向上舍入或截断，由此产生的差就是舍入误差。ア指结果超过表示上限，属于溢出。ウ把指数对齐造成低位丢失的现象放到了乘除法中；指数对齐主要出现在浮点加减法，而且这不是本题所描述的舍入定义。エ描述绝对值接近的数进行有效相减时，高位有效数字相互抵消的“消去误差（桁落ち）”；同号相减和异号相加都可能发生。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 2
  },
  {
    "id": "FE-2025-A-04",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 4,
    "topicZh": "系统可靠性与可用率",
    "stemJa": "MTBF は 4,000 時間，MTTR は 1,000 時間の装置がある。今後の 6 年間は，予防保守によって MTBF を前年に比べて毎年 100 時間ずつ改善し，遠隔保守によって MTTR を前年に比べて毎年 100 時間ずつ改善していく計画である。6 年経過後の稼働率は幾らか。",
    "options": [
      {
        "label": "ア",
        "textJa": "0.88"
      },
      {
        "label": "イ",
        "textJa": "0.90"
      },
      {
        "label": "ウ",
        "textJa": "0.92"
      },
      {
        "label": "エ",
        "textJa": "0.94"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。稼働率（可用率）＝MTBF÷（MTBF＋MTTR）。6 年后，平均故障间隔 MTBF 为 4,000＋6×100＝4,600 小时；平均修复时间 MTTR 为 1,000－6×100＝400 小时。因此可用率＝4,600÷（4,600＋400）＝0.92。其余三个数值都与代入后的计算结果不符。易错点是只调整其中一个指标，或把 MTTR 的改善误作增加。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 3
  },
  {
    "id": "FE-2025-A-05",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 5,
    "topicZh": "低代码开发",
    "stemJa": "ローコード開発ツールを用いたソフトウェア開発の説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "アプリケーションソフトウェアの開発基盤の上で，用意された部品やテンプレートを GUI を用いた操作で組み合わせたり，必要に応じて一部の処理のソースコードを記述したりすることによって，アプリケーションソフトウェアを作成する。"
      },
      {
        "label": "イ",
        "textJa": "アプリケーションソフトウェアの開発基盤の上で，用意された部品やテンプレートを GUI を用いた操作で組み合わせるだけで，ソースコードを記述せずに，アプリケーションソフトウェアを作成する。"
      },
      {
        "label": "ウ",
        "textJa": "アプリケーションソフトウェアの定型的な枠組みを参照して，独自の処理のソースコードを記述することによって，アプリケーションソフトウェアを作成する。"
      },
      {
        "label": "エ",
        "textJa": "利用者がシステムを利用して行う作業を自動化ツールに代行させるために，利用者によるシステムの操作手順をツールに登録する。"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。低代码开发用可视化组件和模板完成大部分工作，但仍允许在需要时编写少量源代码。イ强调完全不写代码，描述的是无代码开发。ウ依靠框架再自行编写处理逻辑，仍以代码开发为中心。エ是将用户操作步骤交给工具执行的 RPA 思路，解决的是操作自动化，而不是这种应用开发方式。关键词是“GUI 组合”加“必要时写一部分代码”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 4
  },
  {
    "id": "FE-2025-A-08",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 8,
    "topicZh": "HTTPS 与服务器证书",
    "stemJa": "HTTP と HTTPS を比較した場合において，HTTPS だけがもつ特徴を示したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "cookie に保存されている情報を用いたセッション管理が可能である。"
      },
      {
        "label": "イ",
        "textJa": "ID とパスワードによって利用者の認証を行うことが可能である。"
      },
      {
        "label": "ウ",
        "textJa": "Web ブラウザでキャッシュさせることによって通信量を減らすことが可能である。"
      },
      {
        "label": "エ",
        "textJa": "通信相手先サーバをサーバ証明書によって確認することが可能である。"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。HTTPS 在 HTTP 通信中使用 TLS，连接时可检查服务器提供的证书，用于确认所连接服务器的身份。ア的 Cookie 会话管理、イ的账号密码登录、ウ的浏览器缓存，在普通 HTTP 上也能实现，因此不构成 HTTPS 独有特征。注意服务器证书验证的是通信对端身份；不要把它与网站上的用户登录混为一谈。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2025-A-09",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 9,
    "topicZh": "密码技术的危殆化",
    "stemJa": "暗号の危殆化に該当するものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "ある CA でデジタル証明書の署名に使っている公開鍵のデジタル証明書の有効期限が切れた。"
      },
      {
        "label": "イ",
        "textJa": "ある暗号アルゴリズムの秘密鍵が不正アクセスによって漏えいした。"
      },
      {
        "label": "ウ",
        "textJa": "あるハッシュ関数においてハッシュ値が同じになるデータの組みを現実的な時間内で発見する方法が見つかった。"
      },
      {
        "label": "エ",
        "textJa": "あるランサムウェアの一種で暗号化されたファイルの復号鍵が公開された。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。“危殆化”指密码算法原本依赖的安全性变得不足。若能在现实可行的时间内找到同一哈希值对应的不同数据，抗碰撞这一安全性质就被破坏，因此属于哈希算法的危殆化。ア是证书到期，属于证书有效期管理。イ是某把秘密密钥泄漏，问题发生在密钥保管。エ是特定勒索软件所用文件解密密钥公开，不能据此认定密码算法本身已不安全。判断时要区分“算法被攻破”和“证书、密钥出了问题”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2025-A-10",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 10,
    "topicZh": "WAF 与安全设备",
    "stemJa": "WAF の説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "Web サイトに対するアクセス内容を監視し，攻撃とみなされるパターンを検知したときに当該アクセスを遮断する。"
      },
      {
        "label": "イ",
        "textJa": "Wi-Fi アライアンスが認定した無線 LAN の暗号化方式の規格であり，AES 暗号に対応している。"
      },
      {
        "label": "ウ",
        "textJa": "様々なシステムの動作ログを一元的に蓄積，管理し，セキュリティ上の脅威となる事象をいち早く検知，分析する。"
      },
      {
        "label": "エ",
        "textJa": "ファイアウォール機能を有し，マルウェア対策機能，侵入検知機能などの複数のセキュリティ機能を連携させ，統合的に管理する。"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。WAF（Web 应用防火墙）检查访问 Web 站点的请求内容，识别攻击模式并拦截可疑访问。イ说的是无线 LAN 加密标准，不是 Web 防护。ウ描述集中收集并分析多系统日志的 SIEM。エ描述将防火墙、恶意软件防护、入侵检测等功能整合的 UTM。区分方法是看防护对象：WAF 重点检查进入 Web 应用的访问内容。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2025-A-11",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 11,
    "topicZh": "E-R 模型",
    "stemJa": "E-R モデルにおけるエンティティの特徴はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "エンティティとインスタンスとは，1 対 1 の対応関係をとる。"
      },
      {
        "label": "イ",
        "textJa": "エンティティとなり得るものは，物的に実現するものである。"
      },
      {
        "label": "ウ",
        "textJa": "エンティティは，特性を表すための属性（アトリビュート）をもつ。"
      },
      {
        "label": "エ",
        "textJa": "異なった種類のエンティティ間の関係は，主として状態遷移として表現される。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。E-R 模型中的实体具有描述其特征的属性，例如“商品”实体可有商品 ID 和名称。ア错在一个实体类型通常对应多个具体实例，而不是固定一对一。イ错在实体也可以是订单、交易等抽象的业务对象，不要求有实体形态。エ错在不同实体间用“关系”表示联系，例如顾客下订单；状态转移不是 E-R 模型表达实体关系的主要方式。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 7
  },
  {
    "id": "FE-2025-A-12",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 12,
    "topicZh": "面向对象与多态",
    "stemJa": "オブジェクト指向プログラミングの特徴のうち，異なるクラスのオブジェクトを同一のインタフェースで操作したときに，操作対象クラスに応じた異なる動作を可能にすることを何と呼ぶか。",
    "options": [
      {
        "label": "ア",
        "textJa": "委譲"
      },
      {
        "label": "イ",
        "textJa": "継承"
      },
      {
        "label": "ウ",
        "textJa": "コンポジション"
      },
      {
        "label": "エ",
        "textJa": "多相性"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ，即多态性：调用同一接口时，实际执行的处理会随对象所属的类而变化。例如对不同图形调用同一个“绘制”操作，各自完成不同绘制。ア“委譲”是把处理交给另一个对象；イ“継承”是子类沿用或扩展父类性质；ウ“コンポジション”是通过包含其他对象来组合功能。题眼是“同一接口”和“按对象类型表现出不同动作”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 7
  },
  {
    "id": "FE-2025-A-13",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 13,
    "topicZh": "Scrum 与产品待办列表",
    "stemJa": "アジャイル開発手法の一つであるスクラムにおいて，プロダクトバックログアイテムの内容や並び順を決定する役割をもつのは誰か。",
    "options": [
      {
        "label": "ア",
        "textJa": "開発者"
      },
      {
        "label": "イ",
        "textJa": "顧客"
      },
      {
        "label": "ウ",
        "textJa": "スクラムマスタ"
      },
      {
        "label": "エ",
        "textJa": "プロダクトオーナ"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。产品负责人（プロダクトオーナ）对产品待办列表负责，决定待办事项的内容和排序，使团队优先完成更有价值的工作。ア开发者负责实施并规划具体开发工作，但不承担题中这项产品待办列表责任。イ客户可提供需求与反馈，却不是 Scrum 在此处指定的角色。ウ Scrum Master 帮助团队理解并实践 Scrum，也不负责决定待办事项的内容和顺序。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 7
  },
  {
    "id": "FE-2025-A-16",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 16,
    "topicZh": "数据挖掘与购物篮分析",
    "stemJa": "データマイニングの手法の一つであって，POS などの蓄積データから“一緒に買われる商品”の組合せを発見する分析手法はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "3C 分析"
      },
      {
        "label": "イ",
        "textJa": "ABC 分析"
      },
      {
        "label": "ウ",
        "textJa": "コンジョイント分析"
      },
      {
        "label": "エ",
        "textJa": "マーケットバスケット分析"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。“一起购买”的商品组合对应购物篮分析：以交易记录为单位，寻找哪些商品经常共同出现在同一次购买中。ア的 3C 分析从顾客、竞争者和自身企业三个角度分析经营环境。イ的 ABC 分析按销售额、库存价值等贡献度给项目分级。ウ的联合分析研究商品属性组合对消费者选择的影响。题目特别给出 POS 积累数据和“同时购买”，直接指向购物篮分析。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 9
  },
  {
    "id": "FE-2025-A-17",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 17,
    "topicZh": "生成式 AI 与退出训练",
    "stemJa": "インターネット上の生成 AI サービスを利用する際に，オプトアウトを設定することはどのような場合に有効か。",
    "options": [
      {
        "label": "ア",
        "textJa": "個々の利用者が，自身が生成 AI から得た情報に対して，著作権を主張したい場合"
      },
      {
        "label": "イ",
        "textJa": "個々の利用者が入力した情報を，生成 AI の学習に利用させたくない場合"
      },
      {
        "label": "ウ",
        "textJa": "個々の利用者が入力した情報を，生成 AI を通じて，他の利用者にも知ってほしい場合"
      },
      {
        "label": "エ",
        "textJa": "生成 AI から得た情報の信ぴょう性を高めたい場合"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。题中的“オプトアウト”指用户明确选择退出某种数据使用；在生成 AI 服务的这个语境中，是不希望自己输入的信息被用于模型学习。ア涉及生成内容的著作权归属，退出数据使用不能决定著作权。ウ希望信息传播，与退出训练用途的方向相反。エ涉及输出事实是否可靠，退出设置不会提高答案可信度。实际使用服务时还应查看其设置说明，确认退出选项涵盖哪些数据用途。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 9
  },
  {
    "id": "FE-2025-B-02",
    "kind": "official",
    "year": 2025,
    "section": "B",
    "number": 2,
    "topicZh": "枚举与循环边界",
    "stemJa": "次のプログラム中の［ a ］に入れる正しい答えを，解答群の中から選べ。\n\n関数 change は，10 より大きい整数を引数 n で受け取り，1 円玉，5 円玉，10 円玉を使ってちょうど n 円にする組合せの総数を返す。\n\n例えば，12 円にする組合せは，次のように数えられる。10 円玉を使わない場合には，1 円玉と 5 円玉だけでちょうど 12 円にすることになる。その組合せは，使える 5 円玉の枚数が 0 以上 (12 ÷ 5 の商) 以下なので，(12 ÷ 5 の商) ＋ 1 ＝ 3 通りある。同様に，10 円玉を 1 枚使う場合には，1 円玉と 5 円玉だけでちょうど 2 円にすることになり，その組合せは (2 ÷ 5 の商) ＋ 1 ＝ 1 通りある。10 円玉を 2 枚以上使う組合せはない。よって，1 円玉，5 円玉，10 円玉を使ってちょうど 12 円にする組合せは，3 ＋ 1 ＝ 4 通りである。\n\n〔プログラム〕\n○整数型: change(整数型: n)\n    整数型: count ← 0\n    整数型: rest ← n\n    while (［ a ］)\n        count ← count ＋ (rest ÷ 5 の商) ＋ 1\n        rest ← rest － 10\n    endwhile\n    return count",
    "options": [
      {
        "label": "ア",
        "textJa": "rest ≧ 0"
      },
      {
        "label": "イ",
        "textJa": "rest ≧ 5"
      },
      {
        "label": "ウ",
        "textJa": "rest ≧ 10"
      },
      {
        "label": "エ",
        "textJa": "rest ＞ 0"
      },
      {
        "label": "オ",
        "textJa": "rest ＞ 5"
      },
      {
        "label": "カ",
        "textJa": "rest ＞ 10"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。每轮固定10日元硬币的枚数，rest是剩余金额；只要rest非负，就能用0到⌊rest/5⌋枚5日元硬币，缺口由1日元硬币填满，所以本轮增加⌊rest/5⌋＋1种。rest＝0仍有一种合法方案：剩余部分不用1元和5元，因此必须包含0。イ、ウ、オ、カ会遗漏rest为0或小于阈值但仍可用1元硬币支付的情况；エ只差等号，也会漏掉rest＝0。例如n=20，10元硬币用2枚的方案会被エ遗漏。",
    "transcriptionNoteZh": "原卷空栏以方框标示；纯文本中用［ a ］表示。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_b_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2024-A-02",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 2,
    "topicZh": "哈希表",
    "stemJa": "キーが小文字のアルファベット 1 文字（a，b，…，z のいずれか）であるデータを，大きさが 10 のハッシュ表に格納する。ハッシュ関数として，アルファベットの ASCII コードを 10 進表記法で表したときの 1 の位の数を用いることにする。衝突が起こるキーの組合せはどれか。ASCII コードでは，昇順に連続した 2 進数が，アルファベット順にコードとして割り当てられている。",
    "options": [
      {
        "label": "ア",
        "textJa": "a と i"
      },
      {
        "label": "イ",
        "textJa": "b と r"
      },
      {
        "label": "ウ",
        "textJa": "c と l"
      },
      {
        "label": "エ",
        "textJa": "d と x"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。哈希值取ASCII十进制的个位，等价于对10取余。d为100，x为120，个位都是0，故碰撞。其余三组分别为a=97、i=105；b=98、r=114；c=99、l=108，个位都不同。题目已说明字母编码按顺序连续，因此也可比较两字母的序号差是否为10的倍数：d到x相差20。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 2
  },
  {
    "id": "FE-2024-A-04",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 4,
    "topicZh": "系统可用性",
    "stemJa": "あるシステムの今年度の MTBF は 3,000 時間，MTTR は 1,000 時間である。翌年度は MTBF について今年度の 20％分の改善，MTTR について今年度の 10％分の改善を図ると，翌年度の稼働率は何％になるか。",
    "options": [
      {
        "label": "ア",
        "textJa": "69"
      },
      {
        "label": "イ",
        "textJa": "73"
      },
      {
        "label": "ウ",
        "textJa": "77"
      },
      {
        "label": "エ",
        "textJa": "80"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。MTBF是平均无故障时间，改善20%后为3000×1.2＝3600小时；MTTR是平均修复时间，改善10%意味着缩短到1000×0.9＝900小时。稼働率＝MTBF／(MTBF＋MTTR)＝3600／4500＝80%。其余69%、73%、77%都不是把两个改善方向分别代入该公式的结果。特别注意修复时间改善应减少，而非增加。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 3
  },
  {
    "id": "FE-2024-A-06",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 6,
    "topicZh": "图像处理",
    "stemJa": "液晶ディスプレイなどの表示装置において，傾いた直線の境界を滑らかに表示する手法はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "アンチエイリアシング"
      },
      {
        "label": "イ",
        "textJa": "シェーディング"
      },
      {
        "label": "ウ",
        "textJa": "テクスチャマッピング"
      },
      {
        "label": "エ",
        "textJa": "バンプマッピング"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。斜线映射到有限像素网格时会出现阶梯状锯齿，抗锯齿通过平滑边缘像素的颜色或覆盖率来减轻这种现象。イ是根据光照给物体表面着色；ウ把纹理图贴到物体表面；エ用表面凹凸的视觉效果增强细节。题眼是“倾斜直线的边界变平滑”，不是物体表面的材质或光照。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 4
  },
  {
    "id": "FE-2024-A-07",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 7,
    "topicZh": "数据库事务与原子性",
    "stemJa": "DBMS に実装すべき原子性（atomicity）を説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "同一データベースに対する同一処理は，何度実行しても結果は同じである。"
      },
      {
        "label": "イ",
        "textJa": "トランザクション完了後にハードウェア障害が発生しても，更新されたデータベースの内容は保証される。"
      },
      {
        "label": "ウ",
        "textJa": "トランザクション内の処理は，全てが実行されるか，全てが取り消されるかのいずれかである。"
      },
      {
        "label": "エ",
        "textJa": "一つのトランザクションの処理結果は，他のトランザクション処理の影響を受けない。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。原子性要求一个事务作为不可分割的整体：其中的操作要么全部成功并提交，要么失败后全部撤销，不能只完成一部分。转账时若已扣款却未入账，就违反原子性。ア说相同操作重复执行仍得到相同结果，是幂等性的描述。イ强调事务提交后即使发生硬件故障，结果也要保留，是持久性。エ强调事务彼此之间不互相干扰，是隔离性。原子性、隔离性和持久性都是 ACID 中不同的要求。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 4
  },
  {
    "id": "FE-2024-A-08",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 8,
    "topicZh": "网络连接设备与 OSI 分层",
    "stemJa": "LAN 間接続装置に関する記述のうち，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "ゲートウェイは，OSI 基本参照モデルにおける第 1 ～ 3 層だけのプロトコルを変換する。"
      },
      {
        "label": "イ",
        "textJa": "ブリッジは，IP アドレスを基にしてフレームを中継する。"
      },
      {
        "label": "ウ",
        "textJa": "リピータは，同種のセグメント間で信号を増幅することによって伝送距離を延長する。"
      },
      {
        "label": "エ",
        "textJa": "ルータは，MAC アドレスを基にしてフレームを中継する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。中继器在物理层处理信号，通过再生或放大信号延长同类网段的传输距离。ア把网关限定为只转换 OSI 第 1～3 层协议，范围错误；网关可进行更高层的协议转换。イ把网桥的判断依据写成 IP 地址，网桥在数据链路层主要依据 MAC 地址转发帧。エ则把路由器的判断依据写成 MAC 地址；路由器在网络层主要依据 IP 地址转发分组。记忆时把“网桥—MAC、路由器—IP、中继器—信号”对应起来。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2024-A-09",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 9,
    "topicZh": "渗透测试",
    "stemJa": "ペネトレーションテストに該当するものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "検査対象の実行プログラムの設計書，ソースコードに着目し，開発プロセスの各工程にセキュリティ上の問題がないかどうかをツールや目視で確認する。"
      },
      {
        "label": "イ",
        "textJa": "公開 Web サーバの各コンテンツファイルのハッシュ値を管理し，定期的に各ファイルから生成したハッシュ値と一致するかどうかを確認する。"
      },
      {
        "label": "ウ",
        "textJa": "公開 Web サーバや組織のネットワークの脆弱性を探索し，サーバに実際に侵入できるかどうかを確認する。"
      },
      {
        "label": "エ",
        "textJa": "内部ネットワークのサーバやネットワーク機器の IPFIX 情報から，各 PC の通信に異常な振る舞いがないかどうかを確認する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。渗透测试不止列出潜在漏洞，还会在授权范围内模拟攻击，验证漏洞能否造成实际入侵。ア通过设计文档与源码检查安全问题，属于开发过程或代码安全检查。イ定期比对文件哈希值，是文件完整性监测，用来发现内容被篡改。エ分析 IPFIX 网络流量信息寻找异常通信，是流量监测。区分关键是题中明确说“确认能否实际侵入”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2024-A-10",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 10,
    "topicZh": "SQL 注入防护",
    "stemJa": "SQL インジェクションの対策として，有効なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "URL を Web ページに出力するときは，“http://”や“https://”で始まる URL だけを許可する。"
      },
      {
        "label": "イ",
        "textJa": "外部からのパラメータで Web サーバ内のファイル名を直接指定しない。"
      },
      {
        "label": "ウ",
        "textJa": "スタイルシートを任意の Web サイトから取り込めるようにしない。"
      },
      {
        "label": "エ",
        "textJa": "プレースホルダを使って命令文を組み立てる。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。用占位符构造参数化SQL时，SQL结构与用户输入的值分开处理，输入中的引号和关键字不会被当成新的SQL语法执行。ア限制可输出的URL方案，偏向防止危险链接；イ避免外部参数直接指定服务器文件，偏向路径遍历风险；ウ限制外部样式表来源，都没有直接解决SQL语句被输入改写的问题。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2024-A-11",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 11,
    "topicZh": "自顶向下集成测试与桩模块",
    "stemJa": "階層構造のモジュール群から成るソフトウェアの結合テストを，上位のモジュールから行う。この場合に使用する，下位のモジュールの代替となるテスト用のモジュールはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "エミュレータ"
      },
      {
        "label": "イ",
        "textJa": "シミュレータ"
      },
      {
        "label": "ウ",
        "textJa": "スタブ"
      },
      {
        "label": "エ",
        "textJa": "ドライバ"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ，即桩模块（stub）。自顶向下集成时，先测试上层模块；尚未接入的下层模块需用一个能接收调用并返回预设结果的替身，这就是桩模块。エ“驱动模块”（driver）方向相反：自底向上测试下层模块时，用它模拟上层的调用方。ア仿真器和イ模拟器用于模拟设备、系统或其行为，并非此题专门要求的下层被调用模块替身。记忆口诀：上层先测，用桩顶住下层；下层先测，用驱动调用下层。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2024-A-12",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 12,
    "topicZh": "Scrum 每日站会",
    "stemJa": "アジャイル開発手法の一つであるスクラムで定義され，スプリントで実施するイベントのうち，毎日決まった時間に決まった場所で行い，開発チームの全員が前回からの進捗状況や今後の作業計画を共有するものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "スプリントプランニング"
      },
      {
        "label": "イ",
        "textJa": "スプリントレトロスペクティブ"
      },
      {
        "label": "ウ",
        "textJa": "スプリントレビュー"
      },
      {
        "label": "エ",
        "textJa": "デイリースクラム"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ，即每日 Scrum。题目的识别点是“在冲刺期间每天进行”，让开发团队同步进展和接下来的计划。ア冲刺计划会决定本次冲刺要完成什么以及怎样开展，通常在冲刺开始时举行。イ冲刺回顾用于检查团队协作方式并商定改进，发生在冲刺末尾。ウ冲刺评审用于查看成果并取得反馈，也不是每天举行。不要只看到“分享计划”就选计划会议，还要结合“每天”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2024-A-14",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 14,
    "topicZh": "服务设计与开发运维协作",
    "stemJa": "システムの開発部門と運用部門が別々に組織化されているとき，システム開発を伴う新規サービスの設計及び移行を円滑かつ効果的に進めるための方法のうち，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "運用テストの完了後に，開発部門がシステム仕様と運用方法を運用部門に説明する。"
      },
      {
        "label": "イ",
        "textJa": "運用テストは，開発部門の支援を受けずに，運用部門だけで実施する。"
      },
      {
        "label": "ウ",
        "textJa": "運用部門からもシステムの運用に関わる要件の抽出に積極的に参加する。"
      },
      {
        "label": "エ",
        "textJa": "開発部門は運用テストを実施して，運用マニュアルを作成し，運用部門に引き渡す。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。新服务的运维要求应在需求和设计阶段就由运维部门参与提出，例如监控、备份、故障恢复和日常操作。这样开发时才能把运行需要纳入系统，移交也更顺畅。ア等运维测试结束后才解释系统，时间过晚。イ让运维部门在没有开发支持下独自测试，无法充分解决设计和实现问题。エ由开发部门单方面测试和编写手册后移交，同样缺少运维方早期参与与实际验证。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 7
  },
  {
    "id": "FE-2024-A-15",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 15,
    "topicZh": "非结构化数据处理",
    "stemJa": "ビッグデータ分析の前段階として，非構造化データを構造化データに加工する処理を記述している事例はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "関係データベースに蓄積された大量の財務データから必要な条件に合致するデータを抽出し，利用者が扱いやすい表計算ソフトウェアデータに加工する。"
      },
      {
        "label": "イ",
        "textJa": "個人情報を含むビッグデータを更に利活用するために，特定の個人を識別することができないように匿名化加工する。"
      },
      {
        "label": "ウ",
        "textJa": "住所データ項目の中にある，“ヶ”と“が”の混在や，丁番地の表記不統一を，標準化された表記へ統一するために加工する。"
      },
      {
        "label": "エ",
        "textJa": "ソーシャルメディアの口コミを機械学習によって単語ごとに分解し，要約を作り，分析可能なデータに加工し，関係データベースに保管する。"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。社交媒体评论是自由文本，没有固定字段；把它分词、提取可分析的信息，再存入关系数据库，符合“非结构化数据转为结构化数据”。ア的起点已经是关系数据库中的财务数据，属于从结构化数据抽取并换一种展示形式。イ侧重隐去个人身份，未说明改变数据结构。ウ是在已有的地址字段内统一写法，属于数据标准化，也不是把自由文本转成结构化记录。答题先看输入是否缺少固定结构，再看输出是否形成可按字段分析的数据。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 7
  },
  {
    "id": "FE-2024-A-16",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 16,
    "topicZh": "企业核心竞争力",
    "stemJa": "コアコンピタンスを説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "経営活動における基本精神や行動指針"
      },
      {
        "label": "イ",
        "textJa": "事業戦略の遂行によって達成すべき到達目標"
      },
      {
        "label": "ウ",
        "textJa": "自社を取り巻く環境に関するビジネス上の機会と脅威"
      },
      {
        "label": "エ",
        "textJa": "他社との競争優位の源泉となる経営資源及び企業能力"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。核心竞争力是企业拥有、并能成为相对其他企业竞争优势来源的资源与能力，例如难以模仿的技术、流程或组织能力。ア说的是经营理念、价值观和行动准则。イ是战略要实现的目标，不是形成优势的能力本身。ウ是外部环境中的机会和威胁，属于环境分析的对象。题眼是“竞争优势的来源”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2024-A-17",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 17,
    "topicZh": "蓝海战略",
    "stemJa": "マーケティング戦略におけるブルーオーシャンの説明として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "競争が存在していない未知の市場"
      },
      {
        "label": "イ",
        "textJa": "コモディティ化が進んだ既存の市場"
      },
      {
        "label": "ウ",
        "textJa": "新事業のアイディアを実際のビジネスに育成するまでの期間"
      },
      {
        "label": "エ",
        "textJa": "製品開発したものを市場化する過程に横たわっている障壁"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。蓝海指竞争尚不存在、可通过创造新需求开拓的未知市场空间。イ是已有商品趋同、竞争激烈的现有市场，更接近“红海”。ウ说的是从新业务构想到培育为实际业务的时期，不是市场竞争状态。エ说的是研发成果走向市场时遇到的障碍，也不是蓝海定义。注意“蓝海”描述的是市场竞争空间，而不是项目所处阶段。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2024-A-18",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 18,
    "topicZh": "HR Tech 与人事数字化",
    "stemJa": "HR テックの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "ICT を活用して，住宅内のエネルギー使用状況の監視，機器の遠隔操作や自動制御などを可能にし，家庭におけるエネルギー管理を支援するソリューション"
      },
      {
        "label": "イ",
        "textJa": "既存のビジネスモデルによる業界秩序や既得権益を破壊してしまうほど大きな影響を与える新しい ICT やビジネスモデル"
      },
      {
        "label": "ウ",
        "textJa": "個人の資金に関わる情報を統合的に管理するサービスやマーケットプレイス・レンディングなどの金融サービスを実現するための新しい情報技術"
      },
      {
        "label": "エ",
        "textJa": "採用，育成，評価，配属などの人事領域の業務を対象に，ビッグデータ解析や AI などの最新 ICT を活用して，業務改善と社員満足度向上を図るソリューション"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。HR 是 Human Resources（人力资源）；HR Tech 把数据分析、AI 等技术用于招聘、培养、评价、岗位安排等人事工作。ア描述家庭能源管理系统 HEMS。イ描述颠覆既有行业格局的创新技术或商业模式。ウ涉及个人财务信息和金融服务，是金融科技 FinTech。识别这类题先看技术服务的业务领域：人事领域才对应 HR Tech。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2024-B-01",
    "kind": "official",
    "year": 2024,
    "section": "B",
    "number": 1,
    "topicZh": "条件分支",
    "stemJa": "次のプログラム中の［ a ］に入れる正しい答えを，解答群の中から選べ。\n\n関数 maximum は，異なる三つの整数を引数で受け取り，そのうちの最大値を返す。\n\n〔プログラム〕\n○整数型: maximum(整数型: x, 整数型: y, 整数型: z)\n    if (［ a ］)\n        return x\n    elseif (y ＞ z)\n        return y\n    else\n        return z\n    endif",
    "options": [
      {
        "label": "ア",
        "textJa": "x ＞ y"
      },
      {
        "label": "イ",
        "textJa": "x ＞ y and x ＞ z"
      },
      {
        "label": "ウ",
        "textJa": "x ＞ y and y ＞ z"
      },
      {
        "label": "エ",
        "textJa": "x ＞ z"
      },
      {
        "label": "オ",
        "textJa": "x ＞ z and z ＞ y"
      },
      {
        "label": "カ",
        "textJa": "z ＞ y"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案是イ。第一分支一旦成立就直接返回x，因此条件必须保证x同时大于y和z。若条件不成立，剩下的分支用y＞z在y与z之间择大，刚好得到三者最大值。ア、エ只比较一对，可能在第三个数更大时误返x；ウ要求y＞z过严，例如x=9、y=1、z=5时会错返z；オ只覆盖x＞z＞y一种顺序，过严；カ仅比较z与y，无法保证返回x时x为最大。",
    "transcriptionNoteZh": "原卷空栏以方框标示；纯文本中用［ a ］表示。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_b_ans.pdf",
    "page": 4
  },
  {
    "id": "FE-2024-B-02",
    "kind": "official",
    "year": 2024,
    "section": "B",
    "number": 2,
    "topicZh": "二进制转换",
    "stemJa": "次のプログラム中の［ a ］に入れる正しい答えを，解答群の中から選べ。\n\n関数 convDecimal は，引数として与えられた，“0”と“1”だけから成る，1 文字以上の文字列を，符号なしの 2 進数と解釈したときの整数値を返す。例えば，引数として“10010”を与えると 18 が返る。\n\n関数 convDecimal が利用する関数 int は，引数で与えられた文字が“0”なら整数値 0 を返し，“1”なら整数値 1 を返す。\n\n〔プログラム〕\n○整数型: convDecimal(文字列型: binary)\n    整数型: i, length, result ← 0\n    length ← binaryの文字数\n    for (i を 1 から length まで 1 ずつ増やす)\n        result ← ［ a ］\n    endfor\n    return result",
    "options": [
      {
        "label": "ア",
        "textJa": "result ＋ int(binary の (length － i ＋ 1)文字目の文字)"
      },
      {
        "label": "イ",
        "textJa": "result ＋ int(binary の i文字目の文字)"
      },
      {
        "label": "ウ",
        "textJa": "result × 2 ＋ int(binary の (length － i ＋ 1)文字目の文字)"
      },
      {
        "label": "エ",
        "textJa": "result × 2 ＋ int(binary の i文字目の文字)"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。按字符串从左到右扫描，每读入一位，新数值＝旧数值×2＋当前位：左移一位相当于乘2。以10010为例，result依次为1、2、4、9、18。ア、イ只相加会得到1的个数，丢失位权；ウ虽乘2却从右往左读取，会把位序颠倒，例如10010会得到01001₂＝9。题目的循环i从1递增，所以应读取第i个字符。",
    "transcriptionNoteZh": "原卷空栏以方框标示；纯文本中用［ a ］表示。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_b_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2023-A-01",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 1,
    "topicZh": "进制转换",
    "stemJa": "16 進小数 0.C を 10 進小数に変換したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "0.12"
      },
      {
        "label": "イ",
        "textJa": "0.55"
      },
      {
        "label": "ウ",
        "textJa": "0.75"
      },
      {
        "label": "エ",
        "textJa": "0.84"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案是ウ。十六进制小数点后第一位的位权是16⁻¹，即1/16；C代表十进制12，因此0.C₁₆＝12/16＝0.75₁₀。ア、イ、エ的数值分别是0.12、0.55、0.84，都不等于12/16。遇到多位十六进制小数时，依次乘以16⁻¹、16⁻²等位权后相加。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 2
  },
  {
    "id": "FE-2023-A-03",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 3,
    "topicZh": "存储器与性能",
    "stemJa": "コンピュータの高速化技術の一つであるメモリインタリーブに関する記述として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "主記憶と入出力装置，又は主記憶同士のデータの受渡しを CPU 経由でなく直接やり取りする方式"
      },
      {
        "label": "イ",
        "textJa": "主記憶にデータを送り出す際に，データをキャッシュに書き込み，キャッシュがあふれたときに主記憶へ書き込む方式"
      },
      {
        "label": "ウ",
        "textJa": "主記憶のデータの一部をキャッシュにコピーすることによって，レジスタと主記憶とのアクセス速度の差を縮める方式"
      },
      {
        "label": "エ",
        "textJa": "主記憶を複数の独立して動作するグループに分けて，各グループに並列にアクセスする方式"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。内存交叉存取把主存分成可独立工作的多个存储体，使相邻访问可分散到不同存储体并行处理，从而提高吞吐量。ア描述绕过CPU的数据直接传送，属于DMA一类；イ讲的是缓存写入策略，并不是内存交叉存取；ウ讲的是用缓存缩小速度差。辨认关键词是“主存分组”和“并行访问”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 3
  },
  {
    "id": "FE-2023-A-04",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 4,
    "topicZh": "边缘计算",
    "stemJa": "エッジコンピューティングの説明として，最も適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "画面生成やデータ処理をクライアント側で実行することによって，Web アプリケーションソフトウェアの操作性や表現力を高めること"
      },
      {
        "label": "イ",
        "textJa": "データが送信されてきたときだけ必要なサーバを立ち上げて，処理が終わり次第サーバを停止してリソースを解放すること"
      },
      {
        "label": "ウ",
        "textJa": "複数のサーバや PC を仮想化して統合することによって一つの高性能なコンピュータを作り上げ，並列処理によって処理能力を高めること"
      },
      {
        "label": "エ",
        "textJa": "利用者や機器に取り付けられたセンサなどのデータ発生源に近い場所にあるサーバなどでデータを一次処理し，処理のリアルタイム性を高めること"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。边缘计算在传感器、设备或用户附近先处理数据，减少送往远端再返回的传输延迟，有利于实时响应。ア强调的是浏览器或客户端执行界面处理；イ是按请求启停计算资源的方式；ウ是把多台机器整合并行计算。看到“靠近数据源处理”才应联想到边缘计算。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 3
  },
  {
    "id": "FE-2023-A-05",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 5,
    "topicZh": "计算机图形学",
    "stemJa": "3 次元グラフィックス処理におけるクリッピングの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "CG 映像作成における最終段階として，物体のデータをディスプレイに描画できるように映像化する処理である。"
      },
      {
        "label": "イ",
        "textJa": "画像表示領域にウィンドウを定義し，ウィンドウの外側を除去し，内側の見える部分だけを取り出す処理である。"
      },
      {
        "label": "ウ",
        "textJa": "スクリーンの画素数が有限であるために図形の境界近くに生じる，階段状のギザギザを目立たなくする処理である。"
      },
      {
        "label": "エ",
        "textJa": "立体感を生じさせるために，物体の表面に陰影を付ける処理である。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案是イ。裁剪（clipping）依据可见窗口或显示区域，去掉边界之外的图形部分，仅保留可见部分。ア描述把图形数据变成可显示图像的绘制过程；ウ是减轻锯齿的抗锯齿处理；エ是通过明暗表现立体感的着色。区分这些术语时先问：处理对象是“显示范围”、像素边缘，还是表面光照。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 4
  },
  {
    "id": "FE-2023-A-06",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 6,
    "topicZh": "数据库函数依赖",
    "stemJa": "次の関数従属を満足するとき，成立する推移的関数従属はどれか。ここで，“A→B”は B が A に関数従属していることを表し，“A→｛B，C｝”は，“A→B”かつ“A→C”が成立することを表す。\n〔関数従属〕\n｛注文コード，商品コード｝→｛顧客注文数量，注文金額｝\n注文コード →｛注文日，顧客コード，注文担当者コード｝\n商品コード →｛商品名，仕入先コード，商品販売価格｝\n仕入先コード →｛仕入先名，仕入先住所，仕入担当者コード｝\n顧客コード →｛顧客名，顧客住所｝",
    "options": [
      {
        "label": "ア",
        "textJa": "仕入先コード → 仕入担当者コード → 仕入先住所"
      },
      {
        "label": "イ",
        "textJa": "商品コード → 仕入先コード → 商品販売価格"
      },
      {
        "label": "ウ",
        "textJa": "注文コード → 顧客コード → 顧客住所"
      },
      {
        "label": "エ",
        "textJa": "注文コード → 商品コード → 顧客注文数量"
      }
    ],
    "answer": "ウ",
    "explanationZh": "传递函数依赖要有两段都成立：若 A 决定 B，且 B 决定 C，就可由 A 经 B 决定 C。已知“注文コード → 顧客コード”，又知“顧客コード → 顧客住所”，因此“注文コード → 顧客コード → 顧客住所”成立，选ウ。ア虽有供应商代码决定采购负责人代码，却没有“采购负责人代码决定供应商地址”；イ没有“供应商代码决定商品销售价格”；エ没有“订单代码决定商品代码”，且顾客订购数量由订单代码与商品代码的组合决定。不能把箭头方向或组合键随意拆开。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 4
  },
  {
    "id": "FE-2023-A-07",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 7,
    "topicZh": "数据库事务",
    "stemJa": "トランザクションが，データベースに対する更新処理を完全に行うか，全く処理しなかったかのように取り消すか，のどちらかの結果になることを保証する特性はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "一貫性（consistency）"
      },
      {
        "label": "イ",
        "textJa": "原子性（atomicity）"
      },
      {
        "label": "ウ",
        "textJa": "耐久性（durability）"
      },
      {
        "label": "エ",
        "textJa": "独立性（isolation）"
      }
    ],
    "answer": "イ",
    "explanationZh": "题干说一组更新只能“全部完成”或“全部取消”，不允许只执行一部分。这是事务的原子性，选イ，可用银行转账作例子：扣款与入账必须作为一个整体。ア一致性是事务前后数据库满足约束，不是描述整组操作能否拆分；ウ持久性是事务提交后结果即使发生故障也应保留；エ隔离性是并发事务之间不应互相干扰。四者合称 ACID，关键词“全做或全不做”只对应原子性。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2023-A-08",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 8,
    "topicZh": "网络诊断",
    "stemJa": "IPv4 ネットワークにおいて，ネットワークの疎通確認に使われるものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "BOOTP"
      },
      {
        "label": "イ",
        "textJa": "DHCP"
      },
      {
        "label": "ウ",
        "textJa": "MIB"
      },
      {
        "label": "エ",
        "textJa": "ping"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。ping发送ICMP Echo Request并等待Echo Reply，可快速检查目标主机是否可达及往返时间。BOOTP和DHCP用于获取IP等网络配置，MIB是网络管理信息库，都不用于主动验证两台主机的连通。注意ping失败只能说明没有收到响应，也可能是ICMP被过滤，不能单凭它断定目标完全离线。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2023-A-12",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 12,
    "topicZh": "敏捷开发 Scrum",
    "stemJa": "アジャイル開発手法のスクラムにおいて，開発チームの全員が 1 人ずつ“昨日やったこと”，“今日やること”，“障害になっていること”などを話し，全員でプロジェクトの状況を共有するイベントはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "スプリントプランニング"
      },
      {
        "label": "イ",
        "textJa": "スプリントレビュー"
      },
      {
        "label": "ウ",
        "textJa": "デイリースクラム"
      },
      {
        "label": "エ",
        "textJa": "レトロスペクティブ"
      }
    ],
    "answer": "ウ",
    "explanationZh": "团队每天简短同步昨天完成什么、今天打算做什么、遇到什么阻碍，是每日 Scrum，选ウ。它帮助成员了解进展并及时发现协作障碍。ア“冲刺计划”是在冲刺开始时决定目标和要做的工作；イ“冲刺评审”是在冲刺结束时展示并检查产出；エ“回顾”是在冲刺结束后检视工作方式、决定如何改进。判断依据是题干的每日同步内容与频率，而非只看有没有团队会议。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 7
  },
  {
    "id": "FE-2023-A-14",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 14,
    "topicZh": "远程办公安全审计",
    "stemJa": "A 社では，従業員が自宅の PC からインターネット経由で自社のネットワークに接続して仕事を行うテレワーキングの実施を計画している。A 社が定めたテレワーキング運用規程について，情報セキュリティ管理基準（平成 28 年）に従って監査を実施した。判明した事項のうち，監査人が，指摘事項として監査報告書に記載すべきものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "テレワーキング運用規程に従うことを条件に，全ての従業員が利用できる。"
      },
      {
        "label": "イ",
        "textJa": "テレワーキングで従業員が使用する PC は，A 社から支給されたものに限定する。"
      },
      {
        "label": "ウ",
        "textJa": "テレワーキングで使用する PC へのマルウェア対策ソフト導入の要不要は，従業員それぞれが判断する。"
      },
      {
        "label": "エ",
        "textJa": "テレワーキングで使用する PC を，従業員の家族に使用させない。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "远程办公设备会连接企业网络，恶意软件防护应由组织统一规定并落实。ウ把是否安装防恶意软件交给每位员工自行决定，会造成保护水平不一致和可避免的感染风险，因此是审计应指出的问题。ア是在遵守统一规程的条件下开放使用，本身不是所问的缺陷；イ把设备限定为公司配发，便于统一管理；エ禁止家人共用工作设备，有助于减少未经授权的使用和信息泄露。审计看的是控制是否有明确、一致的要求。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2023-A-15",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 15,
    "topicZh": "云计算",
    "stemJa": "ハイブリッドクラウドの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "クラウドサービスが提供している機能の一部を，自社用にカスタマイズして利用すること"
      },
      {
        "label": "イ",
        "textJa": "クラウドサービスのサービス内容を，消費者向けと法人向けの両方を対象とするように構成して提供すること"
      },
      {
        "label": "ウ",
        "textJa": "クラウドサービスのサービス内容を，有償サービスと無償サービスとに区分して提供すること"
      },
      {
        "label": "エ",
        "textJa": "自社専用に使用するクラウドサービスと，汎用のクラウドサービスとの間でデータ及びアプリケーションソフトウェアの連携や相互運用が可能となる環境を提供すること"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。混合云把企业专用的私有云和面向一般用户的公有云连接起来，使数据与应用能在两边协作。重点是两种部署形态的组合与互通。ア是单一服务的定制；イ按客户类型划分；ウ按收费方式划分，都没有体现私有云与公有云的联动。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 9
  },
  {
    "id": "FE-2023-A-16",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 16,
    "topicZh": "多样性管理",
    "stemJa": "ダイバーシティマネジメントの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "従業員が仕事と生活の調和を図り，やりがいをもって業務に取り組み，組織の活力を向上させることである。"
      },
      {
        "label": "イ",
        "textJa": "性別や年齢，国籍などの面で従業員の多様性を尊重することによって，組織の活力を向上させることである。"
      },
      {
        "label": "ウ",
        "textJa": "自ら設定した目標の達成を目指して従業員が主体的に業務に取り組み，その達成度に応じて評価が行われることである。"
      },
      {
        "label": "エ",
        "textJa": "労使双方が労働条件についての合意を形成し，協調して収益の増大を目指すことである。"
      }
    ],
    "answer": "イ",
    "explanationZh": "多样性管理强调尊重并运用员工在性别、年龄、国籍等方面的差异，让不同经验与视角发挥作用，提升组织活力，所以选イ。ア描述工作与生活平衡；ウ强调员工设定目标、按达成度评价，属于目标管理式做法；エ强调劳资双方就劳动条件协商合作。它们都涉及组织管理，但只有イ直接以员工多样性为核心。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 9
  },
  {
    "id": "FE-2023-A-17",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 17,
    "topicZh": "企业资源计划",
    "stemJa": "ERP を説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "営業活動に IT を活用して営業の効率と品質を高め，売上・利益の大幅な増加や，顧客満足度の向上を目指す手法・概念である。"
      },
      {
        "label": "イ",
        "textJa": "卸売業・メーカが小売店の経営活動を支援することによって，自社との取引量の拡大につなげる手法・概念である。"
      },
      {
        "label": "ウ",
        "textJa": "企業全体の経営資源を有効かつ総合的に計画して管理し，経営の効率向上を図るための手法・概念である。"
      },
      {
        "label": "エ",
        "textJa": "消費者向けや企業間の商取引を，インターネットなどの電子的なネットワークを活用して行う手法・概念である。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "ERP 是企业资源计划，着眼于企业整体，把资金、人力、物料等经营资源综合规划和管理，提高经营效率，因此ウ正确。ア只聚焦销售活动的信息化，更接近销售支援；イ是批发商或制造商支援零售商经营，以扩大双方交易；エ是通过网络开展电子商务。ERP 的辨识词是“企业整体的经营资源”与“综合计划管理”，范围比单一销售或线上交易更广。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 10
  },
  {
    "id": "FE-2023-A-18",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 18,
    "topicZh": "创新扩散理论",
    "stemJa": "イノベータ理論では，消費者を新製品の購入時期によって，イノベータ，アーリーアダプタ，アーリーマジョリティ，レイトマジョリティ，ラガードの五つに分類する。アーリーアダプタの説明として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "新しい製品及び新技術の採用には懐疑的で，周囲の大多数が採用している場面を見てから採用する層"
      },
      {
        "label": "イ",
        "textJa": "新商品，サービスなどを，リスクを恐れず最も早い段階で受容する層"
      },
      {
        "label": "ウ",
        "textJa": "新商品，サービスなどを早期に受け入れ，消費者に大きな影響を与える層であり，流行に敏感で，自ら情報収集を行い判断する層"
      },
      {
        "label": "エ",
        "textJa": "世の中の動きに関心が薄く，流行が一般化してからそれを採用することが多い層であり，場合によっては不採用を貫く，最も保守的な層"
      }
    ],
    "answer": "ウ",
    "explanationZh": "早期采用者（アーリーアダプタ）会较早接受新产品，主动搜集信息并作判断，而且能影响其他消费者，因此ウ正确。イ强调“不怕风险、最早接受”，对应更早的创新者。ア对新技术持怀疑态度，等多数人采用后才跟进，属于较晚采用者。エ对潮流兴趣低、可能始终不采用，是最后的落后采用者。记顺序：创新者→早期采用者→早期大众→晚期大众→落后采用者；早期采用者虽早，却不是最先一批。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 10
  },
  {
    "id": "FE-2023-A-19",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 19,
    "topicZh": "企业信息负责人",
    "stemJa": "CIO の説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "経営戦略の立案及び業務執行を統括する最高責任者"
      },
      {
        "label": "イ",
        "textJa": "資金調達，財務報告などの財務面での戦略策定及び執行を統括する最高責任者"
      },
      {
        "label": "ウ",
        "textJa": "自社の技術戦略や研究開発計画の立案及び執行を統括する最高責任者"
      },
      {
        "label": "エ",
        "textJa": "情報管理，情報システムに関する戦略立案及び執行を統括する最高責任者"
      }
    ],
    "answer": "エ",
    "explanationZh": "CIO 是首席信息官，负责信息管理及信息系统相关战略的制定与执行，所以选エ。ア统筹经营战略和业务执行，接近 CEO 的职责；イ管融资、财务报告及财务战略，对应 CFO；ウ管技术战略与研发计划，对应 CTO。区分这些职位时看主管领域：信息系统是 CIO，财务是 CFO，技术研发是 CTO，企业整体经营是 CEO。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 11
  },
  {
    "id": "FE-2023-B-01",
    "kind": "official",
    "year": 2023,
    "section": "B",
    "number": 1,
    "topicZh": "质数判定与循环",
    "stemJa": "次のプログラム中の［ a ］と［ b ］に入れる正しい答えの組合せを，解答群の中から選べ。ここで，配列の要素番号は 1 から始まる。\n\n関数 findPrimeNumbers は，引数で与えられた整数以下の，全ての素数だけを格納した配列を返す関数である。ここで，引数に与える整数は 2 以上である。\n\n〔プログラム〕\n○整数型の配列: findPrimeNumbers(整数型: maxNum)\n    整数型の配列: pnList ← {} // 要素数0の配列\n    整数型: i, j\n    論理型: divideFlag\n    for (i を 2 から［ a ］まで 1 ずつ増やす)\n        divideFlag ← true\n        /* iの正の平方根の整数部分が2未満のときは，繰返し処理を実行しない */\n        for (j を 2 から iの正の平方根の整数部分 まで 1 ずつ増やす) // α\n            if (［ b ］)\n                divideFlag ← false\n                αの行から始まる繰返し処理を終了する\n            endif\n        endfor\n        if (divideFlag が true と等しい)\n            pnListの末尾 に iの値 を追加する\n        endif\n    endfor\n    return pnList",
    "options": [
      {
        "label": "ア",
        "textJa": "a: maxNum ／ b: i ÷ j の余り が 0 と等しい"
      },
      {
        "label": "イ",
        "textJa": "a: maxNum ／ b: i ÷ j の商 が 1 と等しくない"
      },
      {
        "label": "ウ",
        "textJa": "a: maxNum ＋ 1 ／ b: i ÷ j の余り が 0 と等しい"
      },
      {
        "label": "エ",
        "textJa": "a: maxNum ＋ 1 ／ b: i ÷ j の商 が 1 と等しくない"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。要求包含不大于maxNum的所有质数，所以外层循环必须走到maxNum，不能到maxNum＋1。若i有介于2和√i之间的因子j，则i÷j的余数为0，此时把divideFlag设为false并退出；若一个也没有，i才是质数。イ、エ检查商是否不等于1，商的值不能判断整除；ウ、エ会把大于上限的maxNum＋1也纳入候选，可能返回越界的质数。只需查到平方根，是因为合数的两个因子不可能都大于其平方根。",
    "transcriptionNoteZh": "原卷以方框标示 a、b 两个空栏；纯文本中用［ a ］和［ b ］表示。选项中的 a:、b: 是原卷双列表格的文字化排列。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_b_ans.pdf",
    "page": 4
  },
  {
    "id": "FE-2023-B-02",
    "kind": "official",
    "year": 2023,
    "section": "B",
    "number": 2,
    "topicZh": "函数调用顺序",
    "stemJa": "次の記述中の［ a ］に入れる正しい答えを，解答群の中から選べ。\n\n次のプログラムにおいて，手続 proc2 を呼び出すと，［ a ］の順に出力される。\n\n〔プログラム〕\n○proc1()\n    \"A\" を出力する\n    proc3()\n○proc2()\n    proc3()\n    \"B\" を出力する\n    proc1()\n○proc3()\n    \"C\" を出力する",
    "options": [
      {
        "label": "ア",
        "textJa": "“A”，“B”，“B”，“C”"
      },
      {
        "label": "イ",
        "textJa": "“A”，“C”"
      },
      {
        "label": "ウ",
        "textJa": "“A”，“C”，“B”，“C”"
      },
      {
        "label": "エ",
        "textJa": "“B”，“A”，“B”，“C”"
      },
      {
        "label": "オ",
        "textJa": "“B”，“C”，“B”，“A”"
      },
      {
        "label": "カ",
        "textJa": "“C”，“B”"
      },
      {
        "label": "キ",
        "textJa": "“C”，“B”，“A”"
      },
      {
        "label": "ク",
        "textJa": "“C”，“B”，“A”，“C”"
      }
    ],
    "answer": "ク",
    "explanationZh": "正确答案是ク。执行proc2时，第一句调用proc3输出C；回到proc2后输出B；再调用proc1，先输出A，再由proc1调用proc3输出C，因此完整顺序是C、B、A、C。ア至オ的起始字母或后续顺序与实际调用链不符；カ停在B，漏了proc1；キ漏了proc1内部最后一次proc3调用。解这类题应顺着调用栈逐行走，子过程执行完才回到调用处的下一行。",
    "transcriptionNoteZh": "原卷空栏以方框标示；纯文本中用［ a ］表示。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_b_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-ORIGINAL-A-01",
    "kind": "original",
    "year": null,
    "section": "A",
    "number": 1,
    "topicZh": "进制转换",
    "stemJa": "2進数 101101 を 10進数で表したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "43"
      },
      {
        "label": "イ",
        "textJa": "44"
      },
      {
        "label": "ウ",
        "textJa": "45"
      },
      {
        "label": "エ",
        "textJa": "46"
      }
    ],
    "answer": "ウ",
    "explanationZh": "这是一道本应用自编练习题，不是 IPA 真题。二进制从右到左的位权依次为 1、2、4、8、16、32。101101₂ 中为 1 的位置是 32、8、4、1，所以十进制值为 32＋8＋4＋1＝45，选ウ。其他三个数字都与位权相加的结果不符；尤其不要把最右边的1漏掉，否则会错算为44。解题时先把六个位置的位权写全，再只相加对应为1的位。"
  },
  {
    "id": "FE-ORIGINAL-A-02",
    "kind": "original",
    "year": null,
    "section": "A",
    "number": 2,
    "topicZh": "数据库与 NULL",
    "stemJa": "表 T の列 v に 10，NULL，20 の 3 行が格納されている。次の SQL 文の実行結果はどれか。\n\nSELECT COUNT(*) FROM T WHERE v IS NULL",
    "options": [
      {
        "label": "ア",
        "textJa": "0"
      },
      {
        "label": "イ",
        "textJa": "1"
      },
      {
        "label": "ウ",
        "textJa": "2"
      },
      {
        "label": "エ",
        "textJa": "3"
      }
    ],
    "answer": "イ",
    "explanationZh": "这是一道本应用自编练习题，不是 IPA 真题。WHERE v IS NULL 只留下 v 为 NULL 的那一行；COUNT(*) 统计过滤后的行数，因此结果为1，选イ。ア把 NULL 行错误地忽略了；ウ、エ把不满足条件的 10 或 20 也算入。这里特意使用 COUNT(*)：它数的是行；若写 COUNT(v)，则会忽略 v 为 NULL 的值，含义不同。"
  },
  {
    "id": "FE-ORIGINAL-A-03",
    "kind": "original",
    "year": null,
    "section": "A",
    "number": 3,
    "topicZh": "系统可用率",
    "stemJa": "ある装置の平均故障間隔（MTBF）が 900 時間，平均修理時間（MTTR）が 100 時間である。稼働率は幾らか。",
    "options": [
      {
        "label": "ア",
        "textJa": "0.10"
      },
      {
        "label": "イ",
        "textJa": "0.50"
      },
      {
        "label": "ウ",
        "textJa": "0.90"
      },
      {
        "label": "エ",
        "textJa": "0.99"
      }
    ],
    "answer": "ウ",
    "explanationZh": "这是一道本应用自编练习题，不是 IPA 真题。一个典型循环包含平均正常运行的900小时与平均修理的100小时，总共1000小时；其中可运行时间占900小时。稼働率＝MTBF÷(MTBF＋MTTR)＝900÷1000＝0.90，选ウ。ア算成了停机时间占比；イ与エ都不符合代入后的分数。注意分母需要同时包括正常运行和修理时间。"
  },
  {
    "id": "FE-ORIGINAL-A-04",
    "kind": "original",
    "year": null,
    "section": "A",
    "number": 4,
    "topicZh": "两要素认证",
    "stemJa": "認証において，知識情報と生体情報という異なる二つの要素を組み合わせたものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "パスワードと暗証番号"
      },
      {
        "label": "イ",
        "textJa": "指紋と静脈"
      },
      {
        "label": "ウ",
        "textJa": "パスワードと指紋"
      },
      {
        "label": "エ",
        "textJa": "暗証番号と秘密の質問の答え"
      }
    ],
    "answer": "ウ",
    "explanationZh": "这是一道本应用自编练习题，不是 IPA 真题。题目要求的是两个不同类别：密码属于“知道的东西”（知识因素），指纹属于“自身特征”（生物因素），所以选ウ。ア的密码和 PIN 都是知识因素；イ的指纹与静脉都是生物因素；エ的 PIN 与秘密问题答案也都是知识因素。使用两种方法并不自动等于两要素，关键是因素类别不同。"
  }
];
