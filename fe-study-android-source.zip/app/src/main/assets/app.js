(function () {
  "use strict";
  const QUESTIONS = Array.isArray(window.FE_QUESTIONS) ? window.FE_QUESTIONS : [];
  const LESSONS = Array.isArray(window.FE_LESSONS) ? window.FE_LESSONS : [];
  const screen = document.getElementById("screen");
  const key = "fe-study-state-v1";
  const byId = new Map(QUESTIONS.map(q => [q.id, q]));
  const ui = { tab: "learn", lessonId: null, session: null, result: null,
    filters: { kind: "all", section: "all", year: "all" } };

  function h(value) {
    return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"})[c]);
  }
  function readState() {
    try {
      const raw = window.StudyStore ? window.StudyStore.load() : localStorage.getItem(key);
      const parsed = raw ? JSON.parse(raw) : {};
      return { attempts: Array.isArray(parsed.attempts) ? parsed.attempts : [], daily: parsed.daily && typeof parsed.daily === "object" ? parsed.daily : {} };
    } catch (_) { return { attempts: [], daily: {} }; }
  }
  let state = readState();
  function saveState() {
    const raw = JSON.stringify(state);
    try { if (window.StudyStore) window.StudyStore.save(raw); else localStorage.setItem(key, raw); } catch (_) { /* storage unavailable */ }
  }
  function today() {
    const d = new Date();
    return [d.getFullYear(), String(d.getMonth()+1).padStart(2,"0"), String(d.getDate()).padStart(2,"0")].join("-");
  }
  function mastery() {
    const result = new Map();
    for (const a of state.attempts) {
      const s = result.get(a.questionId) || { tried: 0, everWrong: false, streakAfterWrong: 0, lastWrongAt: "", lastAt: "" };
      s.tried += 1; s.lastAt = a.at || "";
      if (!a.correct) { s.everWrong = true; s.streakAfterWrong = 0; s.lastWrongAt = a.at || ""; }
      else if (s.everWrong) s.streakAfterWrong += 1;
      result.set(a.questionId, s);
    }
    return result;
  }
  function wrongQuestions() {
    const status = mastery();
    return QUESTIONS.filter(q => { const s = status.get(q.id); return s && s.everWrong && s.streakAfterWrong < 2; });
  }
  function hash(text) {
    let value = 2166136261;
    for (let i=0;i<text.length;i++) { value ^= text.charCodeAt(i); value = Math.imul(value,16777619); }
    return value >>> 0;
  }
  function dailyIds() {
    const date = today();
    if (Array.isArray(state.daily[date])) return state.daily[date].filter(id => byId.has(id));
    const status = mastery();
    const bad = wrongQuestions().sort((a,b) => (status.get(a.id).lastWrongAt || "").localeCompare(status.get(b.id).lastWrongAt || ""));
    const unseen = QUESTIONS.filter(q => !status.has(q.id)).sort((a,b) => hash(date+a.id)-hash(date+b.id));
    const seen = QUESTIONS.filter(q => status.has(q.id) && !bad.some(w => w.id===q.id)).sort((a,b) => (status.get(a.id).lastAt || "").localeCompare(status.get(b.id).lastAt || ""));
    state.daily[date] = [...bad,...unseen,...seen].slice(0,5).map(q=>q.id);
    saveState();
    return state.daily[date];
  }
  function stats() {
    const attempts = state.attempts.length;
    const correct = state.attempts.filter(a=>a.correct).length;
    return {attempts, accuracy: attempts ? Math.round(correct*100/attempts) : 0, wrong: wrongQuestions().length};
  }
  function setTab(tab) {
    ui.tab = tab; ui.lessonId = null; ui.result = null;
    document.querySelectorAll(".nav-item").forEach(button => button.classList.toggle("active", button.dataset.tab === tab));
    render(); window.scrollTo(0,0);
  }
  function sourceLabel(q) {
    return q.kind === "official" ? `出典：令和${q.year-2018}年度 基本情報技術者試験 科目${q.section} 問${q.number}` : "原创练习（非真题）";
  }
  function badge(q) {
    return `<span class="chip ${q.kind === "official" ? "official" : "original"}">${q.kind === "official" ? "IPA 官方公开题" : "原创练习 · 非真题"}</span>`;
  }
  function renderLearn() {
    if (ui.lessonId) {
      const lesson = LESSONS.find(l=>l.id===ui.lessonId);
      if (!lesson) { ui.lessonId = null; return renderLearn(); }
      const related = QUESTIONS.filter(q => lesson.matches.some(word => (q.topicZh || "").includes(word) || (q.stemJa || "").includes(word)));
      return `<button class="back" data-action="back-learn">← 返回学习</button><div class="eyebrow">FE 学习单元</div><h1 class="title">${h(lesson.title)}</h1><p class="lead">${h(lesson.subtitle)}</p><div class="card detail-note"><p>${h(lesson.intro)}</p><ul>${lesson.points.map(p=>`<li>${h(p)}</li>`).join("")}</ul></div><div class="card detail-note"><strong>解题提示</strong><p>${h(lesson.tip)}</p></div><button class="button primary wide" data-action="lesson-quiz" data-lesson="${h(lesson.id)}">练习相关题目${related.length ? `（${related.length} 道）` : ""}</button><p class="source-note">学习提纲依据 IPA 的 FE 考试大纲组织；题目页另列具体出处。</p>`;
    }
    const s = stats();
    return `<section class="hero"><div class="eyebrow">你的 FE 学习空间</div><h1>每天进步一点，<br>把知识真正学会。</h1><p>先理解知识点，再用日语原题检验。答案后有独立编写的中文解析。</p></section><div class="stats"><div class="stat"><strong>${QUESTIONS.length}</strong><span>已核验题目</span></div><div class="stat"><strong>${s.attempts}</strong><span>累计作答</span></div><div class="stat"><strong>${s.accuracy}%</strong><span>答题正确率</span></div></div><div class="section-row"><h2>知识点学习</h2><small>${LESSONS.length} 个单元</small></div>${LESSONS.map(l=>`<button class="card lesson-card" data-action="open-lesson" data-lesson="${h(l.id)}"><span class="lesson-glyph">${h(l.glyph)}</span><span class="lesson-copy"><strong>${h(l.title)}</strong><span>${h(l.subtitle)}</span></span><span class="chevron">›</span></button>`).join("")}<p class="disclaimer">学习内容与中文解析为本应用独立编写，非 IPA 官方讲解。官方试题保留原文并提供来源。</p>`;
  }
  function filteredQuestions() {
    return QUESTIONS.filter(q => (ui.filters.kind === "all" || q.kind === ui.filters.kind) && (ui.filters.section === "all" || q.section === ui.filters.section) && (ui.filters.year === "all" || String(q.year) === ui.filters.year));
  }
  function renderQuizHome() {
    const qs = filteredQuestions();
    const years = [...new Set(QUESTIONS.filter(q=>q.kind==="official").map(q=>q.year))].sort((a,b)=>b-a);
    return `<div class="eyebrow">QUESTION BANK</div><h1 class="title">刷题练习</h1><p class="lead">按科目、年份和题目类型练习。所有官方题都能追溯到 IPA 题册与答案表。</p><div class="filters"><label class="field">题目类型<select data-filter="kind"><option value="all" ${ui.filters.kind==="all"?"selected":""}>全部题目</option><option value="official" ${ui.filters.kind==="official"?"selected":""}>官方公开题</option><option value="original" ${ui.filters.kind==="original"?"selected":""}>原创练习</option></select></label><label class="field">科目<select data-filter="section"><option value="all" ${ui.filters.section==="all"?"selected":""}>全部科目</option><option value="A" ${ui.filters.section==="A"?"selected":""}>科目 A</option><option value="B" ${ui.filters.section==="B"?"selected":""}>科目 B</option></select></label><label class="field">年份<select data-filter="year"><option value="all" ${ui.filters.year==="all"?"selected":""}>全部年份</option>${years.map(y=>`<option value="${y}" ${ui.filters.year===String(y)?"selected":""}>${y} 年</option>`).join("")}</select></label></div><div class="card"><strong>当前可练 ${qs.length} 道</strong><p class="source-note">官方公开题 ${qs.filter(q=>q.kind==="official").length} 道 · 原创练习 ${qs.filter(q=>q.kind==="original").length} 道</p><button class="button primary wide" data-action="start-filtered" ${qs.length?"":"disabled"}>开始练习</button></div><p class="source-note">官方公布的 FE 机考题只占实际考试的一部分。本应用按已经核验并写好中文解析的题目逐步收录。</p>`;
  }
  function renderWrong() {
    const wrong = wrongQuestions();
    const status = mastery();
    return `<div class="eyebrow">REVIEW</div><h1 class="title">错题复习</h1><p class="lead">做错后进入这里；此后连续答对两次会从待复习列表移出，历史作答仍保留。</p>${wrong.length ? `<div class="section-row"><h2>待复习 ${wrong.length} 道</h2></div><button class="button primary wide" data-action="start-wrong">开始复习</button>${wrong.map(q=>`<div class="card question-list-item"><span class="number">${h(q.section)} · ${h(q.number)}</span><span class="list-copy"><strong>${h(q.stemJa)}</strong><small>${h(sourceLabel(q))}</small></span><span class="review-count">还需连对 ${2-status.get(q.id).streakAfterWrong} 次</span></div>`).join("")}` : `<div class="card empty"><span class="icon">✓</span><strong>目前没有待复习错题</strong><span>开始刷题后，做错的题会自动出现在这里。</span></div>`}`;
  }
  function renderDaily() {
    const ids = dailyIds();
    const qs = ids.map(id=>byId.get(id)).filter(Boolean);
    const done = new Set(state.attempts.filter(a=>a.date===today()).map(a=>a.questionId));
    return `<div class="eyebrow">DAILY FIVE</div><h1 class="title">每日推荐题目</h1><p class="lead">先复习待巩固错题，再补充尚未做过的题。当天题单固定，重开应用也不会变。</p><span class="daily-date">${h(today())} · ${qs.length} 道</span>${qs.length ? `<div class="card"><strong>今天已完成 ${qs.filter(q=>done.has(q.id)).length} / ${qs.length} 道</strong><p class="source-note">推荐只从已核验题库选取，题量不足时显示实际数量。</p><button class="button primary wide" data-action="start-daily">开始今日练习</button></div>${qs.map((q,i)=>`<div class="card question-list-item"><span class="number">${String(i+1).padStart(2,"0")}</span><span class="list-copy"><strong>${h(q.stemJa)}</strong><small>${h(sourceLabel(q))}</small></span><span class="chip ${done.has(q.id)?"official":""}">${done.has(q.id)?"已作答":"待作答"}</span></div>`).join("")}` : `<div class="card empty"><strong>题目正在核验</strong><span>题库准备好后，每天会从真实题目中挑选练习。</span></div>`}`;
  }
  function startSession(ids, title, fromTab) {
    const valid = ids.filter(id=>byId.has(id));
    if (!valid.length) return;
    ui.session = { ids: valid, index: 0, selected: null, submitted: false, title, fromTab, startAttemptCount: state.attempts.length };
    ui.result = null; ui.tab = fromTab; render(); window.scrollTo(0,0);
  }
  function renderSession() {
    const s = ui.session;
    const q = byId.get(s.ids[s.index]);
    if (!q) { ui.session=null; return renderQuizHome(); }
    const isCorrect = s.selected === q.answer;
    return `<button class="back" data-action="leave-session">← 返回</button><div class="question-head"><div><div class="eyebrow">${h(s.title)}</div><strong>第 ${s.index+1} / ${s.ids.length} 题</strong></div>${badge(q)}</div><div class="progress"><div style="width:${Math.round((s.index+1)*100/s.ids.length)}%"></div></div><div class="chip-row"><span class="chip">科目 ${h(q.section)}</span><span class="chip">${h(q.topicZh || "综合")}</span>${q.kind==="official"?`<span class="chip">${q.year} 年 · 问 ${q.number}</span>`:""}</div><div class="stem" lang="ja">${h(q.stemJa)}</div>${q.options.map(o=>`<button class="option ${s.selected===o.label?"selected":""} ${s.submitted&&o.label===q.answer?"correct":""} ${s.submitted&&s.selected===o.label&&!isCorrect?"wrong":""}" data-action="select-option" data-option="${h(o.label)}" ${s.submitted?"disabled":""}><span class="letter">${h(o.label)}</span><span lang="ja">${h(o.textJa)}</span></button>`).join("")}${s.submitted?`<div class="answer-panel ${isCorrect?"":"bad"}"><strong>${isCorrect?"答对了":"再看一遍思路"} · ${q.kind==="official"?"官方答案":"参考答案"} ${h(q.answer)}</strong><p>${h(q.explanationZh)}</p><small>${h(sourceLabel(q))}</small>${q.kind==="official"?`<br><a class="source-link" href="${h(q.questionUrl)}#page=${Number(q.page)||1}">查看 IPA 原题 PDF ↗</a> <a class="source-link" href="${h(q.answerUrl)}">核对官方答案 ↗</a>`:""}</div><button class="button primary wide" data-action="next-question" style="margin-top:16px">${s.index===s.ids.length-1?"查看本轮结果":"下一题"}</button>`:`<button class="button primary wide" data-action="submit-answer" ${s.selected?"":"disabled"} style="margin-top:18px">确认答案</button>`}`;
  }
  function renderResult() {
    const r = ui.result;
    return `<button class="back" data-action="close-result">← 返回</button><div class="eyebrow">练习完成</div><h1 class="title">这一轮完成了</h1><div class="card empty"><span class="icon">✦</span><strong>答对 ${r.correct} / ${r.total} 道</strong><span>需要再巩固的题已经进入错题复习。</span></div><div class="button-row"><button class="button secondary" data-action="close-result">返回列表</button><button class="button primary" data-action="go-wrong">查看错题</button></div>`;
  }
  function render() {
    if (ui.result && ui.result.fromTab===ui.tab) screen.innerHTML = renderResult();
    else if (ui.session && ui.session.fromTab===ui.tab) screen.innerHTML = renderSession();
    else screen.innerHTML = ui.tab==="learn" ? renderLearn() : ui.tab==="quiz" ? renderQuizHome() : ui.tab==="wrong" ? renderWrong() : renderDaily();
    if (ui.session && ui.session.fromTab===ui.tab) {
      const q = byId.get(ui.session.ids[ui.session.index]);
      if (q && q.transcriptionNoteZh) {
        const note = document.createElement("p");
        note.className = "source-note";
        note.textContent = q.transcriptionNoteZh;
        screen.querySelector(".stem")?.after(note);
      }
    }
  }
  document.querySelectorAll(".nav-item").forEach(b => b.addEventListener("click",()=>setTab(b.dataset.tab)));
  screen.addEventListener("change", event => {
    const filter = event.target.dataset.filter;
    if (filter) { ui.filters[filter] = event.target.value; render(); }
  });
  screen.addEventListener("click", event => {
    const el = event.target.closest("[data-action]");
    if (!el) return;
    const action = el.dataset.action;
    if (action==="open-lesson") { ui.lessonId=el.dataset.lesson; render(); window.scrollTo(0,0); }
    else if (action==="back-learn") { ui.lessonId=null; render(); window.scrollTo(0,0); }
    else if (action==="lesson-quiz") {
      const lesson=LESSONS.find(l=>l.id===el.dataset.lesson);
      const related=QUESTIONS.filter(q=>lesson.matches.some(w=>(q.topicZh||"").includes(w)||(q.stemJa||"").includes(w)));
      startSession((related.length?related:QUESTIONS).map(q=>q.id),lesson.title,"learn");
    }
    else if (action==="start-filtered") startSession(filteredQuestions().map(q=>q.id),"刷题练习","quiz");
    else if (action==="start-wrong") startSession(wrongQuestions().map(q=>q.id),"错题复习","wrong");
    else if (action==="start-daily") startSession(dailyIds(),"每日推荐","daily");
    else if (action==="select-option" && ui.session && !ui.session.submitted) { ui.session.selected=el.dataset.option; render(); }
    else if (action==="submit-answer" && ui.session && ui.session.selected && !ui.session.submitted) {
      const q=byId.get(ui.session.ids[ui.session.index]);
      state.attempts.push({questionId:q.id,selected:ui.session.selected,correct:ui.session.selected===q.answer,at:new Date().toISOString(),date:today()});
      ui.session.submitted=true; saveState(); render();
      document.querySelector(".answer-panel")?.scrollIntoView({behavior:"smooth",block:"nearest"});
    }
    else if (action==="next-question" && ui.session && ui.session.submitted) {
      if (ui.session.index < ui.session.ids.length-1) {ui.session.index++;ui.session.selected=null;ui.session.submitted=false;render();window.scrollTo(0,0);}
      else {
        const completed=state.attempts.slice(ui.session.startAttemptCount);
        ui.result={total:ui.session.ids.length,correct:completed.filter(a=>a.correct).length,fromTab:ui.session.fromTab};
        ui.session=null;render();window.scrollTo(0,0);
      }
    }
    else if (action==="leave-session") {ui.session=null;ui.lessonId=null;render();window.scrollTo(0,0);}
    else if (action==="close-result") {ui.result=null;ui.lessonId=null;render();window.scrollTo(0,0);}
    else if (action==="go-wrong") {ui.result=null;setTab("wrong");}
  });
  window.FE_goBack = function () {
    if (ui.result && ui.result.fromTab===ui.tab) { ui.result=null; ui.lessonId=null; render(); return true; }
    if (ui.session && ui.session.fromTab===ui.tab) { ui.session=null; ui.lessonId=null; render(); return true; }
    if (ui.lessonId && ui.tab==="learn") { ui.lessonId=null; render(); return true; }
    if (ui.tab!=="learn") { setTab("learn"); return true; }
    return false;
  };
  render();
})();
