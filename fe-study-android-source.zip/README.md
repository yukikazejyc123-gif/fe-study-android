# FE 学习刷题（Android）

面向备考日本 **基本情報技術者試験（FE）** 的离线 Android 应用。界面和解析用中文，题干与选项用日语。

当前题库共 **64 道**：60 道 IPA 官方公开题（2023–2026 年科目 A/B）与 4 道独立标记的原创练习。官方题的题干、选项和答案对照 IPA 原卷及答案表核查。

## 功能

- **学习**：六个知识单元，讲清基础概念与常见陷阱。
- **刷题**：按官方公开题/原创练习、科目和年份筛选；作答后查看中文逐项解析。
- **错题**：做错后自动收录，之后连续答对两次移出待复习列表。
- **每日推荐**：按本机日期固定五题，优先待复习错题，再选未做题；不会生成新题。

应用不要求账号、不请求网络权限。学习记录保存在本机应用数据中。点击 IPA 来源时由手机浏览器打开官方 PDF。

## 题库来源与标识

官方题来自 [IPA 公開問題](https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/index.html)的 2023–2026 年 FE 科目 A/B 试题及官方答案。每题显示「IPA 官方公开题」和年度、科目、题号，并附题册与答案 PDF。因图表及排版可能无法在纯文本中准确还原，只收录已逐题核对且可读的题目；个别科目 B 的空栏以可见占位符排版，并在题目上说明。完整 CBT 题库并未公开。

「原创练习 · 非真题」由本项目编写，题目与答案同样需要核验，绝不标成 IPA 真题。所有中文解析是本项目原创讲解，**不是 IPA 官方解析**。IPA 保留官方试题著作权；使用已公开题目须注明出处和改编情况，详见 [IPA 试题使用说明](https://www.ipa.go.jp/shiken/faq.html)。

## 构建

需要 JDK 17、Android SDK 35、Build Tools 35.0.0、Gradle 8.13。项目使用 Android Gradle Plugin 8.13.0。

```text
node scripts/build-question-bank.mjs
gradle :app:assembleDebug
```

生成的调试 APK 位于 `app/build/outputs/apk/debug/app-debug.apk`。GitHub Actions 在每次推送 `main` 后执行题库校验、APK 构建、包信息与签名检查，并上传 APK 构建产物。调试 APK 使用构建环境的调试签名；若要长期分发并保证升级安装，需要单独配置稳定的发布签名。

本地快速检查：`node scripts/build-question-bank.mjs` 与 `node scripts/smoke-test.mjs`。后者覆盖学习、筛选刷题、答案反馈、错题移出、每日题单持久化、官方/原创标识和应用内返回流程。

## 代码结构

- `app/src/main/assets/questions/*.json`：逐题审校的题库源文件。
- `scripts/build-question-bank.mjs`：校验并生成离线题库脚本。
- `app/src/main/assets/`：应用界面、学习内容和生成的题库。
- `app/src/main/java/`：Android WebView 容器和本地学习记录存储。

本项目与此前的仓库分开维护。
