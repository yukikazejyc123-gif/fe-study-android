import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const sourceDir = path.join(root, 'app', 'src', 'main', 'assets', 'questions');
const outputFile = path.join(root, 'app', 'src', 'main', 'assets', 'questions.js');
const files = fs.readdirSync(sourceDir).filter(name => name.endsWith('.json')).sort();
// Transcribed independently from IPA's answer PDFs, in question-number order.
const officialAnswers = {
  '2023-A': ['ウ','ウ','エ','エ','イ','ウ','イ','エ','ウ','ウ','エ','ウ','エ','ウ','エ','イ','ウ','ウ','エ','ア'],
  '2024-A': ['ウ','エ','イ','エ','ウ','ア','ウ','ウ','ウ','エ','ウ','エ','ウ','ウ','エ','エ','ア','エ','エ','ア'],
  '2025-A': ['エ','イ','イ','ウ','ア','ウ','エ','エ','ウ','ア','ウ','エ','エ','エ','ウ','エ','イ','エ','エ','イ'],
  '2023-B': ['ア','ク','エ','エ','エ','ア'],
  '2024-B': ['イ','エ','エ','イ','オ','ウ'],
  '2025-B': ['カ','ア','イ','ク','オ','ク'],
  '2026-A': ['イ','ウ','イ','イ','イ','イ','エ','ア','ウ','ウ','ア','ウ','ア','エ','ウ','ア','イ','ア','ア','イ'],
  '2026-B': ['エ','カ','ア','エ','イ','ケ']
};
const legacyAnswerDir = path.join(root, 'scripts', 'official-answer-keys');
if (fs.existsSync(legacyAnswerDir)) {
  for (const name of fs.readdirSync(legacyAnswerDir).filter(name => name.endsWith('.json'))) {
    const key = name.slice(0, -5);
    const sample = /^2022-SAMPLE-([AB])$/.exec(key);
    const earlySample = key === '2022-EARLY-B';
    if (!/^20\d\d-(?:春期|秋期)-AM$/.test(key) && !sample && !earlySample) throw new Error(`${name}: invalid IPA answer key filename`);
    const answers = JSON.parse(fs.readFileSync(path.join(legacyAnswerDir, name), 'utf8'));
    const expectedCount = earlySample ? 6 : sample ? sample[1] === 'A' ? 60 : 20 : 80;
    if (!Array.isArray(answers) || answers.length !== expectedCount || answers.some(answer => !'アイウエオカキクケコ'.includes(answer))) {
      throw new Error(`${name}: expected all ${expectedCount} IPA answer letters`);
    }
    officialAnswers[key] = answers;
  }
}
const all = files.flatMap(name => {
  const parsed = JSON.parse(fs.readFileSync(path.join(sourceDir, name), 'utf8'));
  if (!Array.isArray(parsed)) throw new Error(`${name}: root must be an array`);
  return parsed;
});
const ids = new Set();
const reviewedCounts = new Map();
for (const q of all) {
  if (!q.id || ids.has(q.id)) throw new Error(`Duplicate or missing ID: ${q.id}`);
  ids.add(q.id);
  if (!['official', 'sample', 'original'].includes(q.kind)) throw new Error(`${q.id}: invalid kind`);
  if (!['A', 'B', 'AM'].includes(q.section)) throw new Error(`${q.id}: invalid section`);
  if (!q.stemJa || !q.topicZh || !q.explanationZh || q.explanationZh.length < 95) throw new Error(`${q.id}: incomplete text/explanation`);
  if (!Array.isArray(q.options) || q.options.length < 4) throw new Error(`${q.id}: missing options`);
  const labels = new Set(q.options.map(o => o.label));
  if (labels.size !== q.options.length || !labels.has(q.answer)) throw new Error(`${q.id}: answer/options mismatch`);
  if (q.options.some(o => !o.textJa)) throw new Error(`${q.id}: empty option`);
  if (q.imageAssets !== undefined) {
    if (!Array.isArray(q.imageAssets) || !q.imageAssets.length || q.imageAssets.length > 10 || !q.transcriptionNoteZh) throw new Error(`${q.id}: missing source-image note or invalid images`);
    for (const asset of q.imageAssets) {
      if (!/^question-images\/[a-zA-Z0-9][a-zA-Z0-9_.-]*\.(?:png|jpg|webp)$/.test(asset)) throw new Error(`${q.id}: invalid image asset path`);
      const imagePath = path.join(root, 'app', 'src', 'main', 'assets', asset);
      if (!fs.existsSync(imagePath) || fs.statSync(imagePath).size < 100) throw new Error(`${q.id}: missing image asset ${asset}`);
    }
  }
  if (q.kind === 'official' || q.kind === 'sample') {
    if (!Number.isInteger(q.year) || !Number.isInteger(q.number) || !Number.isInteger(q.page) || q.page < 1 || q.page > 40) throw new Error(`${q.id}: missing or invalid source coordinates`);
    if (!/^https:\/\/www\.ipa\.go\.jp\/.*\.pdf$/.test(q.questionUrl) || !/^https:\/\/www\.ipa\.go\.jp\/.*\.pdf$/.test(q.answerUrl)) throw new Error(`${q.id}: source must be IPA PDFs`);
    const earlySample = q.kind === 'sample' && q.sampleSet === 'early';
    if (q.answerUrl !== (earlySample ? q.questionUrl : q.questionUrl.replace(/_qs\.pdf$/, '_ans.pdf'))) throw new Error(`${q.id}: question/answer source mismatch`);
    if (q.answerPage !== undefined && (!Number.isInteger(q.answerPage) || q.answerPage < 1 || q.answerPage > 40)) throw new Error(`${q.id}: invalid answer page`);
    const sample = q.kind === 'sample';
    const legacy = q.section === 'AM';
    let expectedId;
    let answerKey;
    if (sample) {
      if (earlySample) {
        if (q.year !== 2022 || q.section !== 'B' || q.questionUrl !== 'https://www.ipa.go.jp/shiken/syllabus/ps6vr7000000oett-att/fe_kamoku_b_sample.pdf') throw new Error(`${q.id}: invalid early IPA sample source`);
        expectedId = `FE-2022-EARLY-B-${String(q.number).padStart(2, '0')}`;
        answerKey = '2022-EARLY-B';
      } else {
        if (q.sampleSet !== undefined || q.year !== 2022 || legacy || !q.questionUrl.endsWith(`fe_kamoku_${q.section.toLowerCase()}_set_sample_qs.pdf`)) throw new Error(`${q.id}: invalid IPA sample source`);
        expectedId = `FE-2022-SAMPLE-${q.section}-${String(q.number).padStart(2, '0')}`;
        answerKey = `2022-SAMPLE-${q.section}`;
      }
    } else {
      const sourceSuffix = legacy ? '_fe_am_qs.pdf' : `_fe_kamoku_${q.section.toLowerCase()}_qs.pdf`;
      if (!q.questionUrl.endsWith(sourceSuffix) || !q.questionUrl.split('/').at(-1).startsWith(String(q.year))) throw new Error(`${q.id}: source PDF does not match year/section`);
      if (legacy && (!['春期', '秋期'].includes(q.periodJa) || q.year > 2019)) throw new Error(`${q.id}: invalid legacy exam period`);
      if (!legacy && q.year < 2023) throw new Error(`${q.id}: unpublished CBT year or invalid current exam`);
      const periodCode = q.periodJa === '春期' ? 'S' : 'F';
      expectedId = legacy ? `FE-${q.year}-${periodCode}-AM-${String(q.number).padStart(2, '0')}` : `FE-${q.year}-${q.section}-${String(q.number).padStart(2, '0')}`;
      answerKey = legacy ? `${q.year}-${q.periodJa}-AM` : `${q.year}-${q.section}`;
    }
    if (q.id !== expectedId) throw new Error(`${q.id}: ID does not match source fields`);
    const answers = officialAnswers[answerKey];
    if (!answers || answers[q.number - 1] !== q.answer) throw new Error(`${q.id}: answer differs from IPA key`);
    reviewedCounts.set(answerKey, (reviewedCounts.get(answerKey) || 0) + 1);
  }
}
for (const [key, answers] of Object.entries(officialAnswers)) {
  if (reviewedCounts.get(key) !== answers.length) throw new Error(`${key}: incomplete reviewed set, expected ${answers.length} questions`);
}
const sourceRank = q => q.kind === 'original' ? 3 : q.section === 'AM' ? 2 : q.kind === 'sample' ? 1 : 0;
all.sort((a, b) => sourceRank(a) - sourceRank(b) || (b.year || 0) - (a.year || 0) || a.section.localeCompare(b.section) || (a.periodJa || '').localeCompare(b.periodJa || '') || a.number - b.number);
fs.writeFileSync(outputFile, `// Generated from reviewed question JSON. Do not edit directly.\nwindow.FE_QUESTIONS = ${JSON.stringify(all, null, 2)};\n`, 'utf8');
console.log(`Validated ${all.length} questions (${all.filter(q=>q.kind==='official').length} past exam, ${all.filter(q=>q.kind==='sample').length} IPA sample, ${all.filter(q=>q.kind==='original').length} original) from ${files.length} files.`);
