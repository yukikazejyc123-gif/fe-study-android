import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const assets = path.join(root, 'app', 'src', 'main', 'assets');
const questionFiles = fs.readdirSync(path.join(assets, 'questions')).filter(name => name.endsWith('.json'));
const questions = questionFiles.flatMap(name => JSON.parse(fs.readFileSync(path.join(assets, 'questions', name), 'utf8')));
const listeners = {};
const nav = ['learn', 'quiz', 'wrong', 'daily'].map(tab => ({ dataset: { tab }, classList: { toggle() {} }, addEventListener(type, callback) { this.click = callback; } }));
const screen = {
  innerHTML: '',
  addEventListener(type, callback) { listeners[type] = callback; },
  querySelector() { return { after() {} }; }
};
const storage = new Map();
const document = {
  getElementById() { return screen; },
  querySelectorAll() { return nav; },
  querySelector() { return { scrollIntoView() {} }; },
  createElement() { return { className: '', textContent: '' }; }
};
const context = vm.createContext({
  window: { FE_QUESTIONS: questions, scrollTo() {} },
  document,
  localStorage: { getItem(key) { return storage.get(key) ?? null; }, setItem(key, value) { storage.set(key, value); } }
});
const lessonScripts = [...fs.readFileSync(path.join(assets, 'index.html'), 'utf8').matchAll(/<script src="(lessons[^"/]*\.js)"><\/script>/g)].map(match => match[1]);
for (const script of lessonScripts) vm.runInContext(fs.readFileSync(path.join(assets, script), 'utf8'), context);
vm.runInContext(fs.readFileSync(path.join(assets, 'app.js'), 'utf8'), context);

const lessons = context.window.FE_LESSONS;
assert.ok(lessons.filter(l => l.examSection === 'A').length >= 19);
assert.ok(lessons.filter(l => l.examSection === 'A').reduce((total, lesson) => total + lesson.topics.length, 0) >= 120);
assert.ok(lessons.filter(l => l.examSection === 'B').length >= 5);
assert.ok(lessons.filter(l => l.examSection === 'B').reduce((total, lesson) => total + lesson.topics.length, 0) >= 30);
for (const lesson of lessons) {
  assert.ok(['A', 'B'].includes(lesson.examSection));
  for (const topic of lesson.topics) {
    for (const field of ['termJa', 'meaningZh', 'prerequisiteZh', 'explanationZh', 'exampleZh', 'pitfallZh', 'sourceTitle', 'sourceUrl']) {
      assert.ok(topic[field], `${lesson.id}: missing ${field}`);
    }
    assert.equal(topic.stepsZh.length, 3);
    assert.match(topic.sourceUrl, /^https:\/\/www\.ipa\.go\.jp\/.*\.pdf#page=\d+$/);
  }
}

const click = (action, props = {}) => listeners.click({ target: { closest() { return { dataset: { action, ...props } }; } } });
const go = tab => nav.find(item => item.dataset.tab === tab).click();
const state = () => JSON.parse(storage.get('fe-study-state-v1'));
const firstOriginal = questions.find(q => q.kind === 'original');
const wrongOption = firstOriginal.options.find(o => o.label !== firstOriginal.answer).label;

assert.match(screen.innerHTML, /知识点学习/);
click('open-lesson', { lesson: 'numbers' });
assert.match(screen.innerHTML, /先从这里理解/);
assert.match(screen.innerHTML, /一步一步看/);
assert.match(screen.innerHTML, /查看 IPA 日语资料原文/);
click('back-learn');
go('quiz');
assert.match(screen.innerHTML, /刷题练习/);
listeners.change({ target: { dataset: { filter: 'kind' }, value: 'original' } });
assert.match(screen.innerHTML, /原创练习 4 道/);
click('start-filtered');
assert.match(screen.innerHTML, /原创练习 · 非真题/);
click('select-option', { option: wrongOption });
click('submit-answer');
assert.match(screen.innerHTML, /再看一遍思路/);
assert.equal(state().attempts[0].correct, false);
assert.match(state().attempts[0].date, /^\d{4}-\d{2}-\d{2}$/);
go('wrong');
assert.match(screen.innerHTML, /待复习 1 道/);

for (let i = 0; i < 2; i++) {
  click('start-wrong');
  click('select-option', { option: firstOriginal.answer });
  click('submit-answer');
  click('next-question');
  click('close-result');
  assert.match(screen.innerHTML, i === 0 ? /待复习 1 道/ : /目前没有待复习错题/);
}

go('daily');
const firstDaily = state().daily[Object.keys(state().daily)[0]];
assert.equal(firstDaily.length, 5);
go('learn');
go('daily');
assert.deepEqual(state().daily[Object.keys(state().daily)[0]], firstDaily);
click('start-daily');
const dailyQuestion = questions.find(q => q.id === firstDaily[0]);
click('select-option', { option: dailyQuestion.answer });
click('submit-answer');
click('leave-session');
assert.match(screen.innerHTML, /今天已完成 1 \/ 5 道/);

go('quiz');
listeners.change({ target: { dataset: { filter: 'kind' }, value: 'official' } });
click('start-filtered');
assert.match(screen.innerHTML, /IPA 官方公开题/);
assert.equal(context.window.FE_goBack(), true);
assert.match(screen.innerHTML, /刷题练习/);
assert.equal(context.window.FE_goBack(), true);
assert.match(screen.innerHTML, /知识点学习/);
assert.equal(context.window.FE_goBack(), false);
if (questions.some(q => q.section === 'AM')) {
  go('quiz');
  listeners.change({ target: { dataset: { filter: 'section' }, value: 'AM' } });
  assert.match(screen.innerHTML, /旧制度 午前/);
  click('start-filtered');
  assert.match(screen.innerHTML, /旧制午前/);
  click('leave-session');
}
const sample = questions.find(q => q.kind === 'sample');
if (sample) {
  go('quiz');
  listeners.change({ target: { dataset: { filter: 'section' }, value: 'all' } });
  listeners.change({ target: { dataset: { filter: 'kind' }, value: 'sample' } });
  assert.match(screen.innerHTML, /官方样题 \d+ 道/);
  click('start-filtered');
  assert.match(screen.innerHTML, /IPA 官方样题 · 非历年真题/);
  assert.match(screen.innerHTML, /2022 年12月官方样题/);
  const shownNumber = Number(screen.innerHTML.match(/2022 年12月官方样题 · 问 (\d+)/)?.[1]);
  const shown = questions.find(q => q.kind === 'sample' && q.section === 'A' && q.number === shownNumber);
  assert.ok(shown);
  click('select-option', { option: shown.answer });
  click('submit-answer');
  assert.match(screen.innerHTML, /サンプル問題セット/);
  assert.match(screen.innerHTML, /核对官方答案/);
  click('leave-session');
}
go('learn');
click('choose-section', { section: 'B' });
assert.match(screen.innerHTML, /科目 B · 知识点学习/);
assert.ok(!screen.innerHTML.includes('data-lesson="numbers"'));
const firstB = lessons.find(l => l.examSection === 'B');
click('open-lesson', { lesson: firstB.id });
assert.match(screen.innerHTML, /科目 B · 学习单元/);
assert.match(screen.innerHTML, /先从这里理解/);
assert.match(screen.innerHTML, /一步一步看/);
go('quiz');
assert.match(screen.innerHTML, /科目 B · 刷题练习/);
assert.ok(!screen.innerHTML.includes('旧制度 午前'));
click('start-filtered');
assert.match(screen.innerHTML, /科目 B<\/span>/);
click('leave-session');
go('daily');
const bDaily = Object.entries(state().daily).find(([key]) => key.endsWith(':B'))?.[1];
assert.equal(bDaily.length, 5);
assert.ok(bDaily.every(id => questions.find(q => q.id === id).section === 'B'));
assert.equal(state().examSection, 'B');
click('choose-section', { section: 'A' });
const aDaily = Object.entries(state().daily).find(([key]) => key.endsWith(':A'))?.[1];
assert.deepEqual(aDaily, firstDaily);
assert.ok(aDaily.every(id => questions.find(q => q.id === id).section !== 'B'));
console.log(`Smoke test passed: ${lessons.length} sourced A/B units, separate learning/practice/daily, quiz feedback, wrong review, persistence and source labeling.`);
