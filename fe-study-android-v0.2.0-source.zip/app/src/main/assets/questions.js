// Generated from reviewed question JSON. Do not edit directly.
window.FE_QUESTIONS = [
  {
    "id": "FE-2026-A-01",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 1,
    "topicZh": "条件概率与转移概率表",
    "stemJa": "入力されたビットに対して出力されるビットが 0 か 1 のいずれかである確率を遷移確率という。遷移確率を表にしたとき，a，b，c，d の関係はどれか。\n表（行は入力，列は出力）\n入力 出力0 出力1\n0 a b\n1 c d",
    "options": [
      {
        "label": "ア",
        "textJa": "a ＋ b ＋ c ＋ d ＝ 1"
      },
      {
        "label": "イ",
        "textJa": "a ＋ b ＝ 1， c ＋ d ＝ 1"
      },
      {
        "label": "ウ",
        "textJa": "a ＋ c ＝ 1， b ＋ d ＝ 1"
      },
      {
        "label": "エ",
        "textJa": "a ＋ d ＝ 1， b ＋ c ＝ 1"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。这里的每个数都是‘已经知道输入位的情况下，输出某一位的概率’，因此要固定一行来看。输入是 0 时，输出只有 0 或 1 两种互斥且穷尽的结果，它们的概率 a、b 相加必须为 1。输入是 1 时，同理 c＋d＝1。两行代表两个不同的条件，不能把四个格子一起相加，所以ア不对；ウ按列相加，エ沿对角线相加，均混合了不同输入条件。把它看成两个小实验：‘输入 0 后输出什么’与‘输入 1 后输出什么’，就能确定每一行的和。",
    "transcriptionNoteZh": "原题转移概率表按行改排为文字；输入、输出方向与字母位置未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 4
  },
  {
    "id": "FE-2026-A-02",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 2,
    "topicZh": "算法与排序",
    "stemJa": "クイックソートの処理方法を説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "既に整列済みのデータ列の正しい位置に，データを追加する操作を繰り返していく方法である。"
      },
      {
        "label": "イ",
        "textJa": "データ中の最小値を求め，次にそれを除いた部分の中から最小値を求める。この操作を繰り返していく方法である。"
      },
      {
        "label": "ウ",
        "textJa": "適当な基準値を選び，それよりも小さな値のグループと大きな値のグループにデータを分割する。同様にして，グループの中で基準値を選び，それぞれのグループを分割する。この操作を繰り返していく方法である。"
      },
      {
        "label": "エ",
        "textJa": "隣り合ったデータの比較と入替えを繰り返すことによって，小さな値のデータを次第に端の方に移していく方法である。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "快速排序的核心是选一个基准值，把数据分成比它小和比它大的两组，再对各组重复这一过程，所以选ウ。这里要抓住“基准值”和“分组后递归处理”。ア是插入排序：把新元素放入已排好序的部分；イ是选择排序：反复从未排序部分选出最小值；エ是冒泡排序：反复比较并交换相邻元素。四种算法都能排序，但分组依据与处理顺序不同。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 4
  },
  {
    "id": "FE-2026-A-03",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 3,
    "topicZh": "计算机硬件",
    "stemJa": "プロセッサの一つである GPU の特徴として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "OS 及び他のハードウェアから独立して機能し，暗号キーなどの情報を安全に管理する。"
      },
      {
        "label": "イ",
        "textJa": "並列に動作する多数の浮動小数点演算ユニットによって，高速な 3D 演算ができる。"
      },
      {
        "label": "ウ",
        "textJa": "目的に応じて半導体デバイス内部の論理回路を再構成できる。"
      },
      {
        "label": "エ",
        "textJa": "量子ビットによって 0 と 1 を重ね合わせた状態を計算に使うことができる。"
      }
    ],
    "answer": "イ",
    "explanationZh": "GPU 有大量可并行工作的运算单元，适合同时处理图形中许多顶点、像素等数值计算，因此イ所说的高速 3D 浮点运算是其典型特点。ア描述的是用于保护密钥等信息的安全硬件（如 TPM），不是 GPU 的主要功能。ウ描述可重新配置内部逻辑电路的 FPGA。エ描述使用量子比特叠加态的量子计算设备。题目问的是 GPU，应以大量并行运算单元为识别点。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2026-A-04",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 4,
    "topicZh": "云计算服务模型",
    "stemJa": "クラウドコンピューティングのサービスモデルとしての PaaS の説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "OS やアプリケーションを含む任意のソフトウェアを実行可能にするリソースが，利用者に提供される。OS などのプラットフォームへの限定的な設定や制御を行うことができる。"
      },
      {
        "label": "イ",
        "textJa": "アプリケーションの開発や運用に必要となるミドルウェアなどが利用者に提供されるので，これらを利用して，アプリケーションを開発して運用することができる。利用者は，プラットフォームを直接変更することはできない。"
      },
      {
        "label": "ウ",
        "textJa": "利用者は，ハードウェア，OS などのプラットフォームとアプリケーションを自ら準備して，それらの運用を依頼する。利用者は，プラットフォームの構成を決めることができるなど，環境構築の自由度が高い。"
      },
      {
        "label": "エ",
        "textJa": "利用者は，用意されたアプリケーションをそのまま又はカスタマイズして利用するが，OS などのプラットフォームからアプリケーションまで全てを自ら準備する必要はない。利用者は，プラットフォームを直接変更することはできない。"
      }
    ],
    "answer": "イ",
    "explanationZh": "PaaS 是“平台即服务”：服务方提供运行应用所需的平台和中间件，使用者在这个平台上开发、部署、运行自己的应用，但通常不能直接改动平台内部，所以イ正确。ア强调提供运行任意软件的底层计算资源，并允许一定程度控制 OS，更接近 IaaS。ウ要求使用者自行准备硬件、OS 与应用，再委托他人运维，属于委托运维场景。エ直接提供可使用或定制的成品应用，是 SaaS。区分三者时看交付层级：资源、开发运行平台、成品应用。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2026-A-05",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 5,
    "topicZh": "虚拟内存",
    "stemJa": "仮想記憶方式のコンピュータシステムにおいて，処理の多重度を増やしたところ，ページイン，ページアウトが多発して，システムの応答速度が急激に遅くなった。このような現象を何というか。",
    "options": [
      {
        "label": "ア",
        "textJa": "オーバレイ"
      },
      {
        "label": "イ",
        "textJa": "スラッシング"
      },
      {
        "label": "ウ",
        "textJa": "メモリコンパクション"
      },
      {
        "label": "エ",
        "textJa": "ロールアウト"
      }
    ],
    "answer": "イ",
    "explanationZh": "并发处理增多后，物理内存不足以容纳各进程当前需要的页面，系统频繁把页面换入、换出，时间大量耗在分页而非实际计算上，响应速度骤降。这叫“抖动”（スラッシング），选イ。ア“覆盖”是让程序不同部分分时使用同一内存区域；ウ“内存紧缩”是整理分散的空闲空间；エ“换出”是把进程等从主存移往辅助存储的一种动作。题干描述的是频繁分页造成的系统性性能恶化，不是单次换出。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2026-A-06",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 6,
    "topicZh": "NAND 电路化简与时序图",
    "stemJa": "図の回路の A 及び B に信号を入力したときに，Y に出力される信号のタイミングチャートとして，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "タイミングチャート ア"
      },
      {
        "label": "イ",
        "textJa": "タイミングチャート イ"
      },
      {
        "label": "ウ",
        "textJa": "タイミングチャート ウ"
      },
      {
        "label": "エ",
        "textJa": "タイミングチャート エ"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。图中各门都是输出端带小圆圈的 NAND 门。第一个门把 A 同时接到两个输入，输出 ¬(A∧A)＝¬A；第二个同样得到 ¬B。中间 NAND 得到 ¬(¬A∧¬B)＝A∨B。最后一个门又把这个结果同时接到两个输入，相当于反相，所以 Y＝¬(A∨B)。即仅在 A＝0 且 B＝0 的时间段输出 1，其他三种输入组合均输出 0。对照四幅时序图，只有イ符合这个 NOR 真值关系；ア在 A＝0、B＝1 的时间段错误地输出 1，ウ在单个输入为 1 时错误地输出 1，エ呈现的是两输入同时为 1 才高电平的关系。",
    "transcriptionNoteZh": "门电路连接和四幅时间轴波形只以官方原卷图片为准；选项文字仅指向各幅图。",
    "imageAssets": [
      "question-images/fe-2026-a-06.png"
    ],
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2026-A-07",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 7,
    "topicZh": "SQL 主键约束与批量更新",
    "stemJa": "次の SQL 文によって定義され，値が格納されている“商品”表に対して，制約違反で実行エラーとなる SQL 文はどれか。\n〔SQL 文〕\nCREATE TABLE 商品\n(商品コード CHAR(4) PRIMARY KEY, 商品名 VARCHAR(21),\n仕入先コード CHAR(4), 仕入単価 INT, 在庫数 INT)\n商品\n商品コード 商品名 仕入先コード 仕入単価 在庫数\nA111 テレビ S001 75,000 0\nA222 デジタルカメラ S002 50,000 50\nA333 DVDプレーヤ NULL NULL NULL\nA444 洗濯機 S004 45,000 20",
    "options": [
      {
        "label": "ア",
        "textJa": "DELETE FROM 商品 WHERE 仕入先コード IS NULL"
      },
      {
        "label": "イ",
        "textJa": "INSERT INTO 商品 VALUES ('A555', '空気清浄機', 'S005', 60000, 50)"
      },
      {
        "label": "ウ",
        "textJa": "UPDATE 商品 SET 商品コード = 'A666' WHERE 商品コード = 'A444'"
      },
      {
        "label": "エ",
        "textJa": "UPDATE 商品 SET 商品コード = 'A777' WHERE 在庫数 >= 20"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。建表语句把‘商品コード’定义为 PRIMARY KEY（主键），也就是每一行的商品代码必须唯一。エ的条件‘在庫数 >= 20’同时选中 A222（库存 50）和 A444（库存 20），再把两行代码都改成 A777，结果出现两个相同主键，违反唯一性约束。ア用 `IS NULL` 找到供货商代码为空的 A333 并删除，不造成主键重复。イ插入新的 A555，现有代码里没有它。ウ只把 A444 改成尚未存在的 A666，也保持唯一。注意 `UPDATE ... WHERE` 可能影响多行；不能只看新值 A777 在原表中不存在，还要看有多少行会被改成这个值。",
    "transcriptionNoteZh": "原题商品表按行改排为文字；列、数据、NULL 值和 SQL 语句未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 7
  },
  {
    "id": "FE-2026-A-08",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 8,
    "topicZh": "无线网络",
    "stemJa": "無線 LAN では，複数の端末から送信された同じ周波数の電波が衝突した場合，電波が干渉するのでそれらを受信すると信号を復調できないことがある。この問題を回避するためのものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "CSMA/CA"
      },
      {
        "label": "イ",
        "textJa": "SSID"
      },
      {
        "label": "ウ",
        "textJa": "キャリアアグリゲーション"
      },
      {
        "label": "エ",
        "textJa": "テザリング"
      }
    ],
    "answer": "ア",
    "explanationZh": "无线设备不能可靠地像有线网络那样边发边检测冲突，因此 Wi‑Fi 用 CSMA/CA：发送前先侦听信道，尽量避免同时发射，必要时通过等待等机制降低碰撞概率，选ア。SSID 是无线网络名称，用于识别网络，不负责处理信号冲突。载波聚合（ウ）组合多个载波以增加传输能力。网络共享（エ）让其他设备借用终端的网络连接，也不能解决同频发送冲突。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 7
  },
  {
    "id": "FE-2026-A-09",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 9,
    "topicZh": "身份认证",
    "stemJa": "2 要素認証に該当する組みはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "クライアント証明書，ハードウェアトークン"
      },
      {
        "label": "イ",
        "textJa": "静脈認証，指紋認証"
      },
      {
        "label": "ウ",
        "textJa": "パスワード認証，静脈認証"
      },
      {
        "label": "エ",
        "textJa": "パスワード認証，秘密の質問の答え"
      }
    ],
    "answer": "ウ",
    "explanationZh": "双因素认证要求使用两种不同类别的凭据。常见类别是“知道的事”（密码、秘密问题答案）、“持有的物”（证书、硬件令牌）和“自身特征”（指纹、静脉）。ウ把密码的知识因素与静脉的生物因素组合，故正确。ア的客户端证书与硬件令牌都属于持有因素；イ的静脉与指纹都属于生物因素；エ的密码与秘密问题答案都属于知识因素。使用两个凭据不等于使用两个因素。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2026-A-10",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 10,
    "topicZh": "CSIRT 与安全专业组织职责",
    "stemJa": "情報セキュリティに関する専門組織の説明のうち，CSIRT の説明として，最も適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "自社が顧客に提供する製品又はサービスの脆弱性に起因するリスクに対応する組織"
      },
      {
        "label": "イ",
        "textJa": "セキュリティインシデント検知のために，システム監視，ログ分析などのセキュリティ運用を担う組織"
      },
      {
        "label": "ウ",
        "textJa": "発生したセキュリティインシデントに対し，インシデント対応を行う組織"
      },
      {
        "label": "エ",
        "textJa": "標的型サイバー攻撃特別相談窓口をもち，相談をもち込んだ組織の被害の低減と攻撃の連鎖の遮断を支援する組織"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。CSIRT 是处理计算机安全事件的团队。‘安全事件’可以是入侵、恶意程序感染或信息泄露等；发现事件后，需要确认影响、协调处置、恢复服务并总结防止再次发生的措施。ア特别限定为‘自家向客户提供的产品或服务的漏洞风险’，对应产品安全事件响应组织（PSIRT）关注的范围。イ主要是持续监控系统和分析日志以发现异常，更接近安全运营中心（SOC）的工作；SOC 的发现可转交 CSIRT 响应。エ描述的是设立对外专项咨询窗口并支援其他组织的机构，不是题目要找的 CSIRT 一般定义。抓住‘发生了事件后的响应’即可区分。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2026-A-11",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 11,
    "topicZh": "软件开发规范",
    "stemJa": "あるシステムにおいて，“プログラムの記述方法が統一されていないので保守がしづらい”という問題が発生している。今後の新規開発プロジェクトにおけるこの問題の低減策として，最も適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "コーディング規約を見直し，教育する。"
      },
      {
        "label": "イ",
        "textJa": "セキュアプログラミングを採用する。"
      },
      {
        "label": "ウ",
        "textJa": "単体テストでの命令網羅度を上げる。"
      },
      {
        "label": "エ",
        "textJa": "プロジェクト管理レビューに全プログラマーが参加する。"
      }
    ],
    "answer": "ア",
    "explanationZh": "问题的原因是写法不统一，直接措施是制定或修订编码规范，并培训开发人员按规范执行，所以选ア。规范能统一命名、格式、结构等做法，让后续人员更容易阅读和维护。イ的安全编程侧重减少漏洞，不能直接解决风格不一致；ウ提高语句覆盖率用于检验测试执行范围，也不能统一代码写法；エ扩大项目管理评审的参会人员，既不针对代码规范，也未必有助于维护性。选措施时要对应题干给出的根因。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2026-A-12",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 12,
    "topicZh": "敏捷项目管理",
    "stemJa": "バーンダウンチャートの使い方として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "縦軸を完成した成果物の総量，横軸を時間とし，プロジェクトが進むに従って完成した成果物の総量が増加する様子を確認する。"
      },
      {
        "label": "イ",
        "textJa": "縦軸を残課題の総数，横軸を時間とし，プロジェクトが進むに従って残課題の総量が増減する様子を確認する。"
      },
      {
        "label": "ウ",
        "textJa": "縦軸を残作業の量，横軸を時間とし，プロジェクトが進むに従って残作業の量が減少する様子を確認する。"
      },
      {
        "label": "エ",
        "textJa": "縦軸を延べ工数，横軸を時間とし，プロジェクトが進むに従って延べ工数が増加する様子を確認する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "燃尽图以时间为横轴、剩余工作量为纵轴。随着任务完成，剩余工作量逐渐“燃尽”并趋向零，因此ウ正确。ア画的是已完成成果物总量，方向向上，更接近燃起图。イ虽然也在观察“剩余”，但它写的是课题总数随时间增减；本题考查的是剩余工作量下降的趋势，课题数也不一定能体现各项任务的工作量差异。エ统计累计投入工时，随时间增加，不能显示还有多少工作待做。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 9
  },
  {
    "id": "FE-2026-A-13",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 13,
    "topicZh": "项目进度控制",
    "stemJa": "あるシステム開発プロジェクトの進捗が遅延したので，クリティカルパス上の作業への投入工数を増やすことによって遅延の解消を図った。このとき適用した，所要期間を短縮するための手法を何と呼ぶか。",
    "options": [
      {
        "label": "ア",
        "textJa": "クラッシング"
      },
      {
        "label": "イ",
        "textJa": "コーチング"
      },
      {
        "label": "ウ",
        "textJa": "ファストトラッキング"
      },
      {
        "label": "エ",
        "textJa": "メンタリング"
      }
    ],
    "answer": "ア",
    "explanationZh": "关键路径上的任务决定项目最短完工时间。向这些任务追加人力或其他资源，以缩短工期，叫赶工（クラッシング），选ア。ウ“快速跟进”是把原本顺序执行的工作部分并行，改变的是工作安排；本题明确说增加投入工数，属于赶工。イ“教练式辅导”和エ“导师辅导”都是人员培养方式，不是压缩进度计划的专门手法。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 9
  },
  {
    "id": "FE-2026-A-14",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 14,
    "topicZh": "服务可用率的百分比点",
    "stemJa": "A 社は，自社のデータセンタでアプリケーションシステムを運用し，顧客にサービスを提供している。現在，アプリケーションシステムの実行環境をクラウドサービスに移行して，サービス可用性を向上させることを検討している。次の条件のとき，サービス可用性は移行後に何パーセントポイント向上するか。ここで，サービス可用性（％）は小数第 3 位を切り捨てるものとする。\n〔条件〕\n・サービス提供時間は，移行前も移行後も同じで，計画された保守の時間を除き，年間 5,000 時間である。\n・移行前は，サービス提供時間内の停止時間が，年間 100 時間である。\n・移行後は，サービス提供時間内の停止時間が，年間 30 分となる。",
    "options": [
      {
        "label": "ア",
        "textJa": "0.01"
      },
      {
        "label": "イ",
        "textJa": "0.19"
      },
      {
        "label": "ウ",
        "textJa": "1.40"
      },
      {
        "label": "エ",
        "textJa": "1.99"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ，提高 1.99 个百分点。可用率＝(服务提供时间－停止时间)÷服务提供时间×100%。迁移前：(5000－100)÷5000×100%＝98%。迁移后先把 30 分钟换成 0.5 小时：(5000－0.5)÷5000×100%＝99.99%。两者相减是 99.99－98＝1.99 个百分点。这里比较的是两个百分数的差，所以单位是‘百分点’，不是把 99.99 与 98 相除求相对增长率。题目规定第三位小数舍去，本题计算结果正好保留两位小数。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 10
  },
  {
    "id": "FE-2026-A-15",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 15,
    "topicZh": "系统审计",
    "stemJa": "内部監査部門が，情報システム部門に対するシステム監査を経営者から指示されたとき，システム監査人の行為として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "監査報告書に記載した改善提案に対して改善計画を策定した上で，実行する。"
      },
      {
        "label": "イ",
        "textJa": "基幹システムを開発し，保守を行っている外部事業者に，当該システム監査を委託する。"
      },
      {
        "label": "ウ",
        "textJa": "経営者がどのようなニーズを有しているかを十分に把握した上で，システム監査の目的と対象範囲を決定する。"
      },
      {
        "label": "エ",
        "textJa": "情報システム部門の在籍者を監査メンバとして選定する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "审计应先弄清委托方经营者希望解决什么问题，再据此确定审计目的和范围，所以选ウ。ア把审计报告中的改善建议变为计划并执行，是被审计部门或管理层的职责；审计人员执行自己提出的改善措施会损害后续评价的独立性。イ把审计交给开发、维护该系统的同一外部公司，存在自我审查。エ让被审计的信息系统部门人员参加审计，同样影响独立性。辨题关键是审计范围与独立性。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 10
  },
  {
    "id": "FE-2026-A-16",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 16,
    "topicZh": "零售与全渠道",
    "stemJa": "小売事業者が，オムニチャネル戦略を実現するための IT 活用事例はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "実店舗，オンライン店舗，コールセンタなど複数の顧客接点で，顧客情報や在庫情報などを一元的に管理・共有して接客することによって，顧客の利便性を高める。"
      },
      {
        "label": "イ",
        "textJa": "複数店舗からネットワークを経由して，受発注，出荷，請求，支払などの取引情報を電子的に交換することによって，卸売業者とメーカとの間の受発注業務の効率を高める。"
      },
      {
        "label": "ウ",
        "textJa": "複数店舗に設置した監視カメラの画像データを本部に集め，本部が各店舗の状況をリアルタイムに把握することによって，店舗運営業務の効率を高める。"
      },
      {
        "label": "エ",
        "textJa": "複数店舗の POS データを本部に集め，本部が日次で売れ筋商品の抽出，複数の商品の併売率の分析を行うことによって，商品計画や棚割計画を最適化する。"
      }
    ],
    "answer": "ア",
    "explanationZh": "全渠道的重点是打通实体店、网店、呼叫中心等不同顾客接点，让顾客无论从哪个渠道接触企业，都能获得衔接一致的服务。ア把顾客与库存信息统一共享，正好实现这一点。イ是企业间交易信息的电子交换，重点在供应链业务效率；ウ是门店监控与运营效率；エ是汇总 POS 数据辅助选品和陈列。后三项虽都用到 IT，但没有把顾客渠道连接成连续体验。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 11
  },
  {
    "id": "FE-2026-A-17",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 17,
    "topicZh": "客户留存率的计算",
    "stemJa": "サービス A～D の中で会員のリテンション率が最も高いものはどれか。なお，リテンションの対象は前月末から当月末まで継続して在籍した会員とし，当月新規会員は月末までの退会はないものとする。\n単位 人\nサービス 前月末会員数 当月新規会員数 当月末会員数\nA 1,000 500 800\nB 1,000 200 800\nC 1,500 500 1,100\nD 1,500 1,000 1,800",
    "options": [
      {
        "label": "ア",
        "textJa": "サービス A"
      },
      {
        "label": "イ",
        "textJa": "サービス B"
      },
      {
        "label": "ウ",
        "textJa": "サービス C"
      },
      {
        "label": "エ",
        "textJa": "サービス D"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ，服务 B。留存率只看‘上月底已有会员中，到本月底还在的人’占原会员的比例。由于题目保证本月新增者不会在本月底前退会，所以留存的旧会员数＝本月末会员总数－本月新增会员数。A：(800－500)÷1000＝30%；B：(800－200)÷1000＝60%；C：(1100－500)÷1500＝40%；D：(1800－1000)÷1500≈53.3%。最高的是 B 的 60%。不要把本月末会员总数直接除以上月末人数，否则会把新增会员误算成留存会员。原题表格在此按行展示，数字未改。",
    "transcriptionNoteZh": "原题表格改为逐行文字排列，数值和选项未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 11
  },
  {
    "id": "FE-2026-A-18",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 18,
    "topicZh": "规则控制与人工智能实例",
    "stemJa": "AI の事例として，適切でないものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "制御量を目標値側へフィードバックすることによって両者を比較し，その差によって両者を一致させるような修正動作を行う PID 制御のモーターコントローラー"
      },
      {
        "label": "イ",
        "textJa": "部屋の広さや形，家具の位置などを学習し，移動のルートを決めて掃除をするロボット"
      },
      {
        "label": "ウ",
        "textJa": "ヘルプデスク及びコールセンターに代わって，自然言語による質問の意味を推測して返事をするチャットボット"
      },
      {
        "label": "エ",
        "textJa": "ボードゲームでプロの人間に勝つような，多数の統計データを処理することによって人間に勝るソフトウェア"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア，因为题干要找‘不适合作为 AI 例子’的一项。PID 控制器把测得的数值与目标值比较，再按预先确定的控制规则调整输出；题目没有描述它学习数据、推断问题或根据经验改进策略。イ明确写了学习房间形状并决定路线；ウ要推测自然语言问题的意思并回答；エ利用大量数据形成能下棋的策略，都是题目列举的 AI 应用场景。注意‘自动运行’不等于‘AI’：一个装置会自动反馈并修正，也可能只是传统控制算法。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 12
  },
  {
    "id": "FE-2026-A-19",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 19,
    "topicZh": "创意与会议方法",
    "stemJa": "ブレーンストーミングの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "あるテーマの検討において，複数のメンバーで，各自が思いつくままに自由奔放にできるだけ多くのアイディアを出し合うことによって，創造的思考を喚起し，アイディアを開発しようとする会議方法"
      },
      {
        "label": "イ",
        "textJa": "研修を始める前に行う簡単なゲームや，商談や面接の本題に入る前に行う雑談など，参加者の緊張をほぐすためのコミュニケーション方法"
      },
      {
        "label": "ウ",
        "textJa": "情報を，決められた枠組みに従って整理・分析するスキルや方法を利用し，複雑なものごとを明快に把握したり，問題に対する解決策を導き出したりするような思考方法"
      },
      {
        "label": "エ",
        "textJa": "ポイントを繰り返したり，言い換えたりすることによって，お互いの理解する意味合いが一致していることを確認したり，意見・評価を伝えたりする方法"
      }
    ],
    "answer": "ア",
    "explanationZh": "头脑风暴是围绕主题让多人自由提出尽量多的想法，先扩大创意数量，再进一步整理和评价；ア描述的就是这种会议方法。イ是开场破冰，作用是缓解紧张；ウ是按既定框架整理、分析信息的结构化思考；エ是重复或改述对方要点以确认理解、传达反馈的沟通方法。识别头脑风暴要看“多人自由发想”和“尽量多的点子”，而非单纯有讨论或交流。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 12
  },
  {
    "id": "FE-2026-A-20",
    "kind": "official",
    "year": 2026,
    "section": "A",
    "number": 20,
    "topicZh": "日本著作权与作者人格权",
    "stemJa": "A 社は，自社の業務可視化を B 社に委託しその成果物として納品された業務フロー図を C 社に提示することによって，業務システムの開発を C 社に委託することを検討している。A 社がこの業務フロー図を使用する上で生じる制約として，適切なものはどれか。なお，B 社への委託に当たって締結された契約には，著作権は全て A 社に譲渡する旨の記述があり，著作者人格権については特段の記述はない。",
    "options": [
      {
        "label": "ア",
        "textJa": "C 社と守秘義務契約を締結したとしても，C 社に対して，納品された業務フロー図の電子データを提供することはできない。"
      },
      {
        "label": "イ",
        "textJa": "納品された業務フロー図の各ページに作成者名として記されている B 社の企業名を A 社の企業名に変更し，C 社に提示することはできない。"
      },
      {
        "label": "ウ",
        "textJa": "納品された業務フロー図を印刷し，社内資料として A 社の社員に配布することはできない。"
      },
      {
        "label": "エ",
        "textJa": "バックアップの目的で，納品された業務フロー図の電子データを複製し，A 社だけがアクセス可能なクラウドストレージに保管することはできない。"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。本题把两类权利分开考：合同已把可转让的著作权（财产权）全部让给 A 社，因此按题设，A 社可为委托开发而向 C 社提供图的电子数据，也可在公司内部印发，或为备份复制并保存在只有 A 社能访问的云端；所以ア、ウ、エ所说的一概‘不能’都不对。另一方面，著作者人格权保护创作者的署名等人格利益，不能随着财产权一起被转让；合同也没有另行约定人格权的行使。把图上标示的 B 社作成者名擅自换成 A 社，涉及氏名表示权，因此本题判定这种做法受限制。要记住‘取得作品的利用权’不等于‘可以宣称自己是创作者’。本解析依题目给定的合同条件作答；具体项目的权利归属仍需看实际合同与创作事实。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_a_ans.pdf",
    "page": 13
  },
  {
    "id": "FE-2026-B-01",
    "kind": "official",
    "year": 2026,
    "section": "B",
    "number": 1,
    "topicZh": "数组与循环",
    "stemJa": "次のプログラム中の［ a ］に入れる正しい答えを，解答群の中から選べ。ここで，配列の要素番号は 1 から始まる。\n\n次のプログラムは，整数型の配列 data の末尾の要素の値を先頭の要素に移動する。この際，末尾以外の各要素の値は，一つずつ後ろの要素に移動する。\n\n〔プログラム〕\n整数型の配列: data ← {1, 2, 3, 4, 5, 6, 7, 8, 9}\n整数型: top, i\n整数型: len ← dataの要素数\ntop ← data[len]\nfor (i を［ a ］)\n    data[i] ← data[i － 1]\nendfor\ndata[1] ← top",
    "options": [
      {
        "label": "ア",
        "textJa": "2 から len － 1 まで 1 ずつ増やす"
      },
      {
        "label": "イ",
        "textJa": "2 から len まで 1 ずつ増やす"
      },
      {
        "label": "ウ",
        "textJa": "len － 1 から 2 まで 1 ずつ減らす"
      },
      {
        "label": "エ",
        "textJa": "len から 2 まで 1 ずつ減らす"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。先把原末尾9保存到top，再从i=len倒数到2，依次执行data[i]←data[i－1]，最后令data[1]←top。这样结果是{9,1,2,3,4,5,6,7,8}。若按ア或イ从左往右移动，刚写入的值会被后续步骤反复复制，覆盖原值；ウ虽从右往左，但从len－1开始，最后一个位置没有被更新。题目规定下标从1开始，因此循环终点必须是2。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_b_ans.pdf",
    "page": 4,
    "transcriptionNoteZh": "原 PDF 的方框空栏在文字版中以［ a ］标记；请用下方原题链接核对版式。"
  },
  {
    "id": "FE-2026-B-02",
    "kind": "official",
    "year": 2026,
    "section": "B",
    "number": 2,
    "topicZh": "位运算与补码",
    "stemJa": "次のプログラム中の［ a ］に入れる正しい答えを，解答群の中から選べ。\n\n関数 complement は，引数として渡された 8 ビット型の値 x について，x に加算すると 00000000 になる値を返す。8 ビット型の加算は，値を符号なし 2 進数とみなしたときの加算とし，桁あふれが発生したときのあふれた桁は無視する。演算子∧，∨，▽は，それぞれビット単位の論理積，論理和，排他的論理和を表す。\n\n〔プログラム〕\n○8ビット型: complement(8ビット型: x)\n    8ビット型: y\n    y ← ［ a ］\n    y ← y ＋ 00000001\n    return y",
    "options": [
      {
        "label": "ア",
        "textJa": "x ∧ 01111111"
      },
      {
        "label": "イ",
        "textJa": "x ∧ 11111111"
      },
      {
        "label": "ウ",
        "textJa": "x ∨ 01111111"
      },
      {
        "label": "エ",
        "textJa": "x ∨ 11111111"
      },
      {
        "label": "オ",
        "textJa": "x ▽ 01111111"
      },
      {
        "label": "カ",
        "textJa": "x ▽ 11111111"
      }
    ],
    "answer": "カ",
    "explanationZh": "正确答案是カ。8位加法丢弃第9位进位，要求x＋返回值≡0（模256），所以返回值是－x的8位表示。求法是先把x的每一位取反，再加1；与11111111逐位异或恰好能逐位取反，因此选カ。ア仅清掉最高位，イ保持原值；ウ把低7位置1，エ把全部位置1；オ只翻转低7位、保留最高位，都不能对所有x得到所需的负数。例：x=00000001，取反加1得11111111，与x相加后只剩被丢弃的第9位。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_b_ans.pdf",
    "page": 5,
    "transcriptionNoteZh": "原 PDF 的方框空栏在文字版中以［ a ］标记；请用下方原题链接核对版式。"
  },
  {
    "id": "FE-2026-B-03",
    "kind": "official",
    "year": 2026,
    "section": "B",
    "number": 3,
    "topicZh": "递归与动态规划",
    "stemJa": "次のプログラム中の［ a ］に入れる正しい答えを，解答群の中から選べ。ここで，配列の要素番号は 1 から始まる。\n\n関数 func1 に与える引数と，関数 func2 に与える引数とが同じとき，二つの関数は同じ値を返す。プログラムでは，配列の領域外を参照してはならないものとする。\n\n〔プログラム〕\n○整数型: func1(整数型: n)\n    if (nが2以下)\n        return 1\n    endif\n    return 2 × func1(n － 2) ＋ func1(n － 1)\n○整数型: func2(整数型: n)\n    整数型の配列: data ← {1, 1, 1}\n    整数型: i\n    /* nが3より小さいときは繰返し処理を実行しない */\n    for (iを3からnまで1ずつ増やす)\n        data[1] ← data[2]\n        data[2] ← data[3]\n        data[3] ← ［ a ］\n    endfor\n    return data[3]",
    "options": [
      {
        "label": "ア",
        "textJa": "2 × data[1] ＋ data[2]"
      },
      {
        "label": "イ",
        "textJa": "2 × data[2] ＋ data[1]"
      },
      {
        "label": "ウ",
        "textJa": "2 × data[i － 1] ＋ data[i － 2]"
      },
      {
        "label": "エ",
        "textJa": "2 × data[i － 2] ＋ data[i － 1]"
      },
      {
        "label": "オ",
        "textJa": "data[3] ＋ 2 × data[1] ＋ data[2]"
      },
      {
        "label": "カ",
        "textJa": "data[3] ＋ 2 × data[2] ＋ data[1]"
      },
      {
        "label": "キ",
        "textJa": "data[3] ＋ 2 × data[i － 1] ＋ data[i － 2]"
      },
      {
        "label": "ク",
        "textJa": "data[3] ＋ 2 × data[i － 2] ＋ data[i － 1]"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。递归式为f(n)=2f(n－2)＋f(n－1)。在循环中，先执行data[1]←data[2]、data[2]←data[3]，此时data[1]保存上一轮的f(n－2)，data[2]保存f(n－1)，应写入2×data[1]＋data[2]。例如i=3时三项是1、1、1，得到f(3)=3；i=4时数组变为1、3、3，得到f(4)=2×1＋3=5。イ交换了两个系数；オ、カ多加了旧data[3]；ウ、エ、キ、ク用循环变量作数组下标，i较大时会访问只有3个元素的数组之外。",
    "transcriptionNoteZh": "原卷空栏以方框标示；纯文本中用［ a ］表示。保留了伪代码的逐行顺序和缩进。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_b_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2026-B-04",
    "kind": "official",
    "year": 2026,
    "section": "B",
    "number": 4,
    "topicZh": "数组实现单向链表",
    "stemJa": "問４ 次のプログラム中の［ a ］と［ b ］に入れる正しい答えの組合せを，\n解答群の中から選べ。ここで，配列の要素番号は 1 から始まる。\n\n単方向リストを，配列 dataList と配列 pointerList の二つの配列で表現する。\ndataList にリストの要素の値を格納し，pointerList にリストの次の要素に対応する\ndataList の要素番号を格納する。単方向リスト の先頭は， dataList[1] 及び\npointerList[1] の組みである。単方向リストの末尾に対応する pointerList の要素\nは未定義である。dataList のうち単方向リストの要素の値を格納していない要素と，\n対応する pointerList の要素は未定義である。\nプログラムが扱う dataList 及び pointerList の内容を図 1 に示す。先頭の次の要\n素の要素番号は，pointerList[1] に格納された 3 であり，値は dataList[3] に格納\nされた 20 である。その次の要素の要素番号は pointerList[3] に格納された 2 であり，\n値は dataList[2] に格納された 30 である。\n\n要素番号 1 2 3 4 5\ndataList 10 30 20 40\n\n要素番号 1 2 3 4 5\npointerList 3 4 2\n注記 網掛けはその要素が未定義であることを示す。\n図 1 dataList 及び pointerList の内容\n\n関数 orderList は，図 1 の dataList 及び pointerList で表現した単方向リストの\n値を，単方向リストの先頭からたどって順番に格納した配列を返す。関数 orderList\nが返す配列を図 2 に示す。\n\n要素番号 1 2 3 4\n 10 20 30 40\n図 2 関数 orderList が返す配列\n\n〔プログラム〕\n大域: 整数型の配列: dataList ← {10, 30, 20, 40, 未定義の値}\n大域: 整数型の配列: pointerList ← {3, 4, 2, 未定義の値, 未定義の値}\n\n○整数型の配列: orderList()\n  整数型: i, p ← 1\n  整数型の配列: linearList ← {}  // 要素数0の配列\n  for (i を 1 から dataListの要素数 まで 1 ずつ増やす)\n    linearListの末尾 に dataList[p]の値 を追加する\n    if (［ a ］ が 未定義)\n      繰返し処理を終了する\n    endif\n    p ← ［ b ］\n  endfor\n  return linearList",
    "options": [
      {
        "label": "ア",
        "textJa": "a：dataList[p]／b：i"
      },
      {
        "label": "イ",
        "textJa": "a：dataList[p]／b：pointerList[p]"
      },
      {
        "label": "ウ",
        "textJa": "a：pointerList[p]／b：i"
      },
      {
        "label": "エ",
        "textJa": "a：pointerList[p]／b：pointerList[p]"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。p 是当前结点在数组中的位置，dataList[p] 是其值；pointerList[p] 才存下一个结点的位置。每轮先把当前值追加到 linearList，再检查 pointerList[p] 是否未定义，若未定义说明当前已是尾结点，应停止；否则把 p 更新为 pointerList[p]。按题图依次走 p=1→3→2→4，取值10→20→30→40。若用循环变量 i 代替指针，就会按物理下标顺序读取，得不到链表逻辑顺序。",
    "transcriptionNoteZh": "原题为 IPA 公开科目 B 试卷；日语正文按原卷文字提取并补标方框空栏。图片为同一道原卷的完整页面，表格、图形及排版请以图片核对。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_b_ans.pdf",
    "page": 8,
    "imageAssets": [
      "question-images/fe-2026-b-04-p8.png",
      "question-images/fe-2026-b-04-p9.png"
    ]
  },
  {
    "id": "FE-2026-B-05",
    "kind": "official",
    "year": 2026,
    "section": "B",
    "number": 5,
    "topicZh": "独热编码",
    "stemJa": "問５ 次のプログラム中の［ a ］と［ b ］に入れる正しい答えの組合せを，\n解答群の中から選べ。ここで，配列の要素番号は 1 から始まる。\n\n一つの要素だけが 1 で他の要素が 0 であるような整数型の配列による表現を，本問\nでは One-Hot 表現という。関数 oneHotEncoding は，図のように，色の名前が格納さ\nれている要素数 1 以上の文字列型の配列を引数として受け取り，配列に含まれる色の\n名前（図の例では 3 種類）に基づいて，各要素を One-Hot 表現に変換し，整数型配列\nの配列に格納して返す。関数 oneHotEncoding における変換の例を図に示す。\n\n引数の例： {\"Red\", \"Green\", \"Blue\", \"Red\"}\n↓\n\"Red\"の One-Hot 表現  ： {1, 0, 0}\n\"Green\"の One-Hot 表現： {0, 1, 0}\n\"Blue\"のOne-Hot 表現 ： {0, 0, 1}\n↓\n引数の例に対応する戻り値： {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}, {1, 0, 0}}\n図 関数 oneHotEncoding における変換の例\n\n〔プログラム〕\n○整数型配列の配列: oneHotEncoding(文字列型の配列: colors)\n  整数型: i, j, k\n  文字列型の配列: colorVector ← {}  // 要素数0の配列\n  整数型の配列: tempVector\n  整数型配列の配列: oneHotVector ← {}  // 要素数0の配列\n\n  /* 名前一覧の作成 */\n  for (i を 1 から colorsの要素数 まで 1 ずつ増やす)\n    if (colorVector の要素のいずれにも colors[i]の値 が格納されていない)\n      colorVectorの末尾 に ［ a ］を追加する\n    endif\n  endfor\n\n  /* One-Hot表現への変換 */\n  for (j を 1 から colorsの要素数 まで 1 ずつ増やす)\n    tempVector ← {}  // 要素数0の配列\n    for (k を 1 から colorVectorの要素数 まで 1 ずつ増やす)\n      if (［ b ］)\n        tempVectorの末尾 に 1 を追加する\n      else\n        tempVectorの末尾 に 0 を追加する\n      endif\n    endfor\n    oneHotVectorの末尾 に tempVector を追加する\n  endfor\n  return oneHotVector",
    "options": [
      {
        "label": "ア",
        "textJa": "a：colors[i]の値／b：colorsの要素のいずれかにcolorVector[k]の値が格納されている"
      },
      {
        "label": "イ",
        "textJa": "a：colors[i]の値／b：colors[j]がcolorVector[k]と等しい"
      },
      {
        "label": "ウ",
        "textJa": "a：未定義の値／b：colorsの要素のいずれかにcolorVector[k]の値が格納されている"
      },
      {
        "label": "エ",
        "textJa": "a：未定義の値／b：colors[j]がcolorVector[k]と等しい"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。第一轮遍历原始 colors，若某个颜色首次出现，就把实际的 colors[i] 值放到去重后的 colorVector；写未定义值无法建立颜色列表。第二轮对每个原始 colors[j] 建一个向量，依次与 colorVector[k] 的第 k 种颜色比较，匹配时写1，否则写0。因此 b 必须比较当前元素与当前候选颜色。ア只问某颜色是否出现在整个原数组，几乎每个候选都会满足，无法只留一个1。",
    "transcriptionNoteZh": "原题为 IPA 公开科目 B 试卷；日语正文按原卷文字提取并补标方框空栏。图片为同一道原卷的完整页面，表格、图形及排版请以图片核对。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_b_ans.pdf",
    "page": 10,
    "imageAssets": [
      "question-images/fe-2026-b-05-p10.png",
      "question-images/fe-2026-b-05-p11.png"
    ]
  },
  {
    "id": "FE-2026-B-06",
    "kind": "official",
    "year": 2026,
    "section": "B",
    "number": 6,
    "topicZh": "云服务日志访问控制",
    "stemJa": "問６ A 社は，従業員 1,000 名の広告代理店である。A 社では，各部署が A 社の社内ネッ\nトワークに設置したファイルサーバを，設置した部署の運用担当者が管理している。\n各部署で新たなクラウドサービスを利用する場合，各部署の責任者の承認のもと契約\nし，各部署の運用担当者が管理している。\n 営業部では，営業部が A 社の社内ネットワークに設置したファイルサーバ（以下，\nY サーバという）及び顧客管理のためのクラウドサービス（以下，Z サービスという）\nを利用している。営業部の各従業員には Y サーバの一般利用者アカウントが割り当て\nられ，Y サーバ上の全てのファイルが編集可能である。また，営業部の各従業員には，\nZ サービスの一般利用者アカウントが割り当てられ，営業部の運用担当者には，Y サ\nーバと Z サービスの管理者アカウントが割り当てられている。\n 情報セキュリティ部門では，クラウドサービスに関連した情報セキュリティインシ\nデントの発生に備えて，各部署で利用しているクラウドサービスのログ管理に関する\nルールを図 1 のとおりに整備した。\n\n1. ログの取得\n次のログを取得すること\n・ログイン及びログアウトのログ（以下，ログインログという）\n・クラウドサービスでの重要な操作及びその成否に関するログ\n2. ログの項目\n少なくとも次が記録されること\n・対象のアカウント名，日本標準時での日時，操作内容\n3. ログのアクセス管理\n・運用担当者だけがログにアクセスできるようにすること\n・クラウドサービスからログをエクスポートして保管する場合は，社内ネットワークに設置\nした自部署のファイルサーバにログを保管し，運用担当者だけがアクセスできるようにす\nること\n・運用担当者は複数名にすること\n・クラウドサービスへの運用担当者のログインには，2 要素認証を必要とすること\n4. ログの保存期間\n・少なくとも過去 1 年間のログが参照できるようにすること\n5. 改ざんへの対策\n・ログは運用担当者でも書込み及び消去ができないようにすること\n図 1 各部署で利用しているクラウドサービスのログ管理に関するルール\n\n 営業部の情報セキュリティリーダーである B 課長は，運用担当者の C 主任及び情報\nセキュリティ部門の協力を得て，図 1 のルールが順守されているかどうかを調査した。\n\nB 課長は，Z サービスでの現在の運用の中で，図 1 のルールに違反しているものを表 1\nのとおりまとめた。\n\n表 1 図 1 のルールに違反している現在の運用\n項番 現在の運用\n(一) Z サービスのログは，空き容量が一定値以下になった場合，古いログから上書\nきされる。\n(二)\nZ サービスの運用は，営業部の C 主任と D 主任の 2 名で担当していたが，D 主\n任が先月退職したので，現在は C 主任だけである。\n(三) Z サービスのログの日時は，UTC で記録されている。\n(四) Z サービスのログは，毎月末に全てエクスポートし， Y サーバに保管してい\nる。\n\n設問 表 1 中の運用のうち，図 1 のルール 3 に違反しているものの項番だけを全て挙げ\nた組合せを，解答群の中から選べ。",
    "options": [
      {
        "label": "ア",
        "textJa": "(一)，(二)"
      },
      {
        "label": "イ",
        "textJa": "(一)，(二)，(三)"
      },
      {
        "label": "ウ",
        "textJa": "(一)，(二)，(四)"
      },
      {
        "label": "エ",
        "textJa": "(一)，(三)"
      },
      {
        "label": "オ",
        "textJa": "(一)，(三)，(四)"
      },
      {
        "label": "カ",
        "textJa": "(一)，(四)"
      },
      {
        "label": "キ",
        "textJa": "(二)，(三)"
      },
      {
        "label": "ク",
        "textJa": "(二)，(三)，(四)"
      },
      {
        "label": "ケ",
        "textJa": "(二)，(四)"
      },
      {
        "label": "コ",
        "textJa": "(三)，(四)"
      }
    ],
    "answer": "ケ",
    "explanationZh": "正确答案ケ，即（二）与（四）。题目只问图1的规则3“日志访问管理”。（二）现仅有C主任一名运维人员，违反规则3要求多人；（四）把日志导出到Y服务器，而营业部所有员工都能编辑Y服务器的全部文件，违反仅运维人员可访问的要求。（一）旧日志因空间不足被覆盖，涉及至少保留一年的规则4，也可能触及防篡改的规则5；（三）UTC而非日本标准时间，违反日志项目的规则2。不要把所有违规项都选进来，先圈定被问的规则编号。",
    "transcriptionNoteZh": "原题为 IPA 公开科目 B 试卷；日语正文按原卷文字提取并补标方框空栏。图片为同一道原卷的完整页面，表格、图形及排版请以图片核对。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/rcu1hd0000012qj6-att/2026r08_fe_kamoku_b_ans.pdf",
    "page": 12,
    "imageAssets": [
      "question-images/fe-2026-b-06-p12.png",
      "question-images/fe-2026-b-06-p13.png"
    ]
  },
  {
    "id": "FE-2025-A-01",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 1,
    "topicZh": "人工智能与模型微调",
    "stemJa": "大規模言語モデルを用いた自然言語処理において，事前学習済みのモデルに対して行う，ファインチューニングに関する記述として，最も適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "強化学習を行い，最適な結果が得られるようにする。"
      },
      {
        "label": "イ",
        "textJa": "事前学習と同じデータを繰り返し用いて学習を行い，モデルの精度を高めるようにする。"
      },
      {
        "label": "ウ",
        "textJa": "大量のテキストデータを用いて学習を行い，モデルの精度を高めるようにする。"
      },
      {
        "label": "エ",
        "textJa": "特定のデータを用いて追加で学習を行い，目的とするタスクに適用できるようにする。"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。微调的起点是已经完成预训练的模型，再用面向特定任务的数据继续训练，使模型适应该任务。ア只说采用强化学习：强化学习可以用于某些训练阶段，但它并不是这里所问的微调定义。イ只是重复预训练数据，没有体现面向目标任务的适配。ウ描述用大量文本建立通用能力，更接近预训练。抓住“先有预训练模型，再用特定数据追加训练”即可判断。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 2
  },
  {
    "id": "FE-2025-A-02",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 2,
    "topicZh": "浮点数与误差",
    "stemJa": "浮動小数点形式で表現された数値の演算結果における丸め誤差の説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "演算結果がコンピュータの扱える最大値を超えることによって生じる誤差である。"
      },
      {
        "label": "イ",
        "textJa": "数表現のけた数に限度があるので，最下位けたより小さい部分について四捨五入や切上げ，切捨てを行うことによって生じる誤差である。"
      },
      {
        "label": "ウ",
        "textJa": "乗除算において，指数部が小さい方の数値の仮数部の下位部分が失われることによって生じる誤差である。"
      },
      {
        "label": "エ",
        "textJa": "絶対値がほぼ等しい数値の加減算において，上位の有効数字が失われることによって生じる誤差である。"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。浮点数可保存的有效位数有限，结果多出的低位需要四舍五入、向上舍入或截断，由此产生的差就是舍入误差。ア指结果超过表示上限，属于溢出。ウ把指数对齐造成低位丢失的现象放到了乘除法中；指数对齐主要出现在浮点加减法，而且这不是本题所描述的舍入定义。エ描述绝对值接近的数进行有效相减时，高位有效数字相互抵消的“消去误差（桁落ち）”；同号相减和异号相加都可能发生。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 2
  },
  {
    "id": "FE-2025-A-03",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 3,
    "topicZh": "二叉搜索树与中序顺序",
    "stemJa": "図の木構造は 2 分探索木である。a～g の値の大小関係として，適切なものはどれか。ここで，a～g の値は重複しないものとする。\n図の文字表記：根は a。a の左の子は b，右の子は c。b の左の子は d，右の子は e。c の左の子は f，右の子は g。",
    "options": [
      {
        "label": "ア",
        "textJa": "a ＜ b ＜ d ＜ e ＜ c ＜ f ＜ g"
      },
      {
        "label": "イ",
        "textJa": "d ＜ b ＜ e ＜ a ＜ f ＜ c ＜ g"
      },
      {
        "label": "ウ",
        "textJa": "d ＜ e ＜ f ＜ g ＜ b ＜ c ＜ a"
      },
      {
        "label": "エ",
        "textJa": "g ＜ f ＜ c ＜ e ＜ d ＜ b ＜ a"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。二叉搜索树的规则是：每个节点左子树中的值小于该节点，右子树中的值大于该节点；这个规则对所有子树都成立。从最左侧开始按‘左子树→节点→右子树’读取（中序遍历），左半棵树得到 d＜b＜e；然后是根 a；右半棵树得到 f＜c＜g，因此完整顺序是 d＜b＜e＜a＜f＜c＜g。ア把根 a 排到了最小，与左子树应小于 a 的规则冲突。ウ把 b 放在 e、f、g 后面，エ把右子树的 g 排到最小，都违反了左右子树的大小限制。这里判断的是节点值，不是字母本身的字典顺序。",
    "transcriptionNoteZh": "原题二叉树图改写为父子关系文字；节点与左右位置未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 3
  },
  {
    "id": "FE-2025-A-04",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 4,
    "topicZh": "系统可靠性与可用率",
    "stemJa": "MTBF は 4,000 時間，MTTR は 1,000 時間の装置がある。今後の 6 年間は，予防保守によって MTBF を前年に比べて毎年 100 時間ずつ改善し，遠隔保守によって MTTR を前年に比べて毎年 100 時間ずつ改善していく計画である。6 年経過後の稼働率は幾らか。",
    "options": [
      {
        "label": "ア",
        "textJa": "0.88"
      },
      {
        "label": "イ",
        "textJa": "0.90"
      },
      {
        "label": "ウ",
        "textJa": "0.92"
      },
      {
        "label": "エ",
        "textJa": "0.94"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。稼働率（可用率）＝MTBF÷（MTBF＋MTTR）。6 年后，平均故障间隔 MTBF 为 4,000＋6×100＝4,600 小时；平均修复时间 MTTR 为 1,000－6×100＝400 小时。因此可用率＝4,600÷（4,600＋400）＝0.92。其余三个数值都与代入后的计算结果不符。易错点是只调整其中一个指标，或把 MTTR 的改善误作增加。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 3
  },
  {
    "id": "FE-2025-A-05",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 5,
    "topicZh": "低代码开发",
    "stemJa": "ローコード開発ツールを用いたソフトウェア開発の説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "アプリケーションソフトウェアの開発基盤の上で，用意された部品やテンプレートを GUI を用いた操作で組み合わせたり，必要に応じて一部の処理のソースコードを記述したりすることによって，アプリケーションソフトウェアを作成する。"
      },
      {
        "label": "イ",
        "textJa": "アプリケーションソフトウェアの開発基盤の上で，用意された部品やテンプレートを GUI を用いた操作で組み合わせるだけで，ソースコードを記述せずに，アプリケーションソフトウェアを作成する。"
      },
      {
        "label": "ウ",
        "textJa": "アプリケーションソフトウェアの定型的な枠組みを参照して，独自の処理のソースコードを記述することによって，アプリケーションソフトウェアを作成する。"
      },
      {
        "label": "エ",
        "textJa": "利用者がシステムを利用して行う作業を自動化ツールに代行させるために，利用者によるシステムの操作手順をツールに登録する。"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。低代码开发用可视化组件和模板完成大部分工作，但仍允许在需要时编写少量源代码。イ强调完全不写代码，描述的是无代码开发。ウ依靠框架再自行编写处理逻辑，仍以代码开发为中心。エ是将用户操作步骤交给工具执行的 RPA 思路，解决的是操作自动化，而不是这种应用开发方式。关键词是“GUI 组合”加“必要时写一部分代码”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 4
  },
  {
    "id": "FE-2025-A-06",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 6,
    "topicZh": "SQL IN 与 OR 条件",
    "stemJa": "“商品”表に対する SQL 文と同じ結果が得られる SELECT 文はどれか。\n商品\n商品ID 商品名称 仕入先ID 単価\nS001 冷蔵庫 M001 155,000\nS002 食器洗い機 M002 85,000\nS003 電子レンジ M003 78,000\nS004 炊飯器 M003 32,000\nS005 コーヒーメーカー M004 15,000\nS006 ホットプレート M004 12,000\n〔SQL 文〕\nSELECT * FROM 商品 WHERE 仕入先ID IN ('M002', 'M004')",
    "options": [
      {
        "label": "ア",
        "textJa": "SELECT * FROM 商品 WHERE 仕入先ID = 'M002' AND 仕入先ID = 'M004'"
      },
      {
        "label": "イ",
        "textJa": "SELECT * FROM 商品 WHERE 仕入先ID = 'M002'\nINTERSECT\nSELECT * FROM 商品 WHERE 仕入先ID = 'M004'"
      },
      {
        "label": "ウ",
        "textJa": "SELECT * FROM 商品 WHERE 仕入先ID = 'M002' OR 仕入先ID = 'M004'"
      },
      {
        "label": "エ",
        "textJa": "SELECT * FROM 商品 WHERE 仕入先ID BETWEEN 'M002' AND 'M004'"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。`WHERE` 后面是筛选条件，`IN ('M002','M004')` 表示供货商 ID 是 M002 或 M004 中的任意一个。因此可以展开为‘ID = M002 OR ID = M004’，会选到表中的 S002、S005、S006。ア的 AND 要求同一行的同一个 ID 同时等于两个不同值，不可能成立。イ的 INTERSECT 求两次查询结果的交集；同一行也不可能同时属于两个不同的供货商，所以结果为空。エ的 BETWEEN 是包含两端的连续范围，M003 也落在 M002～M004 之间，会额外选到 S003、S004。判断 SQL 选择题时可先在实际表中圈出结果行，再检查每个选项是否恰好返回同一组。",
    "transcriptionNoteZh": "原题商品表改为逐行文字排列，字段、数据和 SQL 语句未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2025-A-07",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 7,
    "topicZh": "数据量、链路速率与利用率",
    "stemJa": "1G バイトの動画データを 40M ビット／秒の回線を使用してダウンロードしたところ，5 分掛かった。このときの回線利用率はおよそ何％か。ここで，ダウンロード時には動画データに 20％の制御情報が付加されるものとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "10"
      },
      {
        "label": "イ",
        "textJa": "53"
      },
      {
        "label": "ウ",
        "textJa": "67"
      },
      {
        "label": "エ",
        "textJa": "80"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ，约 80%。先统一单位：1 字节＝8 位，所以 1 G 字节视频约为 8 G 位，即 8,000 M 位。传输时另加相当于视频数据 20% 的控制信息，线路实际运送的数据约为 8,000×1.2＝9,600 M 位。线路在 5 分钟即 300 秒内的理论最大传送量是 40 M 位/秒×300 秒＝12,000 M 位。因此利用率约为 9,600÷12,000×100%＝80%。ア、イ、ウ都不是这个比值；尤其若只用视频数据计算，会得到约 67%（ウ），漏掉题目明确说的 20% 控制信息。G、M 的换算按题目‘およそ’的近似值处理。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2025-A-08",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 8,
    "topicZh": "HTTPS 与服务器证书",
    "stemJa": "HTTP と HTTPS を比較した場合において，HTTPS だけがもつ特徴を示したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "cookie に保存されている情報を用いたセッション管理が可能である。"
      },
      {
        "label": "イ",
        "textJa": "ID とパスワードによって利用者の認証を行うことが可能である。"
      },
      {
        "label": "ウ",
        "textJa": "Web ブラウザでキャッシュさせることによって通信量を減らすことが可能である。"
      },
      {
        "label": "エ",
        "textJa": "通信相手先サーバをサーバ証明書によって確認することが可能である。"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。HTTPS 在 HTTP 通信中使用 TLS，连接时可检查服务器提供的证书，用于确认所连接服务器的身份。ア的 Cookie 会话管理、イ的账号密码登录、ウ的浏览器缓存，在普通 HTTP 上也能实现，因此不构成 HTTPS 独有特征。注意服务器证书验证的是通信对端身份；不要把它与网站上的用户登录混为一谈。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2025-A-09",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 9,
    "topicZh": "密码技术的危殆化",
    "stemJa": "暗号の危殆化に該当するものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "ある CA でデジタル証明書の署名に使っている公開鍵のデジタル証明書の有効期限が切れた。"
      },
      {
        "label": "イ",
        "textJa": "ある暗号アルゴリズムの秘密鍵が不正アクセスによって漏えいした。"
      },
      {
        "label": "ウ",
        "textJa": "あるハッシュ関数においてハッシュ値が同じになるデータの組みを現実的な時間内で発見する方法が見つかった。"
      },
      {
        "label": "エ",
        "textJa": "あるランサムウェアの一種で暗号化されたファイルの復号鍵が公開された。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。“危殆化”指密码算法原本依赖的安全性变得不足。若能在现实可行的时间内找到同一哈希值对应的不同数据，抗碰撞这一安全性质就被破坏，因此属于哈希算法的危殆化。ア是证书到期，属于证书有效期管理。イ是某把秘密密钥泄漏，问题发生在密钥保管。エ是特定勒索软件所用文件解密密钥公开，不能据此认定密码算法本身已不安全。判断时要区分“算法被攻破”和“证书、密钥出了问题”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2025-A-10",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 10,
    "topicZh": "WAF 与安全设备",
    "stemJa": "WAF の説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "Web サイトに対するアクセス内容を監視し，攻撃とみなされるパターンを検知したときに当該アクセスを遮断する。"
      },
      {
        "label": "イ",
        "textJa": "Wi-Fi アライアンスが認定した無線 LAN の暗号化方式の規格であり，AES 暗号に対応している。"
      },
      {
        "label": "ウ",
        "textJa": "様々なシステムの動作ログを一元的に蓄積，管理し，セキュリティ上の脅威となる事象をいち早く検知，分析する。"
      },
      {
        "label": "エ",
        "textJa": "ファイアウォール機能を有し，マルウェア対策機能，侵入検知機能などの複数のセキュリティ機能を連携させ，統合的に管理する。"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。WAF（Web 应用防火墙）检查访问 Web 站点的请求内容，识别攻击模式并拦截可疑访问。イ说的是无线 LAN 加密标准，不是 Web 防护。ウ描述集中收集并分析多系统日志的 SIEM。エ描述将防火墙、恶意软件防护、入侵检测等功能整合的 UTM。区分方法是看防护对象：WAF 重点检查进入 Web 应用的访问内容。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2025-A-11",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 11,
    "topicZh": "E-R 模型",
    "stemJa": "E-R モデルにおけるエンティティの特徴はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "エンティティとインスタンスとは，1 対 1 の対応関係をとる。"
      },
      {
        "label": "イ",
        "textJa": "エンティティとなり得るものは，物的に実現するものである。"
      },
      {
        "label": "ウ",
        "textJa": "エンティティは，特性を表すための属性（アトリビュート）をもつ。"
      },
      {
        "label": "エ",
        "textJa": "異なった種類のエンティティ間の関係は，主として状態遷移として表現される。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。E-R 模型中的实体具有描述其特征的属性，例如“商品”实体可有商品 ID 和名称。ア错在一个实体类型通常对应多个具体实例，而不是固定一对一。イ错在实体也可以是订单、交易等抽象的业务对象，不要求有实体形态。エ错在不同实体间用“关系”表示联系，例如顾客下订单；状态转移不是 E-R 模型表达实体关系的主要方式。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 7
  },
  {
    "id": "FE-2025-A-12",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 12,
    "topicZh": "面向对象与多态",
    "stemJa": "オブジェクト指向プログラミングの特徴のうち，異なるクラスのオブジェクトを同一のインタフェースで操作したときに，操作対象クラスに応じた異なる動作を可能にすることを何と呼ぶか。",
    "options": [
      {
        "label": "ア",
        "textJa": "委譲"
      },
      {
        "label": "イ",
        "textJa": "継承"
      },
      {
        "label": "ウ",
        "textJa": "コンポジション"
      },
      {
        "label": "エ",
        "textJa": "多相性"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ，即多态性：调用同一接口时，实际执行的处理会随对象所属的类而变化。例如对不同图形调用同一个“绘制”操作，各自完成不同绘制。ア“委譲”是把处理交给另一个对象；イ“継承”是子类沿用或扩展父类性质；ウ“コンポジション”是通过包含其他对象来组合功能。题眼是“同一接口”和“按对象类型表现出不同动作”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 7
  },
  {
    "id": "FE-2025-A-13",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 13,
    "topicZh": "Scrum 与产品待办列表",
    "stemJa": "アジャイル開発手法の一つであるスクラムにおいて，プロダクトバックログアイテムの内容や並び順を決定する役割をもつのは誰か。",
    "options": [
      {
        "label": "ア",
        "textJa": "開発者"
      },
      {
        "label": "イ",
        "textJa": "顧客"
      },
      {
        "label": "ウ",
        "textJa": "スクラムマスタ"
      },
      {
        "label": "エ",
        "textJa": "プロダクトオーナ"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。产品负责人（プロダクトオーナ）对产品待办列表负责，决定待办事项的内容和排序，使团队优先完成更有价值的工作。ア开发者负责实施并规划具体开发工作，但不承担题中这项产品待办列表责任。イ客户可提供需求与反馈，却不是 Scrum 在此处指定的角色。ウ Scrum Master 帮助团队理解并实践 Scrum，也不负责决定待办事项的内容和顺序。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 7
  },
  {
    "id": "FE-2025-A-14",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 14,
    "topicZh": "多条虚活动的项目最短工期",
    "stemJa": "図は，あるプロジェクトの作業A～Iとその作業日数を表している。このプロジェクトの最短所要日数は何日か。",
    "options": [
      {
        "label": "ア",
        "textJa": "27"
      },
      {
        "label": "イ",
        "textJa": "28"
      },
      {
        "label": "ウ",
        "textJa": "29"
      },
      {
        "label": "エ",
        "textJa": "31"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ，31 天。箭线图的节点只有在所有进入它的作业都完成后才能开始后续工作；虚线虽不耗时，也传递等待关系。开始后 A 用 3 天。B 用 6 天，到中间节点最早第 9 天；E 用 5 天到第 8 天，经虚活动也已满足，因此仍取第 9 天。从中间节点，C 用 8 天到第 17 天，G 用 11 天到第 20 天；经 G 后的虚活动要求右侧汇合节点至少等到第 20 天，F 从 A 后节点用 14 天到第 17 天。于是 D 在第 20 天后用 6 天，到第 26 天。H 从中间节点用 15 天，第 24 天结束，最终汇合要等 D 到第 26 天；再做 I 5 天，共 31 天。其余 27、28、29 天都漏掉一条较慢的前置路线。",
    "transcriptionNoteZh": "A～I 的箭线、天数及两条虚活动完整保留在官方题目图片中。",
    "imageAssets": [
      "question-images/fe-2025-a-14.png"
    ],
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2025-A-15",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 15,
    "topicZh": "服务器机房的物理安全",
    "stemJa": "サーバ室の物理的な安全対策の状況について，情報セキュリティ管理基準（平成 28 年）に照らして，情報セキュリティ監査を行って判明した状況のうち，監査人が，指摘事項として監査報告書に記載すべきものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "サーバが設置されている施設の無人領域では，営業時間中でも，警報装置が作動するようになっている。"
      },
      {
        "label": "イ",
        "textJa": "サーバ室に非常口，避難器具，誘導灯などを設置している。"
      },
      {
        "label": "ウ",
        "textJa": "社外からサーバ室へ直接出入りするドアを設置しているが，出入りを考慮して常時施錠していない。"
      },
      {
        "label": "エ",
        "textJa": "場所が分からないように，サーバ室の所在を室外に表示していない。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。题目问的是审计发现的‘应当指出的问题’，要寻找使未经授权者更容易接近服务器的做法。社外人员可直接进入机房的门若长期不上锁，就削弱了限制进入的物理防护，存在被未经许可人员接触设备的风险。ア是在无人区域仍启用报警，有助于发现异常；イ设置紧急出口、避难设备和指示灯是人员安全措施；エ不在室外标示机房位置可以减少无关人员得知位置的机会。这三项本身不构成题目所找的缺陷。不要因为‘方便出入’就忽略机房应有的出入控制；实际管理仍需兼顾依法要求的紧急疏散。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2025-A-16",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 16,
    "topicZh": "数据挖掘与购物篮分析",
    "stemJa": "データマイニングの手法の一つであって，POS などの蓄積データから“一緒に買われる商品”の組合せを発見する分析手法はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "3C 分析"
      },
      {
        "label": "イ",
        "textJa": "ABC 分析"
      },
      {
        "label": "ウ",
        "textJa": "コンジョイント分析"
      },
      {
        "label": "エ",
        "textJa": "マーケットバスケット分析"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。“一起购买”的商品组合对应购物篮分析：以交易记录为单位，寻找哪些商品经常共同出现在同一次购买中。ア的 3C 分析从顾客、竞争者和自身企业三个角度分析经营环境。イ的 ABC 分析按销售额、库存价值等贡献度给项目分级。ウ的联合分析研究商品属性组合对消费者选择的影响。题目特别给出 POS 积累数据和“同时购买”，直接指向购物篮分析。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 9
  },
  {
    "id": "FE-2025-A-17",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 17,
    "topicZh": "生成式 AI 与退出训练",
    "stemJa": "インターネット上の生成 AI サービスを利用する際に，オプトアウトを設定することはどのような場合に有効か。",
    "options": [
      {
        "label": "ア",
        "textJa": "個々の利用者が，自身が生成 AI から得た情報に対して，著作権を主張したい場合"
      },
      {
        "label": "イ",
        "textJa": "個々の利用者が入力した情報を，生成 AI の学習に利用させたくない場合"
      },
      {
        "label": "ウ",
        "textJa": "個々の利用者が入力した情報を，生成 AI を通じて，他の利用者にも知ってほしい場合"
      },
      {
        "label": "エ",
        "textJa": "生成 AI から得た情報の信ぴょう性を高めたい場合"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。题中的“オプトアウト”指用户明确选择退出某种数据使用；在生成 AI 服务的这个语境中，是不希望自己输入的信息被用于模型学习。ア涉及生成内容的著作权归属，退出数据使用不能决定著作权。ウ希望信息传播，与退出训练用途的方向相反。エ涉及输出事实是否可靠，退出设置不会提高答案可信度。实际使用服务时还应查看其设置说明，确认退出选项涵盖哪些数据用途。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 9
  },
  {
    "id": "FE-2025-A-18",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 18,
    "topicZh": "长尾销售模式",
    "stemJa": "物販事業において，ロングテールをビジネスとして成功させるために必要な施策はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "多くの有名ブランド店が出店するショッピングモールの構築"
      },
      {
        "label": "イ",
        "textJa": "交通の利便性が高い地域に対する，生活必需品を広く浅く取りそろえた出店計画"
      },
      {
        "label": "ウ",
        "textJa": "店舗で購入した商品を近隣地域に無償で配送するサービスの実施"
      },
      {
        "label": "エ",
        "textJa": "豊富な品ぞろえと，在庫コストや配送費用を抑えるための大規模な物流センタの構築や活用"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。长尾指大量单品销量不高的小众商品，合起来也可能形成有价值的销售额。要卖这些商品，首先要有足够丰富的品种；但每种商品周转慢，若库存和配送成本过高，利润会被吞掉，所以还要有能降低这些成本的物流能力。エ同时满足‘丰富品种’和‘控制成本’。ア聚焦知名品牌，イ是交通便利的实体店选址，ウ是附近免费配送；它们都没有解决长尾商品品种多、单品销量少这一核心问题。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 9
  },
  {
    "id": "FE-2025-A-19",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 19,
    "topicZh": "固定成本、边际收益与盈亏计算",
    "stemJa": "表の条件で喫茶店を開業したい。月 10 万円の利益を出すためには，1 客席当たり 1 日平均何人の客が必要か。\n客 1 人当たりの売上高 500 円\n客 1 人当たりの変動費 100 円\n固定費 300,000 円／月\n1 か月の営業日数 20 日\n客席数 10 席",
    "options": [
      {
        "label": "ア",
        "textJa": "3.75"
      },
      {
        "label": "イ",
        "textJa": "4"
      },
      {
        "label": "ウ",
        "textJa": "4.2"
      },
      {
        "label": "エ",
        "textJa": "5"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ，即每座每天平均 5 人。每位顾客付 500 日元，其中 100 日元是随着顾客人数增加而增加的变动成本，所以每位顾客可用于覆盖固定费用并形成利润的金额是 500－100＝400 日元。每月要先覆盖 300,000 日元固定费，再赚 100,000 日元，所需总贡献额是 400,000 日元；因此每月需要 400,000÷400＝1,000 人。一个月营业 20 天、共有 10 个座位，平均每座每天需要 1,000÷20÷10＝5 人。不要拿营业额 500 直接去除固定费，因为没有扣除每位顾客的变动费。原题表格在此按行展示，数值不变。",
    "transcriptionNoteZh": "原题表格改为逐行文字排列，数值和选项未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 10
  },
  {
    "id": "FE-2025-A-20",
    "kind": "official",
    "year": 2025,
    "section": "A",
    "number": 20,
    "topicZh": "产品生命周期与碳足迹",
    "stemJa": "カーボンフットプリントの説明として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "温室効果ガスの排出量から吸収量と除去量を差し引いた合計をゼロにする取組"
      },
      {
        "label": "イ",
        "textJa": "原材料調達から廃棄・リサイクルに至るまでのライフサイクル全体を通して排出される温室効果ガスの排出量を，CO2 量に換算して，その値を商品やサービスに表示すること"
      },
      {
        "label": "ウ",
        "textJa": "自動車のエンジンから排出される一酸化炭素，窒素酸化物や炭化水素類などの大気汚染物質の排出量の定め"
      },
      {
        "label": "エ",
        "textJa": "商品がどのような場所で作られて，流通し，販売されているかを把握するための仕組み"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。题目中的碳足迹把商品或服务从原料取得、制造、运输、使用到废弃和回收整个生命周期产生的温室气体排放，换算成二氧化碳当量，再作为数值呈现。‘生命周期全体’与‘CO2 换算’是两个关键字。ア描述排放与吸收、去除相抵后净值为零的目标或举措；ウ是汽车大气污染物排放规定，涉及的物质和范围都不同；エ描述追踪生产流通地点的信息机制，并没有衡量温室气体。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_a_ans.pdf",
    "page": 10
  },
  {
    "id": "FE-2025-B-01",
    "kind": "official",
    "year": 2025,
    "section": "B",
    "number": 1,
    "topicZh": "寻找范围内的4的倍数",
    "stemJa": "問１ 次のプログラム中の［ a ］と［ b ］に入れる正しい答えの組合せを，\n解答群の中から選べ。\n\n関数 function1 が受け取る引数と，関数 function2 が受け取る引数とが同じとき，\n二つの関数は同じ値を返す。ここで，引数 n と引数 m は正の整数であり，引数 m は引\n数 n よりも 10 以上大きい数とする。\n\n〔プログラム〕\n○整数型: function1(整数型: n, 整数型: m)\n  整数型: count ← 0\n  整数型: i\n  for (iをnからmまで1ずつ増やす)\n    if ((i mod 4)が0と等しい)\n      count ← count ＋ 1\n    endif\n  endfor\n  return count\n\n○整数型: function2(整数型: n, 整数型: m)\n  整数型: count ← 0\n  整数型: tempN ← n\n  整数型: i, j\n  for (［ a ］)\n    if ((tempN mod 4)が0と等しい)\n      繰返し処理を終了する\n    endif\n    tempN ← tempN ＋ 1\n  endfor\n\n  for (［ b ］)\n    count ← count ＋ 1\n  endfor\n  return count",
    "options": [
      {
        "label": "ア",
        "textJa": "a：iを1から2まで1ずつ増やす／b：jをnから始めてmを超えない範囲でtempNずつ増やす"
      },
      {
        "label": "イ",
        "textJa": "a：iを1から2まで1ずつ増やす／b：jをtempNからmまで1ずつ増やす"
      },
      {
        "label": "ウ",
        "textJa": "a：iを1から2まで1ずつ増やす／b：jをtempNから始めてmを超えない範囲で4ずつ増やす"
      },
      {
        "label": "エ",
        "textJa": "a：iを1から3まで1ずつ増やす／b：jをnから始めてmを超えない範囲でtempNずつ増やす"
      },
      {
        "label": "オ",
        "textJa": "a：iを1から3まで1ずつ増やす／b：jをtempNからmまで1ずつ増やす"
      },
      {
        "label": "カ",
        "textJa": "a：iを1から3まで1ずつ増やす／b：jをtempNから始めてmを超えない範囲で4ずつ増やす"
      }
    ],
    "answer": "カ",
    "explanationZh": "正确答案カ。function1 逐个检查 n 到 m 的整数，把4的倍数计入 count。function2 应先把 tempN 从 n 调到第一个4的倍数；任意正整数最多加3次就能到下一个4的倍数，所以第一个循环 i 必须为1到3，且每次检测到可整除就提前退出。找到起点后，第二个循环从 tempN 开始，每次加4，直到超过 m，每次计数一次。因此 b 是从 tempN 起以4为步长的写法。仅试2次可能漏掉需要加3的情况。",
    "transcriptionNoteZh": "原题为 IPA 公开科目 B 试卷；日语正文按原卷文字提取并补标方框空栏。图片为同一道原卷的完整页面，表格、图形及排版请以图片核对。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_b_ans.pdf",
    "page": 4,
    "imageAssets": [
      "question-images/fe-2025-b-01-p4.png",
      "question-images/fe-2025-b-01-p5.png"
    ]
  },
  {
    "id": "FE-2025-B-02",
    "kind": "official",
    "year": 2025,
    "section": "B",
    "number": 2,
    "topicZh": "枚举与循环边界",
    "stemJa": "次のプログラム中の［ a ］に入れる正しい答えを，解答群の中から選べ。\n\n関数 change は，10 より大きい整数を引数 n で受け取り，1 円玉，5 円玉，10 円玉を使ってちょうど n 円にする組合せの総数を返す。\n\n例えば，12 円にする組合せは，次のように数えられる。10 円玉を使わない場合には，1 円玉と 5 円玉だけでちょうど 12 円にすることになる。その組合せは，使える 5 円玉の枚数が 0 以上 (12 ÷ 5 の商) 以下なので，(12 ÷ 5 の商) ＋ 1 ＝ 3 通りある。同様に，10 円玉を 1 枚使う場合には，1 円玉と 5 円玉だけでちょうど 2 円にすることになり，その組合せは (2 ÷ 5 の商) ＋ 1 ＝ 1 通りある。10 円玉を 2 枚以上使う組合せはない。よって，1 円玉，5 円玉，10 円玉を使ってちょうど 12 円にする組合せは，3 ＋ 1 ＝ 4 通りである。\n\n〔プログラム〕\n○整数型: change(整数型: n)\n    整数型: count ← 0\n    整数型: rest ← n\n    while (［ a ］)\n        count ← count ＋ (rest ÷ 5 の商) ＋ 1\n        rest ← rest － 10\n    endwhile\n    return count",
    "options": [
      {
        "label": "ア",
        "textJa": "rest ≧ 0"
      },
      {
        "label": "イ",
        "textJa": "rest ≧ 5"
      },
      {
        "label": "ウ",
        "textJa": "rest ≧ 10"
      },
      {
        "label": "エ",
        "textJa": "rest ＞ 0"
      },
      {
        "label": "オ",
        "textJa": "rest ＞ 5"
      },
      {
        "label": "カ",
        "textJa": "rest ＞ 10"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。每轮固定10日元硬币的枚数，rest是剩余金额；只要rest非负，就能用0到⌊rest/5⌋枚5日元硬币，缺口由1日元硬币填满，所以本轮增加⌊rest/5⌋＋1种。rest＝0仍有一种合法方案：剩余部分不用1元和5元，因此必须包含0。イ、ウ、オ、カ会遗漏rest为0或小于阈值但仍可用1元硬币支付的情况；エ只差等号，也会漏掉rest＝0。例如n=20，10元硬币用2枚的方案会被エ遗漏。",
    "transcriptionNoteZh": "原卷空栏以方框标示；纯文本中用［ a ］表示。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_b_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2025-B-03",
    "kind": "official",
    "year": 2025,
    "section": "B",
    "number": 3,
    "topicZh": "栈的入栈与出栈",
    "stemJa": "問３ 次のプログラム中の［ a ］と［ b ］に入れる正しい答え の組合せを，\n解答群の中から選べ。ここで，配列の要素番号は 1 から始まる。\n\n関数 push は，引数 で与えられた整数 をスタック に格納 する。格納できた場合は\ntrue を返し，格納できなかった場合は false を返す。\n関数 pop は，スタックから値を取り出して返す。スタックが空のときは未定義の値\nを返す。\nスタックを，要素数が 4 である大域の整数型の配列 stack，及び次に値を格納する\n位置を示す大域の変数 stackPos で表現する。スタックの初期状態を図に示す。\nプログラムでは，配列の領域外を参照してはならないものとする。\n\n要素番号 1 2 3 4\nstack 4 3\n   ↑\n   stackPos\n注記 網掛けはその要素が未定義であることを示す。\n図 スタックの初期状態\n\n〔プログラム〕\n大域: 整数型: stackPos ← 3\n大域: 整数型の配列: stack ← {4, 3, 未定義の値, 未定義の値}\n\n○論理型: push(整数型: inputData)\n  if (stackPos ≦ stackの要素数)\n    stack[［ a ］] ← inputData\n    stackPos ← stackPos ＋ 1\n    return true\n  else\n    return false\n  endif\n\n○整数型: pop()\n  整数型: popData ← 未定義の値\n  if (stackPos ＞ 1)\n    stackPos ← ［ b ］\n    popData ← stack[stackPos]\n    stack[stackPos] ← 未定義の値\n  endif\n  return popData",
    "options": [
      {
        "label": "ア",
        "textJa": "a：stackPos／b：stackPos ＋ 1"
      },
      {
        "label": "イ",
        "textJa": "a：stackPos／b：stackPos － 1"
      },
      {
        "label": "ウ",
        "textJa": "a：stackPos － 1／b：stackPos ＋ 1"
      },
      {
        "label": "エ",
        "textJa": "a：stackPos － 1／b：stackPos － 1"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。stackPos 表示“下一次要写入的位置”，初始为3，而 stack[1]=4、stack[2]=3。push 时应把新值写到 stack[stackPos]，然后 stackPos 加1。pop 时若非空，必须先把 stackPos 减1，才会回到最近一次写入的格子，再读取并清空它；因此 a=stackPos、b=stackPos－1。若 pop 反而加1会跳过栈顶，还可能越界；若 push 写 stackPos－1，则覆盖原栈顶。",
    "transcriptionNoteZh": "原题为 IPA 公开科目 B 试卷；日语正文按原卷文字提取并补标方框空栏。图片为同一道原卷的完整页面，表格、图形及排版请以图片核对。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_b_ans.pdf",
    "page": 8,
    "imageAssets": [
      "question-images/fe-2025-b-03-p8.png",
      "question-images/fe-2025-b-03-p9.png"
    ]
  },
  {
    "id": "FE-2025-B-04",
    "kind": "official",
    "year": 2025,
    "section": "B",
    "number": 4,
    "topicZh": "子串搜索比较次数",
    "stemJa": "問４ 次の記述中の［　］に入れる正しい答えを，解答群の中から選べ。 ここで，\n配列の要素番号は 1 から始まる。\n\n関数 search は，二つの文字型の配列を，それぞれ引数 data 及び key で受け取り，\ndata から，key の要素の並びと同じ並びを全て探し，その先頭の要素番号を全て格納\nした配列を返す。見つからなければ，要素数 0 の配列を返す。\n関数 search を search({\"a\", \"b\", \"a\", \"b\", \"c\", \"a\", \"b\", \"c\"}, {\"a\", \"b\",\n\"c\"}) として呼び出すと， /*** β ***/の行の条件式が真となる回数は\n［　］回である。\n\n〔プログラム〕\n/* keyは，要素数1以上の配列である */\n○整数型の配列: search(文字型の配列: data, 文字型の配列: key)\n  整数型: i, j, lenData, lenKey\n  整数型の配列: result ← {}  // 要素数0の配列\n\n  lenData ← dataの要素数\n  lenKey ← keyの要素数\n\n  /* (lenData － lenKey ＋ 1) が0以下のときは繰返し処理を実行しない */\n  for (i を 1 から (lenData － lenKey ＋ 1) まで 1 ずつ増やす)\n    for (j を 1 から lenKey まで 1 ずつ増やす)  // α\n      if (data[i ＋ j － 1] が key[j] と等しい)  /*** β ***/\n        if (j が lenKey と等しい)\n          resultの末尾 に iの値 を追加する\n        endif\n      else\n        αの行から始まる繰返し処理を終了する\n      endif\n    endfor\n  endfor\n  return result",
    "options": [
      {
        "label": "ア",
        "textJa": "1"
      },
      {
        "label": "イ",
        "textJa": "2"
      },
      {
        "label": "ウ",
        "textJa": "3"
      },
      {
        "label": "エ",
        "textJa": "4"
      },
      {
        "label": "オ",
        "textJa": "5"
      },
      {
        "label": "カ",
        "textJa": "6"
      },
      {
        "label": "キ",
        "textJa": "7"
      },
      {
        "label": "ク",
        "textJa": "8"
      },
      {
        "label": "ケ",
        "textJa": "9"
      },
      {
        "label": "コ",
        "textJa": "10"
      }
    ],
    "answer": "ク",
    "explanationZh": "正确答案ク，即8次。外层起点 i 可取1到6。i=1 时依次匹配 a、b 两个字符，第3个与 key 的 c 不同，真2次；i=2 起始 b 不等于 a，真0次；i=3 正好匹配 a、b、c，真3次；i=4 和 i=5 首字符都不符，均为0；i=6 再匹配 a、b、c，真3次。合计2＋0＋3＋0＋0＋3＝8。题问 β 条件“为真”的次数，不是循环总执行次数或找到的子串个数。",
    "transcriptionNoteZh": "原题为 IPA 公开科目 B 试卷；日语正文按原卷文字提取并补标方框空栏。图片为同一道原卷的完整页面，表格、图形及排版请以图片核对。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_b_ans.pdf",
    "page": 10,
    "imageAssets": [
      "question-images/fe-2025-b-04-p10.png"
    ]
  },
  {
    "id": "FE-2025-B-05",
    "kind": "official",
    "year": 2025,
    "section": "B",
    "number": 5,
    "topicZh": "列联表理论频数",
    "stemJa": "問５ 次の記述中の［ a ］と［ b ］に入れる正しい答えの組合せを，解答群\nの中から選べ。ここで，配列の要素番号は 1 から始まる。\n\n予防接種の病気 X に対する予防効果を調査するために集めたデータの集計結果を基\nに，病気 X にかかるかどうかが，予防接種の有無に影響されないと仮定した場合の人\n数を計算する。この人数を理論度数という。表 1 に集計結果の例を示し，表 2 に表 1\nを基に計算した理論度数を示す。\n関数 f は，引数 data で受け取った集計結果を基に計算した理論度数を返す。引数\nと戻り値は二次元配列で，その行が表の行，その列が表の列に対応する。\n\n表 1 集計結果の例\n\n 単位 人\n病気 X にかからなかった 病気 X にかかった\n予防接種を受けた 82 6\n予防接種を受けていない 58 8\n\n表 2 表 1 を基に計算した理論度数\n\n 単位 人\n病気 X にかからなかった 病気 X にかかった\n予防接種を受けた\n予防接種を受けていない\n注記 網掛けの部分は表示していない。\n\n〔プログラム〕\n○実数型の二次元配列: f(実数型の二次元配列: data)\n  実数型: t ← dataの要素の和\n  整数型: row ← dataの行数\n  整数型: col ← dataの列数\n  実数型の二次元配列: result ← {row行col列の 未定義の値}\n  整数型: r, c\n  for (r を 1 から row まで 1 ずつ増やす)\n    for (c を 1 から col まで 1 ずつ増やす)\n      result[r, c] ← (dataの行番号rの要素の和) ×\n                      (dataの列番号cの要素の和) ÷ t\n    endfor\n  endfor\n  return result\n表2の空欄：［ a ］は「予防接種を受けた／病気Xにかからなかった」，［ b ］は「予防接種を受けていない／病気Xにかかった」。",
    "options": [
      {
        "label": "ア",
        "textJa": "a：44／b：33"
      },
      {
        "label": "イ",
        "textJa": "a：58／b：8"
      },
      {
        "label": "ウ",
        "textJa": "a：70／b：7"
      },
      {
        "label": "エ",
        "textJa": "a：75／b：2"
      },
      {
        "label": "オ",
        "textJa": "a：80／b：6"
      },
      {
        "label": "カ",
        "textJa": "a：80／b：8"
      },
      {
        "label": "キ",
        "textJa": "a：82／b：6"
      }
    ],
    "answer": "オ",
    "explanationZh": "正确答案オ。表1行合计为接种者 82＋6＝88 人，未接种者 58＋8＝66 人；列合计为未患病 82＋58＝140 人，患病 6＋8＝14 人；总人数154。独立假设下，一个格的理论频数＝该行合计×该列合计÷总人数。图中 a 是“接种且未患病”，故 88×140÷154＝80；b 是“未接种且患病”，故 66×14÷154＝6。注意 b 指“未接种且患病”一格的理论频数6；“接种且患病”一格的实际观察数是6，按理论频数公式计算则是8。",
    "transcriptionNoteZh": "原题为 IPA 公开科目 B 试卷；日语正文按原卷文字提取并补标方框空栏。图片为同一道原卷的完整页面，表格、图形及排版请以图片核对。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_b_ans.pdf",
    "page": 12,
    "imageAssets": [
      "question-images/fe-2025-b-05-p12.png",
      "question-images/fe-2025-b-05-p13.png"
    ]
  },
  {
    "id": "FE-2025-B-06",
    "kind": "official",
    "year": 2025,
    "section": "B",
    "number": 6,
    "topicZh": "RPO、增量备份与批准责任",
    "stemJa": "問６ A 社は従業員 200 名の電子機器メーカーである。東京に本社があり，新潟に工場が\nある。\n A 社では，ファイルサーバを図 1 のように運用している。\n\n・ファイルサーバは本社と工場のサーバルームに設置している。\n・ファイルサーバは，磁気テープを使用してファイルのバックアップを取得している。\n・土曜日の午前 2 時からフルバックアップを取得し，翌週の火曜日と木曜日の午前 2 時から\n増分バックアップを取得している。\n・情報システム部の担当者は毎週月曜日，火曜日，木曜日の朝 10 時頃，バックアップジョ\nブの実行結果の確認と磁気テープの交換を行い，磁気テープは耐火金庫に保管している。\n・磁気テープには上書きモードでバックアップを取得し，1 か月分の磁気テープを世代管理\nしている。\n・これまで，フルバックアップからのリストアには平均して 4 時間，1 回の増分バックアッ\nプからは平均して 0.25 時間掛かっている。\n・A 社は ICT 継続のための試験を実施しており，ファイルサーバも試験対象である。\n注記 事業影響度分析の結果に基づき，ファイルサーバは，72 時間の目標復旧時点（RPO）と\n120 時間の目標復旧時間(RTO)が要求事項として定められている。\n図 1 A 社のファイルサーバの運用\n\nA 社は ISMS 認証を取得しており，最高情報セキュリティ責任者（CISO）を中心に\n情報セキュリティに取り組み，定期的に，情報セキュリティリスクアセスメントを行\nっている。今般，ISMS 認証基準が JIS Q 27001:2023 に改正されたことを受け，情報\nセキュリティリーダーの B さんは，新基準への移行審査に向けて準備することになっ\nた。改正によって新たに追加された情報セキュリティ管理策について，B さんは情報\nシステム部の担当者に取組状況を確認し，その評価結果を表 1 にまとめた。\n\n表 1 B さんの評価結果（抜粋）\n項番 情報セキュリティ管理策 評価結果\n1 （事業継続のための ICT の備え）事業継続の目的及び ICT 継続の\n要求事項に 基づいて，ICT の備えを計画 し，実施し，維持し，試\n験しなければならない。\n実施している\n\nB さんは，移行審査前の内部監査で，内部監査室から表 1 の項番 1 に関するファイ\nルサーバの運用について何点か質問を受け，表 2 のとおり回答した。\n\n表 2 内部監査室への B さんの回答（抜粋）\n項番 B さんの回答\n1 例えば， 金曜日の正午に障害が発生した場合， 少なくとも   の時点の デ\nータは復元しなければならない。\n2 例えば，木曜日の正午に障害が発生し，ファイルサーバの全データが消失した とす\nると，バックアップからのリストアには  時間掛かると予想される。\n3 ICT 継続の計画書は，  が承認している。\n\n設問 表 2 中の  ～  に入れる字句の適切な組合せを ，a に関す\nる解答群の中から選べ。\n表2の空欄：項番1の時点＝［ a1 ］，項番2の時間＝［ a2 ］，項番3の承認者＝［ a3 ］。",
    "options": [
      {
        "label": "ア",
        "textJa": "a1：月曜日の正午／a2：4.25／a3：CISO"
      },
      {
        "label": "イ",
        "textJa": "a1：月曜日の正午／a2：4.25／a3：情報システム部の担当者"
      },
      {
        "label": "ウ",
        "textJa": "a1：月曜日の正午／a2：4.25／a3：内部監査室長"
      },
      {
        "label": "エ",
        "textJa": "a1：月曜日の正午／a2：4.50／a3：CISO"
      },
      {
        "label": "オ",
        "textJa": "a1：月曜日の正午／a2：4.50／a3：情報システム部の担当者"
      },
      {
        "label": "カ",
        "textJa": "a1：火曜日の正午／a2：4.25／a3：情報システム部の担当者"
      },
      {
        "label": "キ",
        "textJa": "a1：火曜日の正午／a2：4.25／a3：内部監査室長"
      },
      {
        "label": "ク",
        "textJa": "a1：火曜日の正午／a2：4.50／a3：CISO"
      },
      {
        "label": "ケ",
        "textJa": "a1：火曜日の正午／a2：4.50／a3：情報システム部の担当者"
      },
      {
        "label": "コ",
        "textJa": "a1：火曜日の正午／a2：4.50／a3：内部監査室長"
      }
    ],
    "answer": "ク",
    "explanationZh": "正确答案ク。RPO 为72小时，若周五正午故障，至少要能恢复到72小时前的周二正午以后；周二凌晨2点已有增量备份不够新，周四凌晨2点的增量备份可满足，所以 a1 在给出的两种时间中选周二正午。若周四正午全数据丢失，需先恢复上周六完整备份4小时，再依次应用本周二、周四两次增量备份，各0.25小时，总计4.50小时。ICT持续计划应由承担最高信息安全责任的CISO批准，因此三项合在一起为ク。",
    "transcriptionNoteZh": "原题为 IPA 公开科目 B 试卷；日语正文按原卷文字提取并补标方框空栏。图片为同一道原卷的完整页面，表格、图形及排版请以图片核对。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/tbl5kb0000005r9r-att/2025r07_fe_kamoku_b_ans.pdf",
    "page": 14,
    "imageAssets": [
      "question-images/fe-2025-b-06-p14.png",
      "question-images/fe-2025-b-06-p15.png"
    ]
  },
  {
    "id": "FE-2024-A-01",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 1,
    "topicZh": "真值表与逻辑运算",
    "stemJa": "X 及び Y はそれぞれ 0 又は 1 の値をとる変数である。X □Y を X と Y の論理演算としたとき，次の真理値表が得られた。X □Y の真理値表はどれか。\nX Y X AND ( X □Y ) X OR ( X □Y )\n0 0 0 1\n0 1 0 1\n1 0 0 1\n1 1 1 1",
    "options": [
      {
        "label": "ア",
        "textJa": "X Y X□Y\n0 0 0\n0 1 0\n1 0 0\n1 1 1"
      },
      {
        "label": "イ",
        "textJa": "X Y X□Y\n0 0 0\n0 1 1\n1 0 0\n1 1 1"
      },
      {
        "label": "ウ",
        "textJa": "X Y X□Y\n0 0 1\n0 1 1\n1 0 0\n1 1 1"
      },
      {
        "label": "エ",
        "textJa": "X Y X□Y\n0 0 1\n0 1 1\n1 0 1\n1 1 0"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。先把未知的 X□Y 暂记作 Z。AND（逻辑与）只有两个输入都为 1 时才输出 1；OR（逻辑或）只要有一个输入为 1 就输出 1。当 X=0 时，X OR Z=Z，原表前两行的 OR 结果都是 1，因此输入 (X,Y)=(0,0) 和 (0,1) 时 Z 都是 1。当 X=1 时，X AND Z=Z；原表第三、四行的 AND 结果依次为 0、1，因此 (1,0) 时 Z=0，(1,1) 时 Z=1。把四行连起来是 1、1、0、1，只有ウ完全一致。ア的第一行是 0，イ的前两行不符，エ的后两行不符。做这种题逐行推，不必先猜 □ 是什么逻辑门。",
    "transcriptionNoteZh": "原题真值表按行改排为文字；表中 0、1 及四个选项的行序未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 2
  },
  {
    "id": "FE-2024-A-02",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 2,
    "topicZh": "哈希表",
    "stemJa": "キーが小文字のアルファベット 1 文字（a，b，…，z のいずれか）であるデータを，大きさが 10 のハッシュ表に格納する。ハッシュ関数として，アルファベットの ASCII コードを 10 進表記法で表したときの 1 の位の数を用いることにする。衝突が起こるキーの組合せはどれか。ASCII コードでは，昇順に連続した 2 進数が，アルファベット順にコードとして割り当てられている。",
    "options": [
      {
        "label": "ア",
        "textJa": "a と i"
      },
      {
        "label": "イ",
        "textJa": "b と r"
      },
      {
        "label": "ウ",
        "textJa": "c と l"
      },
      {
        "label": "エ",
        "textJa": "d と x"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。哈希值取ASCII十进制的个位，等价于对10取余。d为100，x为120，个位都是0，故碰撞。其余三组分别为a=97、i=105；b=98、r=114；c=99、l=108，个位都不同。题目已说明字母编码按顺序连续，因此也可比较两字母的序号差是否为10的倍数：d到x相差20。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 2
  },
  {
    "id": "FE-2024-A-03",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 3,
    "topicZh": "缓存命中率与平均访问时间",
    "stemJa": "図に示す構成で，表に示すようにキャッシュメモリと主記憶のアクセス時間だけが異なり，他の条件は同じ 2 種類の CPU X と Y がある。あるプログラムを CPU X と Y とでそれぞれ実行したところ，両者の処理時間が等しかった。このとき，キャッシュメモリのヒット率は幾らか。ここで，CPU 以外の処理による影響はないものとする。\n図の文字表記：CPU → キャッシュメモリ（256k バイト）→ 主記憶（256M バイト）\n表 アクセス時間（単位 ナノ秒）\nCPU X：キャッシュメモリ 40，主記憶 400\nCPU Y：キャッシュメモリ 20，主記憶 580",
    "options": [
      {
        "label": "ア",
        "textJa": "0.75"
      },
      {
        "label": "イ",
        "textJa": "0.90"
      },
      {
        "label": "ウ",
        "textJa": "0.95"
      },
      {
        "label": "エ",
        "textJa": "0.96"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ，命中率 0.90。缓存比主存快，‘命中’表示所需数据在缓存中，按缓存访问时间计算；‘未命中’按主存访问时间计算。设共同命中率为 h，CPU X 的平均时间是 40h＋400(1－h)，CPU Y 是 20h＋580(1－h)。题目说两种 CPU 对同一程序处理时间相等且其他条件相同，所以令两式相等：40h＋400－400h＝20h＋580－580h，即 400－360h＝580－560h，得到 200h＝180，h＝0.90。也可从差额理解：X 命中比 Y 慢 20 纳秒，未命中却快 180 纳秒，需 9 次命中抵 1 次未命中。ア、ウ、エ代入等式都不会相等。",
    "transcriptionNoteZh": "原题缓存结构图及访问时间表改为文字；容量、时间与单位未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 3
  },
  {
    "id": "FE-2024-A-04",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 4,
    "topicZh": "系统可用性",
    "stemJa": "あるシステムの今年度の MTBF は 3,000 時間，MTTR は 1,000 時間である。翌年度は MTBF について今年度の 20％分の改善，MTTR について今年度の 10％分の改善を図ると，翌年度の稼働率は何％になるか。",
    "options": [
      {
        "label": "ア",
        "textJa": "69"
      },
      {
        "label": "イ",
        "textJa": "73"
      },
      {
        "label": "ウ",
        "textJa": "77"
      },
      {
        "label": "エ",
        "textJa": "80"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。MTBF是平均无故障时间，改善20%后为3000×1.2＝3600小时；MTTR是平均修复时间，改善10%意味着缩短到1000×0.9＝900小时。稼働率＝MTBF／(MTBF＋MTTR)＝3600／4500＝80%。其余69%、73%、77%都不是把两个改善方向分别代入该公式的结果。特别注意修复时间改善应减少，而非增加。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 3
  },
  {
    "id": "FE-2024-A-05",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 5,
    "topicZh": "Web 服务与逻辑组合",
    "stemJa": "複数の Web サービスの入出力処理を連結させて新たなサービスを提供する，“ロジックマッシュアップ”の例はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "利用者が選択した飲食店情報のページを表示する際に，他の Web サービスが提供する地図コンテンツをアクセスマップとして表示する。"
      },
      {
        "label": "イ",
        "textJa": "利用者が選択した投資商品の情報を表示する際に，関連する経済指標のデータを複数の Web サービスから取得し，グラフに加工して表示する。"
      },
      {
        "label": "ウ",
        "textJa": "利用者が入力した予算の範囲で宿泊可能な施設のリストを他の Web サービスから取得し，それらの宿泊施設の空室状況を別の Web サービスから取得して表示する。"
      },
      {
        "label": "エ",
        "textJa": "利用者がマウスのドラッグで地図を操作した際に，Web ページ全体ではなく一部を読み直すことによって地図をスクロールして表示する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。先把用户的预算交给住宿检索服务，得到符合预算的设施清单；再把这些设施交给另一项空房查询服务，得到最终结果。第二个服务的输入依赖第一个服务的输出，这正是题干所说‘输入输出处理相连接’。ア是把地图内容加到页面；イ把若干数据取来绘图，侧重数据或画面组合；エ是局部更新网页的交互方式。判断逻辑组合时，画出‘服务一的输出 → 服务二的输入’这条线最直接。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 4
  },
  {
    "id": "FE-2024-A-06",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 6,
    "topicZh": "图像处理",
    "stemJa": "液晶ディスプレイなどの表示装置において，傾いた直線の境界を滑らかに表示する手法はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "アンチエイリアシング"
      },
      {
        "label": "イ",
        "textJa": "シェーディング"
      },
      {
        "label": "ウ",
        "textJa": "テクスチャマッピング"
      },
      {
        "label": "エ",
        "textJa": "バンプマッピング"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。斜线映射到有限像素网格时会出现阶梯状锯齿，抗锯齿通过平滑边缘像素的颜色或覆盖率来减轻这种现象。イ是根据光照给物体表面着色；ウ把纹理图贴到物体表面；エ用表面凹凸的视觉效果增强细节。题眼是“倾斜直线的边界变平滑”，不是物体表面的材质或光照。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 4
  },
  {
    "id": "FE-2024-A-07",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 7,
    "topicZh": "数据库事务与原子性",
    "stemJa": "DBMS に実装すべき原子性（atomicity）を説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "同一データベースに対する同一処理は，何度実行しても結果は同じである。"
      },
      {
        "label": "イ",
        "textJa": "トランザクション完了後にハードウェア障害が発生しても，更新されたデータベースの内容は保証される。"
      },
      {
        "label": "ウ",
        "textJa": "トランザクション内の処理は，全てが実行されるか，全てが取り消されるかのいずれかである。"
      },
      {
        "label": "エ",
        "textJa": "一つのトランザクションの処理結果は，他のトランザクション処理の影響を受けない。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。原子性要求一个事务作为不可分割的整体：其中的操作要么全部成功并提交，要么失败后全部撤销，不能只完成一部分。转账时若已扣款却未入账，就违反原子性。ア说相同操作重复执行仍得到相同结果，是幂等性的描述。イ强调事务提交后即使发生硬件故障，结果也要保留，是持久性。エ强调事务彼此之间不互相干扰，是隔离性。原子性、隔离性和持久性都是 ACID 中不同的要求。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 4
  },
  {
    "id": "FE-2024-A-08",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 8,
    "topicZh": "网络连接设备与 OSI 分层",
    "stemJa": "LAN 間接続装置に関する記述のうち，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "ゲートウェイは，OSI 基本参照モデルにおける第 1 ～ 3 層だけのプロトコルを変換する。"
      },
      {
        "label": "イ",
        "textJa": "ブリッジは，IP アドレスを基にしてフレームを中継する。"
      },
      {
        "label": "ウ",
        "textJa": "リピータは，同種のセグメント間で信号を増幅することによって伝送距離を延長する。"
      },
      {
        "label": "エ",
        "textJa": "ルータは，MAC アドレスを基にしてフレームを中継する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。中继器在物理层处理信号，通过再生或放大信号延长同类网段的传输距离。ア把网关限定为只转换 OSI 第 1～3 层协议，范围错误；网关可进行更高层的协议转换。イ把网桥的判断依据写成 IP 地址，网桥在数据链路层主要依据 MAC 地址转发帧。エ则把路由器的判断依据写成 MAC 地址；路由器在网络层主要依据 IP 地址转发分组。记忆时把“网桥—MAC、路由器—IP、中继器—信号”对应起来。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2024-A-09",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 9,
    "topicZh": "渗透测试",
    "stemJa": "ペネトレーションテストに該当するものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "検査対象の実行プログラムの設計書，ソースコードに着目し，開発プロセスの各工程にセキュリティ上の問題がないかどうかをツールや目視で確認する。"
      },
      {
        "label": "イ",
        "textJa": "公開 Web サーバの各コンテンツファイルのハッシュ値を管理し，定期的に各ファイルから生成したハッシュ値と一致するかどうかを確認する。"
      },
      {
        "label": "ウ",
        "textJa": "公開 Web サーバや組織のネットワークの脆弱性を探索し，サーバに実際に侵入できるかどうかを確認する。"
      },
      {
        "label": "エ",
        "textJa": "内部ネットワークのサーバやネットワーク機器の IPFIX 情報から，各 PC の通信に異常な振る舞いがないかどうかを確認する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。渗透测试不止列出潜在漏洞，还会在授权范围内模拟攻击，验证漏洞能否造成实际入侵。ア通过设计文档与源码检查安全问题，属于开发过程或代码安全检查。イ定期比对文件哈希值，是文件完整性监测，用来发现内容被篡改。エ分析 IPFIX 网络流量信息寻找异常通信，是流量监测。区分关键是题中明确说“确认能否实际侵入”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2024-A-10",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 10,
    "topicZh": "SQL 注入防护",
    "stemJa": "SQL インジェクションの対策として，有効なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "URL を Web ページに出力するときは，“http://”や“https://”で始まる URL だけを許可する。"
      },
      {
        "label": "イ",
        "textJa": "外部からのパラメータで Web サーバ内のファイル名を直接指定しない。"
      },
      {
        "label": "ウ",
        "textJa": "スタイルシートを任意の Web サイトから取り込めるようにしない。"
      },
      {
        "label": "エ",
        "textJa": "プレースホルダを使って命令文を組み立てる。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。用占位符构造参数化SQL时，SQL结构与用户输入的值分开处理，输入中的引号和关键字不会被当成新的SQL语法执行。ア限制可输出的URL方案，偏向防止危险链接；イ避免外部参数直接指定服务器文件，偏向路径遍历风险；ウ限制外部样式表来源，都没有直接解决SQL语句被输入改写的问题。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2024-A-11",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 11,
    "topicZh": "自顶向下集成测试与桩模块",
    "stemJa": "階層構造のモジュール群から成るソフトウェアの結合テストを，上位のモジュールから行う。この場合に使用する，下位のモジュールの代替となるテスト用のモジュールはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "エミュレータ"
      },
      {
        "label": "イ",
        "textJa": "シミュレータ"
      },
      {
        "label": "ウ",
        "textJa": "スタブ"
      },
      {
        "label": "エ",
        "textJa": "ドライバ"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ，即桩模块（stub）。自顶向下集成时，先测试上层模块；尚未接入的下层模块需用一个能接收调用并返回预设结果的替身，这就是桩模块。エ“驱动模块”（driver）方向相反：自底向上测试下层模块时，用它模拟上层的调用方。ア仿真器和イ模拟器用于模拟设备、系统或其行为，并非此题专门要求的下层被调用模块替身。记忆口诀：上层先测，用桩顶住下层；下层先测，用驱动调用下层。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2024-A-12",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 12,
    "topicZh": "Scrum 每日站会",
    "stemJa": "アジャイル開発手法の一つであるスクラムで定義され，スプリントで実施するイベントのうち，毎日決まった時間に決まった場所で行い，開発チームの全員が前回からの進捗状況や今後の作業計画を共有するものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "スプリントプランニング"
      },
      {
        "label": "イ",
        "textJa": "スプリントレトロスペクティブ"
      },
      {
        "label": "ウ",
        "textJa": "スプリントレビュー"
      },
      {
        "label": "エ",
        "textJa": "デイリースクラム"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ，即每日 Scrum。题目的识别点是“在冲刺期间每天进行”，让开发团队同步进展和接下来的计划。ア冲刺计划会决定本次冲刺要完成什么以及怎样开展，通常在冲刺开始时举行。イ冲刺回顾用于检查团队协作方式并商定改进，发生在冲刺末尾。ウ冲刺评审用于查看成果并取得反馈，也不是每天举行。不要只看到“分享计划”就选计划会议，还要结合“每天”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2024-A-13",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 13,
    "topicZh": "含虚活动的箭线图关键路径",
    "stemJa": "アローダイアグラムで表されるプロジェクトは，完了までに最少で何日を要するか。",
    "options": [
      {
        "label": "ア",
        "textJa": "105"
      },
      {
        "label": "イ",
        "textJa": "115"
      },
      {
        "label": "ウ",
        "textJa": "120"
      },
      {
        "label": "エ",
        "textJa": "125"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ，120 天。图中虚线表示耗时为零但必须等待的前后依赖，不能当成不存在。先做 A 用 30 天。上路 B 用 5 天，到第 35 天；中路 C 用 30 天，到第 60 天，且 B 的虚活动也须完成，所以中间节点最早仍是第 60 天。下路 D 到第 50 天，但还要等待从中间节点来的虚活动，所以底部节点最早也是第 60 天。汇合前：E 在第 35＋40＝75 天结束；F 在第 60＋25＝85 天结束；G 在第 60＋30＝90 天结束。汇合必须等到第 90 天，最后 H 再用 30 天，共 120 天。ア、イ少算了某条必要依赖，エ则超出图中最长实际工期。",
    "transcriptionNoteZh": "箭线图中的两条虚活动与全部作业天数保存在官方原卷图片中。",
    "imageAssets": [
      "question-images/fe-2024-a-13.png"
    ],
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2024-A-14",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 14,
    "topicZh": "服务设计与开发运维协作",
    "stemJa": "システムの開発部門と運用部門が別々に組織化されているとき，システム開発を伴う新規サービスの設計及び移行を円滑かつ効果的に進めるための方法のうち，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "運用テストの完了後に，開発部門がシステム仕様と運用方法を運用部門に説明する。"
      },
      {
        "label": "イ",
        "textJa": "運用テストは，開発部門の支援を受けずに，運用部門だけで実施する。"
      },
      {
        "label": "ウ",
        "textJa": "運用部門からもシステムの運用に関わる要件の抽出に積極的に参加する。"
      },
      {
        "label": "エ",
        "textJa": "開発部門は運用テストを実施して，運用マニュアルを作成し，運用部門に引き渡す。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。新服务的运维要求应在需求和设计阶段就由运维部门参与提出，例如监控、备份、故障恢复和日常操作。这样开发时才能把运行需要纳入系统，移交也更顺畅。ア等运维测试结束后才解释系统，时间过晚。イ让运维部门在没有开发支持下独自测试，无法充分解决设计和实现问题。エ由开发部门单方面测试和编写手册后移交，同样缺少运维方早期参与与实际验证。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 7
  },
  {
    "id": "FE-2024-A-15",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 15,
    "topicZh": "非结构化数据处理",
    "stemJa": "ビッグデータ分析の前段階として，非構造化データを構造化データに加工する処理を記述している事例はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "関係データベースに蓄積された大量の財務データから必要な条件に合致するデータを抽出し，利用者が扱いやすい表計算ソフトウェアデータに加工する。"
      },
      {
        "label": "イ",
        "textJa": "個人情報を含むビッグデータを更に利活用するために，特定の個人を識別することができないように匿名化加工する。"
      },
      {
        "label": "ウ",
        "textJa": "住所データ項目の中にある，“ヶ”と“が”の混在や，丁番地の表記不統一を，標準化された表記へ統一するために加工する。"
      },
      {
        "label": "エ",
        "textJa": "ソーシャルメディアの口コミを機械学習によって単語ごとに分解し，要約を作り，分析可能なデータに加工し，関係データベースに保管する。"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。社交媒体评论是自由文本，没有固定字段；把它分词、提取可分析的信息，再存入关系数据库，符合“非结构化数据转为结构化数据”。ア的起点已经是关系数据库中的财务数据，属于从结构化数据抽取并换一种展示形式。イ侧重隐去个人身份，未说明改变数据结构。ウ是在已有的地址字段内统一写法，属于数据标准化，也不是把自由文本转成结构化记录。答题先看输入是否缺少固定结构，再看输出是否形成可按字段分析的数据。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 7
  },
  {
    "id": "FE-2024-A-16",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 16,
    "topicZh": "企业核心竞争力",
    "stemJa": "コアコンピタンスを説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "経営活動における基本精神や行動指針"
      },
      {
        "label": "イ",
        "textJa": "事業戦略の遂行によって達成すべき到達目標"
      },
      {
        "label": "ウ",
        "textJa": "自社を取り巻く環境に関するビジネス上の機会と脅威"
      },
      {
        "label": "エ",
        "textJa": "他社との競争優位の源泉となる経営資源及び企業能力"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。核心竞争力是企业拥有、并能成为相对其他企业竞争优势来源的资源与能力，例如难以模仿的技术、流程或组织能力。ア说的是经营理念、价值观和行动准则。イ是战略要实现的目标，不是形成优势的能力本身。ウ是外部环境中的机会和威胁，属于环境分析的对象。题眼是“竞争优势的来源”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2024-A-17",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 17,
    "topicZh": "蓝海战略",
    "stemJa": "マーケティング戦略におけるブルーオーシャンの説明として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "競争が存在していない未知の市場"
      },
      {
        "label": "イ",
        "textJa": "コモディティ化が進んだ既存の市場"
      },
      {
        "label": "ウ",
        "textJa": "新事業のアイディアを実際のビジネスに育成するまでの期間"
      },
      {
        "label": "エ",
        "textJa": "製品開発したものを市場化する過程に横たわっている障壁"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。蓝海指竞争尚不存在、可通过创造新需求开拓的未知市场空间。イ是已有商品趋同、竞争激烈的现有市场，更接近“红海”。ウ说的是从新业务构想到培育为实际业务的时期，不是市场竞争状态。エ说的是研发成果走向市场时遇到的障碍，也不是蓝海定义。注意“蓝海”描述的是市场竞争空间，而不是项目所处阶段。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2024-A-18",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 18,
    "topicZh": "HR Tech 与人事数字化",
    "stemJa": "HR テックの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "ICT を活用して，住宅内のエネルギー使用状況の監視，機器の遠隔操作や自動制御などを可能にし，家庭におけるエネルギー管理を支援するソリューション"
      },
      {
        "label": "イ",
        "textJa": "既存のビジネスモデルによる業界秩序や既得権益を破壊してしまうほど大きな影響を与える新しい ICT やビジネスモデル"
      },
      {
        "label": "ウ",
        "textJa": "個人の資金に関わる情報を統合的に管理するサービスやマーケットプレイス・レンディングなどの金融サービスを実現するための新しい情報技術"
      },
      {
        "label": "エ",
        "textJa": "採用，育成，評価，配属などの人事領域の業務を対象に，ビッグデータ解析や AI などの最新 ICT を活用して，業務改善と社員満足度向上を図るソリューション"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。HR 是 Human Resources（人力资源）；HR Tech 把数据分析、AI 等技术用于招聘、培养、评价、岗位安排等人事工作。ア描述家庭能源管理系统 HEMS。イ描述颠覆既有行业格局的创新技术或商业模式。ウ涉及个人财务信息和金融服务，是金融科技 FinTech。识别这类题先看技术服务的业务领域：人事领域才对应 HR Tech。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2024-A-19",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 19,
    "topicZh": "散点图与负相关",
    "stemJa": "図は，製品の製造上のある要因の値xと品質特性の値yとの関係をプロットしたものである。この図から読み取れることはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "xからyを推定するためには，2次回帰係数の計算が必要である。"
      },
      {
        "label": "イ",
        "textJa": "xからyを推定するための回帰式は，yからxを推定する回帰式と同じである。"
      },
      {
        "label": "ウ",
        "textJa": "xとyの相関係数は正である。"
      },
      {
        "label": "エ",
        "textJa": "xとyの相関係数は負である。"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。散点图中点群整体从左上向右下分布：x 越大，y 往往越小，属于负相关，因此相关系数的符号为负。ウ说正相关，方向恰好相反。图中点群近似沿一条下降直线分布，不能由图推断必须计算二次回归系数，故ア不成立。イ也错误：用 x 预测 y 与用 y 预测 x，最小二乘法要分别最小化不同方向的误差，得到的两条回归式一般不能视为同一个式子。此题只需判断趋势方向，不必从散点图估计精确系数。",
    "transcriptionNoteZh": "散点分布趋势保留在官方原卷图片中，文字题干与选项按原文转录。",
    "imageAssets": [
      "question-images/fe-2024-a-19.png"
    ],
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 9
  },
  {
    "id": "FE-2024-A-20",
    "kind": "official",
    "year": 2024,
    "section": "A",
    "number": 20,
    "topicZh": "日本知识产权分类",
    "stemJa": "日本において，産業財産権と総称される四つの権利はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "意匠権，実用新案権，商標権，特許権"
      },
      {
        "label": "イ",
        "textJa": "意匠権，実用新案権，著作権，特許権"
      },
      {
        "label": "ウ",
        "textJa": "意匠権，商標権，著作権，特許権"
      },
      {
        "label": "エ",
        "textJa": "実用新案権，商標権，著作権，特許権"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。日本所说的产业财产权（産業財産権）包括四项：特许权对应技术发明，实用新案权对应物品形状、构造等的考案，意匠权对应产品外观设计，商标权对应区分商品或服务来源的标识。著作权也属于知识产权，但不在这四项产业财产权之内，所以含‘著作権’的イ、ウ、エ都不对。此题考的是权利分类，不要求据此判断某个具体作品是否能申请某种权利。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_a_ans.pdf",
    "page": 9
  },
  {
    "id": "FE-2024-B-01",
    "kind": "official",
    "year": 2024,
    "section": "B",
    "number": 1,
    "topicZh": "条件分支",
    "stemJa": "次のプログラム中の［ a ］に入れる正しい答えを，解答群の中から選べ。\n\n関数 maximum は，異なる三つの整数を引数で受け取り，そのうちの最大値を返す。\n\n〔プログラム〕\n○整数型: maximum(整数型: x, 整数型: y, 整数型: z)\n    if (［ a ］)\n        return x\n    elseif (y ＞ z)\n        return y\n    else\n        return z\n    endif",
    "options": [
      {
        "label": "ア",
        "textJa": "x ＞ y"
      },
      {
        "label": "イ",
        "textJa": "x ＞ y and x ＞ z"
      },
      {
        "label": "ウ",
        "textJa": "x ＞ y and y ＞ z"
      },
      {
        "label": "エ",
        "textJa": "x ＞ z"
      },
      {
        "label": "オ",
        "textJa": "x ＞ z and z ＞ y"
      },
      {
        "label": "カ",
        "textJa": "z ＞ y"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案是イ。第一分支一旦成立就直接返回x，因此条件必须保证x同时大于y和z。若条件不成立，剩下的分支用y＞z在y与z之间择大，刚好得到三者最大值。ア、エ只比较一对，可能在第三个数更大时误返x；ウ要求y＞z过严，例如x=9、y=1、z=5时会错返z；オ只覆盖x＞z＞y一种顺序，过严；カ仅比较z与y，无法保证返回x时x为最大。",
    "transcriptionNoteZh": "原卷空栏以方框标示；纯文本中用［ a ］表示。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_b_ans.pdf",
    "page": 4
  },
  {
    "id": "FE-2024-B-02",
    "kind": "official",
    "year": 2024,
    "section": "B",
    "number": 2,
    "topicZh": "二进制转换",
    "stemJa": "次のプログラム中の［ a ］に入れる正しい答えを，解答群の中から選べ。\n\n関数 convDecimal は，引数として与えられた，“0”と“1”だけから成る，1 文字以上の文字列を，符号なしの 2 進数と解釈したときの整数値を返す。例えば，引数として“10010”を与えると 18 が返る。\n\n関数 convDecimal が利用する関数 int は，引数で与えられた文字が“0”なら整数値 0 を返し，“1”なら整数値 1 を返す。\n\n〔プログラム〕\n○整数型: convDecimal(文字列型: binary)\n    整数型: i, length, result ← 0\n    length ← binaryの文字数\n    for (i を 1 から length まで 1 ずつ増やす)\n        result ← ［ a ］\n    endfor\n    return result",
    "options": [
      {
        "label": "ア",
        "textJa": "result ＋ int(binary の (length － i ＋ 1)文字目の文字)"
      },
      {
        "label": "イ",
        "textJa": "result ＋ int(binary の i文字目の文字)"
      },
      {
        "label": "ウ",
        "textJa": "result × 2 ＋ int(binary の (length － i ＋ 1)文字目の文字)"
      },
      {
        "label": "エ",
        "textJa": "result × 2 ＋ int(binary の i文字目の文字)"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。按字符串从左到右扫描，每读入一位，新数值＝旧数值×2＋当前位：左移一位相当于乘2。以10010为例，result依次为1、2、4、9、18。ア、イ只相加会得到1的个数，丢失位权；ウ虽乘2却从右往左读取，会把位序颠倒，例如10010会得到01001₂＝9。题目的循环i从1递增，所以应读取第i个字符。",
    "transcriptionNoteZh": "原卷空栏以方框标示；纯文本中用［ a ］表示。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_b_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2024-B-03",
    "kind": "official",
    "year": 2024,
    "section": "B",
    "number": 3,
    "topicZh": "无向图邻接矩阵",
    "stemJa": "問３ 次のプログラム中の［　］に入れる正しい答えを，解答群の中から選べ。 こ\nこで，配列の要素番号は 1 から始まる。\n\n図 1 に示すグラフの頂点には，1 から順に整数で番号が付けられている。グラフは\n無向グラフであり，各頂点間には高々一つの辺がある。一つの辺は両端の頂点の番号\nを要素にもつ要素数 2 の整数型の 配列で表現できる。 例えば，{1，3} は頂点 1 と頂\n点 3 を端点とする辺を表す。グラフ全体は，グラフに含まれる辺を表す要素数 2 の配\n列を全て格納した配列（以下，辺の配列という）で表現できる。辺の配列の要素数は\nグラフの辺の個数と等しい。図 1 のグラフは整数型配列の配列{{1, 3}, {1, 4}, {3,\n4}, {2, 4}, {4, 5}}と表現できる。\n\n1\n3\n2\n4\n5\n\n図 1 グラフの例\n\n関数 edgesToMatrix は，辺の配列を隣接行列に変換する。隣接行列とは，グラフに\n含まれる頂点の個数と等しい行数及び列数の正方行列で，i 行 j 列の成分は頂点 i と\n頂点 j を結ぶ辺があるときに 1 となり，それ以外は 0 となる。行列の対角成分は全て\n0 で，無向グラフの場合は対称行列になる。図 1 のグラフを表現する隣接行列を図 2\nに示す。\n\n0  0  1  1  0\n0  0  0  1  0\n1  0  0  1  0\n1  1  1  0  1\n0  0  0  1  0\n\n図 2 図 1 のグラフを表現する隣接行列\n\n関数 edgesToMatrix は，引数 edgeList で辺の配列を，引数 nodeNum でグラフの頂\n点の個数をそれぞれ受け取り，隣接行列を表す整数型の二次元配列を返す。\n\n〔プログラム〕\n○整数型の二次元配列: edgesToMatrix(整数型配列の配列: edgeList,\n                                    整数型: nodeNum)\n  整数型の二次元配列: adjMatrix ← {nodeNum行nodeNum列の 0}\n  整数型: i, u, v\n  for (i を 1 から edgeListの要素数 まで 1 ずつ増やす)\n    u ← edgeList[i][1]\n    v ← edgeList[i][2]\n    ［　］\n  endfor\n  return adjMatrix",
    "options": [
      {
        "label": "ア",
        "textJa": "adjMatrix[u, u] ← 1"
      },
      {
        "label": "イ",
        "textJa": "adjMatrix[u, u] ← 1；adjMatrix[v, v] ← 1"
      },
      {
        "label": "ウ",
        "textJa": "adjMatrix[u, v] ← 1"
      },
      {
        "label": "エ",
        "textJa": "adjMatrix[u, v] ← 1；adjMatrix[v, u] ← 1"
      },
      {
        "label": "オ",
        "textJa": "adjMatrix[v, u] ← 1"
      },
      {
        "label": "カ",
        "textJa": "adjMatrix[v, v] ← 1"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。边 {u,v} 表示两个不同顶点之间相连，邻接矩阵第 u 行第 v 列应置1。由于题中是无向图，从 v 看向 u 也有同一条边，所以第 v 行第 u 列也要置1，矩阵才关于对角线对称。对角线表示顶点连自己，题设例子的对角元素全为0，ア、イ、カ都错误；ウ或オ只填一侧，漏了反方向。示例边 {1,3} 对应 matrix[1,3] 和 matrix[3,1] 均为1。",
    "transcriptionNoteZh": "原题为 IPA 公开科目 B 试卷；日语正文按原卷文字提取并补标方框空栏。图片为同一道原卷的完整页面，表格、图形及排版请以图片核对。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_b_ans.pdf",
    "page": 6,
    "imageAssets": [
      "question-images/fe-2024-b-03-p6.png",
      "question-images/fe-2024-b-03-p7.png"
    ]
  },
  {
    "id": "FE-2024-B-04",
    "kind": "official",
    "year": 2024,
    "section": "B",
    "number": 4,
    "topicZh": "有序数组归并追踪",
    "stemJa": "問４ 次の記述中の［　］に入れる正しい答えを，解答群の中から選べ。 ここで，\n配列の要素番号は 1 から始まる。\n\n関数 merge は，昇順に整列された整数型の配列 data1 及び data2 を受け取り，これ\nらを併合してできる昇順に整列された整数型の配列を返す。\n関数 merge を merge({2, 3}, {1, 4}) として呼び出すと ，/*** α ***/ の行は［　］。\n\n〔プログラム〕\n○整数型の配列: merge(整数型の配列: data1, 整数型の配列: data2)\n  整数型: n1 ← data1の要素数\n  整数型: n2 ← data2の要素数\n  整数型の配列: work ← {(n1 ＋ n2)個の 未定義の値}\n  整数型: i ← 1\n  整数型: j ← 1\n  整数型: k ← 1\n\n  while ((i ≦ n1) and (j ≦ n2))\n    if (data1[i] ≦ data2[j])\n      work[k] ← data1[i]\n      i ← i ＋ 1\n    else\n      work[k] ← data2[j]\n      j ← j ＋ 1\n    endif\n    k ← k ＋ 1\n  endwhile\n\n  while (i ≦ n1)\n    work[k] ← data1[i]\n    i ← i ＋ 1\n    k ← k ＋ 1\n  endwhile\n\n  while (j ≦ n2)\n    work[k] ← data2[j]  /*** α ***/\n    j ← j ＋ 1\n    k ← k ＋ 1\n  endwhile\n\n  return work",
    "options": [
      {
        "label": "ア",
        "textJa": "実行されない"
      },
      {
        "label": "イ",
        "textJa": "1回実行される"
      },
      {
        "label": "ウ",
        "textJa": "2回実行される"
      },
      {
        "label": "エ",
        "textJa": "3回実行される"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。merge({2,3},{1,4}) 时先比较2和1，把1放到 work[1]，data2 指针前进；再比较2和4，把2放到 work[2]；再比较3和4，把3放到 work[3]。此时 data1 已经读完，结束双数组比较循环，第二个“补拷 data1”循环不执行。data2 还剩4，第三个补拷循环执行一次，α 行把4写到 work[4]。所以既不是零次，也不是两次以上；最终数组为 {1,2,3,4}。",
    "transcriptionNoteZh": "原题为 IPA 公开科目 B 试卷；日语正文按原卷文字提取并补标方框空栏。图片为同一道原卷的完整页面，表格、图形及排版请以图片核对。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_b_ans.pdf",
    "page": 8,
    "imageAssets": [
      "question-images/fe-2024-b-04-p8.png",
      "question-images/fe-2024-b-04-p9.png"
    ]
  },
  {
    "id": "FE-2024-B-05",
    "kind": "official",
    "year": 2024,
    "section": "B",
    "number": 5,
    "topicZh": "商品关联度计数",
    "stemJa": "問５ 次のプログラム中 の［ a ］～［ c ］に入れる正しい答えの組合せを，\n解答群の中から選べ。ここで，配列の要素番号は 1 から始まる。\n\n一度の注文で購入された商品のリストを，注文ごとに記録した注文データがある。\n表に，注文データの例を示す。\n\n表 注文データの例\n注文番号 購入された商品のリスト\n1 A, B, D\n2 A, D\n3 A\n4 A, B, E\n5 B\n6 C, E\n\n注文データから，商品 x と商品 y とが同一の注文で購入されやすい傾向を示す関連\n度 Lxy を，次の式で計算する。\nLxy ＝\nMxy × 全注文数\nKx × Ky\n\nここで，Mxy は商品 x と商品 y とが同一の注文で購入された注文数，Kx は商品 x が\n購入された注文数，Ky は商品 y が購入された注文数を表す。表の例では，MAB が 2，\n全注文数が 6，KA が 4，KB が 3 であるので，商品 A と商品 B の関連度 LAB は，(2 ×\n6) ／ (4 × 3) ＝ 1.0 である。\n手続 putRelatedItem は，大域変数 orders に格納された注文データを基に，引数で\n与えられた商品との関連度が最も大きい商品のうちの一つと，その関連度を出力する。\nプログラムでは，商品は文字列で表し，注文は購入された商品の配列，注文データは\n注文の配列で表している。注文データには 2 種類以上の商品が含まれるものとする。\nまた，注文データにある商品以外の商品が，引数として与えられることはないものと\nする。\n\n〔プログラム〕\n// 注文データ（ここでは表の例を与えている）\n大域: 文字列型配列の配列: orders ← {{\"A\", \"B\", \"D\"}, {\"A\", \"D\"}, {\"A\"},\n                                     {\"A\", \"B\", \"E\"}, {\"B\"}, {\"C\", \"E\"}}\n\n○putRelatedItem(文字列型: item)\n  文字列型の配列: allItems ← ordersに含まれる文字列を\n                              重複なく辞書順に格納した配列\n                              // 表の例では {\"A\", \"B\", \"C\", \"D\", \"E\"}\n\n  文字列型の配列: otherItems ← allItemsの複製から値がitemである\n                                要素を除いた配列\n\n  整数型: i, itemCount ← 0\n  整数型の配列: arrayK ← {otherItemsの要素数個の0}\n  整数型の配列: arrayM ← {otherItemsの要素数個の0}\n  実数型: valueL, maxL ← －∞\n  文字列型の配列: order\n  文字列型: relatedItem\n\n  for (orderにordersの要素を順に代入する)\n    if (orderのいずれかの要素の値がitemの値と等しい)\n      itemCountの値を1増やす\n    endif\n    for (iを1からotherItemsの要素数まで1ずつ増やす)\n      if (orderのいずれかの要素の値がotherItems[i]の値と等しい)\n        if (orderのいずれかの要素の値がitemの値と等しい)\n          ［ a ］の値を1増やす\n        endif\n        ［ b ］の値を1増やす\n      endif\n    endfor\n  endfor\n  for (iを1からotherItemsの要素数まで1ずつ増やす)\n    valueL ← (arrayM[i] × ［ c ］) ÷ (itemCount × arrayK[i])\n                                                /* 実数として計算する */\n    if (valueLがmaxLより大きい)\n      maxL ← valueL\n      relatedItem ← otherItems[i]\n    endif\n  endfor\n  relatedItemの値とmaxLの値をこの順にコンマ区切りで出力する",
    "options": [
      {
        "label": "ア",
        "textJa": "a：arrayK[i]／b：arrayM[i]／c：allItemsの要素数"
      },
      {
        "label": "イ",
        "textJa": "a：arrayK[i]／b：arrayM[i]／c：ordersの要素数"
      },
      {
        "label": "ウ",
        "textJa": "a：arrayK[i]／b：arrayM[i]／c：otherItemsの要素数"
      },
      {
        "label": "エ",
        "textJa": "a：arrayM[i]／b：arrayK[i]／c：allItemsの要素数"
      },
      {
        "label": "オ",
        "textJa": "a：arrayM[i]／b：arrayK[i]／c：ordersの要素数"
      },
      {
        "label": "カ",
        "textJa": "a：arrayM[i]／b：arrayK[i]／c：otherItemsの要素数"
      }
    ],
    "answer": "オ",
    "explanationZh": "正确答案オ。Mxy 是商品 item 与 otherItems[i] 在同一订单中出现的次数，所以只有两者都在当前订单时才增加 arrayM[i]，这对应 a。K_y 是候选商品单独出现的订单数，只要当前订单包含 otherItems[i] 就增加 arrayK[i]，这对应 b。公式的分子还要乘“全订单数”，程序里订单数组是 orders，因此 c 为 orders 的元素数，而不是商品种类数。把示例 A、B 代入得 2×6/(4×3)=1，可反查变量意义。",
    "transcriptionNoteZh": "原题为 IPA 公开科目 B 试卷；日语正文按原卷文字提取并补标方框空栏。图片为同一道原卷的完整页面，表格、图形及排版请以图片核对。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_b_ans.pdf",
    "page": 10,
    "imageAssets": [
      "question-images/fe-2024-b-05-p10.png",
      "question-images/fe-2024-b-05-p11.png",
      "question-images/fe-2024-b-05-p12.png"
    ]
  },
  {
    "id": "FE-2024-B-06",
    "kind": "official",
    "year": 2024,
    "section": "B",
    "number": 6,
    "topicZh": "远程办公云服务二要素认证",
    "stemJa": "問６ A 社は従業員 450 名の商社であり，昨年から働き方改革の一環として，在宅でのテ\nレワークを推進している。A 社のシステム環境を図 1 に示す。\n\n・従業員には，一人に 1 台デスクトップPC（以下，社内PC という）を貸与している。\n・従業員が利用するシステムには，自社で開発し A 社に設置している業務システムのほか\nに，次の二つの SaaS（以下，二つの SaaS を A 社利用クラウドサービス という）があ\nる。\n1. メー ル機能，チャット 機能及びクラウドストレー ジ機能をもつグループウェア\n（以下，A 社利用グループウェアという）\n2. オンライン会議サービス\n・テレワークでは，従業員の個人所有 PC（以下，私有 PC という）の業務利用（BYOD）を\n許可している。\n・テレワークでは，社内 PC 及び私有 PC のそれぞれに専用のアプリケーションソフトウェ\nア（以下，専用アプリという）を導入し，社内 PC のデスクトップから私有 PC に画面転\n送を行うリモートデスクトップ方式を採用している。\n・専用アプリには，リモートデスクトップから PC へのファイルのダウンロード及びファ\nイル，文字列，画像などのコピー＆ ペーストを禁止する機能（以下，保存禁止機能とい\nう）があり，A 社では私有 PC に対して当該機能を有効にしている。\n・業務システムには，社内 PC のデスクトップから利用者 ID 及びパスワードを入力してロ\nグインしている。\n・A 社利用クラウドサービスへの ログインは，A 社利用クラウドサービス側の設定によっ\nて A 社の社内ネットワークからだけ可能になるように制限している。ログインには利用\n者 ID 及びパスワードを用いている。\n図 1 A 社のシステム環境（抜粋）\n\n テレワークの定着が進むにつれて，社内 PC からインターネットへの接続が極端に\n遅くなり，業務に支障をきたしているので改善できないかと，従業員から問合せがあ\nった。A 社の社内ネットワークとインターネットとの間の通信量を調査したところ，\nテレワーク導入前に比べ，業務時間帯で顕著に増加していることが判明した。そのた\nめ，情報システム部では，テレワークで A 社利用クラウドサービスに接続する場合に\nは，A 社の社内ネットワークも社内 PC も介さずに直接接続することを可能にするネ\nットワークの設定変更を実施することにした。\n 設定変更に当たり，情報セキュリティ上の問題がないかを A 社の情報セキュリティ\nリーダーである B さんが検討したところ，幾つか問題があることが分かった。その一\nつは，A 社利用クラウドサービスへの不正アクセスのリスク が増加することである。\nそこで B さんは，リスクを低減するために，情報システム部に対策を依頼することに\nした。\n\n設問 次の対策のうち，情報システム部に依頼することにしたものはどれか。解答群の\nうち，最も適切なものを選べ。",
    "options": [
      {
        "label": "ア",
        "textJa": "A社の社内ネットワークからA社利用クラウドサービスへの通信を監視する。"
      },
      {
        "label": "イ",
        "textJa": "A社の社内ネットワークとA社利用クラウドサービスとの間の通信速度を制限する。"
      },
      {
        "label": "ウ",
        "textJa": "A社利用クラウドサービスにA社外から接続する際の認証に2要素認証を導入する。"
      },
      {
        "label": "エ",
        "textJa": "A社利用クラウドサービスのうち，A社利用グループウェアだけを直接接続の対象とする。"
      },
      {
        "label": "オ",
        "textJa": "専用アプリの保存禁止機能を無効にする。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。原先云服务只允许从公司内网登录，远程办公要改成私有PC直接连接，等于放宽了网络来源限制，账号密码被盗后的外部登录风险随之升高。对外部连接增加二要素认证，可在密码之外再要求另一类凭据，直接降低冒用风险。ア监视旧的内网通道，不能保护新增的直接连接；イ限速不等于身份验证；エ只覆盖一个云服务；オ关闭保存限制会增加数据落到私有PC的风险。",
    "transcriptionNoteZh": "原题为 IPA 公开科目 B 试卷；日语正文按原卷文字提取并补标方框空栏。图片为同一道原卷的完整页面，表格、图形及排版请以图片核对。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/eid2eo0000007g1d-att/2024r06_fe_kamoku_b_ans.pdf",
    "page": 14,
    "imageAssets": [
      "question-images/fe-2024-b-06-p14.png",
      "question-images/fe-2024-b-06-p15.png"
    ]
  },
  {
    "id": "FE-2023-A-01",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 1,
    "topicZh": "进制转换",
    "stemJa": "16 進小数 0.C を 10 進小数に変換したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "0.12"
      },
      {
        "label": "イ",
        "textJa": "0.55"
      },
      {
        "label": "ウ",
        "textJa": "0.75"
      },
      {
        "label": "エ",
        "textJa": "0.84"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案是ウ。十六进制小数点后第一位的位权是16⁻¹，即1/16；C代表十进制12，因此0.C₁₆＝12/16＝0.75₁₀。ア、イ、エ的数值分别是0.12、0.55、0.84，都不等于12/16。遇到多位十六进制小数时，依次乘以16⁻¹、16⁻²等位权后相加。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 2
  },
  {
    "id": "FE-2023-A-02",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 2,
    "topicZh": "双向链表与指针更新",
    "stemJa": "双方向のポインタをもつリスト構造のデータを表に示す。この表において新たな社員 G を社員 A と社員 K の間に追加する。追加後の表のポインタ a ～ f の中で追加前と比べて値が変わるポインタだけを全て列記したものはどれか。\n表\nアドレス 社員名 次ポインタ 前ポインタ\n100 社員 A 300 0\n200 社員 T 0 300\n300 社員 K 200 100\n追加後の表\nアドレス 社員名 次ポインタ 前ポインタ\n100 社員 A a b\n200 社員 T c d\n300 社員 K e f\n400 社員 G x y",
    "options": [
      {
        "label": "ア",
        "textJa": "a，b，e，f"
      },
      {
        "label": "イ",
        "textJa": "a，e，f"
      },
      {
        "label": "ウ",
        "textJa": "a，f"
      },
      {
        "label": "エ",
        "textJa": "b，e"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。先读表：地址 100 的 A 的‘次指针’原来指向地址 300 的 K；K 的‘前指针’原来指回 A 的地址 100。要把新节点 G（地址 400）插在 A 与 K 中间，顺序就变成 A→G→K。于是 A 的次指针 a 从 300 改成 400，K 的前指针 f 从 100 改成 400。新节点自己的 x、y 要分别填 300、100，但题目只问 a～f，所以不计。A 的前指针 b 仍为 0；K 的次指针 e 仍为 200；T 的 c、d 也不动。ア、イ、エ都包含不应改变的指针，或漏掉 a、f。双向链表插入时要检查被插位置两侧的指针，而不是把整条链都改写。",
    "transcriptionNoteZh": "原题两张表按行改排为文字；地址、姓名、指针符号及数值未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 2
  },
  {
    "id": "FE-2023-A-03",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 3,
    "topicZh": "存储器与性能",
    "stemJa": "コンピュータの高速化技術の一つであるメモリインタリーブに関する記述として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "主記憶と入出力装置，又は主記憶同士のデータの受渡しを CPU 経由でなく直接やり取りする方式"
      },
      {
        "label": "イ",
        "textJa": "主記憶にデータを送り出す際に，データをキャッシュに書き込み，キャッシュがあふれたときに主記憶へ書き込む方式"
      },
      {
        "label": "ウ",
        "textJa": "主記憶のデータの一部をキャッシュにコピーすることによって，レジスタと主記憶とのアクセス速度の差を縮める方式"
      },
      {
        "label": "エ",
        "textJa": "主記憶を複数の独立して動作するグループに分けて，各グループに並列にアクセスする方式"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。内存交叉存取把主存分成可独立工作的多个存储体，使相邻访问可分散到不同存储体并行处理，从而提高吞吐量。ア描述绕过CPU的数据直接传送，属于DMA一类；イ讲的是缓存写入策略，并不是内存交叉存取；ウ讲的是用缓存缩小速度差。辨认关键词是“主存分组”和“并行访问”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 3
  },
  {
    "id": "FE-2023-A-04",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 4,
    "topicZh": "边缘计算",
    "stemJa": "エッジコンピューティングの説明として，最も適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "画面生成やデータ処理をクライアント側で実行することによって，Web アプリケーションソフトウェアの操作性や表現力を高めること"
      },
      {
        "label": "イ",
        "textJa": "データが送信されてきたときだけ必要なサーバを立ち上げて，処理が終わり次第サーバを停止してリソースを解放すること"
      },
      {
        "label": "ウ",
        "textJa": "複数のサーバや PC を仮想化して統合することによって一つの高性能なコンピュータを作り上げ，並列処理によって処理能力を高めること"
      },
      {
        "label": "エ",
        "textJa": "利用者や機器に取り付けられたセンサなどのデータ発生源に近い場所にあるサーバなどでデータを一次処理し，処理のリアルタイム性を高めること"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。边缘计算在传感器、设备或用户附近先处理数据，减少送往远端再返回的传输延迟，有利于实时响应。ア强调的是浏览器或客户端执行界面处理；イ是按请求启停计算资源的方式；ウ是把多台机器整合并行计算。看到“靠近数据源处理”才应联想到边缘计算。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 3
  },
  {
    "id": "FE-2023-A-05",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 5,
    "topicZh": "计算机图形学",
    "stemJa": "3 次元グラフィックス処理におけるクリッピングの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "CG 映像作成における最終段階として，物体のデータをディスプレイに描画できるように映像化する処理である。"
      },
      {
        "label": "イ",
        "textJa": "画像表示領域にウィンドウを定義し，ウィンドウの外側を除去し，内側の見える部分だけを取り出す処理である。"
      },
      {
        "label": "ウ",
        "textJa": "スクリーンの画素数が有限であるために図形の境界近くに生じる，階段状のギザギザを目立たなくする処理である。"
      },
      {
        "label": "エ",
        "textJa": "立体感を生じさせるために，物体の表面に陰影を付ける処理である。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案是イ。裁剪（clipping）依据可见窗口或显示区域，去掉边界之外的图形部分，仅保留可见部分。ア描述把图形数据变成可显示图像的绘制过程；ウ是减轻锯齿的抗锯齿处理；エ是通过明暗表现立体感的着色。区分这些术语时先问：处理对象是“显示范围”、像素边缘，还是表面光照。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 4
  },
  {
    "id": "FE-2023-A-06",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 6,
    "topicZh": "数据库函数依赖",
    "stemJa": "次の関数従属を満足するとき，成立する推移的関数従属はどれか。ここで，“A→B”は B が A に関数従属していることを表し，“A→｛B，C｝”は，“A→B”かつ“A→C”が成立することを表す。\n〔関数従属〕\n｛注文コード，商品コード｝→｛顧客注文数量，注文金額｝\n注文コード →｛注文日，顧客コード，注文担当者コード｝\n商品コード →｛商品名，仕入先コード，商品販売価格｝\n仕入先コード →｛仕入先名，仕入先住所，仕入担当者コード｝\n顧客コード →｛顧客名，顧客住所｝",
    "options": [
      {
        "label": "ア",
        "textJa": "仕入先コード → 仕入担当者コード → 仕入先住所"
      },
      {
        "label": "イ",
        "textJa": "商品コード → 仕入先コード → 商品販売価格"
      },
      {
        "label": "ウ",
        "textJa": "注文コード → 顧客コード → 顧客住所"
      },
      {
        "label": "エ",
        "textJa": "注文コード → 商品コード → 顧客注文数量"
      }
    ],
    "answer": "ウ",
    "explanationZh": "传递函数依赖要有两段都成立：若 A 决定 B，且 B 决定 C，就可由 A 经 B 决定 C。已知“注文コード → 顧客コード”，又知“顧客コード → 顧客住所”，因此“注文コード → 顧客コード → 顧客住所”成立，选ウ。ア虽有供应商代码决定采购负责人代码，却没有“采购负责人代码决定供应商地址”；イ没有“供应商代码决定商品销售价格”；エ没有“订单代码决定商品代码”，且顾客订购数量由订单代码与商品代码的组合决定。不能把箭头方向或组合键随意拆开。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 4
  },
  {
    "id": "FE-2023-A-07",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 7,
    "topicZh": "数据库事务",
    "stemJa": "トランザクションが，データベースに対する更新処理を完全に行うか，全く処理しなかったかのように取り消すか，のどちらかの結果になることを保証する特性はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "一貫性（consistency）"
      },
      {
        "label": "イ",
        "textJa": "原子性（atomicity）"
      },
      {
        "label": "ウ",
        "textJa": "耐久性（durability）"
      },
      {
        "label": "エ",
        "textJa": "独立性（isolation）"
      }
    ],
    "answer": "イ",
    "explanationZh": "题干说一组更新只能“全部完成”或“全部取消”，不允许只执行一部分。这是事务的原子性，选イ，可用银行转账作例子：扣款与入账必须作为一个整体。ア一致性是事务前后数据库满足约束，不是描述整组操作能否拆分；ウ持久性是事务提交后结果即使发生故障也应保留；エ隔离性是并发事务之间不应互相干扰。四者合称 ACID，关键词“全做或全不做”只对应原子性。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2023-A-08",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 8,
    "topicZh": "网络诊断",
    "stemJa": "IPv4 ネットワークにおいて，ネットワークの疎通確認に使われるものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "BOOTP"
      },
      {
        "label": "イ",
        "textJa": "DHCP"
      },
      {
        "label": "ウ",
        "textJa": "MIB"
      },
      {
        "label": "エ",
        "textJa": "ping"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。ping发送ICMP Echo Request并等待Echo Reply，可快速检查目标主机是否可达及往返时间。BOOTP和DHCP用于获取IP等网络配置，MIB是网络管理信息库，都不用于主动验证两台主机的连通。注意ping失败只能说明没有收到响应，也可能是ICMP被过滤，不能单凭它断定目标完全离线。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2023-A-09",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 9,
    "topicZh": "网页访问与恶意软件感染",
    "stemJa": "ドライブバイダウンロード攻撃に該当するものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "PC から物理的にハードディスクドライブを盗み出し，その中のデータを Web サイトで公開し，ダウンロードさせる。"
      },
      {
        "label": "イ",
        "textJa": "電子メールの添付ファイルを開かせて，マルウェアに感染した PC のハードディスクドライブ内のファイルを暗号化し，元に戻すための鍵を攻撃者のサーバからダウンロードさせることと引換えに金銭を要求する。"
      },
      {
        "label": "ウ",
        "textJa": "利用者が悪意のある Web サイトにアクセスしたときに，Web ブラウザの脆弱性を悪用して利用者の PC をマルウェアに感染させる。"
      },
      {
        "label": "エ",
        "textJa": "利用者に気付かれないように無償配布のソフトウェアに不正プログラムを混在させておき，利用者の操作によって PC にダウンロードさせ，インストールさせることでハードディスクドライブから個人情報を収集して攻撃者のサーバに送信する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。Drive by download 指用户访问被攻击者控制或植入恶意内容的网页时，网页利用浏览器等软件的漏洞，使恶意程序被下载并运行。判断重点是‘访问网站’与‘利用浏览器漏洞’，并不是用户主动安装一个正常软件。ア是物理盗取硬盘；イ描述通过附件感染并索要赎金的勒索软件场景；エ是在软件安装包中混入恶意程序，属于捆绑或伪装软件传播。防护思路包括及时修补浏览器及插件漏洞，避免访问不可信页面。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2023-A-10",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 10,
    "topicZh": "WAF 安装位置与 HTTPS 解密",
    "stemJa": "図のような構成と通信サービスのシステムにおいて，Web アプリケーションの脆弱性対策のための WAF の設置場所として，最も適切な箇所はどこか。ここで，WAF には通信を暗号化したり，復号したりする機能はないものとする。\n図の文字表記：PC → インターネット → ファイアウォール → SSL アクセラレータ → Web サーバ → データベースアクセス用サービス → データベースサーバ。候補 a と b は HTTPS 区間，候補 c は SSL アクセラレータによる復号後の HTTP 区間で Web サーバの手前，候補 d は Web サーバの後方にある。",
    "options": [
      {
        "label": "ア",
        "textJa": "a"
      },
      {
        "label": "イ",
        "textJa": "b"
      },
      {
        "label": "ウ",
        "textJa": "c"
      },
      {
        "label": "エ",
        "textJa": "d"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ，即 c。WAF（Web Application Firewall）要检查发往 Web 应用的 HTTP 请求内容，例如可疑的输入或攻击模式。题目明确规定它本身不会加密、解密，所以在 a、b 的 HTTPS 加密区间无法直接读取请求正文；它应放在 SSL 加速器完成解密之后。同时，检查要发生在 Web 服务器处理请求之前，放在服务器后面的 d 已经太晚。c 恰好同时满足‘可以读到解密后的 HTTP 内容’和‘先于 Web 应用处理’两个条件。注意普通防火墙与 WAF 的关注点不同，本题不是简单把 WAF 放在最外层。",
    "transcriptionNoteZh": "原题网络结构图改为文字说明；a～d 所处的加密区间及相对位置按原图保留。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2023-A-11",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 11,
    "topicZh": "流程图与欧几里得减法循环",
    "stemJa": "次の流れ図において，① → ② → ③ → ⑤ → ② → ③ → ④ → ② → ⑥ の順に実行させるために，①においてmとnに与えるべき初期値aとbの関係はどれか。ここで，a，bはともに正の整数とする。",
    "options": [
      {
        "label": "ア",
        "textJa": "a＝2b"
      },
      {
        "label": "イ",
        "textJa": "2a＝b"
      },
      {
        "label": "ウ",
        "textJa": "2a＝3b"
      },
      {
        "label": "エ",
        "textJa": "3a＝2b"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。先按原卷流程图逐步倒推：①令 m＝a、n＝b；②不相等才去③。第一次要求执行⑤，说明此时 m＜n，即 a＜b。⑤把 n 更新成 b－a，而 m 仍为 a。第二次要求执行④，说明 a＞b－a。④把 m 更新成 a－(b－a)＝2a－b，此时 n 仍为 b－a。随后②直接去⑥，意味着两者相等，所以 2a－b＝b－a，整理得 3a＝2b。ア和ウ会使起始 a＞b，不会先到⑤；イ使 a＝b／2，执行⑤后立即相等，跳过④。此流程本质上通过反复相减寻找公因数。",
    "transcriptionNoteZh": "①～⑥节点编号、判断分支与更新方向以原卷完整流程图图片为准。",
    "imageAssets": [
      "question-images/fe-2023-a-11.png"
    ],
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 7
  },
  {
    "id": "FE-2023-A-12",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 12,
    "topicZh": "敏捷开发 Scrum",
    "stemJa": "アジャイル開発手法のスクラムにおいて，開発チームの全員が 1 人ずつ“昨日やったこと”，“今日やること”，“障害になっていること”などを話し，全員でプロジェクトの状況を共有するイベントはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "スプリントプランニング"
      },
      {
        "label": "イ",
        "textJa": "スプリントレビュー"
      },
      {
        "label": "ウ",
        "textJa": "デイリースクラム"
      },
      {
        "label": "エ",
        "textJa": "レトロスペクティブ"
      }
    ],
    "answer": "ウ",
    "explanationZh": "团队每天简短同步昨天完成什么、今天打算做什么、遇到什么阻碍，是每日 Scrum，选ウ。它帮助成员了解进展并及时发现协作障碍。ア“冲刺计划”是在冲刺开始时决定目标和要做的工作；イ“冲刺评审”是在冲刺结束时展示并检查产出；エ“回顾”是在冲刺结束后检视工作方式、决定如何改进。判断依据是题干的每日同步内容与频率，而非只看有没有团队会议。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 7
  },
  {
    "id": "FE-2023-A-13",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 13,
    "topicZh": "关键路径压缩与最小增量成本",
    "stemJa": "図に示すとおりに作業を実施する予定であったが，作業Aで1日の遅れが生じた。各作業の費用増加率を表の値とするとき，当初の予定日数で終了するために掛かる増加費用を最も少なくするには，どの作業を短縮すべきか。ここで，費用増加率とは，作業を1日短縮するために要する増加費用のことである。",
    "options": [
      {
        "label": "ア",
        "textJa": "B"
      },
      {
        "label": "イ",
        "textJa": "C"
      },
      {
        "label": "ウ",
        "textJa": "D"
      },
      {
        "label": "エ",
        "textJa": "E"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ，即缩短工作 E 一天。原定三条从开始到结束的路线为 A→B→E→G＝4＋6＋5＋5＝20 天，A→C→G＝4＋8＋5＝17 天，A→D→F→G＝4＋4＋4＋5＝17 天，所以首条是关键路径。A 延误一天后，关键路径变成 21 天，另两条仅为 18 天。要回到原定的 20 天，必须在关键路径上缩短一天。给定四个候选中，B 和 E 位于该路径，C 与 D 不在该路径；B 的缩短费用为 6，E 只需 2.5，因此 E 成本最低。虽然 D 的单日费用 2 更低，缩短 D 不能压低决定完工日的最长路径。",
    "transcriptionNoteZh": "作业依赖箭线、标准日数和各项费用增加率完整保留在原卷截图中。",
    "imageAssets": [
      "question-images/fe-2023-a-13.png"
    ],
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2023-A-14",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 14,
    "topicZh": "远程办公安全审计",
    "stemJa": "A 社では，従業員が自宅の PC からインターネット経由で自社のネットワークに接続して仕事を行うテレワーキングの実施を計画している。A 社が定めたテレワーキング運用規程について，情報セキュリティ管理基準（平成 28 年）に従って監査を実施した。判明した事項のうち，監査人が，指摘事項として監査報告書に記載すべきものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "テレワーキング運用規程に従うことを条件に，全ての従業員が利用できる。"
      },
      {
        "label": "イ",
        "textJa": "テレワーキングで従業員が使用する PC は，A 社から支給されたものに限定する。"
      },
      {
        "label": "ウ",
        "textJa": "テレワーキングで使用する PC へのマルウェア対策ソフト導入の要不要は，従業員それぞれが判断する。"
      },
      {
        "label": "エ",
        "textJa": "テレワーキングで使用する PC を，従業員の家族に使用させない。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "远程办公设备会连接企业网络，恶意软件防护应由组织统一规定并落实。ウ把是否安装防恶意软件交给每位员工自行决定，会造成保护水平不一致和可避免的感染风险，因此是审计应指出的问题。ア是在遵守统一规程的条件下开放使用，本身不是所问的缺陷；イ把设备限定为公司配发，便于统一管理；エ禁止家人共用工作设备，有助于减少未经授权的使用和信息泄露。审计看的是控制是否有明确、一致的要求。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2023-A-15",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 15,
    "topicZh": "云计算",
    "stemJa": "ハイブリッドクラウドの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "クラウドサービスが提供している機能の一部を，自社用にカスタマイズして利用すること"
      },
      {
        "label": "イ",
        "textJa": "クラウドサービスのサービス内容を，消費者向けと法人向けの両方を対象とするように構成して提供すること"
      },
      {
        "label": "ウ",
        "textJa": "クラウドサービスのサービス内容を，有償サービスと無償サービスとに区分して提供すること"
      },
      {
        "label": "エ",
        "textJa": "自社専用に使用するクラウドサービスと，汎用のクラウドサービスとの間でデータ及びアプリケーションソフトウェアの連携や相互運用が可能となる環境を提供すること"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。混合云把企业专用的私有云和面向一般用户的公有云连接起来，使数据与应用能在两边协作。重点是两种部署形态的组合与互通。ア是单一服务的定制；イ按客户类型划分；ウ按收费方式划分，都没有体现私有云与公有云的联动。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 9
  },
  {
    "id": "FE-2023-A-16",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 16,
    "topicZh": "多样性管理",
    "stemJa": "ダイバーシティマネジメントの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "従業員が仕事と生活の調和を図り，やりがいをもって業務に取り組み，組織の活力を向上させることである。"
      },
      {
        "label": "イ",
        "textJa": "性別や年齢，国籍などの面で従業員の多様性を尊重することによって，組織の活力を向上させることである。"
      },
      {
        "label": "ウ",
        "textJa": "自ら設定した目標の達成を目指して従業員が主体的に業務に取り組み，その達成度に応じて評価が行われることである。"
      },
      {
        "label": "エ",
        "textJa": "労使双方が労働条件についての合意を形成し，協調して収益の増大を目指すことである。"
      }
    ],
    "answer": "イ",
    "explanationZh": "多样性管理强调尊重并运用员工在性别、年龄、国籍等方面的差异，让不同经验与视角发挥作用，提升组织活力，所以选イ。ア描述工作与生活平衡；ウ强调员工设定目标、按达成度评价，属于目标管理式做法；エ强调劳资双方就劳动条件协商合作。它们都涉及组织管理，但只有イ直接以员工多样性为核心。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 9
  },
  {
    "id": "FE-2023-A-17",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 17,
    "topicZh": "企业资源计划",
    "stemJa": "ERP を説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "営業活動に IT を活用して営業の効率と品質を高め，売上・利益の大幅な増加や，顧客満足度の向上を目指す手法・概念である。"
      },
      {
        "label": "イ",
        "textJa": "卸売業・メーカが小売店の経営活動を支援することによって，自社との取引量の拡大につなげる手法・概念である。"
      },
      {
        "label": "ウ",
        "textJa": "企業全体の経営資源を有効かつ総合的に計画して管理し，経営の効率向上を図るための手法・概念である。"
      },
      {
        "label": "エ",
        "textJa": "消費者向けや企業間の商取引を，インターネットなどの電子的なネットワークを活用して行う手法・概念である。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "ERP 是企业资源计划，着眼于企业整体，把资金、人力、物料等经营资源综合规划和管理，提高经营效率，因此ウ正确。ア只聚焦销售活动的信息化，更接近销售支援；イ是批发商或制造商支援零售商经营，以扩大双方交易；エ是通过网络开展电子商务。ERP 的辨识词是“企业整体的经营资源”与“综合计划管理”，范围比单一销售或线上交易更广。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 10
  },
  {
    "id": "FE-2023-A-18",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 18,
    "topicZh": "创新扩散理论",
    "stemJa": "イノベータ理論では，消費者を新製品の購入時期によって，イノベータ，アーリーアダプタ，アーリーマジョリティ，レイトマジョリティ，ラガードの五つに分類する。アーリーアダプタの説明として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "新しい製品及び新技術の採用には懐疑的で，周囲の大多数が採用している場面を見てから採用する層"
      },
      {
        "label": "イ",
        "textJa": "新商品，サービスなどを，リスクを恐れず最も早い段階で受容する層"
      },
      {
        "label": "ウ",
        "textJa": "新商品，サービスなどを早期に受け入れ，消費者に大きな影響を与える層であり，流行に敏感で，自ら情報収集を行い判断する層"
      },
      {
        "label": "エ",
        "textJa": "世の中の動きに関心が薄く，流行が一般化してからそれを採用することが多い層であり，場合によっては不採用を貫く，最も保守的な層"
      }
    ],
    "answer": "ウ",
    "explanationZh": "早期采用者（アーリーアダプタ）会较早接受新产品，主动搜集信息并作判断，而且能影响其他消费者，因此ウ正确。イ强调“不怕风险、最早接受”，对应更早的创新者。ア对新技术持怀疑态度，等多数人采用后才跟进，属于较晚采用者。エ对潮流兴趣低、可能始终不采用，是最后的落后采用者。记顺序：创新者→早期采用者→早期大众→晚期大众→落后采用者；早期采用者虽早，却不是最先一批。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 10
  },
  {
    "id": "FE-2023-A-19",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 19,
    "topicZh": "企业信息负责人",
    "stemJa": "CIO の説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "経営戦略の立案及び業務執行を統括する最高責任者"
      },
      {
        "label": "イ",
        "textJa": "資金調達，財務報告などの財務面での戦略策定及び執行を統括する最高責任者"
      },
      {
        "label": "ウ",
        "textJa": "自社の技術戦略や研究開発計画の立案及び執行を統括する最高責任者"
      },
      {
        "label": "エ",
        "textJa": "情報管理，情報システムに関する戦略立案及び執行を統括する最高責任者"
      }
    ],
    "answer": "エ",
    "explanationZh": "CIO 是首席信息官，负责信息管理及信息系统相关战略的制定与执行，所以选エ。ア统筹经营战略和业务执行，接近 CEO 的职责；イ管融资、财务报告及财务战略，对应 CFO；ウ管技术战略与研发计划，对应 CTO。区分这些职位时看主管领域：信息系统是 CIO，财务是 CFO，技术研发是 CTO，企业整体经营是 CEO。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 11
  },
  {
    "id": "FE-2023-A-20",
    "kind": "official",
    "year": 2023,
    "section": "A",
    "number": 20,
    "topicZh": "软件许可与批量授权",
    "stemJa": "ボリュームライセンス契約の説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "企業などソフトウェアの大量購入者向けに，インストールできる台数をあらかじめ取り決め，ソフトウェアの使用を認める契約"
      },
      {
        "label": "イ",
        "textJa": "使用場所を限定した契約であり，特定の施設の中であれば台数や人数に制限なく使用が許される契約"
      },
      {
        "label": "ウ",
        "textJa": "ソフトウェアをインターネットからダウンロードしたとき画面に表示される契約内容に同意するを選択することによって，使用が許される契約"
      },
      {
        "label": "エ",
        "textJa": "標準の使用許諾条件を定め，その範囲で一定量のパッケージの包装を解いたときに，権利者と購入者との間に使用許諾契約が自動的に成立したとみなす契約"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。‘Volume’是数量，批量许可面向需要在多台设备上使用软件的企业等购买者，先约定允许安装或使用的数量，再按合同取得使用权。它并不意味着可以无限安装。イ强调某一场所内不限设备或人数，与题目的数量约定不同。ウ说在下载时点击同意，是通过界面同意许可条款；エ描述拆开包装即视为同意的旧式许可形式。做题时抓住‘大量购买’与‘事先约定台数’两项条件。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_a_ans.pdf",
    "page": 11
  },
  {
    "id": "FE-2023-B-01",
    "kind": "official",
    "year": 2023,
    "section": "B",
    "number": 1,
    "topicZh": "质数判定与循环",
    "stemJa": "次のプログラム中の［ a ］と［ b ］に入れる正しい答えの組合せを，解答群の中から選べ。ここで，配列の要素番号は 1 から始まる。\n\n関数 findPrimeNumbers は，引数で与えられた整数以下の，全ての素数だけを格納した配列を返す関数である。ここで，引数に与える整数は 2 以上である。\n\n〔プログラム〕\n○整数型の配列: findPrimeNumbers(整数型: maxNum)\n    整数型の配列: pnList ← {} // 要素数0の配列\n    整数型: i, j\n    論理型: divideFlag\n    for (i を 2 から［ a ］まで 1 ずつ増やす)\n        divideFlag ← true\n        /* iの正の平方根の整数部分が2未満のときは，繰返し処理を実行しない */\n        for (j を 2 から iの正の平方根の整数部分 まで 1 ずつ増やす) // α\n            if (［ b ］)\n                divideFlag ← false\n                αの行から始まる繰返し処理を終了する\n            endif\n        endfor\n        if (divideFlag が true と等しい)\n            pnListの末尾 に iの値 を追加する\n        endif\n    endfor\n    return pnList",
    "options": [
      {
        "label": "ア",
        "textJa": "a: maxNum ／ b: i ÷ j の余り が 0 と等しい"
      },
      {
        "label": "イ",
        "textJa": "a: maxNum ／ b: i ÷ j の商 が 1 と等しくない"
      },
      {
        "label": "ウ",
        "textJa": "a: maxNum ＋ 1 ／ b: i ÷ j の余り が 0 と等しい"
      },
      {
        "label": "エ",
        "textJa": "a: maxNum ＋ 1 ／ b: i ÷ j の商 が 1 と等しくない"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。要求包含不大于maxNum的所有质数，所以外层循环必须走到maxNum，不能到maxNum＋1。若i有介于2和√i之间的因子j，则i÷j的余数为0，此时把divideFlag设为false并退出；若一个也没有，i才是质数。イ、エ检查商是否不等于1，商的值不能判断整除；ウ、エ会把大于上限的maxNum＋1也纳入候选，可能返回越界的质数。只需查到平方根，是因为合数的两个因子不可能都大于其平方根。",
    "transcriptionNoteZh": "原卷以方框标示 a、b 两个空栏；纯文本中用［ a ］和［ b ］表示。选项中的 a:、b: 是原卷双列表格的文字化排列。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_b_ans.pdf",
    "page": 4
  },
  {
    "id": "FE-2023-B-02",
    "kind": "official",
    "year": 2023,
    "section": "B",
    "number": 2,
    "topicZh": "函数调用顺序",
    "stemJa": "次の記述中の［ a ］に入れる正しい答えを，解答群の中から選べ。\n\n次のプログラムにおいて，手続 proc2 を呼び出すと，［ a ］の順に出力される。\n\n〔プログラム〕\n○proc1()\n    \"A\" を出力する\n    proc3()\n○proc2()\n    proc3()\n    \"B\" を出力する\n    proc1()\n○proc3()\n    \"C\" を出力する",
    "options": [
      {
        "label": "ア",
        "textJa": "“A”，“B”，“B”，“C”"
      },
      {
        "label": "イ",
        "textJa": "“A”，“C”"
      },
      {
        "label": "ウ",
        "textJa": "“A”，“C”，“B”，“C”"
      },
      {
        "label": "エ",
        "textJa": "“B”，“A”，“B”，“C”"
      },
      {
        "label": "オ",
        "textJa": "“B”，“C”，“B”，“A”"
      },
      {
        "label": "カ",
        "textJa": "“C”，“B”"
      },
      {
        "label": "キ",
        "textJa": "“C”，“B”，“A”"
      },
      {
        "label": "ク",
        "textJa": "“C”，“B”，“A”，“C”"
      }
    ],
    "answer": "ク",
    "explanationZh": "正确答案是ク。执行proc2时，第一句调用proc3输出C；回到proc2后输出B；再调用proc1，先输出A，再由proc1调用proc3输出C，因此完整顺序是C、B、A、C。ア至オ的起始字母或后续顺序与实际调用链不符；カ停在B，漏了proc1；キ漏了proc1内部最后一次proc3调用。解这类题应顺着调用栈逐行走，子过程执行完才回到调用处的下一行。",
    "transcriptionNoteZh": "原卷空栏以方框标示；纯文本中用［ a ］表示。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_b_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2023-B-03",
    "kind": "official",
    "year": 2023,
    "section": "B",
    "number": 3,
    "topicZh": "快速排序逐行追踪",
    "stemJa": "問３ 次の記述中の［　］に入れる正しい答えを，解答群の中から選べ。 ここで，\n配列の要素番号は 1 から始まる。\n\n次の手続 sort は，大域の整数型の配列 data の，引数 first で与えられた要素番号\nから引数 last で与えられた要素番号までの要素を昇順に整列する。 ここで，first\n＜ last とする。手続 sort を sort(1, 5) として呼び出すと，/*** α ***/ の行を最\n初に実行したときの出力は“［　］”となる。\n\n〔プログラム〕\n大域: 整数型の配列: data ← {2, 1, 3, 5, 4}\n\n○sort(整数型: first, 整数型: last)\n  整数型: pivot, i, j\n  pivot ← data[(first ＋ last) ÷ 2 の商]\n  i ← first\n  j ← last\n\n  while (true)\n    while (data[i] ＜ pivot)\n      i ← i ＋ 1\n    endwhile\n    while (pivot ＜ data[j])\n      j ← j － 1\n    endwhile\n    if (i ≧ j)\n      繰返し処理を終了する\n    endif\n    data[i]とdata[j]の値を入れ替える\n    i ← i ＋ 1\n    j ← j － 1\n  endwhile\n  dataの全要素の値を要素番号の順に空白区切りで出力する  /*** α ***/\n  if (first ＜ i － 1)\n    sort(first, i － 1)\n  endif\n  if (j ＋ 1 ＜ last)\n    sort(j ＋ 1, last)\n  endif",
    "options": [
      {
        "label": "ア",
        "textJa": "1 2 3 4 5"
      },
      {
        "label": "イ",
        "textJa": "1 2 3 5 4"
      },
      {
        "label": "ウ",
        "textJa": "2 1 3 4 5"
      },
      {
        "label": "エ",
        "textJa": "2 1 3 5 4"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。pivot 是 data[(1＋5)÷2]=data[3]=3。i 从1开始，data[1]=2小于3，于是 i 到2；data[2]=1仍小于3，i 到3。j 从5开始，data[5]=4大于3，于是 j 到4；data[4]=5仍大于3，j 到3。此时 i=3、j=3，满足 i≧j，内层循环结束，尚未发生交换，data 仍为 {2,1,3,5,4}。因此首次执行 α 行输出“2 1 3 5 4”。要记住题问的是第一次输出，不是递归排序后的最终结果。",
    "transcriptionNoteZh": "原题为 IPA 公开科目 B 试卷；日语正文按原卷文字提取并补标方框空栏。图片为同一道原卷的完整页面，表格、图形及排版请以图片核对。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_b_ans.pdf",
    "page": 6,
    "imageAssets": [
      "question-images/fe-2023-b-03-p6.png",
      "question-images/fe-2023-b-03-p7.png"
    ]
  },
  {
    "id": "FE-2023-B-04",
    "kind": "official",
    "year": 2023,
    "section": "B",
    "number": 4,
    "topicZh": "哈希表双哈希定位",
    "stemJa": "問４ 次の記述中の［　］に入れる正しい答えを，解答群の中から選べ。 ここで，\n配列の要素番号は 1 から始まる。\n\n関数 add は，引数で指定された正の整数 value を大域の整数型の配列 hashArray に\n格納する。格納できた場合は true を返し，格納できなかった場合は false を返す。\nここで，整数 value を hashArray のどの要素に格納すべきかを，関数 calcHash1 及び\ncalcHash2 を利用して決める。\n手続 test は，関数 add を呼び出して，hashArray に正の整数を格納する。手続\ntest の処理が終了した直後の hashArray の内容は，［　］である。\n\n〔プログラム〕\n大域: 整数型の配列: hashArray\n\n○論理型: add(整数型: value)\n  整数型: i ← calcHash1(value)\n  if (hashArray[i] ＝ －1)\n    hashArray[i] ← value\n    return true\n  else\n    i ← calcHash2(value)\n    if (hashArray[i] ＝ －1)\n      hashArray[i] ← value\n      return true\n    endif\n  endif\n  return false\n\n○整数型: calcHash1(整数型: value)\n  return (value mod hashArrayの要素数) ＋ 1\n\n○整数型: calcHash2(整数型: value)\n  return ((value ＋ 3) mod hashArrayの要素数) ＋ 1\n\n○test()\n  hashArray ← {5個の －1}\n  add(3)\n  add(18)\n  add(11)",
    "options": [
      {
        "label": "ア",
        "textJa": "{－1, 3, －1, 18, 11}"
      },
      {
        "label": "イ",
        "textJa": "{－1, 11, －1, 3, －1}"
      },
      {
        "label": "ウ",
        "textJa": "{－1, 11, －1, 18, －1}"
      },
      {
        "label": "エ",
        "textJa": "{－1, 18, －1, 3, 11}"
      },
      {
        "label": "オ",
        "textJa": "{－1, 18, 11, 3, －1}"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。数组有5格，下标从1开始。add(3) 的首选位置是 3 mod 5＋1=4，所以第4格放3。add(18) 的首选也是 18 mod 5＋1=4，碰撞后改算 (18＋3) mod 5＋1=2，故第2格放18。add(11) 的首选是 11 mod 5＋1=2，也被占用；次选 (11＋3) mod 5＋1=5，故第5格放11。最终为 {－1,18,－1,3,11}。逐次写出位置、是否碰撞和备用位置，可避免把值与下标混淆。",
    "transcriptionNoteZh": "原题为 IPA 公开科目 B 试卷；日语正文按原卷文字提取并补标方框空栏。图片为同一道原卷的完整页面，表格、图形及排版请以图片核对。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_b_ans.pdf",
    "page": 8,
    "imageAssets": [
      "question-images/fe-2023-b-04-p8.png",
      "question-images/fe-2023-b-04-p9.png"
    ]
  },
  {
    "id": "FE-2023-B-05",
    "kind": "official",
    "year": 2023,
    "section": "B",
    "number": 5,
    "topicZh": "余弦相似度",
    "stemJa": "問５ 次のプログラム中 の［ a ］と［ b ］に入れる正しい答えの組合せを，\n解答群の中から選べ。ここで，配列の要素番号は 1 から始まる。\n\nコサイン類似度は ，二つ のベクトル の向き の類似性を 測る 尺度 である。 関数\ncalcCosineSimilarity は，いずれも要素数が n(n≧1) である実数型の配列 vector1\nと vector2 を受け取り，二つの配列のコサイン類似度を返す。配列 vector1 が {a1,\na2, …, an}，配列 vector2 が {b1, b2, …, bn} のとき，コサイン類似度は次の数式で\n計算される。ここで，配列 vector1 と配列 vector2 のいずれも，全ての要素に 0 が格\n納されていることはないものとする。\n\n(a1b1 ＋ a2b2 ＋ … ＋ anbn) ÷ (√(a1² ＋ a2² ＋ … ＋ an²) × √(b1² ＋ b2² ＋ … ＋ bn²))\n\n〔プログラム〕\n○実数型: calcCosineSimilarity(実数型の配列: vector1,\n                               実数型の配列: vector2)\n  実数型: similarity, numerator, denominator, temp ← 0\n  整数型: i\n  numerator ← 0\n\n  for (i を 1 から vector1の要素数 まで 1 ずつ増やす)\n    numerator ← numerator ＋ ［ a ］\n  endfor\n\n  for (i を 1 から vector1の要素数 まで 1 ずつ増やす)\n    temp ← temp ＋ vector1[i]の2乗\n  endfor\n  denominator ← tempの正の平方根\n\n  temp ← 0\n  for (i を 1 から vector2の要素数 まで 1 ずつ増やす)\n    temp ← temp ＋ vector2[i]の2乗\n  endfor\n  denominator ← ［ b ］\n\n  similarity ← numerator ÷ denominator\n  return similarity",
    "options": [
      {
        "label": "ア",
        "textJa": "a：(vector1[i] × vector2[i])の正の平方根／b：denominator × (tempの正の平方根)"
      },
      {
        "label": "イ",
        "textJa": "a：(vector1[i] × vector2[i])の正の平方根／b：denominator ＋ (tempの正の平方根)"
      },
      {
        "label": "ウ",
        "textJa": "a：(vector1[i] × vector2[i])の正の平方根／b：tempの正の平方根"
      },
      {
        "label": "エ",
        "textJa": "a：vector1[i] × vector2[i]／b：denominator × (tempの正の平方根)"
      },
      {
        "label": "オ",
        "textJa": "a：vector1[i] × vector2[i]／b：denominator ＋ (tempの正の平方根)"
      },
      {
        "label": "カ",
        "textJa": "a：vector1[i] × vector2[i]／b：tempの正の平方根"
      },
      {
        "label": "キ",
        "textJa": "a：vector1[i]の2乗／b：denominator × (tempの正の平方根)"
      },
      {
        "label": "ク",
        "textJa": "a：vector1[i]の2乗／b：denominator ＋ (tempの正の平方根)"
      },
      {
        "label": "ケ",
        "textJa": "a：vector1[i]の2乗／b：tempの正の平方根"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。余弦相似度的分子是两向量对应元素乘积的总和，因此第一处每轮加 vector1[i]×vector2[i]。分母是两个向量长度的乘积：第一轮平方和开根后已存入 denominator，第二轮把 vector2 的平方和开根，必须继续相乘，所以第二处为 denominator×√temp。不能把对应乘积逐项开根，也不能把长度相加；仅把第二向量长度赋给分母则丢失第一向量的长度。可用相同向量检验结果应为1。",
    "transcriptionNoteZh": "原题为 IPA 公开科目 B 试卷；日语正文按原卷文字提取并补标方框空栏。图片为同一道原卷的完整页面，表格、图形及排版请以图片核对。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_b_ans.pdf",
    "page": 10,
    "imageAssets": [
      "question-images/fe-2023-b-05-p10.png",
      "question-images/fe-2023-b-05-p11.png"
    ]
  },
  {
    "id": "FE-2023-B-06",
    "kind": "official",
    "year": 2023,
    "section": "B",
    "number": 6,
    "topicZh": "委外扫描邮件冒充风险",
    "stemJa": "問６ A 社は，放送会社や運輸会社向けに広告制作ビジネスを展開 している。A 社は，人\n事業務の効率化を図るべく，人事業務の委託を検討することにした。A 社が委託する\n業務（以下，B 業務という）を図 1 に示す。\n\n・採用予定者から郵送されてくる入社時の誓約書，前職の源泉徴収票などの書類を PDF フ\nァイルに変換し，ファイルサーバに格納する。\n（省略）\n図 1 B 業務\n\n 委託先候補の C 社は，B 業務について，次のように A 社に提案した。\n・B 業務だけに従事する専任の従業員を割り当てる。\n・B 業務では，図 2 の複合機のスキャン機能を使用する。\n\n・スキャン機能を使用する際は，従業員ごとに付与した利用者 ID とパスワードをパネルに入\n力する。\n・スキャンしたデータを PDF ファイルに変換する。\n・PDF ファイルを従業員ごとに異なる鍵で暗号化して，電子メールに添付する。\n・スキャンを実行した本人宛てに電子メールを送信する。\n・PDF ファイルが大きい場合は，PDF ファイルを添付する代わりに，自社の社内ネットワーク\n上に設置したサーバ（以下，B サーバという）1)に自動的に保存し，保存先の URL を電子メ\nールの本文に記載して送信する。\n注 1) B サーバにアクセスする際は，従業員ごとの利用者 ID とパスワードが必要になる。\n図 2 複合機のスキャン機能（抜粋）\n\n A 社は，C 社と業務委託契約を締結する前に，秘密保持契約を締結し た。その後，C\n社に質問表を送付し，回答を受けて，業務委託での情報セキュリティリスクの評価を\n実施した。その結果，図 3 の発見があった。\n\n・複合機のスキャン機能では，電子メールの差出人アドレス，件名，本文及び添付ファイル\n名を初期設定 1)の状態で使用しており，誰がスキャンを実行しても同じである。\n・複合機のスキャン機能の初期設定情報はベンダーの Web サイトで公開されており，誰でも\n閲覧できる。\n注 1)  複合機の初期設定はC 社の情報システム部だけが変更可能である。\n図 3 発見事項\n\n そこで，A 社では，初期設定の状態のままでは A 社にとって情報セキュリティリス\nクがあり，初期設定から変更するという対策が必要であると評価した。\n\n設問 対策が必要であると A 社が評価した情報セキュリティリスクはどれか。解答群の\nうち，最も適切なものを選べ。",
    "options": [
      {
        "label": "ア",
        "textJa": "B業務に従事する従業員が，攻撃者からの電子メールを複合機からのものと信じて本文中にあるURLをクリックし，フィッシングサイトに誘導される。その結果，A社の採用予定者の個人情報が漏えいする。"
      },
      {
        "label": "イ",
        "textJa": "B業務に従事する従業員が，複合機から送信される電子メールをスパムメールと誤認し，電子メールを削除する。その結果，再スキャンが必要となり，B業務が遅延する。"
      },
      {
        "label": "ウ",
        "textJa": "攻撃者が，複合機から送信される電子メールを盗聴し，添付ファイルを暗号化して身代金を要求する。その結果，A社が復号鍵を受け取るために多額の身代金を支払うことになる。"
      },
      {
        "label": "エ",
        "textJa": "攻撃者が，複合機から送信される電子メールを盗聴し，本文に記載されているURLを使ってBサーバにアクセスする。その結果，A社の採用予定者の個人情報が漏えいする。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。已知扫描设备发出的邮件在发件人、主题、正文和附件名上对所有人都使用同一套公开的初始设置。攻击者可照着公开模板伪造看似来自设备的邮件，在正文放假链接；工作人员相信邮件而进入钓鱼站，可能泄露处理中的个人信息。イ说真实邮件被误删，与设置公开导致的冒充风险不相符。ウ把窃听邮件直接推成对附件实施勒索，缺少条件；エ即使知道邮件里的B服务器URL，服务器还要求员工账号和密码，单凭URL不能访问。",
    "transcriptionNoteZh": "原题为 IPA 公开科目 B 试卷；日语正文按原卷文字提取并补标方框空栏。图片为同一道原卷的完整页面，表格、图形及排版请以图片核对。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_b_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/t6hhco0000003zx0-att/2023r05_fe_kamoku_b_ans.pdf",
    "page": 12,
    "imageAssets": [
      "question-images/fe-2023-b-06-p12.png",
      "question-images/fe-2023-b-06-p13.png"
    ]
  },
  {
    "id": "FE-2022-SAMPLE-A-01",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 1,
    "topicZh": "二补数与按位运算",
    "stemJa": "負数を 2 の補数で表すとき，8 ビットの 2 進正数 n に対し－n を求める式はどれか。ここで，＋は加算を表し，OR はビットごとの論理和，XOR はビットごとの排他的論理和を表す。",
    "options": [
      {
        "label": "ア",
        "textJa": "(n OR 10000000) ＋ 00000001"
      },
      {
        "label": "イ",
        "textJa": "(n OR 11111110) ＋ 11111111"
      },
      {
        "label": "ウ",
        "textJa": "(n XOR 10000000) ＋ 11111111"
      },
      {
        "label": "エ",
        "textJa": "(n XOR 11111111) ＋ 00000001"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。8 位二补数表示中，把正数 n 变成－n 的固定步骤是‘每一位 0、1 反转，然后加 1’。与 11111111 逐位 XOR 恰好完成所有位的反转，再加 00000001，所以得到目标值。以 n=00000101（5）为例，反转成 11111010，再加 1 得 11111011，作为 8 位二补数即－5。ア只强制最高位为 1，不会反转其他位；イ的 OR 会强制许多位为 1；ウ只翻转最高位且加的数也不对。要注意运算在题目指定的 8 位范围内理解。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 4
  },
  {
    "id": "FE-2022-SAMPLE-A-02",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 2,
    "topicZh": "十进制转二进制的流程图",
    "stemJa": "次の流れ図は，10 進整数 j（0＜j＜100）を 8 桁の 2 進数に変換する処理を表している。2 進数は下位桁から順に，配列の要素 NISHIN (1) から NISHIN (8) に格納される。流れ図の a 及び b に入れる処理はどれか。ここで，j div 2 は j を2 で割った商の整数部分を，j mod 2は jを2で割った余りを表す。",
    "options": [
      {
        "label": "ア",
        "textJa": "a：j ← j div 2／b：NISHIN (k) ← j mod 2"
      },
      {
        "label": "イ",
        "textJa": "a：j ← j mod 2／b：NISHIN (k) ← j div 2"
      },
      {
        "label": "ウ",
        "textJa": "a：NISHIN (k) ← j div 2／b：j ← j mod 2"
      },
      {
        "label": "エ",
        "textJa": "a：NISHIN (k) ← j mod 2／b：j ← j div 2"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。把整数反复除以 2 时，每次的余数就是当前最低位，因此先执行 NISHIN(k)←j mod 2，把这一位保存下来；再用 j←j div 2 去掉已保存的最低位，准备取下一位。流程图中的 k 从 1 到 8，正好按低位到高位存入数组。以 j＝5 为例：第一次存 1 后 j＝2，第二次存 0 后 j＝1，第三次存 1，得到低位起 1、0、1。ア先除再取余，会丢掉原最低位；イ把 j 改为余数，使后续高位无法取得；ウ保存商而非单个二进制位，也不对。",
    "transcriptionNoteZh": "原卷流程图与 a/b 对照表完整保存在题目图片；选项在文字区按原表逐行线性化。",
    "imageAssets": [
      "question-images/fe-2022-sample-a-02.png"
    ],
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 4
  },
  {
    "id": "FE-2022-SAMPLE-A-03",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 3,
    "topicZh": "命题逻辑与逐步推理",
    "stemJa": "P，Q，R はいずれも命題である。命題 P の真理値は真であり，命題 (not P ) or Q 及び命題 (not Q ) or R のいずれの真理値も真であることが分かっている。Q，R の真理値はどれか。ここで，X or Y は X と Y の論理和，not X は X の否定を表す。",
    "options": [
      {
        "label": "ア",
        "textJa": "Q：偽，R：偽"
      },
      {
        "label": "イ",
        "textJa": "Q：偽，R：真"
      },
      {
        "label": "ウ",
        "textJa": "Q：真，R：偽"
      },
      {
        "label": "エ",
        "textJa": "Q：真，R：真"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。题目已知 P 为真，所以 not P 为假。要让‘假 or Q’为真，Q 只能为真。接着 Q 为真意味着 not Q 为假；要让‘假 or R’也为真，R 只能为真。于是 Q 和 R 都为真。ア、イ把 Q 设成假，会让第一个复合命题为假；ウ把 R 设成假，会让第二个复合命题为假。做题时先把已知的 P 代入第一式，得到 Q，再把 Q 代入第二式，比同时猜两个未知量简单。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2022-SAMPLE-A-04",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 4,
    "topicZh": "有限状态自动机的输出追踪",
    "stemJa": "入力記号，出力記号の集合が｛0，1｝であり，状態遷移図で示されるオートマトンがある。0011001110 を入力記号とした場合の出力記号はどれか。ここで，入力記号は左から順に読み込まれるものとする。また，S₁ は初期状態を表し，遷移の矢印のラベルは，入力／出力を表している。",
    "options": [
      {
        "label": "ア",
        "textJa": "0001000110"
      },
      {
        "label": "イ",
        "textJa": "0001001110"
      },
      {
        "label": "ウ",
        "textJa": "0010001000"
      },
      {
        "label": "エ",
        "textJa": "0011111110"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。按原卷状态图从 S₁ 开始逐字符追踪：前两个 0 都沿 S₁ 的 0／0 自环，输出 00；第一个 1 沿 S₁→S₂ 的 1／0 输出 0；第二个 1 沿 S₂→S₃ 的 1／1 输出 1。接下来的 0 从 S₃ 回 S₁ 输出 0，再一个 0 在 S₁ 输出 0；后面三个 1 分别走 S₁→S₂（0）、S₂→S₃（1）、S₃ 自环（1）；最后 0 从 S₃ 回 S₁ 输出 0。逐位合并为 0001000110。其余三个选项至少有一个状态转换后的输出位与图不符。",
    "transcriptionNoteZh": "状态、箭头方向及输入／输出标记以原卷图片为准，图片包含完整状态图和选项。",
    "imageAssets": [
      "question-images/fe-2022-sample-a-04.png"
    ],
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2022-SAMPLE-A-05",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 5,
    "topicZh": "二叉搜索树性质",
    "stemJa": "2分探索木になっている2分木はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "図ア"
      },
      {
        "label": "イ",
        "textJa": "図イ"
      },
      {
        "label": "ウ",
        "textJa": "図ウ"
      },
      {
        "label": "エ",
        "textJa": "図エ"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。二叉搜索树要求每个节点的左子树所有值小于该节点，右子树所有值大于该节点，检查必须覆盖整个子树。イ的根为 17，左子树 14、10、16 都小于 17，右子树 19、18 都大于 17；各子节点也分别满足左右大小关系。ア的节点 15 的右孩子 14 比 15 小；ウ的节点 16 的右孩子 14 比 16 小；エ的根 20 的右孩子 19 比 20 小。这些局部逆序就足以排除。图形结构与节点数值请直接看原卷图片。",
    "transcriptionNoteZh": "四棵候选树无法用单行文字准确表达父子关系，完整保留官方原卷截图。",
    "imageAssets": [
      "question-images/fe-2022-sample-a-05.png"
    ],
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2022-SAMPLE-A-06",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 6,
    "topicZh": "二维数组旋转与坐标映射",
    "stemJa": "配列Aが図2の状態のとき，図1の流れ図を実行すると，配列Bが図3の状態になった。図 1 の a に入れる操作はどれか。ここで，配列 A，B の要素をそれぞれ A (i，j) ，B (i，j) とする。",
    "options": [
      {
        "label": "ア",
        "textJa": "B (7－i，7－j) ← A (i，j)"
      },
      {
        "label": "イ",
        "textJa": "B (7－j，i) ← A (i，j)"
      },
      {
        "label": "ウ",
        "textJa": "B (i，7－j) ← A (i，j)"
      },
      {
        "label": "エ",
        "textJa": "B ( j，7－i) ← A (i，j)"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。原图中 A 的第 1 列从上到下有连续的星号，执行后 B 的第 1 行从右到左有连续星号；A 的第 0 行横向星号则变为 B 的第 7 列纵向星号，说明整体顺时针旋转 90 度。对于从 0 到 7 的 8×8 下标，原位置 (i,j) 顺时针旋转后的坐标为 (j,7－i)，即 B(j,7－i)←A(i,j)。ア是旋转 180 度；イ是逆时针 90 度；ウ只作左右镜像。对照原图中的 L 形星号即可验证四种变换的方向。",
    "transcriptionNoteZh": "数组星号分布、循环流程图以及四个坐标表达式均保留在官方原卷图片中。",
    "imageAssets": [
      "question-images/fe-2022-sample-a-06.png"
    ],
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 7
  },
  {
    "id": "FE-2022-SAMPLE-A-07",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 7,
    "topicZh": "哈希函数与取余",
    "stemJa": "10 進法で 5 桁の数 a1a2a3a4a5 を，ハッシュ法を用いて配列に格納したい。ハッシュ関数を mod ( a1＋a2＋a3＋a4＋a5，13 ) とし，求めたハッシュ値に対応する位置の配列要素に格納する場合，54321 は配列のどの位置に入るか。ここで，mod ( x，13 ) は，x を 13 で割った余りとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "1"
      },
      {
        "label": "イ",
        "textJa": "2"
      },
      {
        "label": "ウ",
        "textJa": "7"
      },
      {
        "label": "エ",
        "textJa": "11"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ，位置 2。哈希函数已明确要求先把五个十进制数字逐位相加，54321 的各位是 5、4、3、2、1，和为 15。再求 15 除以 13 的余数：15＝13×1＋2，因此 mod(15,13)＝2。题目说‘与哈希值对应的位置’，所以放在下标 2。ア、ウ、エ都不是实际余数。不要把 54321 整个数拿去除以 13，也不要把五位按乘法处理；应严格按函数中写出的逐位求和执行。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2022-SAMPLE-A-08",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 8,
    "topicZh": "递归函数展开",
    "stemJa": "自然数 n に対して，次のとおり再帰的に定義される関数 f (n) を考える。f (5) の値はどれか。\nf (n)： if n≦1 then return 1 else return n＋ f (n－1)",
    "options": [
      {
        "label": "ア",
        "textJa": "6"
      },
      {
        "label": "イ",
        "textJa": "9"
      },
      {
        "label": "ウ",
        "textJa": "15"
      },
      {
        "label": "エ",
        "textJa": "25"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ，即 15。递归是函数在计算中再次调用自己，这里必须不断把 n 减 1，直到遇到停止条件 n≤1。依次展开：f(5)＝5＋f(4)＝5＋4＋f(3)＝5＋4＋3＋f(2)＝5＋4＋3＋2＋f(1)。因为 f(1)＝1，合计 5＋4＋3＋2＋1＝15。ア、イ、エ都不等于完整展开的和。最容易漏掉的是最后的 f(1)；停止条件并不是返回 0，而是明确返回 1。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2022-SAMPLE-A-09",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 9,
    "topicZh": "编码规范与分配失败处理",
    "stemJa": "プログラムのコーディング規約に規定する事項のうち，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "局所変数は，用途が異なる場合でもデータ型が同じならば，できるだけ同一の変数を使うようにする。"
      },
      {
        "label": "イ",
        "textJa": "処理性能を向上させるために，ループの制御変数には浮動小数点型変数を使用する。"
      },
      {
        "label": "ウ",
        "textJa": "同様の計算を何度も繰り返すときは，関数の再帰呼出しを用いる。"
      },
      {
        "label": "エ",
        "textJa": "領域割付け関数を使用するときは，割付けができなかったときの処理を記述する。"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。程序申请内存等资源可能失败；如果调用分配函数后不检查结果，就可能继续使用无效地址并导致程序异常。因此编码规范应要求写明分配失败时如何处理，例如报错、释放已取得的资源或安全结束。ア把不同用途的变量复用会降低代码可读性；イ用浮点数控制循环容易受精度误差影响，不能当作性能规则；ウ的递归也不是重复计算的通用要求，还可能增加调用开销。编码规范追求可读、可靠与一致，而非只追求写法短。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 9
  },
  {
    "id": "FE-2022-SAMPLE-A-10",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 10,
    "topicZh": "外部中断与内部异常",
    "stemJa": "外部割込みの原因となるものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "ゼロによる除算命令の実行"
      },
      {
        "label": "イ",
        "textJa": "存在しない命令コードの実行"
      },
      {
        "label": "ウ",
        "textJa": "タイマーによる時間経過の通知"
      },
      {
        "label": "エ",
        "textJa": "ページフォールトの発生"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。外部中断来自处理器正在执行的指令流程之外，例如定时器到时后向 CPU 发出的通知。CPU 暂停当前执行并转去处理中断。ア的除以零、イ的无效指令、エ的缺页都是当前程序执行指令时触发的异常，通常归入内部中断或异常处理。区分时问自己：原因是‘外设或计时器在外部发来通知’，还是‘当前指令执行中出现问题’？本题只有定时器符合前者。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 9
  },
  {
    "id": "FE-2022-SAMPLE-A-11",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 11,
    "topicZh": "ECC 冗余位与指数",
    "stemJa": "メモリのエラー検出及び訂正に ECC を利用している。データバス幅 2ⁿ ビットに対して冗長ビットが n＋2 ビット必要なとき，128 ビットのデータバス幅に必要な冗長ビットは何ビットか。",
    "options": [
      {
        "label": "ア",
        "textJa": "7"
      },
      {
        "label": "イ",
        "textJa": "8"
      },
      {
        "label": "ウ",
        "textJa": "9"
      },
      {
        "label": "エ",
        "textJa": "10"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ，9 位。题目直接给出规则：数据总线宽度写作 2 的 n 次方位时，冗余位数是 n＋2。128＝2⁷，因此 n＝7，代入得到 7＋2＝9。这里无需推导 ECC 编码结构，也不要把 128 直接加 2；关键是先把 128 写成 2 的幂。ア只取指数而忘记加 2，イ少算 1，エ多算 1。ECC 是让存储器具备检测和纠正某些错误能力的技术，题目只考给定公式的代入。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 9,
    "transcriptionNoteZh": "原题用排版的 2 的 n 次方；此处改为 2ⁿ，含义未变。"
  },
  {
    "id": "FE-2022-SAMPLE-A-12",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 12,
    "topicZh": "缓存平均访问时间排序",
    "stemJa": "A ～ D を，主記憶の実効アクセス時間が短い順に並べたものはどれか。\n表：区分／キャッシュメモリ有無／キャッシュアクセス時間（ナノ秒）／ヒット率（％）／主記憶アクセス時間（ナノ秒）\nA／なし／－／－／15\nB／なし／－／－／30\nC／あり／20／60／70\nD／あり／10／90／80",
    "options": [
      {
        "label": "ア",
        "textJa": "A，B，C，D"
      },
      {
        "label": "イ",
        "textJa": "A，D，B，C"
      },
      {
        "label": "ウ",
        "textJa": "C，D，A，B"
      },
      {
        "label": "エ",
        "textJa": "D，C，A，B"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。没有缓存的 A、B，每次都访问主存，实效时间分别是 15 和 30 纳秒。有缓存时按‘命中率×缓存时间＋未命中率×主存时间’算：C＝0.60×20＋0.40×70＝40 纳秒；D＝0.90×10＋0.10×80＝17 纳秒。四者从短到长为 A(15)、D(17)、B(30)、C(40)。ア把 B 放在 D 前面，ウ、エ都把最慢的 C 排得过早。注意缓存存在并不保证整体一定最快；还要看命中率及未命中时主存有多慢。",
    "transcriptionNoteZh": "原题访问时间表按行改排为文字；数值及单位未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 10
  },
  {
    "id": "FE-2022-SAMPLE-A-13",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 13,
    "topicZh": "虚拟机资源与降级运行阈值",
    "stemJa": "仮想化マシン環境を物理マシン 20 台で運用しているシステムがある。次の運用条件のとき，物理マシンが最低何台停止すると縮退運転になるか。\n〔運用条件〕\n(1) 物理マシンが停止すると，そこで稼働していた仮想マシンは他の全ての物理マシンで均等に稼働させ，使用していた資源も同様に配分する。\n(2) 物理マシンが 20 台のときに使用する資源は，全ての物理マシンにおいて 70％である。\n(3) 1 台の物理マシンで使用している資源が 90％を超えた場合，システム全体が縮退運転となる。\n(4) (1) ～ (3) 以外の条件は考慮しなくてよい。",
    "options": [
      {
        "label": "ア",
        "textJa": "2"
      },
      {
        "label": "イ",
        "textJa": "3"
      },
      {
        "label": "ウ",
        "textJa": "4"
      },
      {
        "label": "エ",
        "textJa": "5"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ，最低停 5 台。原来 20 台各用 70%，总负载相当于 20×0.70＝14 台机器的满额资源，故障后总负载不变。若停 4 台，剩 16 台，每台平均 14÷16＝87.5%，还没有‘超过 90%’；若停 5 台，剩 15 台，每台平均 14÷15≈93.3%，超过阈值，开始降级运行。因此最少是 5。ア、イ、ウ对应仍有 18、17、16 台，都不会超过 90%。特别留意题目写的是‘90%を超えた’，即严格大于，而不是达到就算。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 10
  },
  {
    "id": "FE-2022-SAMPLE-A-14",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 14,
    "topicZh": "串并联系统可用率",
    "stemJa": "図のように，1 台のサーバ，3 台のクライアント及び 2 台のプリンタが LAN で接続されている。このシステムはクライアントからの指示に基づいて，サーバにあるデータをプリンタに出力する。各装置の稼働率が表のとおりであるとき，このシステムの稼働率を表す計算式はどれか。ここで，クライアントは3台のうちどれか1台が稼働していればよく，プリンタは2台のうちどちらかが稼働していればよい。",
    "options": [
      {
        "label": "ア",
        "textJa": "ab³c²"
      },
      {
        "label": "イ",
        "textJa": "a(1－b³)(1－c²)"
      },
      {
        "label": "ウ",
        "textJa": "a(1－b)³(1－c)²"
      },
      {
        "label": "エ",
        "textJa": "a(1－(1－b)³)(1－(1－c)²)"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。服务器只有一台，工作概率为 a；三台客户端只需至少一台工作。若单台工作概率为 b，则三台全部故障的概率是 (1－b)³，至少一台工作的概率是 1－(1－b)³。两台打印机同理，至少一台工作的概率是 1－(1－c)²。LAN 的工作概率为 1，故系统可用率是三部分相乘：a×[1－(1－b)³]×[1－(1－c)²]。ア要求所有客户端和打印机同时工作；イ把‘全部正常’的补集误当作‘至少一台正常’；ウ计算的反而是所有客户端和打印机都故障。",
    "transcriptionNoteZh": "原卷连接图与稼働率表完整保留在图片；文字选项将上标改排为 Unicode 指数。",
    "imageAssets": [
      "question-images/fe-2022-sample-a-14.png"
    ],
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 11
  },
  {
    "id": "FE-2022-SAMPLE-A-15",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 15,
    "topicZh": "缓冲区容量与收发速度",
    "stemJa": "図の送信タスクから受信タスクに T 秒間連続してデータを送信する。1 秒当たりの送信量を S，1 秒当たりの受信量を R としたとき，バッファがオーバフローしないバッファサイズ L を表す関係式として適切なものはどれか。ここで，受信タスクよりも送信タスクの方が転送速度は速く，次の転送開始までの時間間隔は十分にあるものとする。\n図の文字表記：送信タスク（毎秒 S）→バッファ（サイズ L）→受信タスク（毎秒 R）。",
    "options": [
      {
        "label": "ア",
        "textJa": "L ＜（ R － S ）× T"
      },
      {
        "label": "イ",
        "textJa": "L ＜（ S － R ）× T"
      },
      {
        "label": "ウ",
        "textJa": "L ≧（ R － S ）× T"
      },
      {
        "label": "エ",
        "textJa": "L ≧（ S － R ）× T"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。每秒发送 S，接收端每秒只取走 R，且题目说 S>R，所以缓冲区每秒增加 S－R 的待处理数据。连续发送 T 秒后，最多积累 (S－R)×T；要不溢出，容量 L 至少要等于这个值，所以是 L≥(S－R)×T。ア、ウ把差额写成 R－S，在已知 S>R 时为负数，不能代表积累量；イ方向虽正确，却要求容量小于需要值，恰好容易溢出。‘下次发送前间隔足够长’表示上一批可以排空，不必把多次传输量叠加。",
    "transcriptionNoteZh": "原题简图改为文字链路；发送、接收速度及缓冲区位置未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 12
  },
  {
    "id": "FE-2022-SAMPLE-A-16",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 16,
    "topicZh": "解释器与编译器",
    "stemJa": "インタプリタの説明として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "原始プログラムを，解釈しながら実行するプログラムである。"
      },
      {
        "label": "イ",
        "textJa": "原始プログラムを，推論しながら翻訳するプログラムである。"
      },
      {
        "label": "ウ",
        "textJa": "原始プログラムを，目的プログラムに翻訳するプログラムである。"
      },
      {
        "label": "エ",
        "textJa": "実行可能なプログラムを，主記憶装置にロードするプログラムである。"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。解释器（インタプリタ）读取源程序，边解释其内容边执行。ウ说的是把源程序翻译成目标程序，更接近编译器；エ说的是把可执行程序装入主存的加载程序；イ的‘推论着翻译’并不是解释器定义。对零基础可先记住三个动作：编译是翻译程序，解释是读着执行，加载是把可执行程序放进内存。真实语言工具可能混合使用这些方法，但本题只要求识别基本术语。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 12
  },
  {
    "id": "FE-2022-SAMPLE-A-17",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 17,
    "topicZh": "最大剩余空间分配算法",
    "stemJa": "三つの媒体 A ～ C に次の条件でファイル領域を割り当てた場合，割り当てた領域の総量が大きい順に媒体を並べたものはどれか。\n〔条件〕\n(1) ファイル領域を割り当てる際の媒体選択アルゴリズムとして，空き領域が最大の媒体を選択する方式を採用する。\n(2) 割当て要求されるファイル領域の大きさは，順に 90，30，40，40，70，30（M バイト）であり，割り当てられたファイル領域は，途中で解放されない。\n(3) 各媒体は容量が同一であり，割当て要求に対して十分な大きさをもち，初めは全て空きの状態である。\n(4) 空き領域の大きさが等しい場合には，A，B，C の順に選択する。",
    "options": [
      {
        "label": "ア",
        "textJa": "A，B，C"
      },
      {
        "label": "イ",
        "textJa": "A，C，B"
      },
      {
        "label": "ウ",
        "textJa": "B，A，C"
      },
      {
        "label": "エ",
        "textJa": "C，B，A"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。三块媒体容量相同，所以‘空余最大’等价于‘当前已分配最少’。按请求顺序模拟，并按 A、B、C 解决并列：初始 (0,0,0)，90 给 A→(90,0,0)；30 给 B→(90,30,0)；40 给 C→(90,30,40)；下一笔 40 给已分配最少的 B→(90,70,40)；70 给 C→(90,70,110)；最后 30 给 B→(90,100,110)。按总分配量由大到小是 C(110)、B(100)、A(90)。其他选项都和这个最终顺序不符。不要按单次请求大小排序；必须每分配一笔就重新比较空余量。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 13
  },
  {
    "id": "FE-2022-SAMPLE-A-18",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 18,
    "topicZh": "文件系统绝对路径",
    "stemJa": "ファイルシステムの絶対パス名を説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "あるディレクトリから対象ファイルに至る幾つかのパス名のうち，最短のパス名"
      },
      {
        "label": "イ",
        "textJa": "カレントディレクトリから対象ファイルに至るパス名"
      },
      {
        "label": "ウ",
        "textJa": "ホームディレクトリから対象ファイルに至るパス名"
      },
      {
        "label": "エ",
        "textJa": "ルートディレクトリから対象ファイルに至るパス名"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。绝对路径从文件系统的根目录开始描述目标文件的位置，因此不依赖当前工作目录。例如类 Unix 路径 /home/user/a.txt 从根 / 起步。ア强调最短，但路径长短与绝对或相对无关；イ从当前目录起步，是相对路径的典型情形；ウ从用户主目录起步，仍不是‘从根目录起步’这个定义。判断时只需辨认路径的起点，而不用推测目标文件与当前位置的远近。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 13
  },
  {
    "id": "FE-2022-SAMPLE-A-19",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 19,
    "topicZh": "DRAM 的结构与刷新",
    "stemJa": "DRAM の特徴はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "書込み及び消去を一括又はブロック単位で行う。"
      },
      {
        "label": "イ",
        "textJa": "データを保持するためのリフレッシュ操作又はアクセス操作が不要である。"
      },
      {
        "label": "ウ",
        "textJa": "電源が遮断された状態でも，記憶した情報を保持することができる。"
      },
      {
        "label": "エ",
        "textJa": "メモリセル構造が単純なので高集積化することができ，ビット単価を安くできる。"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。DRAM 的基本存储单元结构相对简单，适合高密度集成，因此常作为需要较大容量的主存，单位位成本较低。它通过电容中的电荷表示数据，电荷会逐渐流失，需要周期性刷新，故イ说‘不需要刷新’相反；断电后数据消失，所以ウ也错。ア所说按块写入和擦除更接近闪存的性质，不是 DRAM 的典型描述。记忆时把 DRAM 和‘动态、要刷新、易做大容量、断电会丢数据’连在一起。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 13
  },
  {
    "id": "FE-2022-SAMPLE-A-20",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 20,
    "topicZh": "输入数据的逻辑检查",
    "stemJa": "次のような注文データが入力されたとき，注文日が入力日以前の営業日かどうかを検査するチェックはどれか。\n注文データ：伝票番号（文字），注文日（文字），商品コード（文字），数量（数値），顧客コード（文字）",
    "options": [
      {
        "label": "ア",
        "textJa": "シーケンスチェック"
      },
      {
        "label": "イ",
        "textJa": "重複チェック"
      },
      {
        "label": "ウ",
        "textJa": "フォーマットチェック"
      },
      {
        "label": "エ",
        "textJa": "論理チェック"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ，即逻辑检查。题目不是只看日期字符串能否写成某种格式，而是要判断‘订单日是否为营业日’以及‘是否不晚于输入日’这两个业务规则是否同时成立。ア的顺序检查主要看编号或记录排列是否按预期顺序；イ检查同一数据是否重复；ウ检查年月日等外形和格式，但格式正确的日期也可能是休业日或未来日期。只有把日期与营业日历、输入日进行比较，才能完成题目要求的逻辑判断。",
    "transcriptionNoteZh": "原题仅展示字段名称与数据类型的空白表格；此处按行合并展示，字段未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 14
  },
  {
    "id": "FE-2022-SAMPLE-A-21",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 21,
    "topicZh": "关系数据库视图",
    "stemJa": "RDBMS におけるビューに関する記述のうち，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "ビューとは，名前を付けた導出表のことである。"
      },
      {
        "label": "イ",
        "textJa": "ビューに対して，ビューを定義することはできない。"
      },
      {
        "label": "ウ",
        "textJa": "ビューの定義を行ってから，必要があれば，その基底表を定義する。"
      },
      {
        "label": "エ",
        "textJa": "ビューは一つの基底表に対して一つだけ定義できる。"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。视图（ビュー）可以理解为给一个查询结果起名字，让用户像看表一样使用，因此称‘有名字的导出表’。视图是根据已有的基础表或其他视图定义出来的，ウ把顺序倒过来了。一个表可以定义多个不同用途的视图，エ所说‘只能一个’没有依据。视图还可以在另一视图的基础上定义，所以イ也不对。入门时要区分基础表保存原始记录，而视图表达一种观察、筛选或组合数据的方式；具体数据库对可更新视图等另有条件。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 14
  },
  {
    "id": "FE-2022-SAMPLE-A-22",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 22,
    "topicZh": "UML 多重度与概念数据模型",
    "stemJa": "UMLを用いて表した図の概念データモデルの解釈として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "従業員の総数と部署の総数は一致する。"
      },
      {
        "label": "イ",
        "textJa": "従業員は，同時に複数の部署に所属してもよい。"
      },
      {
        "label": "ウ",
        "textJa": "所属する従業員がいない部署の存在は許されない。"
      },
      {
        "label": "エ",
        "textJa": "どの部署にも所属しない従業員が存在してもよい。"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。UML 关联线一端的多重度表示：对另一端的一个对象，本端可关联多少对象。图中靠‘部署’端标 1..*，表示一个従業員至少属于一个部门，也允许同时属于多个部门，所以イ正确。靠‘従業員’端标 0..*，表示一个部门可以有零个或多个员工，因此ウ说不能有空部门是错的。由于员工必须至少属于一个部门，エ错误；这些范围不要求员工总数等于部门总数，ア也错误。特别注意不要把两端的数字读反。",
    "transcriptionNoteZh": "UML 关联方向和两端多重度完整保留在原卷图片中。",
    "imageAssets": [
      "question-images/fe-2022-sample-a-22.png"
    ],
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 14
  },
  {
    "id": "FE-2022-SAMPLE-A-23",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 23,
    "topicZh": "数据湖与原始数据",
    "stemJa": "ビッグデータのデータ貯蔵場所であるデータレイクの特徴として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "あらゆるデータをそのままの形式や構造で格納しておく。"
      },
      {
        "label": "イ",
        "textJa": "データ量を抑えるために，データの記述情報であるメタデータは格納しない。"
      },
      {
        "label": "ウ",
        "textJa": "データを格納する前にデータ利用方法を設計し，それに沿ってスキーマをあらかじめ定義しておく。"
      },
      {
        "label": "エ",
        "textJa": "テキストファイルやバイナリデータなど，格納するデータの形式に応じてリポジトリを使い分ける。"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。数据湖的要点是可以把结构化表格、文本、图像等不同形式的数据先按原样汇集保存，随后依据分析目的再处理。イ错在‘不存元数据’：为了知道数据来源、含义和位置，元数据反而很重要。ウ要求入库前就完全确定用途和模式，更接近预先设计好的数据仓库式处理，与题目要找的数据湖特点不同。エ按格式分散到不同存储库，不是这里的核心定义。‘先收集原始数据，使用时再整理’是本题的记忆线索。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 15
  },
  {
    "id": "FE-2022-SAMPLE-A-24",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 24,
    "topicZh": "关系代数的投影",
    "stemJa": "関係モデルにおいて表 X から表 Y を得る関係演算はどれか。\n表 X：商品番号 商品名 価格 数量\nA01 カメラ 13,000 20\nA02 テレビ 58,000 15\nB01 冷蔵庫 65,000 8\nB05 洗濯機 48,000 10\nB06 乾燥機 35,000 5\n表 Y：商品番号 数量\nA01 20\nA02 15\nB01 8\nB05 10\nB06 5",
    "options": [
      {
        "label": "ア",
        "textJa": "結合（join）"
      },
      {
        "label": "イ",
        "textJa": "射影（projection）"
      },
      {
        "label": "ウ",
        "textJa": "選択（selection）"
      },
      {
        "label": "エ",
        "textJa": "併合（merge）"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。比较 X、Y：五行商品完全相同，变化的是列，Y 只留下‘商品番号’和‘数量’两列。关系代数中按列取出所需属性叫射影（projection）。ウ的选择（selection）是按条件筛选行，不能解释列减少而行不变。ア的连接（join）通常把两张关系按条件组合；エ的併合也不是本题这种取列操作。做表题先数‘行有没有变、列有没有变’：本题只变列，所以选投影。",
    "transcriptionNoteZh": "原题 X、Y 两张表按行改排为文字；列名与各行数据未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 15
  },
  {
    "id": "FE-2022-SAMPLE-A-25",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 25,
    "topicZh": "BLE 与近距离个人网络",
    "stemJa": "IoT で用いられる無線通信技術であり，近距離の IT 機器同士が通信する無線 PAN（Personal Area Network）と呼ばれるネットワークに利用されるものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "BLE（Bluetooth Low Energy）"
      },
      {
        "label": "イ",
        "textJa": "LTE（Long Term Evolution）"
      },
      {
        "label": "ウ",
        "textJa": "PLC（Power Line Communication）"
      },
      {
        "label": "エ",
        "textJa": "PPP（Point-to-Point Protocol）"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。PAN 是人身边较小范围的设备网络，BLE 是低功耗蓝牙，适合手环、传感器等近距离设备之间的无线通信。イ的 LTE 是移动通信网络技术，覆盖范围与用途不同；ウ的 PLC 利用电力线传输数据，不属于题干所说的无线近距离 PAN；エ的 PPP 是点对点链路协议，不是这种无线通信技术。判断时同时看‘近距离’‘无线’‘设备间’三个条件，只有 BLE 全部满足。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 16
  },
  {
    "id": "FE-2022-SAMPLE-A-26",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 26,
    "topicZh": "传输时间与传输效率",
    "stemJa": "1.5 M ビット／秒の伝送路を用いて 12 M バイトのデータを転送するのに必要な伝送時間は何秒か。ここで，伝送路の伝送効率を 50％とする。",
    "options": [
      {
        "label": "ア",
        "textJa": "16"
      },
      {
        "label": "イ",
        "textJa": "32"
      },
      {
        "label": "ウ",
        "textJa": "64"
      },
      {
        "label": "エ",
        "textJa": "128"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ，128 秒。速度单位是‘位/秒’，数据单位是‘字节’，先换算 1 字节＝8 位：12 M 字节＝96 M 位。传输效率只有 50%，有效传输速度是 1.5×0.5＝0.75 M 位/秒。时间＝数据量÷有效速度＝96÷0.75＝128 秒。若忘记效率会算成 64 秒（ウ），若忘记字节到位的 8 倍换算则会更小。公式可记为‘需要传送的位数÷实际有效位速率’，M 单位在分子分母中相消。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 16
  },
  {
    "id": "FE-2022-SAMPLE-A-27",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 27,
    "topicZh": "电子邮件附件与 MIME",
    "stemJa": "TCP/IP を利用している環境で，電子メールに画像データなどを添付するための規格はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "JPEG"
      },
      {
        "label": "イ",
        "textJa": "MIME"
      },
      {
        "label": "ウ",
        "textJa": "MPEG"
      },
      {
        "label": "エ",
        "textJa": "SMTP"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。MIME 定义了电子邮件中如何表示不同类型的内容，使原本面向文本的邮件能够包含图像等附件，并标示内容类型和编码方式。ア的 JPEG 是图像文件压缩格式；ウ的 MPEG 是音视频压缩相关标准；エ的 SMTP 用于在服务器之间等场景传送邮件，不负责规定附件内容怎样放进邮件正文结构。把‘邮件的传送’和‘邮件内部内容及附件的表示’分开，就能在 SMTP 与 MIME 中作出选择。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 16
  },
  {
    "id": "FE-2022-SAMPLE-A-28",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 28,
    "topicZh": "UDP 与实时通信",
    "stemJa": "トランスポート層のプロトコルであり，信頼性よりもリアルタイム性が重視される場合に用いられるものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "HTTP"
      },
      {
        "label": "イ",
        "textJa": "IP"
      },
      {
        "label": "ウ",
        "textJa": "TCP"
      },
      {
        "label": "エ",
        "textJa": "UDP"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。UDP 属于传输层，报文发送机制较简单，本身不像 TCP 那样提供确认、重传和按序交付，因此可用于更重视及时到达的场景。ウ的 TCP 也在传输层，但它重视可靠、有序传输，不符合题干的对比。ア的 HTTP 是应用层协议；イ的 IP 是网络层协议，先在‘传输层’这一条件下就可排除。注意 UDP 不是保证实时性的魔法；应用若需要可靠性，可自行增加相应机制。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 16
  },
  {
    "id": "FE-2022-SAMPLE-A-29",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 29,
    "topicZh": "网络请求与响应端口",
    "stemJa": "PC と Web サーバが HTTP で通信している。PC から Web サーバ宛てのパケットでは，送信元ポート番号は PC 側で割り当てた 50001，宛先ポート番号は 80 であった。Web サーバから PC への戻りのパケットでのポート番号の組合せはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "送信元（Web サーバ）のポート番号：80，宛先（PC）のポート番号：50001"
      },
      {
        "label": "イ",
        "textJa": "送信元（Web サーバ）のポート番号：50001，宛先（PC）のポート番号：80"
      },
      {
        "label": "ウ",
        "textJa": "送信元（Web サーバ）のポート番号：80 と 50001 以外からサーバ側で割り当てた番号，宛先（PC）のポート番号：80"
      },
      {
        "label": "エ",
        "textJa": "送信元（Web サーバ）のポート番号：80 と 50001 以外からサーバ側で割り当てた番号，宛先（PC）のポート番号：50001"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。一次连接的请求从 PC 的临时端口 50001 发往 Web 服务器的 HTTP 端口 80；服务器回复时方向反过来，因此发送端是服务器的 80，目标端是 PC 的 50001。イ只是把原请求的数字顺序照抄成回复方向，弄反两端。ウ、エ凭空换成第三个服务器端口，题目没有说服务端另起连接。可把请求写成‘PC:50001 → Server:80’，回复自然是‘Server:80 → PC:50001’。",
    "transcriptionNoteZh": "原题端口组合表改为逐项文字；号码及两列含义未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 17
  },
  {
    "id": "FE-2022-SAMPLE-A-30",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 30,
    "topicZh": "社会工程攻击",
    "stemJa": "緊急事態を装って組織内部の人間からパスワードや機密情報を入手する不正な行為は，どれに分類されるか。",
    "options": [
      {
        "label": "ア",
        "textJa": "ソーシャルエンジニアリング"
      },
      {
        "label": "イ",
        "textJa": "トロイの木馬"
      },
      {
        "label": "ウ",
        "textJa": "踏み台攻撃"
      },
      {
        "label": "エ",
        "textJa": "ブルートフォース攻撃"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。社会工程攻击利用人的信任、紧张或服从权威等心理，而不是先破解机器；伪装紧急情况向员工套取密码正是这种手法。イ的特洛伊木马是伪装成正常程序的恶意软件；ウ的跳板攻击借已控制的计算机继续攻击其他目标；エ的暴力破解通过反复尝试候选密码。它们都没有题目所描述的‘对人施压或欺骗以取得信息’这一核心。遇到索要密码的紧急联络应按组织规定核实来源。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 17
  },
  {
    "id": "FE-2022-SAMPLE-A-31",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 31,
    "topicZh": "僵尸网络与命令控制服务器",
    "stemJa": "ボットネットにおける C&C サーバの役割として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "Web サイトのコンテンツをキャッシュし，本来のサーバに代わってコンテンツを利用者に配信することによって，ネットワークやサーバの負荷を軽減する。"
      },
      {
        "label": "イ",
        "textJa": "外部からインターネットを経由して社内ネットワークにアクセスする際に，CHAP などのプロトコルを中継することによって，利用者認証時のパスワードの盗聴を防止する。"
      },
      {
        "label": "ウ",
        "textJa": "外部からインターネットを経由して社内ネットワークにアクセスする際に，時刻同期方式を採用したワンタイムパスワードを発行することによって，利用者認証時のパスワードの盗聴を防止する。"
      },
      {
        "label": "エ",
        "textJa": "侵入して乗っ取ったコンピュータに対して，他のコンピュータへの攻撃などの不正な操作をするよう，外部から命令を出したり応答を受け取ったりする。"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。C&C 是 Command and Control，即命令与控制；攻击者用这类服务器向已被控制的计算机下达攻击指令，并接收其回应，这些受控计算机组成僵尸网络。ア描述缓存内容、替原服务器分发的代理或 CDN 相关功能；イ描述认证通信中转；ウ描述一次性密码发放，三者都不是操纵受控主机。题干中的‘ボットネット’和‘外部から命令’应连起来理解：重点是远程指挥，而非单纯存储或转发普通网页。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 18
  },
  {
    "id": "FE-2022-SAMPLE-A-32",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 32,
    "topicZh": "消息认证码与完整性",
    "stemJa": "メッセージ認証符号の利用目的に該当するものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "メッセージが改ざんされていないことを確認する。"
      },
      {
        "label": "イ",
        "textJa": "メッセージの暗号化方式を確認する。"
      },
      {
        "label": "ウ",
        "textJa": "メッセージの概要を確認する。"
      },
      {
        "label": "エ",
        "textJa": "メッセージの秘匿性を確保する。"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。消息认证码（MAC）由消息和共享秘密等信息计算而来；接收方重新计算并比较，可检查传送途中内容是否被改变，并验证持有相应密钥的一方参与了生成。イ的‘确认加密方式’不是它的目的；ウ把‘认证码’误当摘要内容说明；エ的保密性要靠加密，单独使用 MAC 并不隐藏原文。可把三个目标分开：加密主要解决别人能否看见，MAC 重点检查有没有被改动及来源的可信性。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 18
  },
  {
    "id": "FE-2022-SAMPLE-A-33",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 33,
    "topicZh": "UPS 与短时断电",
    "stemJa": "UPS の導入によって期待できる情報セキュリティ対策としての効果はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "PC が電力線通信（PLC）からマルウェアに感染することを防ぐ。"
      },
      {
        "label": "イ",
        "textJa": "サーバと端末間の通信における情報漏えいを防ぐ。"
      },
      {
        "label": "ウ",
        "textJa": "電源の瞬断に起因するデータの破損を防ぐ。"
      },
      {
        "label": "エ",
        "textJa": "電子メールの内容が改ざんされることを防ぐ。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。UPS 是不间断电源，短时停电或瞬断时可继续供电一段时间，让设备保持运行或有序停机，降低写入中断导致数据损坏的风险。ア涉及恶意软件传播，UPS 不会检查或阻止程序感染；イ是通信信息泄漏问题，需要相应通信安全措施；エ是邮件内容完整性问题，也不是供电设备能直接保证的。UPS 管的是‘电力连续性’，不是网络内容、访问身份或恶意代码。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 18
  },
  {
    "id": "FE-2022-SAMPLE-A-34",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 34,
    "topicZh": "模糊测试发现漏洞",
    "stemJa": "ファジングに該当するものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "サーバに FIN パケットを送信し，サーバからの応答を観測して，稼働しているサービスを見つけ出す。"
      },
      {
        "label": "イ",
        "textJa": "サーバの OS やアプリケーションソフトウェアが生成したログやコマンド履歴などを解析して，ファイルサーバに保存されているファイルの改ざんを検知する。"
      },
      {
        "label": "ウ",
        "textJa": "ソフトウェアに，問題を引き起こしそうな多様なデータを入力し，挙動を監視して，脆弱性を見つけ出す。"
      },
      {
        "label": "エ",
        "textJa": "ネットワーク上を流れるパケットを収集し，そのプロトコルヘッダやペイロードを解析して，あらかじめ登録された攻撃パターンと一致するものを検出する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。模糊测试（fuzzing）把大量正常、异常或边界输入送进被测软件，观察是否崩溃、行为异常或暴露漏洞。重点是‘主动输入多样数据并观察程序反应’。ア是探测服务器开放服务的扫描行为；イ分析已有日志和命令记录；エ监控网络包并匹配已知攻击模式，更接近入侵检测。它们都没有把不同测试数据送入目标软件。模糊测试可发现意料外输入导致的问题，但发现异常后还需复现与分析。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 19
  },
  {
    "id": "FE-2022-SAMPLE-A-35",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 35,
    "topicZh": "恶意软件动态分析",
    "stemJa": "マルウェアの動的解析に該当するものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "検体のハッシュ値を計算し，オンラインデータベースに登録された既知のマルウェアのハッシュ値のリストと照合してマルウェアを特定する。"
      },
      {
        "label": "イ",
        "textJa": "検体をサンドボックス上で実行し，その動作や外部との通信を観測する。"
      },
      {
        "label": "ウ",
        "textJa": "検体をネットワーク上の通信データから抽出し，さらに，逆コンパイルして取得したコードから検体の機能を調べる。"
      },
      {
        "label": "エ",
        "textJa": "ハードディスク内のファイルの拡張子とファイルヘッダの内容を基に，拡張子が偽装された不正なプログラムファイルを検出する。"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。动态分析的‘动态’指实际运行样本，再观察它打开什么文件、修改什么设置、与哪些外部地址通信等。沙箱提供受控环境，便于记录这些行为并降低影响。ア计算哈希并比对已有名单，没有运行样本；ウ逆编译后读代码是静态分析；エ比较扩展名和文件头也是检查文件特征，不是运行观察。区分时只问一件事：分析过程中是否让检体执行？本题只有イ明确执行。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 19
  },
  {
    "id": "FE-2022-SAMPLE-A-36",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 36,
    "topicZh": "SQL 注入的防护",
    "stemJa": "SQLインジェクション攻撃による被害を防ぐ方法はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "入力された文字が，データベースへの問合せや操作において，特別な意味をもつ文字として解釈されないようにする。"
      },
      {
        "label": "イ",
        "textJa": "入力に HTML タグが含まれていたら，HTML タグとして解釈されない他の文字列に置き換える。"
      },
      {
        "label": "ウ",
        "textJa": "入力に上位ディレクトリを指定する文字列（.. /）が含まれているときは受け付けない。"
      },
      {
        "label": "エ",
        "textJa": "入力の全体の長さが制限を超えているときは受け付けない。"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。SQL 注入的根源是用户输入被拼接进数据库查询后，某些字符被当作 SQL 语法执行，而不是普通数据。应使输入在查询中始终作为数据处理，例如使用参数化查询；这样引号等字符不会改变原 SQL 结构。イ针对的是 HTML 标记解释，常与跨站脚本防护有关；ウ是对上级目录字符串的检查，针对路径遍历；エ限制输入长度可以约束数据大小，却不能阻止短小的注入语句。不同攻击要对应其实际解释环节。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 20
  },
  {
    "id": "FE-2022-SAMPLE-A-37",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 37,
    "topicZh": "发信认证与 SMTP-AUTH",
    "stemJa": "電子メールをドメイン A の送信者がドメイン B の宛先に送信するとき，送信者をドメイン A のメールサーバで認証するためのものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "APOP"
      },
      {
        "label": "イ",
        "textJa": "POP3S"
      },
      {
        "label": "ウ",
        "textJa": "S/MIME"
      },
      {
        "label": "エ",
        "textJa": "SMTP-AUTH"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。题目要求的是发件人向自己域名的邮件服务器提交邮件时，邮件服务器怎样认证这个发送者。SMTP-AUTH 为 SMTP 发送流程增加用户认证，符合场景。ア的 APOP 是 POP 收信认证方式；イ的 POP3S 是加密连接的 POP3 收信服务，方向都不是发信；ウ的 S/MIME 用于邮件内容的签名和加密等处理，不负责服务器对提交邮件的用户登录认证。先辨别‘发信还是收信’，再选协议，比只背缩写更可靠。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 20
  },
  {
    "id": "FE-2022-SAMPLE-A-38",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 38,
    "topicZh": "面向对象的封装",
    "stemJa": "オブジェクト指向プログラムにおいて，データとメソッドを一つにまとめ，オブジェクトの実装の詳細をユーザから見えなくすることを何と呼ぶか。",
    "options": [
      {
        "label": "ア",
        "textJa": "インスタンス"
      },
      {
        "label": "イ",
        "textJa": "カプセル化"
      },
      {
        "label": "ウ",
        "textJa": "クラスタ化"
      },
      {
        "label": "エ",
        "textJa": "抽象化"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。封装（カプセル化）把对象的数据和操作数据的方法放在一起，并向使用者隐藏不必知道的内部实现细节；使用者只需通过公开的操作来使用对象。ア的实例是根据类创建的具体对象，并不是这种组织方式。ウ的集群化通常指把多个资源组织成群，与这里的对象内部结构无关。エ的抽象化是抓住重要特征、舍去不相关细节，概念相关但题干明确强调‘数据＋方法组合且隐藏实现’，应选封装。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 20
  },
  {
    "id": "FE-2022-SAMPLE-A-39",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 39,
    "topicZh": "模块之间的弱耦合",
    "stemJa": "モジュール結合度が最も弱くなるものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "一つのモジュールで，できるだけ多くの機能を実現する。"
      },
      {
        "label": "イ",
        "textJa": "二つのモジュール間で必要なデータ項目だけを引数として渡す。"
      },
      {
        "label": "ウ",
        "textJa": "他のモジュールとデータ項目を共有するためにグローバルな領域を使用する。"
      },
      {
        "label": "エ",
        "textJa": "他のモジュールを呼び出すときに，呼び出したモジュールの論理を制御するための引数を渡す。"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。耦合度表示两个模块相互依赖有多深。只通过参数传递对方真正需要的数据，模块不必知道彼此内部结构，依赖较小。ウ通过全局共享区域互相影响，修改一方可能影响另一方；エ传控制另一模块内部逻辑的参数，使调用者知道对方怎样工作，依赖更强。ア讲一个模块承担多少功能，更接近模块内部职责或内聚性的问题，不能保证模块间耦合最弱。考试中要分清‘模块内部’与‘模块之间’。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 20
  },
  {
    "id": "FE-2022-SAMPLE-A-40",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 40,
    "topicZh": "黑盒测试",
    "stemJa": "モジュールの内部構造を考慮することなく，仕様書どおりに機能するかどうかをテストする手法はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "トップダウンテスト"
      },
      {
        "label": "イ",
        "textJa": "ブラックボックステスト"
      },
      {
        "label": "ウ",
        "textJa": "ボトムアップテスト"
      },
      {
        "label": "エ",
        "textJa": "ホワイトボックステスト"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。黑盒测试把被测模块当成看不到内部的盒子，依据规格说明给输入、检查输出是否符合要求，不依赖源代码的分支和结构。エ的白盒测试会考虑内部逻辑、路径或分支，与题干相反。ア的自顶向下和ウ的自底向上描述的是集成测试中模块组合的顺序，不能回答‘是否查看内部结构’这个维度。读题时抓住‘内部構造を考慮することなく’，它就是选择黑盒的直接线索。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 21
  },
  {
    "id": "FE-2022-SAMPLE-A-41",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 41,
    "topicZh": "Scrum 迭代目标",
    "stemJa": "アジャイル開発のスクラムにおけるスプリントのルールのうち，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "スプリントの期間を決定したら，スプリントの 1 回目には要件定義工程を，2 回目には設計工程を，3 回目にはコード作成工程を，4 回目にはテスト工程をそれぞれ割り当てる。"
      },
      {
        "label": "イ",
        "textJa": "成果物の内容を確認するスプリントレビューを，スプリントの期間の中間時点で実施する。"
      },
      {
        "label": "ウ",
        "textJa": "プロジェクトで設定したスプリントの期間でリリース判断が可能なプロダクトインクリメントができるように，スプリントゴールを設定する。"
      },
      {
        "label": "エ",
        "textJa": "毎回のスプリントプランニングにおいて，スプリントの期間をゴールの難易度に応じて，1 週間から 1 か月までの範囲に設定する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。Scrum 的每个冲刺要朝着一个冲刺目标推进，并形成可检查、达到完成标准的产品增量；因此应在设定的冲刺期间内安排可完成的工作。ア把需求、设计、编码、测试机械地拆成四个冲刺，相当于按阶段串行安排，而冲刺中应完成一段可用增量。イ把冲刺评审放在中点，题目所述做法不合适；评审通常在冲刺结束时检查结果。エ每轮按难度随意改变冲刺长度，不利于保持稳定节奏。入门可记‘短周期内完成并检查一个增量’。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 21
  },
  {
    "id": "FE-2022-SAMPLE-A-42",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 42,
    "topicZh": "项目生命周期风险",
    "stemJa": "プロジェクトライフサイクルの一般的な特性はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "開発要員数は，プロジェクト開始時が最多であり，プロジェクトが進むにつれて減少し，完了に近づくと再度増加する。"
      },
      {
        "label": "イ",
        "textJa": "ステークホルダがコストを変えずにプロジェクトの成果物に対して及ぼすことができる影響の度合いは，プロジェクト完了直前が最も大きくなる。"
      },
      {
        "label": "ウ",
        "textJa": "プロジェクトが完了に近づくほど，変更やエラーの修正がプロジェクトに影響する度合いは小さくなる。"
      },
      {
        "label": "エ",
        "textJa": "リスクは，プロジェクトが完了に近づくにつれて減少する。"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。本题问项目生命周期的一般趋势：开始时有许多不确定因素，随着设计、实施和验证不断完成，部分风险逐渐被识别并处理，整体风险通常朝着降低的方向走。ア把人员数说成开头最多、结束再增，与常见项目的人员投入趋势不符。イ说临近完工时还能不增加成本地施加最大影响，实际上越晚改动越受既有成果约束。ウ说越晚修正错误影响越小，也与返工成本可能增大的趋势相反。这是一般特性，具体项目仍会有新风险出现。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 21
  },
  {
    "id": "FE-2022-SAMPLE-A-43",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 43,
    "topicZh": "功能点估算",
    "stemJa": "ソフトウェア開発の見積方法の一つであるファンクションポイント法の説明として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "開発規模が分かっていることを前提として，工数と工期を見積もる方法である。ビジネス分野に限らず，全分野に適用可能である。"
      },
      {
        "label": "イ",
        "textJa": "過去に経験した類似のソフトウェアについてのデータを基にして，ソフトウェアの相違点を調べ，同じ部分については過去のデータを使い，異なった部分は経験に基づいて，規模と工数を見積もる方法である。"
      },
      {
        "label": "ウ",
        "textJa": "ソフトウェアの機能を入出力データ数やファイル数などによって定量的に計測し，複雑さによる調整を行って，ソフトウェア規模を見積もる方法である。"
      },
      {
        "label": "エ",
        "textJa": "単位作業項目に適用する作業量の基準値を決めておき，作業項目を単位作業項目まで分解し，基準値を適用して算出した作業量の積算で全体の作業量を見積もる方法である。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。功能点法从用户能看到的功能规模出发，数输入、输出、文件等功能要素，再按复杂程度调整，估算软件规模。它首先衡量的是‘提供了多少功能’，不是直接数代码行。ア说已知规模后推算工时与工期，偏向依据规模的成本模型；イ参考以前做过的相似项目，是类比估算；エ把工作拆细、逐项按基准工量累加，是自底向上的工作量估算。看到‘入出力データ数、ファイル数、複雑さ’应联想到功能点。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 22
  },
  {
    "id": "FE-2022-SAMPLE-A-44",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 44,
    "topicZh": "箭线图与关键路径",
    "stemJa": "アローダイアグラムの日程計画をもつプロジェクトの，開始から終了までの最少所要日数は何日か。",
    "options": [
      {
        "label": "ア",
        "textJa": "9"
      },
      {
        "label": "イ",
        "textJa": "10"
      },
      {
        "label": "ウ",
        "textJa": "11"
      },
      {
        "label": "エ",
        "textJa": "12"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ，即最短完工时间 12 天。箭线图中可并行进行的支路必须等各自前置工作完成后才能汇合，所以项目总工期由耗时最长的路径决定。原图三条主要路径分别为 A→B→E→H→J：2＋2＋2＋2＋4＝12；A→C→F→I→J：2＋1＋3＋1＋4＝11；A→D→G：2＋4＋3＝9。最长的第一条是关键路径，决定即使其他工作提前也不能把总工期缩短到 11 天。ア和ウ只取了较短支路；イ也没有覆盖完整关键路径。",
    "transcriptionNoteZh": "工作依赖关系与每条箭线的天数以官方原卷图片为准。",
    "imageAssets": [
      "question-images/fe-2022-sample-a-44.png"
    ],
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 22
  },
  {
    "id": "FE-2022-SAMPLE-A-45",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 45,
    "topicZh": "服务管理标杆比较",
    "stemJa": "サービスマネジメントのプロセス改善におけるベンチマーキングはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "IT サービスのパフォーマンスを財務，顧客，内部プロセス，学習と成長の観点から測定し，戦略的な活動をサポートする。"
      },
      {
        "label": "イ",
        "textJa": "業界内外の優れた業務方法（ベストプラクティス）と比較して，サービス品質及びパフォーマンスのレベルを評価する。"
      },
      {
        "label": "ウ",
        "textJa": "サービスのレベルで可用性，信頼性，パフォーマンスを測定し，顧客に報告する。"
      },
      {
        "label": "エ",
        "textJa": "強み，弱み，機会，脅威の観点から IT サービスマネジメントの現状を分析する。"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。标杆比较是拿自己的做法和行业内外公认的优秀做法比较，找出差距与改进方向。ア用财务、客户、内部流程、学习成长四个角度衡量，更接近平衡计分卡。ウ是测量并报告服务级别，属于服务水平管理相关活动；エ按优势、劣势、机会、威胁分析，属于 SWOT 分析。要抓住‘与最佳实践比较’这个动作，而不是只看到‘测量性能’就选。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 23
  },
  {
    "id": "FE-2022-SAMPLE-A-46",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 46,
    "topicZh": "数据库恢复与重做日志",
    "stemJa": "ディスク障害時に，フルバックアップを取得してあるテープからディスクにデータを復元した後，フルバックアップ取得時以降の更新後コピーをログから反映させてデータベースを回復する方法はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "チェックポイントリスタート"
      },
      {
        "label": "イ",
        "textJa": "リブート"
      },
      {
        "label": "ウ",
        "textJa": "ロールバック"
      },
      {
        "label": "エ",
        "textJa": "ロールフォワード"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。先从完整备份恢复到过去某一时刻，再把备份之后已经完成的更新从日志按时间向前重放，就叫 roll forward（前滚）。乌的 roll back（回滚）是撤销尚未完成或不应保留的更新，方向相反。ア的检查点重启是从检查点继续处理，不等于题目所说的备份加后续更新重放；イ的重启只让设备或程序重新运行，不能自动把丢失的数据补回。记忆：forward 是把数据库状态从备份时刻‘往前推’。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 23
  },
  {
    "id": "FE-2022-SAMPLE-A-47",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 47,
    "topicZh": "系统审计的外观独立性",
    "stemJa": "経営者が社内のシステム監査人の外観上の独立性を担保するために講じる措置として，最も適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "システム監査人に IT に関する継続的学習を義務付ける。"
      },
      {
        "label": "イ",
        "textJa": "システム監査人に必要な知識や経験を定めて公表する。"
      },
      {
        "label": "ウ",
        "textJa": "システム監査人の監査技法研修制度を設ける。"
      },
      {
        "label": "エ",
        "textJa": "システム監査人の所属部署を内部監査部門とする。"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。‘外观上的独立性’强调从组织安排上也能看出审计人员不受被审部门支配。让系统审计人归属内部审计部门，比放在其要审查的系统运营部门更能表明独立地位。ア的持续学习、イ规定经验要求、ウ的审计培训都能提高能力，却不能解决‘看起来是否独立于被审对象’。审计问题常分成能力、客观态度、组织独立性；题干点名外观独立，就看汇报和所属关系。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 23
  },
  {
    "id": "FE-2022-SAMPLE-A-48",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 48,
    "topicZh": "信息安全的可用性",
    "stemJa": "情報セキュリティ監査において，可用性を確認するチェック項目はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "外部記憶媒体の無断持出しが禁止されていること"
      },
      {
        "label": "イ",
        "textJa": "中断時間を定めたSLAの水準が保たれるように管理されていること"
      },
      {
        "label": "ウ",
        "textJa": "データ入力時のエラーチェックが適切に行われていること"
      },
      {
        "label": "エ",
        "textJa": "データベースが暗号化されていること"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。信息安全中的可用性指系统和信息在需要时能够使用。SLA 约定允许的中断时间并监控其是否达标，直接检验服务是否持续可用。ア禁止未经许可携带外部存储介质，主要防止信息泄漏，偏向机密性；ウ检查输入错误，关注数据正确性，偏向完整性；エ对数据库加密，重点也是防止未授权读取。用‘能否在需要时正常使用’来判断可用性，别把保密和正确性混为一谈。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 24
  },
  {
    "id": "FE-2022-SAMPLE-A-49",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 49,
    "topicZh": "VDI 远程虚拟桌面",
    "stemJa": "テレワークで活用している VDI に関する記述として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "PC 環境を仮想化してサーバ上に置くことで，社外から端末の種類を選ばず自分のデスクトップ PC 環境として利用できるシステム"
      },
      {
        "label": "イ",
        "textJa": "インターネット上に仮想の専用線を設定し，特定の人だけが利用できる専用ネットワーク"
      },
      {
        "label": "ウ",
        "textJa": "紙で保管されている資料を，ネットワークを介して遠隔地からでも参照可能な電子書類に変換・保存することができるツール"
      },
      {
        "label": "エ",
        "textJa": "対面での会議開催が困難な場合に，ネットワークを介して対面と同じようなコミュニケーションができるツール"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。VDI 是虚拟桌面基础设施，把桌面运行环境放在服务器侧，使用者从其他地点的终端连接到自己的桌面。イ描述的是 VPN 式的虚拟专用网络，重点在连接通道；ウ是纸质资料数字化和远程查看；エ是视频会议或远程沟通工具。后三者都可能服务于远程办公，但都不等于‘把 PC 桌面环境放在服务器上’。看题时应把 VDI 与桌面的运行位置联系起来。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 24
  },
  {
    "id": "FE-2022-SAMPLE-A-50",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 50,
    "topicZh": "投资回报率 ROI 比较",
    "stemJa": "投資案件において，5 年間の投資効果を ROI（Return On Investment）で評価した場合，四つの案件 a～d のうち，最も ROI が高いものはどれか。ここで，割引率は考慮しなくてもよいものとする。\n案 a：年目 1 2 3 4 5，利益 15 30 45 30 15，投資額 100\n案 b：年目 1 2 3 4 5，利益 105 75 45 15 0，投資額 200\n案 c：年目 1 2 3 4 5，利益 60 75 90 75 60，投資額 300\n案 d：年目 1 2 3 4 5，利益 105 105 105 105 105，投資額 400",
    "options": [
      {
        "label": "ア",
        "textJa": "a"
      },
      {
        "label": "イ",
        "textJa": "b"
      },
      {
        "label": "ウ",
        "textJa": "c"
      },
      {
        "label": "エ",
        "textJa": "d"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア，方案 a。按题目给的五年利益合计与投资额比较：a 的利益总和 135，135÷100＝1.35；b 的利益总和 240，240÷200＝1.20；c 的利益总和 360，360÷300＝1.20；d 的利益总和 525，525÷400＝1.3125。因此 a 的投资收益相对投入最大。即使用‘(累计收益－投资额)÷投资额’定义净 ROI，各方案同时减 1，大小顺序也不变。不能只看绝对利润总和，d 虽然利润 525 最大，但投入也大。题目明确说不考虑折现率，所以直接相加即可。",
    "transcriptionNoteZh": "原题四张逐年利润表改排为每案一行；年度、利益及投资额未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 25
  },
  {
    "id": "FE-2022-SAMPLE-A-51",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 51,
    "topicZh": "绿色采购与环境政策",
    "stemJa": "国や地方公共団体が，環境への配慮を積極的に行っていると評価されている製品・サービスを選んでいる。この取組を何というか。",
    "options": [
      {
        "label": "ア",
        "textJa": "CSR"
      },
      {
        "label": "イ",
        "textJa": "エコマーク認定"
      },
      {
        "label": "ウ",
        "textJa": "環境アセスメント"
      },
      {
        "label": "エ",
        "textJa": "グリーン購入"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。绿色采购（グリーン購入）指购买方在选择商品和服务时考虑环境负荷，优先选购环境表现较好的产品。题干的主语是国家及地方公共团体，动作是‘选择产品和服务’，因此对应采购。ア的 CSR 是企业履行社会责任的总体理念；イ的生态标志认定是给符合条件的产品授予标志，并非购买行为；ウ的环境评估是事先评价项目对环境的影响。抓住‘谁在买、买什么’即可区分。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 25
  },
  {
    "id": "FE-2022-SAMPLE-A-52",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 52,
    "topicZh": "核心竞争力",
    "stemJa": "コアコンピタンスの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "競合他社にはまねのできない自社ならではの卓越した能力"
      },
      {
        "label": "イ",
        "textJa": "経営を行う上で法令や各種規制，社会的規範などを遵守する企業活動"
      },
      {
        "label": "ウ",
        "textJa": "市場・技術・商品（サービス）の観点から設定した，事業の展開領域"
      },
      {
        "label": "エ",
        "textJa": "組織活動の目的を達成するために行う，業務とシステムの全体最適化手法"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。核心竞争力是企业长期积累、难被竞争对手模仿，且能支撑竞争优势的独特能力；题目以‘其他公司无法模仿的卓越能力’直接描述它。イ说的是遵守法律、规定及社会规范的合规经营；ウ说的是从市场、技术、商品三个角度界定业务领域；エ说的是对业务和系统整体进行优化的方法。不要把‘公司做得好的事’一概叫核心竞争力，关键还在于独特、难模仿，并能带来优势。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 26
  },
  {
    "id": "FE-2022-SAMPLE-A-53",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 53,
    "topicZh": "精益创业与最小可行产品",
    "stemJa": "新しい事業に取り組む際の手法として，E.リースが提唱したリーンスタートアップの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "国・地方公共団体など，公共機関の補助金・助成金の交付を前提とし，事前に詳細な事業計画を検討・立案した上で，公共性のある事業を立ち上げる手法"
      },
      {
        "label": "イ",
        "textJa": "市場環境の変化によって競争力を喪失した事業分野に対して，経営資源を大規模に追加投入し，リニューアルすることによって，基幹事業として再出発を期す手法"
      },
      {
        "label": "ウ",
        "textJa": "持続可能な事業を迅速に構築し，展開するために，あらかじめ詳細に立案された事業計画を厳格に遂行して，成果の検証や計画の変更を最小限にとどめる手法"
      },
      {
        "label": "エ",
        "textJa": "実用最小限の製品・サービスを短期間で作り，構築・計測・学習というフィードバックループで改良や方向転換をして，継続的にイノベーションを行う手法"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。精益创业先用短时间做出能够验证关键假设的最小可行产品，再根据真实用户反馈，反复经历‘构建、测量、学习’，决定改进或转向。这样能减少在未经验证的想法上投入过多资源。ア以公共补助和详细预先计划为前提；イ向失去竞争力的旧业务大规模追加资源；ウ尽量减少验证及计划变更。这三种都与快速试验、用数据学习和适时调整的核心做法不符。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 26
  },
  {
    "id": "FE-2022-SAMPLE-A-54",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 54,
    "topicZh": "家庭能源管理 HEMS",
    "stemJa": "IoTの応用事例のうち，HEMSの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "工場内の機械に取り付けたセンサで振動，温度，音などを常時計測し，収集したデータを基に機械の劣化状態を分析して，適切なタイミングで部品を交換する。"
      },
      {
        "label": "イ",
        "textJa": "自動車に取り付けたセンサで車両の状態，路面状況などのデータを計測し，ネットワークを介して保存し分析することによって，効率的な運転を支援する。"
      },
      {
        "label": "ウ",
        "textJa": "情報通信技術や環境技術を駆使して，街灯などの公共設備や交通システムをはじめとする都市基盤のエネルギーの可視化と消費の最適制御を行う。"
      },
      {
        "label": "エ",
        "textJa": "太陽光発電装置などのエネルギー機器，家電機器，センサ類などを家庭内通信ネットワークに接続して，エネルギーの可視化と消費の最適制御を行う。"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。HEMS 是家庭能源管理系统，题干选项中的‘家庭内通信ネットワーク’、家电和太阳能设备是决定性线索。它把家庭中的能源设备及传感器连接起来，使居民看见用能情况，并控制能耗。ア描述工厂设备的状态监测与预防维护；イ描述联网汽车的数据分析；ウ描述城市公共基础设施的能源管理。虽然四项都涉及 IoT，只有エ把管理范围限定在‘家庭’，与 HEMS 的 H 对应。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 27
  },
  {
    "id": "FE-2022-SAMPLE-A-55",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 55,
    "topicZh": "长尾现象",
    "stemJa": "ロングテールの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "Web コンテンツを構成するテキストや画像などのデジタルコンテンツに，統合的・体系的な管理，配信などの必要な処理を行うこと"
      },
      {
        "label": "イ",
        "textJa": "インターネットショッピングで，売上の全体に対して，あまり売れない商品群の売上合計が無視できない割合になっていること"
      },
      {
        "label": "ウ",
        "textJa": "自分のWebサイトやブログに企業へのリンクを掲載し，他者がこれらのリンクを経由して商品を購入したときに，企業が紹介料を支払うこと"
      },
      {
        "label": "エ",
        "textJa": "メーカや卸売業者から商品を直接発送することによって，在庫リスクを負うことなく自分のWebサイトで商品が販売できること"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。长尾现象指单件销量很少的众多商品，合起来也能形成不可忽视的总销量。在线商店能以较低的展示和检索成本提供大量小众商品，因此这条‘长尾’可能具有商业价值。ア描述数字内容的集中管理与发布；ウ是联盟营销，网站引导成交后获得介绍费；エ是由厂家或批发商直接发货的无库存销售模式。关键要看是否同时出现‘每件卖得少’和‘众多商品的合计销量显著’。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 27
  },
  {
    "id": "FE-2022-SAMPLE-A-56",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 56,
    "topicZh": "消费者生成媒体",
    "stemJa": "CGM（Consumer Generated Media）の例はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "企業が，経営状況や財務状況，業績動向に関する情報を，個人投資家向けに公開する自社のWebサイト"
      },
      {
        "label": "イ",
        "textJa": "企業が，自社の商品の特徴や使用方法に関する情報を，一般消費者向けに発信する自社のWebサイト"
      },
      {
        "label": "ウ",
        "textJa": "行政機関が，政策，行政サービスに関する情報を，一般市民向けに公開する自組織のWebサイト"
      },
      {
        "label": "エ",
        "textJa": "個人が，自らが使用した商品などの評価に関する情報を，不特定多数に向けて発信するブログやSNSなどのWebサイト"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。CGM 中的 C 是消费者；内容由普通用户产生并在网络上分享，例如使用者写商品评价并发布在博客或社交网站。ア、イ虽然是网页内容，但发布者是企业，属于企业对投资者或消费者的信息发布；ウ的发布者是行政机关。辨认 CGM 时重点看‘内容由谁创建’，不能只因渠道是网站或 SNS 就判断为 CGM。题目中的エ明确说个人分享自己使用商品后的评价。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 28
  },
  {
    "id": "FE-2022-SAMPLE-A-57",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 57,
    "topicZh": "线性规划与最大利润",
    "stemJa": "製品X 及びY を生産するために 2 種類の原料 A，B が必要である。製品 1 個の生産に必要となる原料の量と調達可能量は表に示すとおりである。製品XとYの1個当たりの販売利益が，それぞれ100円，150円であるとき，最大利益は何円か。\n原料 A：製品Xの1個当たりの必要量 2，製品Yの1個当たりの必要量 1，調達可能量 100。\n原料 B：製品Xの1個当たりの必要量 1，製品Yの1個当たりの必要量 2，調達可能量 80。",
    "options": [
      {
        "label": "ア",
        "textJa": "5,000"
      },
      {
        "label": "イ",
        "textJa": "6,000"
      },
      {
        "label": "ウ",
        "textJa": "7,000"
      },
      {
        "label": "エ",
        "textJa": "8,000"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ，即 7,000 日元。设生产 X 为 x 个、Y 为 y 个，目标是使 100x＋150y 最大。原料 A 限制 2x＋y≤100，原料 B 限制 x＋2y≤80，且 x、y≥0。可行区域的关键顶点有 (50,0)、(0,40)，以及两条限制线交点。联立 2x＋y＝100、x＋2y＝80 得 x＝40、y＝20。三处利润分别是 5,000、6,000、7,000，因此最大值为 7,000。エ的 8,000 虽更大，却不满足原料限制。",
    "transcriptionNoteZh": "原题原料需求表按 A、B 两行线性化，数字与单位均保留。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 28
  },
  {
    "id": "FE-2022-SAMPLE-A-58",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 58,
    "topicZh": "定额折旧与固定资产出售损失",
    "stemJa": "令和2年4月に30万円で購入したPCを3年後に1万円で売却するとき，固定資産売却損は何万円か。ここで，耐用年数は4年，減価償却は定額法，定額法の償却率は0.250，残存価額は0円とする。",
    "options": [
      {
        "label": "ア",
        "textJa": "6.0"
      },
      {
        "label": "イ",
        "textJa": "6.5"
      },
      {
        "label": "ウ",
        "textJa": "7.0"
      },
      {
        "label": "エ",
        "textJa": "7.5"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ，即 6.5 万日元。定额法每年的折旧额＝取得价 30 万×折旧率 0.250＝7.5 万。经过 3 年累计折旧 22.5 万，出售时账面价值＝30－22.5＝7.5 万。实际只卖得 1 万，因此资产出售损失＝账面价值 7.5－售价 1＝6.5 万。エ的 7.5 是出售前的账面价值，忘了扣除售价；ア和ウ也不符合题给年数、折旧率与售价的计算。题目已给完整三年和残值为零，按这些条件计算即可。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 28
  },
  {
    "id": "FE-2022-SAMPLE-A-59",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 59,
    "topicZh": "变动成本率与目标利润",
    "stemJa": "売上高が100百万円のとき，変動費が60百万円，固定費が30百万円掛かる。変動費率，固定費は変わらないものとして，目標利益 18 百万円を達成するのに必要な売上高は何百万円か。",
    "options": [
      {
        "label": "ア",
        "textJa": "108"
      },
      {
        "label": "イ",
        "textJa": "120"
      },
      {
        "label": "ウ",
        "textJa": "156"
      },
      {
        "label": "エ",
        "textJa": "180"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ，即销售额 120 百万日元。现有销售额 100、变动费 60，所以变动费率＝60÷100＝0.60；每增加 1 日元销售额，扣除变动费后留下 0.40 日元。设所需销售额为 S，则利润＝S×(1－0.60)－固定费 30＝0.40S－30。令利润等于目标 18，得到 0.40S＝48、S＝120。ア、ウ、エ代回公式分别得到 13.2、32.4、42 百万，均非题目要求的 18 百万。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 29
  },
  {
    "id": "FE-2022-SAMPLE-A-60",
    "kind": "sample",
    "year": 2022,
    "section": "A",
    "number": 60,
    "topicZh": "劳动者派遣关系",
    "stemJa": "労働者派遣法に基づく，派遣先企業と労働者との関係（図の太線部分）はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "請負契約関係"
      },
      {
        "label": "イ",
        "textJa": "雇用契約関係"
      },
      {
        "label": "ウ",
        "textJa": "指揮命令関係"
      },
      {
        "label": "エ",
        "textJa": "労働者派遣契約関係"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。派遣劳动者通常与派遣元企业订立雇佣合同，派遣元与派遣先企业之间订立劳动者派遣合同。实际到派遣先企业工作时，由派遣先对该劳动者进行工作上的指挥命令。因此图中‘派遣先企业—劳动者’对应的是指挥命令关系。イ的雇佣关系发生在派遣元与劳动者之间；エ的派遣合同发生在两家企业之间；ア的承包关系不是题图所问的这条关系。把三方主体先分清，再判断连线。",
    "transcriptionNoteZh": "原题三方关系图须结合原卷图片辨认粗线；文字题干与四个选项照录。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_a_set_sample_ans.pdf",
    "page": 29
  },
  {
    "id": "FE-2022-SAMPLE-B-01",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "number": 1,
    "topicZh": "赋值语句逐行追踪",
    "stemJa": "次の記述中の［ a ］に入れる正しい答えを，解答群の中から選べ。プログラムを実行すると，“［ a ］”と出力される。\n〔プログラム〕\n整数型: x ← 1\n整数型: y ← 2\n整数型: z ← 3\nx ← y\ny ← z\nz ← x\nyの値 と zの値 をこの順にコンマ区切りで出力する",
    "options": [
      {
        "label": "ア",
        "textJa": "1,2"
      },
      {
        "label": "イ",
        "textJa": "1,3"
      },
      {
        "label": "ウ",
        "textJa": "2,1"
      },
      {
        "label": "エ",
        "textJa": "2,3"
      },
      {
        "label": "オ",
        "textJa": "3,1"
      },
      {
        "label": "カ",
        "textJa": "3,2"
      }
    ],
    "answer": "カ",
    "explanationZh": "答案是カ，输出 3,2。最初 x=1、y=2、z=3。执行 x←y 后 x 变成 2，原来的 x=1 已经被覆盖；执行 y←z 后 y 变成 3；执行 z←x 后 z 取得当前 x 的值 2。最后按题目指定的顺序先输出 y 再输出 z，得到 3,2。其他选项或使用了旧值，或把输出顺序反过来。遇到赋值题，可以在纸上画 x、y、z 三列，每执行一行立即更新对应列，不要把三条赋值误以为同时发生。",
    "transcriptionNoteZh": "原 PDF 中填空框以［ a ］表示；程序与输出顺序未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_ans.pdf",
    "page": 4
  },
  {
    "number": 1,
    "page": 2,
    "topicZh": "条件分支与年龄区间",
    "stemJa": "次のプログラム中の［ a ］に入れる正しい答えを，解答群の中から選べ。\nある施設の入場料は，0歳から3歳までは100円，4歳から9歳までは300円，10歳以上は500円である。関数feeは，年齢を表す0以上の整数を引数として受け取り，入場料を返す。\n〔プログラム〕\n○整数型: fee(整数型: age)\n  整数型: ret\n  if (age が 3 以下)\n    ret ← 100\n  elseif (［ a ］)\n    ret ← 300\n  else\n    ret ← 500\n  endif\n  return ret",
    "explanationZh": "正确答案カ，即“age が 9 以下”。程序先检查年龄是否在3岁以下，满足者会被归入100日元分支，后续elseif不会执行。因此进入elseif时，年龄必然至少为4岁，只需再检查是否不超过9岁，就正好覆盖4～9岁的300日元区间。ア把9岁排除；イ只涵盖4岁和9岁，遗漏5～8岁；ウ把4岁排除；エ和オ会让10岁以上也进入300日元分支；キ又排除了9岁。逐个检查4、9、10这三个边界年龄，可以验证条件是否正确。",
    "id": "FE-2022-EARLY-B-01",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "sampleSet": "early",
    "options": [
      {
        "label": "ア",
        "textJa": "(age が 4 以上) and (age が 9 より小さい)"
      },
      {
        "label": "イ",
        "textJa": "(age が 4 と等しい) or (age が 9 と等しい)"
      },
      {
        "label": "ウ",
        "textJa": "(age が 4 より大きい) and (age が 9 以下)"
      },
      {
        "label": "エ",
        "textJa": "age が 4 以上"
      },
      {
        "label": "オ",
        "textJa": "age が 4 より大きい"
      },
      {
        "label": "カ",
        "textJa": "age が 9 以下"
      },
      {
        "label": "キ",
        "textJa": "age が 9 より小さい"
      }
    ],
    "answer": "カ",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/ps6vr7000000oett-att/fe_kamoku_b_sample.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/ps6vr7000000oett-att/fe_kamoku_b_sample.pdf",
    "answerPage": 11,
    "imageAssets": [
      "question-images/fe-2022-early-b-p02.jpg"
    ],
    "transcriptionNoteZh": "图表与填空位置以所附IPA官方原卷页为准；文中用［ a ］等标记原卷空格。"
  },
  {
    "id": "FE-2022-SAMPLE-B-02",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "number": 2,
    "topicZh": "条件分支顺序与 FizzBuzz",
    "stemJa": "次のプログラム中の［ a ］～［ c ］に入れる正しい答えの組合せを，解答群の中から選べ。関数 fizzBuzz は，引数で与えられた値が，3 で割り切れて 5 で割り切れない場合は“3 で割り切れる”を，5 で割り切れて 3 で割り切れない場合は“5 で割り切れる”を，3 と 5 で割り切れる場合は“3 と 5 で割り切れる”を返す。それ以外の場合は“3 でも 5 でも割り切れない”を返す。\n〔プログラム〕\n○文字列型: fizzBuzz(整数型: num)\n  文字列型: result\n  if (num が［ a ］で割り切れる)\n    result ← \"［ a ］で割り切れる\"\n  elseif (num が［ b ］で割り切れる)\n    result ← \"［ b ］で割り切れる\"\n  elseif (num が［ c ］で割り切れる)\n    result ← \"［ c ］で割り切れる\"\n  else\n    result ← \"3 でも 5 でも割り切れない\"\n  endif\n  return result",
    "options": [
      {
        "label": "ア",
        "textJa": "a：3，b：3 と 5，c：5"
      },
      {
        "label": "イ",
        "textJa": "a：3，b：5，c：3 と 5"
      },
      {
        "label": "ウ",
        "textJa": "a：3 と 5，b：3，c：5"
      },
      {
        "label": "エ",
        "textJa": "a：5，b：3，c：3 と 5"
      },
      {
        "label": "オ",
        "textJa": "a：5，b：3 と 5，c：3"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。if/elseif 从上往下检查，一旦某个条件为真就执行该分支，后面的分支不再检查。若把‘能被 3 整除’或‘能被 5 整除’放在第一项，像 15 这样同时满足二者的数字会被过早归入单独的 3 或 5，永远到不了‘3 和 5 都能整除’。因此第一个条件 a 必须是‘3 と 5’，随后 b、c 分别检查 3 和 5；选项里只有ウ按这个顺序排列。用 15、9、10、7 四个测试值分别检查四类结果，能快速验证。",
    "transcriptionNoteZh": "原 PDF 填空框以［ a ］～［ c ］标示；程序判断顺序及解答群未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_ans.pdf",
    "page": 5
  },
  {
    "number": 2,
    "page": 3,
    "topicZh": "数组逆序与交换",
    "stemJa": "次のプログラム中の［ a ］と［ b ］に入れる正しい答えの組合せを，解答群の中から選べ。ここで，配列の要素番号は1から始まる。\n次のプログラムは，整数型の配列arrayの要素の並びを逆順にする。\n〔プログラム〕\n整数型の配列: array ← {1, 2, 3, 4, 5}\n整数型: right, left\n整数型: tmp\nfor (left を 1 から (arrayの要素数 ÷ 2 の商) まで 1 ずつ増やす)\n  right ← ［ a ］\n  tmp ← array[right]\n  array[right] ← array[left]\n  ［ b ］ ← tmp\nendfor",
    "explanationZh": "正确答案ウ。数组从1编号且长度为5，最左的第1个元素应与最右的第5个交换，第2个应与第4个交换；对应下标公式是“元素数－left＋1”，所以a取这个式子。程序先把右侧旧值存进tmp，再把左侧值写到右侧，最后必须把tmp写回左侧array[left]，因此b是array[left]。逐步追踪：left＝1时交换1和5，left＝2时交换2和4，中间的3不动，最终得到{5,4,3,2,1}。",
    "id": "FE-2022-EARLY-B-02",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "sampleSet": "early",
    "options": [
      {
        "label": "ア",
        "textJa": "a：array の要素数 － left，b：array[left]"
      },
      {
        "label": "イ",
        "textJa": "a：array の要素数 － left，b：array[right]"
      },
      {
        "label": "ウ",
        "textJa": "a：array の要素数 － left ＋ 1，b：array[left]"
      },
      {
        "label": "エ",
        "textJa": "a：array の要素数 － left ＋ 1，b：array[right]"
      }
    ],
    "answer": "ウ",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/ps6vr7000000oett-att/fe_kamoku_b_sample.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/ps6vr7000000oett-att/fe_kamoku_b_sample.pdf",
    "answerPage": 11,
    "imageAssets": [
      "question-images/fe-2022-early-b-p03.jpg"
    ],
    "transcriptionNoteZh": "图表与填空位置以所附IPA官方原卷页为准；文中用［ a ］等标记原卷空格。"
  },
  {
    "id": "FE-2022-SAMPLE-B-03",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "number": 3,
    "topicZh": "数组前缀和与一基下标",
    "stemJa": "次の記述中の［ a ］に入れる正しい答えを，解答群の中から選べ。ここで，配列の要素番号は 1 から始まる。関数 makeNewArray は，要素数 2 以上の整数型の配列を引数にとり，整数型の配列を返す関数である。関数 makeNewArray を makeNewArray({3, 2, 1, 6, 5, 4})として呼び出したとき，戻り値の配列の要素番号 5 の値は［ a ］となる。\n〔プログラム〕\n○整数型の配列: makeNewArray(整数型の配列: in)\n  整数型の配列: out ← {} // 要素数0の配列\n  整数型: i, tail\n  outの末尾 に in[1]の値 を追加する\n  for (i を 2 から inの要素数 まで 1 ずつ増やす)\n    tail ← out[outの要素数]\n    outの末尾 に (tail ＋ in[i]) の結果を追加する\n  endfor\n  return out",
    "options": [
      {
        "label": "ア",
        "textJa": "5"
      },
      {
        "label": "イ",
        "textJa": "6"
      },
      {
        "label": "ウ",
        "textJa": "9"
      },
      {
        "label": "エ",
        "textJa": "11"
      },
      {
        "label": "オ",
        "textJa": "12"
      },
      {
        "label": "カ",
        "textJa": "17"
      },
      {
        "label": "キ",
        "textJa": "21"
      }
    ],
    "answer": "カ",
    "explanationZh": "答案是カ，17。out 起初为空，先放入 in[1]=3，所以 out[1]=3。循环每次把‘已有 out 的最后一项＋当前 in[i]’追加到末尾：i=2 时 3+2=5；i=3 时 5+1=6；i=4 时 6+6=12；i=5 时 12+5=17。题目要的是 out 的第 5 个元素，到这里即可停止追踪；最后 i=6 会得到 21，但那是第 6 个元素，对应キ。其余选项是某一步的中间值或错误累加结果。这个数组实际上存了输入序列的逐项累计和。",
    "transcriptionNoteZh": "原 PDF 填空框以［ a ］标示；代码及数组元素值未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_ans.pdf",
    "page": 6
  },
  {
    "number": 3,
    "page": 4,
    "topicZh": "单向链表尾部追加",
    "stemJa": "次のプログラム中の［ a ］と［ b ］に入れる正しい答えの組合せを，解答群の中から選べ。\n手続appendは，引数で与えられた文字を単方向リストに追加する手続である。単方向リストの各要素は，クラスListElementを用いて表現する。ListElement型の変数はクラスListElementのインスタンスの参照を格納するものとする。大域変数listHeadは，単方向リストの先頭の要素の参照を格納する。リストが空のときは，listHeadは未定義である。\n〔クラスListElementの説明〕\nメンバ変数val：文字型。リストに格納する文字。\nメンバ変数next：ListElement型。リストの次の文字を保持するインスタンスの参照。初期状態は未定義である。\nコンストラクタListElement(文字型: qVal)：引数qValでメンバ変数valを初期化する。\n〔プログラム〕\n大域: ListElement: listHead ← 未定義の値\n○append(文字型: qVal)\n  ListElement: prev, curr\n  curr ← ListElement(qVal)\n  if (listHead が ［ a ］)\n    listHead ← curr\n  else\n    prev ← listHead\n    while (prev.next が 未定義でない)\n      prev ← prev.next\n    endwhile\n    prev.next ← ［ b ］\n  endif",
    "explanationZh": "正确答案ア。先创建包含新字符的节点curr。若listHead为未定义，说明链表没有首节点，此时直接把curr设为首节点，因此a应是“未定義”。若非空，就从首节点出发，让prev沿着next不断前进，直到prev.next未定义；这表明prev是当前末尾节点。要把新节点接在它后面，应写prev.next←curr，因此b是curr。写成curr.next或listHead都不会把新节点正确接到尾部，还可能破坏链的结构。",
    "id": "FE-2022-EARLY-B-03",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "sampleSet": "early",
    "options": [
      {
        "label": "ア",
        "textJa": "a：未定義，b：curr"
      },
      {
        "label": "イ",
        "textJa": "a：未定義，b：curr.next"
      },
      {
        "label": "ウ",
        "textJa": "a：未定義，b：listHead"
      },
      {
        "label": "エ",
        "textJa": "a：未定義でない，b：curr"
      },
      {
        "label": "オ",
        "textJa": "a：未定義でない，b：curr.next"
      },
      {
        "label": "カ",
        "textJa": "a：未定義でない，b：listHead"
      }
    ],
    "answer": "ア",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/ps6vr7000000oett-att/fe_kamoku_b_sample.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/ps6vr7000000oett-att/fe_kamoku_b_sample.pdf",
    "answerPage": 11,
    "imageAssets": [
      "question-images/fe-2022-early-b-p04.jpg",
      "question-images/fe-2022-early-b-p05.jpg"
    ],
    "transcriptionNoteZh": "图表与填空位置以所附IPA官方原卷页为准；文中用［ a ］等标记原卷空格。"
  },
  {
    "id": "FE-2022-SAMPLE-B-04",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "number": 4,
    "topicZh": "减法版欧几里得算法",
    "stemJa": "次のプログラム中の［ a ］～［ c ］に入れる正しい答えの組合せを，解答群の中から選べ。関数 gcd は，引数で与えられた二つの正の整数 num1 と num2 の最大公約数を，次の(1)～(3) の性質を利用して求める。(1) num1 と num2 が等しいとき，num1 と num2 の最大公約数は num1 である。(2) num1 が num2 より大きいとき，num1 と num2 の最大公約数は，(num1 － num2) と num2 の最大公約数と等しい。(3) num2 が num1 より大きいとき，num1 と num2 の最大公約数は，(num2 － num1) と num1 の最大公約数と等しい。\n〔プログラム〕\n○整数型: gcd(整数型: num1, 整数型: num2)\n  整数型: x ← num1\n  整数型: y ← num2\n  ［ a ］(［ b ］)\n    if (［ c ］)\n      x ← x － y\n    else\n      y ← y － x\n    endif\n  ［ a の終端 ］\n  return x",
    "options": [
      {
        "label": "ア",
        "textJa": "a：if，b：x ≠ y，c：x ＜ y"
      },
      {
        "label": "イ",
        "textJa": "a：if，b：x ≠ y，c：x ＞ y"
      },
      {
        "label": "ウ",
        "textJa": "a：while，b：x ≠ y，c：x ＜ y"
      },
      {
        "label": "エ",
        "textJa": "a：while，b：x ≠ y，c：x ＞ y"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。最大公约数用减法反复缩小较大的数，直到 x 和 y 相等，所以外层必须是 `while (x ≠ y)`，不是只执行一次的 if；先排除ア、イ。内层如果 x>y，应执行 `x←x－y`，否则执行 `y←y－x`，因此 c 为 x>y，选エ。以 (x,y)=(12,8) 为例：先变成 (4,8)，再变成 (4,4)，循环结束返回 4。ウ把比较方向写反，在 12、8 时会从较小的 y 中减去较大的 x，错误。",
    "transcriptionNoteZh": "原 PDF 代码填空框改写成［ a ］～［ c ］；循环和条件的候选结构逐项保留。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_ans.pdf",
    "page": 7
  },
  {
    "number": 4,
    "page": 6,
    "topicZh": "稀疏矩阵三数组表示",
    "stemJa": "次の記述中の［ a ］～［ c ］に入れる正しい答えの組合せを，解答群の中から選べ。ここで，配列の要素番号は1から始まる。\n要素の多くが0の行列を疎行列という。次のプログラムは，二次元配列に格納された行列のデータ量を削減するために，疎行列の格納に適したデータ構造に変換する。関数transformSparseMatrixは，引数matrixで二次元配列として与えられた行列を，整数型配列の配列に変換して返す。関数transformSparseMatrixをtransformSparseMatrix({{3, 0, 0, 0, 0}, {0, 2, 2, 0, 0}, {0, 0, 0, 1, 3}, {0, 0, 0, 2, 0}, {0, 0, 0, 0, 1}})として呼び出したときの戻り値は，{{［ a ］}, {［ b ］}, {［ c ］}}である。\n〔プログラム〕\n○整数型配列の配列: transformSparseMatrix(整数型の二次元配列: matrix)\n  整数型: i, j\n  整数型配列の配列: sparseMatrix\n  sparseMatrix ← {{}, {}, {}}  /* 要素数0の配列を三つ要素にもつ配列 */\n  for (i を 1 から matrixの行数 まで 1 ずつ増やす)\n    for (j を 1 から matrixの列数 まで 1 ずつ増やす)\n      if (matrix[i, j] が 0 でない)\n        sparseMatrix[1]の末尾 に iの値 を追加する\n        sparseMatrix[2]の末尾 に jの値 を追加する\n        sparseMatrix[3]の末尾 に matrix[i, j]の値 を追加する\n      endif\n    endfor\n  endfor\n  return sparseMatrix",
    "explanationZh": "正确答案イ。程序按行i从1到5、每行按列j从1到5扫描，只有遇到非零元素才分别记录“行号、列号、值”。逐项列出是(1,1,3)、(2,2,2)、(2,3,2)、(3,4,1)、(3,5,3)、(4,4,2)、(5,5,1)。因此第一数组为行号1,2,2,3,3,4,5；第二数组为列号1,2,3,4,5,4,5；第三数组为值3,2,2,1,3,2,1。把三个数组相同下标的元素重新拼成三元组，便可反向核对原矩阵。",
    "id": "FE-2022-EARLY-B-04",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "sampleSet": "early",
    "options": [
      {
        "label": "ア",
        "textJa": "a：1, 2, 2, 3, 3, 4, 5／b：1, 2, 3, 4, 5, 4, 5／c：3, 2, 2, 1, 2, 3, 1"
      },
      {
        "label": "イ",
        "textJa": "a：1, 2, 2, 3, 3, 4, 5／b：1, 2, 3, 4, 5, 4, 5／c：3, 2, 2, 1, 3, 2, 1"
      },
      {
        "label": "ウ",
        "textJa": "a：1, 2, 3, 4, 5, 4, 5／b：1, 2, 2, 3, 3, 4, 5／c：3, 2, 2, 1, 2, 3, 1"
      },
      {
        "label": "エ",
        "textJa": "a：1, 2, 3, 4, 5, 4, 5／b：1, 2, 2, 3, 3, 4, 5／c：3, 2, 2, 1, 3, 2, 1"
      }
    ],
    "answer": "イ",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/ps6vr7000000oett-att/fe_kamoku_b_sample.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/ps6vr7000000oett-att/fe_kamoku_b_sample.pdf",
    "answerPage": 11,
    "imageAssets": [
      "question-images/fe-2022-early-b-p06.jpg"
    ],
    "transcriptionNoteZh": "图表与填空位置以所附IPA官方原卷页为准；文中用［ a ］等标记原卷空格。"
  },
  {
    "id": "FE-2022-SAMPLE-B-05",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "number": 5,
    "topicZh": "平方根函数与表达式翻译",
    "stemJa": "次のプログラム中の［ a ］に入れる正しい答えを，解答群の中から選べ。関数 calc は，正の実数 x と y を受け取り，√(x²＋y²) の計算結果を返す。関数 calc が使う関数 pow は，第 1 引数として正の実数 a を，第 2 引数として実数 b を受け取り，a の b 乗の値を実数型で返す。\n〔プログラム〕\n○実数型: calc(実数型: x, 実数型: y)\n  return ［ a ］",
    "options": [
      {
        "label": "ア",
        "textJa": "(pow(x, 2) ＋ pow(y, 2)) ÷ pow(2, 0.5)"
      },
      {
        "label": "イ",
        "textJa": "(pow(x, 2) ＋ pow(y, 2)) ÷ pow(x, y)"
      },
      {
        "label": "ウ",
        "textJa": "pow(2, pow(x, 0.5)) ＋ pow(2, pow(y, 0.5))"
      },
      {
        "label": "エ",
        "textJa": "pow(pow(pow(2, x), y), 0.5)"
      },
      {
        "label": "オ",
        "textJa": "pow(pow(x, 2) ＋ pow(y, 2), 0.5)"
      },
      {
        "label": "カ",
        "textJa": "pow(x, 2) × pow(y, 2) ÷ pow(x, y)"
      },
      {
        "label": "キ",
        "textJa": "pow(x, y) ÷ pow(2, 0.5)"
      }
    ],
    "answer": "オ",
    "explanationZh": "答案是オ。题目要求先求 x² 和 y²，再相加，最后对整个和开平方；`pow(v,0.5)` 表示 v 的 1/2 次方，也就是平方根。因此 `pow(pow(x,2)+pow(y,2),0.5)` 顺序完全对应。ア、イ是把平方和除以另一个数，不是对平方和开根；ウ分别对 x、y 做不同幂运算后相加；エ把 2、x、y 互相嵌套成幂；カ、キ也没有‘平方和整体开根’的结构。把数学式从里向外拆成三步，就能判断括号位置。",
    "transcriptionNoteZh": "原题根号排版改为 √(x²＋y²)，代码填空框以［ a ］表示；公式含义未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_ans.pdf",
    "page": 8
  },
  {
    "number": 5,
    "page": 7,
    "topicZh": "字符串后继字符比例",
    "stemJa": "次のプログラム中の［ a ］に入れる正しい答えを，解答群の中から選べ。\n任意の異なる2文字をc1，c2とするとき，英単語群に含まれる英単語において，c1の次にc2が出現する割合を求めるプログラムである。英単語は，英小文字だけから成る。英単語の末尾の文字がc1である場合，その箇所は割合の計算に含めない。例えば，図に示す4語の英単語“importance”，“inflation”，“information”，“innovation”から成る英単語群において，c1を“n”，c2を“f”とする。英単語の末尾の文字以外に“n”は五つあり，そのうち次の文字が“f”であるものは二つである。したがって，求める割合は，2÷5＝0.4である。c1とc2の並びが一度も出現しない場合，c1の出現回数によらず割合を0と定義する。\nプログラムにおいて，英単語群はWords型の大域変数wordsに格納されている。クラスWordsのメソッドは次のとおりである。freq(文字列型: str)は英単語群中の文字列strの出現回数を返す。freqE(文字列型: str)は英単語群の中で文字列strで終わる英単語の数を返す。本問において，文字列に対する演算子“＋”は文字列の連結を表す。また，整数に対する演算子“÷”は，実数として計算する。\n〔プログラム〕\n大域: Words: words  /* 英単語群が格納されている */\n/* c1の次にc2が出現する割合を返す */\n○実数型: prob(文字型: c1, 文字型: c2)\n  文字列型: s1 ← c1の1文字だけから成る文字列\n  文字列型: s2 ← c2の1文字だけから成る文字列\n  if (words.freq(s1 ＋ s2) が 0 より大きい)\n    return ［ a ］\n  else\n    return 0\n  endif",
    "explanationZh": "正确答案ウ。题目要计算“c1出现且后面确实还有字符的那些位置中，下一字符恰为c2的比例”。分子就是连续字符串c1＋c2在词群中的出现次数，即freq(s1＋s2)。分母不能简单用freq(s1)，因为单词末尾的c1没有后继字符，必须减去以s1结尾的单词数freqE(s1)。所以公式为freq(s1＋s2)÷(freq(s1)－freqE(s1))。例子里是2÷(所有n次数减末尾n次数)＝2÷5＝0.4。程序仅在分子大于0时做除法，避免没有有效后继位置时除以零。",
    "id": "FE-2022-EARLY-B-05",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "sampleSet": "early",
    "options": [
      {
        "label": "ア",
        "textJa": "(words.freq(s1) － words.freqE(s1)) ÷ words.freq(s1 ＋ s2)"
      },
      {
        "label": "イ",
        "textJa": "(words.freq(s2) － words.freqE(s2)) ÷ words.freq(s1 ＋ s2)"
      },
      {
        "label": "ウ",
        "textJa": "words.freq(s1 ＋ s2) ÷ (words.freq(s1) － words.freqE(s1))"
      },
      {
        "label": "エ",
        "textJa": "words.freq(s1 ＋ s2) ÷ (words.freq(s2) － words.freqE(s2))"
      }
    ],
    "answer": "ウ",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/ps6vr7000000oett-att/fe_kamoku_b_sample.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/ps6vr7000000oett-att/fe_kamoku_b_sample.pdf",
    "answerPage": 11,
    "imageAssets": [
      "question-images/fe-2022-early-b-p07.jpg",
      "question-images/fe-2022-early-b-p08.jpg"
    ],
    "transcriptionNoteZh": "图表与填空位置以所附IPA官方原卷页为准；文中用［ a ］等标记原卷空格。"
  },
  {
    "id": "FE-2022-SAMPLE-B-06",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "number": 6,
    "topicZh": "位移运算与位序反转",
    "stemJa": "次のプログラム中の［ a ］に入れる正しい答えを，解答群の中から選べ。関数 rev は 8 ビット型の引数 byte を受け取り，ビットの並びを逆にした値を返す。例えば，関数 rev を rev(01001011) として呼び出すと，戻り値は 11010010 となる。なお，演算子 ∧ はビット単位の論理積，演算子 ∨ はビット単位の論理和，演算子 >> は論理右シフト，演算子 << は論理左シフトを表す。例えば，value >> n は value の値を n ビットだけ右に論理シフトし，value << n は value の値を n ビットだけ左に論理シフトする。\n〔プログラム〕\n○8 ビット型: rev(8 ビット型: byte)\n  8 ビット型: rbyte ← byte\n  8 ビット型: r ← 00000000\n  整数型: i\n  for (i を 1 から 8 まで 1 ずつ増やす)\n    ［ a ］\n  endfor\n  return r",
    "options": [
      {
        "label": "ア",
        "textJa": "r ← (r << 1) ∨ (rbyte ∧ 00000001)\nrbyte ← rbyte >> 1"
      },
      {
        "label": "イ",
        "textJa": "r ← (r << 7) ∨ (rbyte ∧ 00000001)\nrbyte ← rbyte >> 7"
      },
      {
        "label": "ウ",
        "textJa": "r ← (rbyte << 1) ∨ (rbyte >> 7)\nrbyte ← r"
      },
      {
        "label": "エ",
        "textJa": "r ← (rbyte >> 1) ∨ (rbyte << 7)\nrbyte ← r"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。每轮先用 `rbyte ∧ 00000001` 只取输入当前最低位，再把已有结果 r 左移一位，腾出最低位给刚取到的位；最后把 rbyte 右移一位，为下一轮取新的最低位。这样按‘原输入从右往左’取位，却按‘结果从左往右’累计，8 轮后顺序反转。イ一次移 7 位会不断丢失已累积的位；ウ、エ把 rbyte 自身旋转或重组，没有逐位抽取并追加到独立结果 r。可用输入 01001011 的前两位追踪：先取 1，再取 1，结果依次为 00000001、00000011。",
    "transcriptionNoteZh": "原 PDF 程序空白行以［ a ］表示；位运算符和四组候选语句未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_ans.pdf",
    "page": 9
  },
  {
    "number": 6,
    "page": 9,
    "topicZh": "PaaS环境下漏洞整改责任",
    "stemJa": "〔分野：情報セキュリティ〕\n問６　製造業のA社では，ECサイト（以下，A社のECサイトをAサイトという）を使用し，個人向けの製品販売を行っている。Aサイトは，A社の製品やサービスが検索可能で，ログイン機能を有しており，あらかじめAサイトに利用登録した個人（以下，会員という）の氏名やメールアドレスといった情報（以下，会員情報という）を管理している。Aサイトは，B社のPaaSで稼働しており，PaaS上のDBMSとアプリケーションサーバを利用している。\nA社は，Aサイトの開発，運用をC社に委託している。A社とC社との間の委託契約では，Webアプリケーションプログラムの脆弱性対策は，C社が実施するとしている。\n最近，A社の同業他社が運営しているWebサイトで脆弱性が悪用され，個人情報が漏えいするという事件が発生した。そこでA社は，セキュリティ診断サービスを行っているD社に，Aサイトの脆弱性診断を依頼した。脆弱性診断の結果，対策が必要なセキュリティ上の脆弱性が複数指摘された。図1にD社からの指摘事項を示す。\n〔図1 D社からの指摘事項〕\n(一) Aサイトで利用しているDBMSに既知の脆弱性があり，脆弱性を悪用した攻撃を受けるおそれがある。\n(二) Aサイトで利用しているアプリケーションサーバのOSに既知の脆弱性があり，脆弱性を悪用した攻撃を受けるおそれがある。\n(三) ログイン機能に脆弱性があり，Aサイトのデータベースに蓄積された情報のうち，会員には非公開の情報を閲覧されるおそれがある。\n設問　図1中の項番(一)～(三)それぞれに対処する組織の適切な組合せを，解答群の中から選べ。",
    "explanationZh": "正确答案オ，对应(一)B社、(二)B社、(三)C社。先按“谁管理出问题的层”而不是谁发现漏洞来判断。A站点运行在B公司的PaaS上，所用DBMS以及应用服务器操作系统都是平台层组件，其已知漏洞由平台提供方B社处理。登录功能属于网站的Web应用程序；题目明确A已把网站开发与运行委托C，合同又规定Web程序的漏洞对策由C实施，所以第三项由C社处理。A仍负有整体监督责任，但不是本题三项直接整改者。此题和12月样题问17复用情境；漏洞清单、顺序及正确选项不同，不能照搬12月卷的字母答案。",
    "transcriptionNoteZh": "2022年4月早期官方样题。与2022年12月官方样题问17复用A社EC站点、B社PaaS、C社运维情境，但原卷漏洞表、排列和选项对应不同；请按本题原卷图及本题答案オ判断，不可直接套用12月版问17的答案字母。",
    "id": "FE-2022-EARLY-B-06",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "sampleSet": "early",
    "options": [
      {
        "label": "ア",
        "textJa": "(一)A社／(二)A社／(三)A社"
      },
      {
        "label": "イ",
        "textJa": "(一)A社／(二)A社／(三)C社"
      },
      {
        "label": "ウ",
        "textJa": "(一)A社／(二)B社／(三)B社"
      },
      {
        "label": "エ",
        "textJa": "(一)B社／(二)B社／(三)B社"
      },
      {
        "label": "オ",
        "textJa": "(一)B社／(二)B社／(三)C社"
      },
      {
        "label": "カ",
        "textJa": "(一)B社／(二)C社／(三)B社"
      },
      {
        "label": "キ",
        "textJa": "(一)B社／(二)C社／(三)C社"
      },
      {
        "label": "ク",
        "textJa": "(一)C社／(二)B社／(三)B社"
      },
      {
        "label": "ケ",
        "textJa": "(一)C社／(二)B社／(三)C社"
      },
      {
        "label": "コ",
        "textJa": "(一)C社／(二)C社／(三)B社"
      }
    ],
    "answer": "オ",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/ps6vr7000000oett-att/fe_kamoku_b_sample.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/ps6vr7000000oett-att/fe_kamoku_b_sample.pdf",
    "answerPage": 11,
    "imageAssets": [
      "question-images/fe-2022-early-b-p09.jpg",
      "question-images/fe-2022-early-b-p10.jpg"
    ]
  },
  {
    "id": "FE-2022-SAMPLE-B-07",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "number": 7,
    "topicZh": "阶乘递归与停止条件",
    "stemJa": "次のプログラム中の［ a ］に入れる正しい答えを，解答群の中から選べ。関数 factorial は非負の整数 n を引数にとり，その階乗を返す関数である。非負の整数 n の階乗は n が 0 のときに 1 になり，それ以外の場合は 1 から n までの整数を全て掛け合わせた数となる。\n〔プログラム〕\n○整数型: factorial(整数型: n)\n  if (n ＝ 0)\n    return 1\n  endif\n  return ［ a ］",
    "options": [
      {
        "label": "ア",
        "textJa": "(n － 1) × factorial(n)"
      },
      {
        "label": "イ",
        "textJa": "factorial(n － 1)"
      },
      {
        "label": "ウ",
        "textJa": "n"
      },
      {
        "label": "エ",
        "textJa": "n × (n － 1)"
      },
      {
        "label": "オ",
        "textJa": "n × factorial(1)"
      },
      {
        "label": "カ",
        "textJa": "n × factorial(n － 1)"
      }
    ],
    "answer": "カ",
    "explanationZh": "答案是カ。阶乘满足 n!＝n×(n－1)!，程序已有 n=0 时返回 1 的停止条件，因此一般情况必须返回 `n × factorial(n－1)`。以 n=3 追踪：factorial(3)=3×factorial(2)=3×2×factorial(1)=3×2×1×factorial(0)=6。イ少乘当前 n；ウ、エ只算局部一两项；オ每次都调用 factorial(1)，最多返回 n；ア递归时没有让参数变小，无法走向 n=0 的停止条件。递归题务必同时检查‘规模变小’与‘结果组合’。",
    "transcriptionNoteZh": "原 PDF 填空框以［ a ］表示；程序分支及六个候选式未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_ans.pdf",
    "page": 10
  },
  {
    "id": "FE-2022-SAMPLE-B-08",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "number": 8,
    "topicZh": "优先队列与同优先级先入先出",
    "stemJa": "次の記述中の［ a ］に入れる正しい答えを，解答群の中から選べ。優先度付きキューを操作するプログラムである。優先度付きキューとは扱う要素に優先度を付けたキューであり，要素を取り出す際には優先度の高いものから順番に取り出される。ここで，優先度は整数型の値 1，2，3 のいずれかであり，小さい値ほど優先度が高いものとする。\nクラス PrioQueue：PrioQueue() は空の優先度付きキューを生成する。enqueue(s, prio) は文字列 s を優先度 prio で追加する。dequeue() は最も優先度の高い要素を取り出して返す。同じ優先度なら，最初に追加された要素を取り出す。size() は要素数を返す。\n手続 prioSched を呼び出したとき，出力は［ a ］の順となる。\n〔プログラム〕\n○prioSched()\n  PrioQueue: prioQueue ← PrioQueue()\n  prioQueue.enqueue(\"A\", 1)\n  prioQueue.enqueue(\"B\", 2)\n  prioQueue.enqueue(\"C\", 2)\n  prioQueue.enqueue(\"D\", 3)\n  prioQueue.dequeue() /* 戻り値は使用しない */\n  prioQueue.dequeue() /* 戻り値は使用しない */\n  prioQueue.enqueue(\"D\", 3)\n  prioQueue.enqueue(\"B\", 2)\n  prioQueue.dequeue() /* 戻り値は使用しない */\n  prioQueue.dequeue() /* 戻り値は使用しない */\n  prioQueue.enqueue(\"C\", 2)\n  prioQueue.enqueue(\"A\", 1)\n  while (prioQueue.size() が 0 と等しくない)\n    prioQueue.dequeue() の戻り値を出力\n  endwhile",
    "options": [
      {
        "label": "ア",
        "textJa": "“A”，“B”，“C”，“D”"
      },
      {
        "label": "イ",
        "textJa": "“A”，“B”，“D”，“D”"
      },
      {
        "label": "ウ",
        "textJa": "“A”，“C”，“C”，“D”"
      },
      {
        "label": "エ",
        "textJa": "“A”，“C”，“D”，“D”"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。先入队 A1、B2、C2、D3，数字越小越先出，所以前两次未输出的 dequeue 依次删 A、B，剩 C2、D3。再加入 D3 和 B2，队列中按取出顺序可看作 C2、B2、D3、D3；接下来的两次未输出 dequeue 删 C、B，剩两个 D3。最后加入 C2 和 A1，真正输出时先取 A1，再取 C2，最后两个 D3，所以是 A、C、D、D。其他三个选项都把前面已删除的 B 或 C 误留在队列。要把‘删除但不输出’也记入状态变化。",
    "transcriptionNoteZh": "原题类说明表改排为文字；enqueue、dequeue、size 的规则与全部程序行未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_ans.pdf",
    "page": 13
  },
  {
    "id": "FE-2022-SAMPLE-B-09",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "number": 9,
    "topicZh": "二叉树的中序遍历",
    "stemJa": "次の記述中の［ a ］に入れる正しい答えを，解答群の中から選べ。ここで，配列の要素番号は 1 から始まる。手続 order は，図の 2 分木の，引数で指定した節を根とする部分木をたどりながら，全ての節番号を出力する。大域の配列 tree が図の 2 分木を表している。配列 tree の要素は，対応する節の子の節番号を，左の子，右の子の順に格納した配列である。例えば，配列 tree の要素番号 1 の要素は，節番号 1 の子の節番号から成る配列であり，左の子の節番号 2，右の子の節番号 3 を配列 {2，3} として格納する。手続 order を order(1)として呼び出すと，［ a ］の順に出力される。\n〔プログラム〕\n大域: 整数型配列の配列: tree ← {{2, 3}, {4, 5}, {6, 7}, {8, 9}, {10, 11}, {12, 13}, {14}, {}, {}, {}, {}, {}, {}, {}} // {}は要素数0の配列\n○order(整数型: n)\n  if (tree[n]の要素数 が 2 と等しい)\n    order(tree[n][1])\n    nを出力\n    order(tree[n][2])\n  elseif (tree[n]の要素数 が 1 と等しい)\n    order(tree[n][1])\n    nを出力\n  else\n    nを出力\n  endif",
    "options": [
      {
        "label": "ア",
        "textJa": "1，2，3，4，5，6，7，8，9，10，11，12，13，14"
      },
      {
        "label": "イ",
        "textJa": "1，2，4，8，9，5，10，11，3，6，12，13，7，14"
      },
      {
        "label": "ウ",
        "textJa": "8，4，9，2，10，5，11，1，12，6，13，3，14，7"
      },
      {
        "label": "エ",
        "textJa": "8，9，4，10，11，5，2，12，13，6，14，7，3，1"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。程序在有两个孩子时执行‘先递归左孩子 → 输出当前节点 → 再递归右孩子’，这就是中序遍历。根 1 的左子树：节点 4 先输出 8、4、9；再输出 2；节点 5 输出 10、5、11；合成 8、4、9、2、10、5、11。然后输出根 1。右子树：节点 6 输出 12、6、13；再输出 3；节点 7 只有左孩子 14，因此输出 14、7。连起来正好是ウ。イ是先输出根的前序模式，エ把根放最后更像后序，ア仅按编号排列，都不符合程序实际的递归顺序。",
    "transcriptionNoteZh": "原题二叉树图已由完整 tree 数组及左右孩子规则复现；程序和解答群完整保留。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_ans.pdf",
    "page": 15
  },
  {
    "id": "FE-2022-SAMPLE-B-10",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "number": 10,
    "topicZh": "单向链表删除节点",
    "stemJa": "次のプログラム中の［ a ］に入れる正しい答えを，解答群の中から選べ。手続 delNode は，単方向リストから，引数 pos で指定された位置の要素を削除する手続である。引数 pos は，リストの要素数以下の正の整数とする。リストの先頭の位置を 1 とする。クラス ListElement は，単方向リストの要素を表す。メンバ変数 val は要素の値（文字型），next は次の要素の参照（ListElement 型）であり，次の要素がないときは未定義。ListElement 型の変数はインスタンスの参照を格納する。大域変数 listHead にはリストの先頭要素の参照があらかじめ格納されている。\n〔プログラム〕\n大域: ListElement: listHead // リストの先頭要素が格納されている\n○delNode(整数型: pos) /* posは，リストの要素数以下の正の整数 */\n  ListElement: prev\n  整数型: i\n  if (pos が 1 と等しい)\n    listHead ← listHead.next\n  else\n    prev ← listHead\n    /* posが2と等しいときは繰返し処理を実行しない */\n    for (i を 2 から pos － 1 まで 1 ずつ増やす)\n      prev ← prev.next\n    endfor\n    prev.next ← ［ a ］\n  endif",
    "options": [
      {
        "label": "ア",
        "textJa": "listHead"
      },
      {
        "label": "イ",
        "textJa": "listHead.next"
      },
      {
        "label": "ウ",
        "textJa": "listHead.next.next"
      },
      {
        "label": "エ",
        "textJa": "prev"
      },
      {
        "label": "オ",
        "textJa": "prev.next"
      },
      {
        "label": "カ",
        "textJa": "prev.next.next"
      }
    ],
    "answer": "カ",
    "explanationZh": "答案是カ。pos=1 时已有特别处理；其余情况，循环使 prev 最终指向‘待删节点的前一个节点’。此时 prev.next 正是待删节点，prev.next.next 是它后面的节点。要跳过待删节点，就令 `prev.next ← prev.next.next`。以链 A→B→C、删除位置 2 为例，prev 指向 A，新的 A.next 应指向 C。オ把 A.next 仍设为 B，相当于没删；エ会让 A 指向自己；ア、イ、ウ都只从表头计算，不适用于任意 pos。注意引用链的关键是改前驱的 next，而不是只清掉被删节点本身。",
    "transcriptionNoteZh": "原题 ListElement 说明表改为文字；程序、位置规则和选项均保留。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_ans.pdf",
    "page": 16
  },
  {
    "id": "FE-2022-SAMPLE-B-11",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "number": 11,
    "topicZh": "直接下标排序的输入条件",
    "stemJa": "次の記述中の［ a ］に入れる正しい答えを，解答群の中から選べ。ここで，配列の要素番号は 1 から始まる。関数 binSort を binSort(［ a ］) として呼び出すと，戻り値の配列には未定義の要素は含まれておらず，値は昇順に並んでいる。\n〔プログラム〕\n○整数型の配列: binSort(整数型の配列: data)\n  整数型: n ← dataの要素数\n  整数型の配列: bins ← {n個の未定義の値}\n  整数型: i\n  for (i を 1 から n まで 1 ずつ増やす)\n    bins[data[i]] ← data[i]\n  endfor\n  return bins",
    "options": [
      {
        "label": "ア",
        "textJa": "{2, 6, 3, 1, 4, 5}"
      },
      {
        "label": "イ",
        "textJa": "{3, 1, 4, 4, 5, 2}"
      },
      {
        "label": "ウ",
        "textJa": "{4, 2, 1, 5, 6, 2}"
      },
      {
        "label": "エ",
        "textJa": "{5, 3, 4, 3, 2, 6}"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。程序把每个值 v 直接放进 `bins[v]`，返回数组要没有空位，输入就必须恰好包含 1～n 的每个整数一次。四个选项的元素数都是 6；ア包含 1、2、3、4、5、6 各一次，所以依次写入下标 1～6 后得到 {1,2,3,4,5,6}。イ重复 4、缺 6；ウ重复 2、缺 3；エ重复 3、缺 1，都会留下未定义位置，且重复值覆盖同一下标。此题不是一般比较排序，而是用值本身当数组下标。",
    "transcriptionNoteZh": "原 PDF 输入空框以［ a ］标示；代码和四组数组未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_ans.pdf",
    "page": 18
  },
  {
    "id": "FE-2022-SAMPLE-B-12",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "number": 12,
    "topicZh": "数组同位比较与相似率",
    "stemJa": "次のプログラム中の［ a ］に入れる正しい答えを，解答群の中から選べ。ここで，配列の要素番号は 1 から始まる。関数 simRatio は，要素数 1 以上の二つの文字型配列 s1 と s2 を比較する。要素数が等しければ，（同じ要素番号の文字が一致する組の個数 ÷ s1の要素数）を実数型で返し，等しくなければ－1を返す。配列の領域外を参照してはならない。\n例：s1={\"a\",\"p\",\"p\",\"l\",\"e\"}，s2={\"a\",\"p\",\"p\",\"l\",\"e\"}→1；s2={\"a\",\"p\",\"r\",\"i\",\"l\"}→0.4；s2={\"m\",\"e\",\"l\",\"o\",\"n\"}→0；s2={\"p\",\"e\",\"n\"}→－1。\n〔プログラム〕\n○実数型: simRatio(文字型の配列: s1, 文字型の配列: s2)\n  整数型: i, cnt ← 0\n  if (s1の要素数 ≠ s2の要素数)\n    return －1\n  endif\n  for (i を 1 から s1の要素数 まで 1 ずつ増やす)\n    if (［ a ］)\n      cnt ← cnt ＋ 1\n    endif\n  endfor\n  return cnt ÷ s1の要素数 /* 実数として計算する */",
    "options": [
      {
        "label": "ア",
        "textJa": "s1[i] ≠ s2[cnt]"
      },
      {
        "label": "イ",
        "textJa": "s1[i] ≠ s2[i]"
      },
      {
        "label": "ウ",
        "textJa": "s1[i] ＝ s2[cnt]"
      },
      {
        "label": "エ",
        "textJa": "s1[i] ＝ s2[i]"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。题目定义的是‘同一个下标位置的字符相同’才计数，因此循环在 i=1,2,… 时应比较 `s1[i]` 与 `s2[i]`，相等就给 cnt 加 1。以 apple 与 april 的例子，第 1、2 位相同，后 3 位不同，cnt=2，2÷5=0.4。イ把不相等的数了进去，方向反了；ア、ウ使用 `s2[cnt]`，cnt 初值为 0，而数组下标从 1 开始，甚至可能越界，也不对应同一位置。判断填空时可先根据文字定义写出‘同位且相等’，再找对应表达式。",
    "transcriptionNoteZh": "原题示例表按行改排，保留输入数组和返回值；问题描述略去重复叙述但计算定义、程序和选项完整。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_ans.pdf",
    "page": 20
  },
  {
    "id": "FE-2022-SAMPLE-B-13",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "number": 13,
    "topicZh": "二分搜索的边界更新错误",
    "stemJa": "次の記述中の［ a ］に入れる正しい答えを，解答群の中から選べ。ここで，配列の要素番号は 1 から始まる。関数 search は，昇順で重複のない配列 data に target が含まれていればその要素番号を返し，含まれていなければ－1を返す。関数 search には不具合がある。例えば，data が［ a ］場合は，無限ループになる。\n〔プログラム〕\n○整数型: search(整数型の配列: data, 整数型: target)\n  整数型: low, high, middle\n  low ← 1\n  high ← dataの要素数\n  while (low ≦ high)\n    middle ← (low ＋ high) ÷ 2 の商\n    if (data[middle] ＜ target)\n      low ← middle\n    elseif (data[middle] ＞ target)\n      high ← middle\n    else\n      return middle\n    endif\n  endwhile\n  return －1",
    "options": [
      {
        "label": "ア",
        "textJa": "要素数が 1 で，target がその要素の値と等しい"
      },
      {
        "label": "イ",
        "textJa": "要素数が 2 で，target が data の先頭要素の値と等しい"
      },
      {
        "label": "ウ",
        "textJa": "要素数が 2 で，target が data の末尾要素の値と等しい"
      },
      {
        "label": "エ",
        "textJa": "要素に－1 が含まれている"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。若 data 只有两个递增元素，且 target 是末尾值，初始 low=1、high=2，中点 `(1+2)÷2` 的商为 1。因为 data[1]<target，程序执行 `low←middle`，但 low 本来就是 1，状态完全不变；下轮又算出 middle=1，如此无限重复。ア、イ会在第一轮命中并返回。エ只说数组含－1，不足以保证触发这种边界停滞。正确的二分搜索通常在已排除中点时令 low=middle+1 或 high=middle－1，使搜索区间严格缩小。",
    "transcriptionNoteZh": "原 PDF 条件填空以［ a ］表示；程序中的错误边界更新保持原样。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_ans.pdf",
    "page": 22
  },
  {
    "id": "FE-2022-SAMPLE-B-14",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "number": 14,
    "topicZh": "五数概括与分位位置",
    "stemJa": "次の記述中の［ a ］に入れる正しい答えを，解答群の中から選べ。ここで，配列の要素番号は 1 から始まる。要素数が 1 以上で，昇順に整列済みの配列を基に，配列を特徴づける五つの値を返すプログラムである。関数 summarize を summarize({0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1})として呼び出すと，戻り値は［ a ］である。\n〔プログラム〕\n○実数型: findRank(実数型の配列: sortedData, 実数型: p)\n  整数型: i\n  i ← (p × (sortedDataの要素数 － 1)) の小数点以下を切り上げた値\n  return sortedData[i ＋ 1]\n○実数型の配列: summarize(実数型の配列: sortedData)\n  実数型の配列: rankData ← {} /* 要素数0の配列 */\n  実数型の配列: p ← {0, 0.25, 0.5, 0.75, 1}\n  整数型: i\n  for (i を 1 から pの要素数 まで 1 ずつ増やす)\n    rankDataの末尾 に findRank(sortedData, p[i])の戻り値 を追加する\n  endfor\n  return rankData",
    "options": [
      {
        "label": "ア",
        "textJa": "{0.1, 0.3, 0.5, 0.7, 1}"
      },
      {
        "label": "イ",
        "textJa": "{0.1, 0.3, 0.5, 0.8, 1}"
      },
      {
        "label": "ウ",
        "textJa": "{0.1, 0.3, 0.6, 0.7, 1}"
      },
      {
        "label": "エ",
        "textJa": "{0.1, 0.3, 0.6, 0.8, 1}"
      },
      {
        "label": "オ",
        "textJa": "{0.1, 0.4, 0.5, 0.7, 1}"
      },
      {
        "label": "カ",
        "textJa": "{0.1, 0.4, 0.5, 0.8, 1}"
      },
      {
        "label": "キ",
        "textJa": "{0.1, 0.4, 0.6, 0.7, 1}"
      },
      {
        "label": "ク",
        "textJa": "{0.1, 0.4, 0.6, 0.8, 1}"
      }
    ],
    "answer": "ク",
    "explanationZh": "答案是ク。数组有 10 项，公式先算 `p×(10－1)=9p`，小数向上取整后再加 1 作为一基下标。p=0 时下标 1→0.1；p=0.25 时 9p=2.25，向上取整为 3，下标 4→0.4；p=0.5 时 4.5 向上取整为 5，下标 6→0.6；p=0.75 时 6.75 向上取整为 7，下标 8→0.8；p=1 时 9，下标 10→1。因此是 {0.1,0.4,0.6,0.8,1}。其余选项至少有一个位置错在未向上取整或漏掉末尾的 +1。应按给定函数计算，不套用别的统计软件分位数规则。",
    "transcriptionNoteZh": "原 PDF 返回值填空框以［ a ］表示；数组、向上取整公式及八个候选数组未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_ans.pdf",
    "page": 23
  },
  {
    "id": "FE-2022-SAMPLE-B-15",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "number": 15,
    "topicZh": "井字棋博弈树与极大极小法",
    "stemJa": "次の記述中の a と b に入れる正しい答えの組合せを，解答群の中から選べ。\n三目並べにおいて自分が勝利する可能性が最も高い手を決定する。次の手順で，ゲームの状態遷移を木構造として表現し，根以外の各節の評価値を求める。その結果，根の子の中で最も評価値が高い手を，最も勝利する可能性が高い手とする。自分が選択した手を○で表し，相手が選択した手を×で表す。\n〔手順〕\n(1) 現在の盤面の状態を根とし，勝敗がつくか，引き分けとなるまでの考えられる全ての手を木構造で表現する。\n(2) 葉の状態を次のように評価する。① 自分が勝ちの場合は10。② 自分が負けの場合は－10。③ 引き分けの場合は0。\n(3) 葉以外の節の評価値は，その節の全ての子の評価値を基に決定する。① 自分の手番の節である場合，子の評価値で最大の評価値を節の評価値とする。② 相手の手番の節である場合，子の評価値で最小の評価値を節の評価値とする。\nゲームが図の最上部にある根の状態のとき，自分が選択できる手は三つある。そのうちA が指す子の評価値は a であり，B が指す子の評価値は b である。",
    "options": [
      {
        "label": "ア",
        "textJa": "a＝0，b＝－10"
      },
      {
        "label": "イ",
        "textJa": "a＝0，b＝0"
      },
      {
        "label": "ウ",
        "textJa": "a＝10，b＝－10"
      },
      {
        "label": "エ",
        "textJa": "a＝10，b＝0"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア，a＝0、b＝－10。这是极大极小法：轮到自己时取子节点最大值，轮到对手时要假设对手会选对自己最不利的最小值。A 分支下，对手有两种后续选择：左侧最终为平局 0，右侧最终为自己获胜 10，因此 A 节点评价值 min(0,10)＝0，不能乐观地只取 10。B 分支下，对手可以让自己直接输掉，值为－10；另一条后续是平局 0，因此 B 节点取 min(－10,0)＝－10。イ忽略 B 的失败叶子；ウ和エ把 A 的最好结果误当作对手一定会选择的结果。根节点若要比较三手，应选择子节点中评价最高者。",
    "transcriptionNoteZh": "官方题跨 PDF 第 24、25 页，状态树、井字棋盘和答案组合表分别保存在两张原卷图片中；文字保留规则与题问。",
    "imageAssets": [
      "question-images/fe-2022-sample-b-15-p24.png",
      "question-images/fe-2022-sample-b-15-p25.png"
    ],
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_ans.pdf",
    "page": 24
  },
  {
    "id": "FE-2022-SAMPLE-B-16",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "number": 16,
    "topicZh": "UTF-8 三字节编码与每组六位",
    "stemJa": "次のプログラム中の［ a ］に入れる正しい答えを，解答群の中から選べ。二つの［ a ］には，同じ答えが入る。ここで，配列の要素番号は 1 から始まる。Unicode の符号位置を，UTF-8 の符号に変換するプログラムである。本問で数値の後ろに“(16)”と記載した場合は，その数値が 16 進数であることを表す。Unicode の各文字には，符号位置と呼ばれる整数値が与えられている。UTF-8 は，Unicode の文字を符号化する方式の一つであり，符号位置が 800(16) 以上 FFFF(16) 以下の文字は，次のように 3 バイトの値に符号化する。3 バイトの長さのビットパターンを 1110xxxx 10xxxxxx 10xxxxxx とする。ビットパターンの“x”の箇所に，符号位置を 2 進数で表した値を右詰めで格納し，余った“x”の箇所に 0 を格納する。この 3 バイトの値が UTF-8 の符号である。例えば，ひらがなの“あ”の符号位置である 3042(16) を 2 進数で表すと 11000001000010 である。これを，上に示したビットパターンの“x”の箇所に右詰めで格納すると，1110xx11 10000001 10000010 となる。余った二つの“x”の箇所に 0 を格納すると，“あ”の UTF-8 の符号 11100011 10000001 10000010 が得られる。関数 encode は，引数で渡された Unicode の符号位置を UTF-8 の符号に変換し，先頭から順に 1 バイトずつ要素に格納した整数型の配列を返す。encode には，引数として，800(16) 以上 FFFF(16) 以下の整数値だけが渡されるものとする。\n〔プログラム〕\n○整数型の配列: encode(整数型: codePoint)\n  /* utf8Bytesの初期値は，ビットパターンの“x”を全て0に置き換え，8桁ごとに区切って，それぞれを2進数とみなしたときの値 */\n  整数型の配列: utf8Bytes ← {224, 128, 128}\n  整数型: cp ← codePoint\n  整数型: i\n  for (i を utf8Bytesの要素数 から 1 まで 1 ずつ減らす)\n    utf8Bytes[i] ← utf8Bytes[i] ＋ (cp ÷［ a ］の余り)\n    cp ← cp ÷［ a ］の商\n  endfor\n  return utf8Bytes",
    "options": [
      {
        "label": "ア",
        "textJa": "((4 － i) × 2)"
      },
      {
        "label": "イ",
        "textJa": "(2 の (4 － i)乗)"
      },
      {
        "label": "ウ",
        "textJa": "(2 の i 乗)"
      },
      {
        "label": "エ",
        "textJa": "(i × 2)"
      },
      {
        "label": "オ",
        "textJa": "2"
      },
      {
        "label": "カ",
        "textJa": "6"
      },
      {
        "label": "キ",
        "textJa": "16"
      },
      {
        "label": "ク",
        "textJa": "64"
      },
      {
        "label": "ケ",
        "textJa": "256"
      }
    ],
    "answer": "ク",
    "explanationZh": "答案是ク，64。三字节 UTF-8 的后两个字节各留出 6 个 x 位，所以从右向左分组时，每组数值范围是 0～63，基数为 2⁶＝64。程序从第 3 字节向第 1 字节循环：`cp÷64` 的余数取最低 6 位放入当前字节，再把整数商交给下一轮。用题目例子 3042₁₆=12354：第 3 字节余数 2，128+2=130；商 193；第 2 字节余数 1，128+1=129；商 3；第 1 字节 224+3=227，正好对应 E3 81 82。256 是按整字节切分，16 是按十六进制一位切分，都不能对应连续的 6 个 x 位。",
    "transcriptionNoteZh": "原 PDF 的两处填空框用［ a ］表示；上下文、位模式、程序与选项保持原意。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_ans.pdf",
    "page": 26
  },
  {
    "id": "FE-2022-SAMPLE-B-17",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "number": 17,
    "topicZh": "PaaS 分层漏洞责任",
    "stemJa": "製造業の A 社では，EC サイト（以下，A 社の EC サイトを A サイトという）を使用し，個人向けの製品販売を行っている。A サイトは，A 社の製品やサービスが検索可能で，ログイン機能を有しており，あらかじめ A サイトに利用登録した個人（以下，会員という）の氏名やメールアドレスといった情報（以下，会員情報という）を管理している。A サイトは，B 社の PaaS で稼働しており，PaaS 上の DBMS とアプリケーションサーバを利用している。A 社は，A サイトの開発，運用を C 社に委託している。A 社と C 社との間の委託契約では，Web アプリケーションプログラムの脆弱性対策は，C 社が実施するとしている。最近，A 社の同業他社が運営している Web サイトで脆弱性が悪用され，個人情報が漏えいするという事件が発生した。そこで A 社は，セキュリティ診断サービスを行っている D 社に，A サイトの脆弱性診断を依頼した。脆弱性診断の結果，対策が必要なセキュリティ上の脆弱性が複数指摘された。\n図 1 D 社からの指摘事項\n項番 1：A サイトで利用しているアプリケーションサーバの OS に既知の脆弱性があり，脆弱性を悪用した攻撃を受けるおそれがある。\n項番 2：A サイトにクロスサイトスクリプティングの脆弱性があり，会員情報を不正に取得されるおそれがある。\n項番 3：A サイトで利用している DBMS に既知の脆弱性があり，脆弱性を悪用した攻撃を受けるおそれがある。\n設問 図 1 中の各項番それぞれに対処する組織の適切な組合せを，解答群の中から選べ。",
    "options": [
      {
        "label": "ア",
        "textJa": "項番1：A 社，項番2：A 社，項番3：A 社"
      },
      {
        "label": "イ",
        "textJa": "項番1：A 社，項番2：A 社，項番3：C 社"
      },
      {
        "label": "ウ",
        "textJa": "項番1：A 社，項番2：B 社，項番3：B 社"
      },
      {
        "label": "エ",
        "textJa": "項番1：B 社，項番2：B 社，項番3：B 社"
      },
      {
        "label": "オ",
        "textJa": "項番1：B 社，項番2：B 社，項番3：C 社"
      },
      {
        "label": "カ",
        "textJa": "項番1：B 社，項番2：C 社，項番3：B 社"
      },
      {
        "label": "キ",
        "textJa": "項番1：B 社，項番2：C 社，項番3：C 社"
      },
      {
        "label": "ク",
        "textJa": "項番1：C 社，項番2：B 社，項番3：B 社"
      },
      {
        "label": "ケ",
        "textJa": "項番1：C 社，項番2：B 社，項番3：C 社"
      },
      {
        "label": "コ",
        "textJa": "項番1：C 社，項番2：C 社，項番3：B 社"
      }
    ],
    "answer": "カ",
    "explanationZh": "答案是カ，即 B 社、C 社、B 社。按层分开看：B 社提供 PaaS 及其应用服务器、DBMS，因此应用服务器 OS 的已知漏洞（项番 1）和 PaaS 上 DBMS 的已知漏洞（项番 3）由 B 社处理。项番 2 是 A 网站 Web 应用程序的跨站脚本漏洞；题目明确说 A 与 C 的委托合同把应用程序漏洞对策交给 C 社，所以由 C 社处理。A 社是业务主体并负有整体管理责任，但本题问这三个技术处置任务在给定分工下由谁执行。其余九个组合至少把平台层或应用层的一项责任放错了。",
    "transcriptionNoteZh": "原题三项诊断结果表及答案表按行转为文字；公司、漏洞类别和组合未改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_ans.pdf",
    "page": 28
  },
  {
    "id": "FE-2022-SAMPLE-B-18",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "number": 18,
    "topicZh": "BYOD、VPN 与新增风险",
    "stemJa": "A 社は IT 開発を行っている従業員 1,000 名の企業である。総務部 50 名，営業部 50 名で，ほかは開発部に所属している。開発部員の 9 割は客先に常駐している。現在，A 社における PC の利用状況は図 1 のとおりである。\n1 A 社の PC：総務部員，営業部員及び A 社オフィスに勤務する開発部員には，会社が用意した PC（以下，A 社 PC という）を一人 1 台ずつ貸与している。客先常駐開発部員には，A 社 PC を貸与していないが，代わりに客先常駐開発部員が A 社オフィスに出社したときに利用するための共用 PC を用意している。\n2 客先常駐開発部員の業務システム利用：客先常駐開発部員が休暇申請，経費精算などで業務システムを利用するためには共用 PC を使う必要がある。\n3 A 社の VPN 利用：A 社には，VPN サーバが設置されており，営業部員が出張時に A 社 PC からインターネット経由で社内ネットワークに VPN 接続し，業務システムを利用できるようになっている。規則で，VPN 接続には A 社 PC を利用すると定められている。\nA 社では，客先常駐開発部員が業務システムを使うためだけに A 社オフィスに出社するのは非効率的であると考え，客先常駐開発部員に対して個人所有 PC の業務利用（BYOD）と VPN 接続の許可を検討することにした。\n設問 客先常駐開発部員に，個人所有 PC からの VPN 接続を許可した場合に，増加する又は新たに生じると考えられるリスクを二つ挙げた組合せは，次のうちどれか。解答群のうち，最も適切なものを選べ。\n(一) VPN 接続が増加し，可用性が損なわれるリスク\n(二) 客先常駐開発部員が A 社 PC を紛失するリスク\n(三) 客先常駐開発部員がフィッシングメールの URL をクリックして個人所有 PC がマルウェアに感染するリスク\n(四) 総務部員が個人所有 PC を VPN 接続するリスク\n(五) マルウェアに感染した個人所有 PC が社内ネットワークに VPN 接続され，マルウェアが社内ネットワークに拡散するリスク",
    "options": [
      {
        "label": "ア",
        "textJa": "(一)，(二)"
      },
      {
        "label": "イ",
        "textJa": "(一)，(三)"
      },
      {
        "label": "ウ",
        "textJa": "(一)，(四)"
      },
      {
        "label": "エ",
        "textJa": "(一)，(五)"
      },
      {
        "label": "オ",
        "textJa": "(二)，(三)"
      },
      {
        "label": "カ",
        "textJa": "(二)，(四)"
      },
      {
        "label": "キ",
        "textJa": "(二)，(五)"
      },
      {
        "label": "ク",
        "textJa": "(三)，(四)"
      },
      {
        "label": "ケ",
        "textJa": "(三)，(五)"
      },
      {
        "label": "コ",
        "textJa": "(四)，(五)"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ，风险（一）和（五）。先识别变更点：大量原本不能从个人电脑连入 A 社内网的驻场开发人员，今后可经 VPN 连入。因此 VPN 连接量上升可能压低可用性（一）；若个人电脑已感染恶意软件，连接内网后还可能把感染扩散进去（五）。二不成立，因为题目明确说驻场开发人员本来就没有获配 A 社 PC；三的钓鱼邮件感染个人电脑即使不许 VPN 也可能发生，不是授权 VPN 新增的风险；四只给驻场开发部员开通许可，不能据此推出总务部员会用个人 PC 连接。其余九个组合至少包含二、三、四中的一项，或漏掉一、五。",
    "transcriptionNoteZh": "原题图 1 是分点文字说明，此处按分点转录；人数、现行规则、拟变更范围和五项风险保留。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_ans.pdf",
    "page": 30
  },
  {
    "id": "FE-2022-SAMPLE-B-19",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "number": 19,
    "topicZh": "受注系统权限与职责分离",
    "stemJa": "A 社は従業員 200 名の通信販売業者である。一般消費者向けに生活雑貨，ギフト商品などの販売を手掛けている。取扱商品の一つである商品 Z は，Z 販売課が担当している。\n〔Z販売課の業務〕現在，Z 販売課の要員は，商品 Z についての受注管理業務及び問合せ対応業務を行っている。商品Zについての受注管理業務の手順を図1に示す。\n商品Zの顧客からの注文は電子メールで届く。(1) 入力：販売担当者は，届いた注文（変更，キャンセルを含む）の内容を受注管理システム（以下，Jシステムという）に入力し，販売責任者に承認を依頼する。(2) 承認：販売責任者は，注文の内容と J システムへの入力結果を突き合わせて確認し，問題がなければ承認する。問題があれば差し戻す。Jシステムは A社情報システム部が運用している。利用者は，販売責任者，販売担当者などである。販売責任者は Z販売課の課長1名だけである。\n〔Jシステムの操作権限〕Z販売課では，Jシステムについて，次の利用方針を定めている。［方針1］ある利用者が入力した情報は，別の利用者が承認する。［方針2］販売責任者は，Z販売課の全業務の情報を閲覧できる。Jシステムでは，業務上必要な操作権限を利用者に与える機能が実装されている。\nこの度，商品 Z の受注管理業務が受注増によって増えていることから，B 社に一部を委託することにした（以下，商品 Z の受注管理業務の入力作業を行う B 社従業員を商品 Z の B 社販売担当者といい，商品 Z の B 社販売担当者の入力結果を閲覧して，不備があれば A 社に口頭で差戻しを依頼する B 社従業員を商品 Z の B 社販売責任者という）。\n委託に当たって，Z 販売課は情報システム部に J システムに関する次の要求事項を伝えた。［要求1］B社が入力した場合は，A社が承認する。［要求2］A社の販売担当者が入力した場合は，現状どおりに A社の販売責任者が承認する。上記を踏まえ，情報システム部は今後の各利用者に付与される操作権限を表1にまとめ，Z販売課の情報セキュリティリーダーであるCさんに確認をしてもらった。\n表1：a1 の利用者には閲覧権限だけ，a2 の利用者には閲覧権限と入力権限を付与する。設問：表1中の a1，a2 に入れる字句の適切な組合せを選べ。",
    "options": [
      {
        "label": "ア",
        "textJa": "a1＝Z販売課の販売責任者，a2＝商品ZのB社販売責任者"
      },
      {
        "label": "イ",
        "textJa": "a1＝Z販売課の販売責任者，a2＝商品ZのB社販売担当者"
      },
      {
        "label": "ウ",
        "textJa": "a1＝商品ZのB社販売責任者，a2＝Z販売課の販売責任者"
      },
      {
        "label": "エ",
        "textJa": "a1＝商品ZのB社販売責任者，a2＝商品ZのB社販売担当者"
      },
      {
        "label": "オ",
        "textJa": "a1＝商品ZのB社販売担当者，a2＝商品ZのB社販売責任者"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。先按实际工作确定最小权限：B 公司的‘销售担当者’负责把订单输入 J 系统，必须能查看并输入，所以占表中‘閲覧＋入力’的 a2。B 公司的‘销售责任者’只查看 B 公司输入结果，若有问题通过口头方式要求 A 公司退回，不执行系统输入或批准，所以只需‘閲覧’权限，占 a1。A 公司 Z 销售课责任者仍须按要求批准 A 公司担当者输入的订单，而 B 公司所输入的订单也必须由 A 公司一方批准；题目没有指定后一种情况由 A 公司的哪一个具体岗位执行。Z 销售课责任者需要批准权限，不能放在无批准权的 a1 或 a2；因此ア、イ、ウ排除。オ把 B 公司两种角色的权限颠倒，让负责输入的人无输入权、负责查看的人有输入权，也错误。题目特别强调‘由 A 公司批准’，故 B 公司任何一方都不应获批准权限。",
    "transcriptionNoteZh": "官方题跨 PDF 第 32、33 页；两张原卷截图保留流程图、权限表与选项。正文按原文顺序线性化图1及表1，脚注改写为紧邻正文。",
    "imageAssets": [
      "question-images/fe-2022-sample-b-19-p32.png",
      "question-images/fe-2022-sample-b-19-p33.png"
    ],
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_ans.pdf",
    "page": 32
  },
  {
    "id": "FE-2022-SAMPLE-B-20",
    "kind": "sample",
    "year": 2022,
    "section": "B",
    "number": 20,
    "topicZh": "防火墙变更的职责分离",
    "stemJa": "A 社は栄養補助食品を扱う従業員 500 名の企業である。A 社のサーバ及びファイアウォール（以下，FW という）を含む情報システムの運用は情報システム部が担当している。ある日，内部監査部の監査があり，FW の運用状況について情報システム部の B 部長が図 1 のとおり説明したところ，表 1 に示す指摘を受けた。\n・FW を含め，情報システムの運用は，情報システム部の運用チームに所属する 6 名の運用担当者が担当している。\n・FW の運用には，FW ルールの編集，操作ログの確認，並びに編集後の FW ルールの確認及び操作の承認（以下，編集後の FW ルールの確認及び操作の承認を操作承認という）の三つがある。\n・FW ルールの編集は事前に作成された操作指示書に従って行う。\n・FW の機能には，FW ルールの編集，操作ログの確認，及び操作承認の三つがある。\n・FW ルールの変更には，FW ルールの編集と操作承認の両方が必要である。操作承認の前に操作ログの確認を行う。\n・FW の利用者 ID は各運用担当者に個別に発行されており，利用者 ID の共用はしていない。\n・FW では，機能を利用する権限を運用担当者の利用者 ID ごとに付与できる。\n・現在は，6 名の運用担当者とも全権限を付与されており，運用担当者は FW のルールの編集後，編集を行った運用担当者が操作に誤りがないことを確認し，操作承認をしている。\n・FW へのログインにはパスワードを利用している。パスワードは 8 文字の英数字である。\n・FW の運用では，運用担当者の利用者 ID ごとに，ネットワークを経由せずコンソールでログインできるかどうか，ネットワークを経由してリモートからログインできるかどうかを設定できる。\n・FW は，ネットワークを経由せずコンソールでログインした場合でも，ネットワークを経由してリモートからログインした場合でも，同一の機能を利用できる。\n・FW はサーバルームに設置されており，サーバルームにはほかに数種類のサーバも設置されている。\n・運用担当者だけがサーバルームへの入退室を許可されている。\n表 1 内部監査部からの指摘：指摘 1 FW の運用の作業の中で，職務が適切に分離されていない。指摘 2～4（省略）。\nB 部長は表 1 の指摘に対する改善策を検討することにした。\n設問 表 1 中の指摘 1 について，FW ルールの誤った変更を防ぐための改善策はどれか。解答群のうち，最も適切なものを選べ。",
    "options": [
      {
        "label": "ア",
        "textJa": "Endpoint Detection and Response（EDR）をコンソールに導入し，監視を強化する。"
      },
      {
        "label": "イ",
        "textJa": "FW での運用担当者のログインにはパスワード認証の代わりに多要素認証を導入する。"
      },
      {
        "label": "ウ",
        "textJa": "FW のアクセス制御機能を使って，運用担当者をコンソールからログインできる者，リモートからログインできる者に分ける。"
      },
      {
        "label": "エ",
        "textJa": "FW の運用担当者を 1 人に限定する。"
      },
      {
        "label": "オ",
        "textJa": "運用担当者の一部を操作ログの確認だけをする者とし，それらの者には操作ログの確認権限だけを付与する。"
      },
      {
        "label": "カ",
        "textJa": "運用担当者を，FW ルールの編集を行う者，操作ログを確認し，操作承認をする者に分け，それぞれに必要最小限の権限を付与する。"
      },
      {
        "label": "キ",
        "textJa": "作業を行う運用担当者を，曜日ごとに割り当てる。"
      }
    ],
    "answer": "カ",
    "explanationZh": "答案是カ。审计指出‘职责没有适当分离’，根因是同一名运维人员既能编辑防火墙规则，又能查看日志并批准自己的修改，缺少独立复核。カ把编辑者与‘核对日志并批准者’分成不同人，并分别只授予必要权限，直接阻断自己改、自己批的流程。ア的 EDR 加强终端监控；イ的多因素认证增强登录身份确认；ウ按本地或远程登录分组，但题目说两种登录方式仍可用同一功能；エ只剩一人会让职责更难分离；オ虽把一些人限制为看日志，但其他人仍可能同时编辑并批准；キ按星期轮班也不阻止同一人当天自审。",
    "transcriptionNoteZh": "原题图 1、表 1 是分点说明，此处线性排版；所有相关条件及七个选项未删改。",
    "questionUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/syllabus/henkou/2022/ssf7ph000000h5tb-att/fe_kamoku_b_set_sample_ans.pdf",
    "page": 34
  },
  {
    "id": "FE-2019-F-AM-01",
    "kind": "official",
    "year": 2019,
    "section": "AM",
    "number": 1,
    "topicZh": "十进制转二进制的流程图",
    "stemJa": "次の流れ図は，10 進整数 j（0＜j＜100）を 8 桁の 2 進数に変換する処理を表している。2 進数は下位桁から順に，配列の要素 NISHIN (1) から NISHIN (8) に格納される。流れ図の a 及び b に入れる処理はどれか。ここで，j div 2 は j を2 で割った商の整数部分を，j mod 2は jを2で割った余りを表す。",
    "options": [
      {
        "label": "ア",
        "textJa": "a：j ← j div 2／b：NISHIN (k) ← j mod 2"
      },
      {
        "label": "イ",
        "textJa": "a：j ← j mod 2／b：NISHIN (k) ← j div 2"
      },
      {
        "label": "ウ",
        "textJa": "a：NISHIN (k) ← j div 2／b：j ← j mod 2"
      },
      {
        "label": "エ",
        "textJa": "a：NISHIN (k) ← j mod 2／b：j ← j div 2"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。把整数反复除以 2 时，每次的余数就是当前最低位，因此先执行 NISHIN(k)←j mod 2，把这一位保存下来；再用 j←j div 2 去掉已保存的最低位，准备取下一位。流程图中的 k 从 1 到 8，正好按低位到高位存入数组。以 j＝5 为例：第一次存 1 后 j＝2，第二次存 0 后 j＝1，第三次存 1，得到低位起 1、0、1。ア先除再取余，会丢掉原最低位；イ把 j 改为余数，使后续高位无法取得；ウ保存商而非单个二进制位，也不对。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 3,
    "periodJa": "秋期",
    "imageAssets": [
      "question-images/fe-2019-f-am-01.jpg"
    ],
    "transcriptionNoteZh": "本题与 2022 官方科目 A 样题复用同一题干；图形以 2019 秋期原卷裁图为准。"
  },
  {
    "number": 2,
    "stemJa": "8ビットの値の全ビットを反転する操作はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "16進表記 00 のビット列と排他的論理和をとる。"
      },
      {
        "label": "イ",
        "textJa": "16進表記 00 のビット列と論理和をとる。"
      },
      {
        "label": "ウ",
        "textJa": "16進表記 FF のビット列と排他的論理和をとる。"
      },
      {
        "label": "エ",
        "textJa": "16進表記 FF のビット列と論理和をとる。"
      }
    ],
    "answer": "ウ",
    "id": "FE-2019-F-AM-02",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "位运算与异或",
    "explanationZh": "正确答案ウ。8位的FF是11111111，每一位与1做异或都会翻转：0⊕1＝1，1⊕1＝0，因此整字节取反。ア与00异或会原样保留；イ与00做或也原样保留；エ与FF做或会把所有位变成1。记住异或1才翻转，异或0保持不变。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 3
  },
  {
    "id": "FE-2019-F-AM-03",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 3,
    "topicZh": "无向图与邻接矩阵",
    "stemJa": "ノードとノードの間のエッジの有無を，隣接行列を用いて表す。ある無向グラフの隣接行列が次の場合，グラフで表現したものはどれか。ここで，ノードを隣接行列の行と列に対応させて，ノード間にエッジが存在する場合は1で，エッジが存在しない場合は0で示す。",
    "options": [
      {
        "label": "ア",
        "textJa": "図ア"
      },
      {
        "label": "イ",
        "textJa": "図イ"
      },
      {
        "label": "ウ",
        "textJa": "図ウ"
      },
      {
        "label": "エ",
        "textJa": "図エ"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。邻接矩阵中某行某列为 1，表示对应两个节点之间有边；无向图的矩阵还会沿对角线对称。逐行读出边：a－b，b－c，b－d，c－d，c－e，e－f。ウ图恰好具有这六条边。ア缺 b－c 等连接，イ和エ各有与矩阵不一致的邻接关系。可以先数节点度数作快速检查：a 和 f 各连一条，b 与 c 各连三条，d 与 e 各连两条；再逐边核对，避免只凭图形相似判断。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 4,
    "imageAssets": [
      "question-images/fe-2019-f-am-03.jpg"
    ],
    "transcriptionNoteZh": "图形、表格或公式以核对过的 IPA 官方原卷裁图为准。"
  },
  {
    "id": "FE-2019-F-AM-04",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 4,
    "topicZh": "函数极限与增长速度",
    "stemJa": "a及びbを定数とする関数 f(t)＝a／(t＋1) 及び g(t)＝b／(t²－t) に対して，lim[t→∞] g(t)／f(t) はどれか。ここで，a≠0，b≠0，t＞1 とする。",
    "options": [
      {
        "label": "ア",
        "textJa": "0"
      },
      {
        "label": "イ",
        "textJa": "1"
      },
      {
        "label": "ウ",
        "textJa": "b／a"
      },
      {
        "label": "エ",
        "textJa": "∞"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア，即 0。先把比值写成一个分式：g(t)／f(t)＝[b／(t²－t)]÷[a／(t＋1)]＝(b／a)×(t＋1)／(t²－t)。分子随 t 约按 t 增长，分母约按 t² 增长，因此比值约等于常数除以 t，t 趋向无穷时收敛到 0。イ和ウ把两个函数当成相同阶的量，エ则把分母增长更快的方向看反。题给 a、b 非零，避免了除零问题。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 5,
    "imageAssets": [
      "question-images/fe-2019-f-am-04.jpg"
    ],
    "transcriptionNoteZh": "图形、表格或公式以核对过的 IPA 官方原卷裁图为准。"
  },
  {
    "id": "FE-2019-F-AM-05",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 5,
    "topicZh": "正态分布的均值与标准差",
    "stemJa": "平均が60，標準偏差が10の正規分布を表すグラフはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "図ア"
      },
      {
        "label": "イ",
        "textJa": "図イ"
      },
      {
        "label": "ウ",
        "textJa": "図ウ"
      },
      {
        "label": "エ",
        "textJa": "図エ"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。正态分布曲线应关于均值对称，峰值位于 60；标准差 10 表示横轴从均值 60 到 70 恰为一个标准差。ア图同时满足对称性、中心 60、间距 10。イ把 55 至 65 的总间距标成 10，单侧只有 5；ウ出现两个峰，已不是单峰正态曲线；エ曲线左右不对称且标出 50 至 60 的单侧间距 10。判断时先看形状是否对称，再看均值到相邻标记的距离。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 5,
    "imageAssets": [
      "question-images/fe-2019-f-am-05.jpg"
    ],
    "transcriptionNoteZh": "图形、表格或公式以核对过的 IPA 官方原卷裁图为准。"
  },
  {
    "number": 6,
    "stemJa": "Random(n)は，0以上n未満の整数を一様な確率で返す関数である。整数型の変数A，B及びCに対して次の一連の手続を実行したとき，Cの値が0になる確率はどれか。\n\n　　A＝Random(10)\n　　B＝Random(10)\n　　C＝A－B",
    "options": [
      {
        "label": "ア",
        "textJa": "1/100"
      },
      {
        "label": "イ",
        "textJa": "1/20"
      },
      {
        "label": "ウ",
        "textJa": "1/10"
      },
      {
        "label": "エ",
        "textJa": "1/5"
      }
    ],
    "answer": "ウ",
    "id": "FE-2019-F-AM-06",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "独立随机数的相等概率",
    "explanationZh": "正确答案ウ。C＝A－B要等于0，必须A与B取到同一个数。A、B各有0至9共10种等概率结果，合计10×10＝100种有序组合；相同的只有(0,0)至(9,9)共10种，所以概率10/100＝1/10。ア的1/100只算了一个相同组合；イ的1/20和エ的1/5都不符合等概率计数。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 6,
    "transcriptionNoteZh": "原卷中的分数、函数或指数排版改为等值纯文本，数值及题意未改变。"
  },
  {
    "number": 7,
    "stemJa": "次のBNFで定義される＜変数名＞に合致するものはどれか。\n\n　＜数字＞::＝ 0｜1｜2｜3｜4｜5｜6｜7｜8｜9\n　＜英字＞::＝ A｜B｜C｜D｜E｜F\n　＜英数字＞::＝＜英字＞｜＜数字＞｜_\n　＜変数名＞::＝＜英字＞｜＜変数名＞＜英数字＞",
    "options": [
      {
        "label": "ア",
        "textJa": "_B39"
      },
      {
        "label": "イ",
        "textJa": "246"
      },
      {
        "label": "ウ",
        "textJa": "3E5"
      },
      {
        "label": "エ",
        "textJa": "F5_1"
      }
    ],
    "answer": "エ",
    "id": "FE-2019-F-AM-07",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "BNF语法与标识符",
    "explanationZh": "正确答案エ。规则要求变量名的首字符必须是A至F的字母，之后可反复追加字母、数字或下划线。F5_1从F开始，后续5、_、1都允许。ア以_开头、イ以数字2开头、ウ以数字3开头，均在第一字符处违反语法。看BNF时先找最短的起始产生式，再看递归追加规则。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 6
  },
  {
    "number": 8,
    "stemJa": "A，C，K，S，Tの順に文字が入力される。スタックを利用して，S，T，A，C，Kという順に文字を出力するために，最小限必要となるスタックは何個か。ここで，どのスタックにおいてもポップ操作が実行されたときには必ず文字を出力する。また，スタック間の文字の移動は行わない。",
    "options": [
      {
        "label": "ア",
        "textJa": "1"
      },
      {
        "label": "イ",
        "textJa": "2"
      },
      {
        "label": "ウ",
        "textJa": "3"
      },
      {
        "label": "エ",
        "textJa": "4"
      }
    ],
    "answer": "ウ",
    "id": "FE-2019-F-AM-08",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "栈的后进先出",
    "explanationZh": "正确答案ウ。输入按A、C、K、S、T到达，却要先输出S、T，所以A、C、K必须暂存；若放在同一栈，之后弹出顺序会变成K、C、A，不能得到A、C、K。可分别把A、C、K放入三个栈，S与T直接输出，然后依次弹出A、C、K。因此3个足够且少于3个不可能。ア、イ不足，エ不是最小值。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2019-F-AM-09",
    "kind": "official",
    "year": 2019,
    "section": "AM",
    "number": 9,
    "topicZh": "二维数组旋转与坐标映射",
    "stemJa": "配列Aが図2の状態のとき，図1の流れ図を実行すると，配列Bが図3の状態になった。図 1 の a に入れる操作はどれか。ここで，配列 A，B の要素をそれぞれ A (i，j) ，B (i，j) とする。",
    "options": [
      {
        "label": "ア",
        "textJa": "B (7－i，7－j) ← A (i，j)"
      },
      {
        "label": "イ",
        "textJa": "B (7－j，i) ← A (i，j)"
      },
      {
        "label": "ウ",
        "textJa": "B (i，7－j) ← A (i，j)"
      },
      {
        "label": "エ",
        "textJa": "B ( j，7－i) ← A (i，j)"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。原图中 A 的第 1 列从上到下有连续的星号，执行后 B 的第 1 行从右到左有连续星号；A 的第 0 行横向星号则变为 B 的第 7 列纵向星号，说明整体顺时针旋转 90 度。对于从 0 到 7 的 8×8 下标，原位置 (i,j) 顺时针旋转后的坐标为 (j,7－i)，即 B(j,7－i)←A(i,j)。ア是旋转 180 度；イ是逆时针 90 度；ウ只作左右镜像。对照原图中的 L 形星号即可验证四种变换的方向。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 7,
    "periodJa": "秋期",
    "imageAssets": [
      "question-images/fe-2019-f-am-09.jpg"
    ],
    "transcriptionNoteZh": "本题与 2022 官方科目 A 样题复用同一题干；图形以 2019 秋期原卷裁图为准。"
  },
  {
    "id": "FE-2019-F-AM-10",
    "kind": "official",
    "year": 2019,
    "section": "AM",
    "number": 10,
    "topicZh": "哈希函数与取余",
    "stemJa": "10 進法で 5 桁の数 a1a2a3a4a5 を，ハッシュ法を用いて配列に格納したい。ハッシュ関数を mod ( a1＋a2＋a3＋a4＋a5，13 ) とし，求めたハッシュ値に対応する位置の配列要素に格納する場合，54321 は配列のどの位置に入るか。ここで，mod ( x，13 ) は，x を 13 で割った余りとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "1"
      },
      {
        "label": "イ",
        "textJa": "2"
      },
      {
        "label": "ウ",
        "textJa": "7"
      },
      {
        "label": "エ",
        "textJa": "11"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ，位置 2。哈希函数已明确要求先把五个十进制数字逐位相加，54321 的各位是 5、4、3、2、1，和为 15。再求 15 除以 13 的余数：15＝13×1＋2，因此 mod(15,13)＝2。题目说‘与哈希值对应的位置’，所以放在下标 2。ア、ウ、エ都不是实际余数。不要把 54321 整个数拿去除以 13，也不要把五位按乘法处理；应严格按函数中写出的逐位求和执行。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 8,
    "periodJa": "秋期"
  },
  {
    "number": 11,
    "stemJa": "自然数nに対して，次のとおり再帰的に定義される関数f(n)を考える。f(5)の値はどれか。\n\n　f(n)：if n≦1 then return 1 else return n＋f(n－1)",
    "options": [
      {
        "label": "ア",
        "textJa": "6"
      },
      {
        "label": "イ",
        "textJa": "9"
      },
      {
        "label": "ウ",
        "textJa": "15"
      },
      {
        "label": "エ",
        "textJa": "25"
      }
    ],
    "answer": "ウ",
    "id": "FE-2019-F-AM-11",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "递归函数展开",
    "explanationZh": "正确答案ウ。递归就是函数在定义中再次调用自身。先找到终止条件：n≤1时f(n)＝1；再向上计算f(2)＝2＋1＝3，f(3)＝3＋3＝6，f(4)＝4＋6＝10，f(5)＝5＋10＝15。ア的6停在f(3)，イ的9不是该递推结果，エ的25把递归误当成5×5。遇到递归先写基例再逐层返回。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 8,
    "transcriptionNoteZh": "原卷中的分数、函数或指数排版改为等值纯文本，数值及题意未改变。"
  },
  {
    "number": 12,
    "stemJa": "1GHzのクロックで動作するCPUがある。このCPUは，機械語の1命令を平均0.8クロックで実行できることが分かっている。このCPUは1秒間に平均何万命令を実行できるか。",
    "options": [
      {
        "label": "ア",
        "textJa": "125"
      },
      {
        "label": "イ",
        "textJa": "250"
      },
      {
        "label": "ウ",
        "textJa": "80,000"
      },
      {
        "label": "エ",
        "textJa": "125,000"
      }
    ],
    "answer": "エ",
    "id": "FE-2019-F-AM-12",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "CPU时钟与指令吞吐量",
    "explanationZh": "正确答案エ。1GHz表示每秒10亿个时钟周期；题目说平均每条指令只耗0.8周期，所以每秒指令数＝10亿÷0.8＝12.5亿。题目单位是“万指令”，再除以1万得到125,000万指令。ア、イ数量级过小；ウ相当于错误地用0.8去乘时钟数。关键是先统一秒、周期、指令及“万”的单位。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2019-F-AM-13",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 13,
    "topicZh": "多重中断的 CPU 占用",
    "stemJa": "メイン処理，及び表に示す二つの割込み A，B の処理があり，多重割込みが許可されている。割込み A，B が図のタイミングで発生するとき，0ミリ秒から5ミリ秒までの間にメイン処理が利用できる CPU 時間は何ミリ秒か。ここで，割込み処理の呼出し及び復帰に伴うオーバヘッドは無視できるものとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "2"
      },
      {
        "label": "イ",
        "textJa": "2.5"
      },
      {
        "label": "ウ",
        "textJa": "3.5"
      },
      {
        "label": "エ",
        "textJa": "5"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア，2 毫秒。原表给出每次 A 中断处理 0.5 毫秒、B 中断处理 1.5 毫秒；0～5 毫秒内，A 在第 1、2.5、3.5 毫秒发生三次，B 在第 0 毫秒发生一次，第 5 毫秒才发生的 B 不计入此前区间。中断总占用为 3×0.5＋1×1.5＝3 毫秒，主处理能使用 5－3＝2 毫秒。多重中断允许高优先级 A 暂停 B，但不改变这些处理时间的合计；イ和ウ漏算了中断，エ把中断时间全忽略。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 9,
    "imageAssets": [
      "question-images/fe-2019-f-am-13.jpg"
    ],
    "transcriptionNoteZh": "图形、表格或公式以核对过的 IPA 官方原卷裁图为准。"
  },
  {
    "id": "FE-2019-F-AM-14",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 14,
    "topicZh": "菊链式连接",
    "stemJa": "次に示す接続のうち，デイジーチェーンと呼ばれる接続方法はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "PCと計測機器とをRS-232Cで接続し，PCとプリンタとをUSBを用いて接続する。"
      },
      {
        "label": "イ",
        "textJa": "Thunderbolt接続ポートが2口ある4Kディスプレイ2台を，PCのThunderbolt接続ポートから1台目のディスプレイにケーブルで接続し，さらに，1台目のディスプレイと2台目のディスプレイとの間をケーブルで接続する。"
      },
      {
        "label": "ウ",
        "textJa": "キーボード，マウス及びプリンタをUSBハブにつなぎ，USBハブとPCとを接続する。"
      },
      {
        "label": "エ",
        "textJa": "数台のネットワークカメラ及びPCをネットワークハブに接続する。"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。菊链式连接是设备一个接一个串接：PC 先连第一台显示器，第一台再连第二台，正好形成链。ア是 PC 分别通过不同接口直接连两个设备，不是一条链；ウ通过 USB 集线器汇聚成星形；エ通过网络集线器连接多台设备，也属于集中连接。关键不是使用 Thunderbolt 这种特定协议，而是拓扑中‘前一个设备再接下一个设备’的顺序结构。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 9
  },
  {
    "number": 15,
    "stemJa": "RAIDの分類において，ミラーリングを用いることで信頼性を高め，障害発生時には冗長ディスクを用いてデータ復元を行う方式はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "RAID1"
      },
      {
        "label": "イ",
        "textJa": "RAID2"
      },
      {
        "label": "ウ",
        "textJa": "RAID3"
      },
      {
        "label": "エ",
        "textJa": "RAID4"
      }
    ],
    "answer": "ア",
    "id": "FE-2019-F-AM-15",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "RAID 1镜像",
    "explanationZh": "正确答案ア。RAID1将相同数据写入镜像磁盘，一块盘故障时仍可从另一份副本读取，因此符合题目中的镜像和冗余恢复。イ的RAID2使用纠错码；ウ的RAID3采用专用校验盘；エ的RAID4按块分条并有专用校验盘。后三者的冗余机制不是题干所说的镜像。镜像不能代替备份，因为误删也会被同步。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 10
  },
  {
    "number": 16,
    "stemJa": "2台の処理装置から成るシステムがある。少なくともいずれか一方が正常に動作すればよいときの稼働率と，2台とも正常に動作しなければならないときの稼働率の差は幾らか。ここで，処理装置の稼働率はいずれも0.9とし，処理装置以外の要因は考慮しないものとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "0.09"
      },
      {
        "label": "イ",
        "textJa": "0.10"
      },
      {
        "label": "ウ",
        "textJa": "0.18"
      },
      {
        "label": "エ",
        "textJa": "0.19"
      }
    ],
    "answer": "ウ",
    "id": "FE-2019-F-AM-16",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "并联系统与串联系统可用率",
    "explanationZh": "正确答案ウ。两台各自可用率0.9，先假设装置故障相互独立。至少一台工作时，只在两台都坏时失败，故可用率1－0.1×0.1＝0.99；两台都要工作时可用率0.9×0.9＝0.81。两者相差0.18。ア、イ把故障率或单机可用率直接当差值；エ把0.99误减成0.80。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 10
  },
  {
    "id": "FE-2019-F-AM-17",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 17,
    "topicZh": "生产消费速率与缓冲区容量",
    "stemJa": "図の送信タスクから受信タスクにT秒間連続してデータを送信する。1秒当たりの送信量をS，1秒当たりの受信量をRとしたとき，バッファがオーバフローしないバッファサイズLを表す関係式として適切なものはどれか。ここで，受信タスクよりも送信タスクの方が転送速度は速く，次の転送開始までの時間間隔は十分にあるものとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "L＜(R－S)×T"
      },
      {
        "label": "イ",
        "textJa": "L＜(S－R)×T"
      },
      {
        "label": "ウ",
        "textJa": "L≧(R－S)×T"
      },
      {
        "label": "エ",
        "textJa": "L≧(S－R)×T"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。发送速度 S 大于接收速度 R，所以每秒积压 S－R 的数据，持续 T 秒后积压最多 (S－R)T。缓冲区容量 L 至少要容纳这个最大积压量，即 L≧(S－R)T；等号时恰好装满而不溢出。ア和ウ把差写成 R－S，在题给 S＞R 时得到负数，没有物理意义；イ虽用对了速度差，却要求容量小于积压量，会发生溢出。两次传输间隔足够长，表示上一轮积压能先被清空，不必累加多轮。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 10,
    "imageAssets": [
      "question-images/fe-2019-f-am-17.jpg"
    ],
    "transcriptionNoteZh": "图形、表格或公式以核对过的 IPA 官方原卷裁图为准。"
  },
  {
    "number": 18,
    "stemJa": "優先度に基づくプリエンプティブなスケジューリングを行うリアルタイムOSで，二つのタスクA，Bをスケジューリングする。Aの方がBより優先度が高い場合にリアルタイムOSが行う動作のうち，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "Aの実行中にBに起動がかかると，Aを実行可能状態にしてBを実行する。"
      },
      {
        "label": "イ",
        "textJa": "Aの実行中にBに起動がかかると，Aを待ち状態にしてBを実行する。"
      },
      {
        "label": "ウ",
        "textJa": "Bの実行中にAに起動がかかると，Bを実行可能状態にしてAを実行する。"
      },
      {
        "label": "エ",
        "textJa": "Bの実行中にAに起動がかかると，Bを待ち状態にしてAを実行する。"
      }
    ],
    "answer": "ウ",
    "id": "FE-2019-F-AM-18",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "实时操作系统抢占调度",
    "explanationZh": "正确答案ウ。抢占式调度允许新就绪的高优先级任务A打断正在运行的低优先级任务B。B只是暂时停止运行，仍能运行，所以回到“可运行状态”，然后CPU执行A。ア、イ让低优先级B抢占A，颠倒了优先级；エ把并未等待外部事件的B写成“等待状态”。要分清可运行与因I/O等原因而等待。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 11
  },
  {
    "number": 19,
    "stemJa": "バックアップ方式の説明のうち，増分バックアップはどれか。ここで，最初のバックアップでは，全てのファイルのバックアップを取得し，OSが管理しているファイル更新を示す情報はリセットされるものとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "最初のバックアップの後，ファイル更新を示す情報があるファイルだけをバックアップし，ファイル更新を示す情報は変更しないでそのまま残しておく。"
      },
      {
        "label": "イ",
        "textJa": "最初のバックアップの後，ファイル更新を示す情報にかかわらず，全てのファイルをバックアップし，ファイル更新を示す情報はリセットする。"
      },
      {
        "label": "ウ",
        "textJa": "直前に行ったバックアップの後，ファイル更新を示す情報があるファイルだけをバックアップし，ファイル更新を示す情報はリセットする。"
      },
      {
        "label": "エ",
        "textJa": "直前に行ったバックアップの後，ファイル更新を示す情報にかかわらず，全てのファイルをバックアップし，ファイル更新を示す情報は変更しないでそのまま残しておく。"
      }
    ],
    "answer": "ウ",
    "id": "FE-2019-F-AM-19",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "增量备份",
    "explanationZh": "正确答案ウ。先做一次全量备份；此后每次增量备份只保存自上一次备份后发生变化的文件，并清除更新标记，使下次能只找新的变化。ア保存变化文件却不清标记，更接近相对初次全量备份的差异备份；イ、エ都备份全部文件，不是增量。恢复时通常需要全量备份加上其后各次增量备份。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 11
  },
  {
    "number": 20,
    "stemJa": "DRAMの特徴はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "書込み及び消去を一括又はブロック単位で行う。"
      },
      {
        "label": "イ",
        "textJa": "データを保持するためのリフレッシュ操作又はアクセス操作が不要である。"
      },
      {
        "label": "ウ",
        "textJa": "電源が遮断された状態でも，記憶した情報を保持することができる。"
      },
      {
        "label": "エ",
        "textJa": "メモリセル構造が単純なので高集積化することができ，ビット単価を安くできる。"
      }
    ],
    "answer": "エ",
    "id": "FE-2019-F-AM-20",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "DRAM动态内存",
    "explanationZh": "正确答案エ。DRAM单元通常靠电容保存电荷，结构简单、集成密度高、每位成本较低，所以常用作主存。电荷会泄漏，必须周期性刷新，而且断电后数据丢失。ア描述按块擦写的闪存；イ声称无需刷新，与DRAM特性相反；ウ描述非易失性存储，不是DRAM。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 12
  },
  {
    "id": "FE-2019-F-AM-21",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 21,
    "topicZh": "移位寄存器与上升沿采样",
    "stemJa": "クロックの立上りエッジで，8ビットのシリアル入力パラレル出力シフトレジスタの内容を上位方向へシフトすると同時に正論理のデータをレジスタの最下位ビットに取り込む。また，ストローブの立上りエッジで値を確定する。各信号の波形を観測した結果が図のとおりであるとき，確定後のシフトレジスタの値はどれか。ここで，数値は16進数で表記している。",
    "options": [
      {
        "label": "ア",
        "textJa": "63"
      },
      {
        "label": "イ",
        "textJa": "8D"
      },
      {
        "label": "ウ",
        "textJa": "B1"
      },
      {
        "label": "エ",
        "textJa": "C6"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ，即 8D。读时序图必须只在时钟上升沿采样数据线，不能按高电平持续时间或下降沿计数。每次采样后，旧寄存器内容向高位移动一格，当前读到的 0 或 1 进入最低位。到选通信号的上升沿时，保留此前最近八次采样，按先入高位、后入低位排列得到二进制 10001101；分成四位为 1000 和 1101，对应十六进制 8D。ア、ウ、エ各自对应错误的采样边沿、位序或采样窗口。原卷波形截图应与文字步骤一起核对。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 12,
    "imageAssets": [
      "question-images/fe-2019-f-am-21.jpg"
    ],
    "transcriptionNoteZh": "图形、表格或公式以核对过的 IPA 官方原卷裁图为准。"
  },
  {
    "id": "FE-2019-F-AM-22",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 22,
    "topicZh": "逻辑门与异或真值表",
    "stemJa": "次の回路の入力と出力の関係として，正しいものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "A,Bが00,01,10,11のときXは0,0,0,1"
      },
      {
        "label": "イ",
        "textJa": "A,Bが00,01,10,11のときXは0,1,1,0"
      },
      {
        "label": "ウ",
        "textJa": "A,Bが00,01,10,11のときXは1,0,0,0"
      },
      {
        "label": "エ",
        "textJa": "A,Bが00,01,10,11のときXは1,1,1,0"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。上方支路先取反 A，再与 B 做 AND，得到 ¬A∧B；下方支路把 A 与取反后的 B 做 AND，得到 A∧¬B。最后 OR 合并，X＝(¬A∧B)∨(A∧¬B)，这正是异或：A、B 不同才输出 1。逐项代入 00、01、10、11，输出顺序为 0、1、1、0。ア是 AND 的真值模式；ウ仅在两个输入都为 0 时为 1；エ则是 NAND 模式。图中门的形状与小圆圈表示取反，必须逐级读。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 13,
    "imageAssets": [
      "question-images/fe-2019-f-am-22.jpg"
    ],
    "transcriptionNoteZh": "图形、表格或公式以核对过的 IPA 官方原卷裁图为准。"
  },
  {
    "number": 23,
    "stemJa": "コードから商品の内容が容易に分かるようにしたいとき，どのコード体系を選択するのが適切か。",
    "options": [
      {
        "label": "ア",
        "textJa": "区分コード"
      },
      {
        "label": "イ",
        "textJa": "桁別コード"
      },
      {
        "label": "ウ",
        "textJa": "表意コード"
      },
      {
        "label": "エ",
        "textJa": "連番コード"
      }
    ],
    "answer": "ウ",
    "id": "FE-2019-F-AM-23",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "编码体系的含义",
    "explanationZh": "正确答案ウ。表意代码让编码本身携带对象的含义，看到代码就较容易推知商品类别或内容，因此符合题干的可读性要求。ア区分代码强调区分类别；イ桁别代码按各位赋予分类含义，但这里官方要求的总体类别是表意代码；エ连番代码只表顺序，不能直接表达商品内容。别把编号唯一性当成语义性。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 13
  },
  {
    "id": "FE-2019-F-AM-24",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 24,
    "topicZh": "H.264 视频编码",
    "stemJa": "H.264/MPEG-4 AVCの説明として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "5.1チャンネルサラウンドシステムで使用されている音声圧縮技術"
      },
      {
        "label": "イ",
        "textJa": "携帯電話で使用されている音声圧縮技術"
      },
      {
        "label": "ウ",
        "textJa": "ディジタルカメラで使用されている静止画圧縮技術"
      },
      {
        "label": "エ",
        "textJa": "ワンセグ放送で使用されている動画圧縮技術"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。H.264/MPEG-4 AVC 是视频压缩编码，用于压缩连续画面，原题举出的单段广播视频属于该用途。ア与イ都描述音频压缩，处理对象不是视频帧；ウ描述数码相机的静态图片压缩，也不是 H.264 的主要对象。记忆时把术语 AVC 与视频联系起来，再用‘音频、静态图、视频’三个媒体类型排除干扰项。题目是 2019 年原题，应用场景按当年原卷表述。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 14
  },
  {
    "id": "FE-2019-F-AM-25",
    "kind": "official",
    "year": 2019,
    "section": "AM",
    "number": 25,
    "topicZh": "UML 多重度与概念数据模型",
    "stemJa": "UMLを用いて表した図の概念データモデルの解釈として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "従業員の総数と部署の総数は一致する。"
      },
      {
        "label": "イ",
        "textJa": "従業員は，同時に複数の部署に所属してもよい。"
      },
      {
        "label": "ウ",
        "textJa": "所属する従業員がいない部署の存在は許されない。"
      },
      {
        "label": "エ",
        "textJa": "どの部署にも所属しない従業員が存在してもよい。"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。UML 关联线一端的多重度表示：对另一端的一个对象，本端可关联多少对象。图中靠‘部署’端标 1..*，表示一个従業員至少属于一个部门，也允许同时属于多个部门，所以イ正确。靠‘従業員’端标 0..*，表示一个部门可以有零个或多个员工，因此ウ说不能有空部门是错的。由于员工必须至少属于一个部门，エ错误；这些范围不要求员工总数等于部门总数，ア也错误。特别注意不要把两端的数字读反。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 14,
    "periodJa": "秋期",
    "imageAssets": [
      "question-images/fe-2019-f-am-25.jpg"
    ],
    "transcriptionNoteZh": "本题与 2022 官方科目 A 样题复用同一题干；图形以 2019 秋期原卷裁图为准。"
  },
  {
    "id": "FE-2019-F-AM-26",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 26,
    "topicZh": "SQL 分组与 HAVING 过滤",
    "stemJa": "“得点”表から，学生ごとに全科目の点数の平均を算出し，平均が80点以上の学生の学生番号とその平均点を求める。aに入れる適切な字句はどれか。ここで，実線の下線は主キーを表す。得点（学生番号，科目，点数）。SQL文：SELECT 学生番号，AVG(点数) FROM 得点 GROUP BY a",
    "options": [
      {
        "label": "ア",
        "textJa": "科目 HAVING AVG(点数) >= 80"
      },
      {
        "label": "イ",
        "textJa": "科目 WHERE 点数 >= 80"
      },
      {
        "label": "ウ",
        "textJa": "学生番号 HAVING AVG(点数) >= 80"
      },
      {
        "label": "エ",
        "textJa": "学生番号 WHERE 点数 >= 80"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。要求‘每个学生’的平均分，所以 GROUP BY 必须按学生番号分组。平均值 AVG(点数) 是每组聚合后才计算出来的结果，筛选平均分至少 80 需用 HAVING，而不能先用 WHERE 挑出单科高分记录。ア、イ按科目分组，得到的是每门课而非每名学生的平均；エ虽按学生分组，却在分组前排除低于 80 的成绩，平均会被抬高。把分组对象与筛选时点分开考虑，就能唯一得到学生番号 HAVING AVG(点数)>=80。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 15,
    "imageAssets": [
      "question-images/fe-2019-f-am-26.jpg"
    ],
    "transcriptionNoteZh": "图形、表格或公式以核对过的 IPA 官方原卷裁图为准。"
  },
  {
    "number": 27,
    "stemJa": "関係モデルにおいて，関係から特定の属性だけを取り出す演算はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "結合(join)"
      },
      {
        "label": "イ",
        "textJa": "射影(projection)"
      },
      {
        "label": "ウ",
        "textJa": "選択(selection)"
      },
      {
        "label": "エ",
        "textJa": "和(union)"
      }
    ],
    "answer": "イ",
    "id": "FE-2019-F-AM-27",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "关系代数中的投影",
    "explanationZh": "正确答案イ。关系模型可把表理解成由行和列组成：只取若干属性，也就是保留指定的列，叫投影。ア连接把两个关系按条件组合；ウ选择按条件筛行；エ并集把同结构关系中的行合在一起。记忆时用“投影取列、选择取行”，先看题目要删的是列还是行。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 16
  },
  {
    "id": "FE-2019-F-AM-28",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 28,
    "topicZh": "事务状态与提交中止",
    "stemJa": "一つのトランザクションはトランザクションを開始した後，五つの状態（アクティブ，アボート処理中，アボート済，コミット処理中，コミット済）を取り得るものとする。このとき，取ることのない状態遷移はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "アボート処理中 → アボート済"
      },
      {
        "label": "イ",
        "textJa": "アボート処理中 → コミット処理中"
      },
      {
        "label": "ウ",
        "textJa": "コミット処理中 → アボート処理中"
      },
      {
        "label": "エ",
        "textJa": "コミット処理中 → コミット済"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。事务进入‘中止处理中’说明正在撤销此前的操作，完成后应成为‘已中止’，不会在尚未完成回滚时转入‘提交处理中’。ア正是正常的回滚完成路径；提交处理中若出现不能完成提交的故障，可能需要转入中止处理，因此ウ可发生；提交正常完成则从提交处理中到已提交，エ可发生。题问的是绝不会采用的状态迁移，关键是区分回滚与提交这两个互斥的终结方向。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 16,
    "imageAssets": [
      "question-images/fe-2019-f-am-28.jpg"
    ],
    "transcriptionNoteZh": "图形、表格或公式以核对过的 IPA 官方原卷裁图为准。"
  },
  {
    "id": "FE-2019-F-AM-29",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 29,
    "topicZh": "两阶段锁与死锁",
    "stemJa": "2相ロッキングプロトコルに従ってロックを獲得するトランザクションA，Bを図のように同時実行した場合に，デッドロックが発生しないデータ処理順序はどれか。ここで，readとupdateの位置は，アプリケーションプログラムでの命令発行時点を表す。また，データWへのreadは共有ロックを要求し，データX，Y，Zへのupdateは各データへの専有ロックを要求する。",
    "options": [
      {
        "label": "ア",
        "textJa": "read W → update Y → update X → update Z"
      },
      {
        "label": "イ",
        "textJa": "read W → update Y → update Z → update X"
      },
      {
        "label": "ウ",
        "textJa": "update X → read W → update Y → update Z"
      },
      {
        "label": "エ",
        "textJa": "update Y → update Z → update X → read W"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。事务 A 的锁顺序是先共享读 W，再独占更新 X、Y、Z；ウ的 B 也先争用 X，再依次 Y、Z，且 W 只是可共享的读锁。谁先取得 X，谁便能按同一顺序继续执行；另一事务只能等 X，无法形成‘甲等乙持有的 Y、乙又等甲持有的 X’的环。ア、イ、エ均让 B 先独占 Y 再请求 X，若 A 已占 X 而等待 Y，就产生循环等待。两阶段锁本身不保证无死锁，统一资源获取次序才是这里的关键。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 17,
    "imageAssets": [
      "question-images/fe-2019-f-am-29.jpg"
    ],
    "transcriptionNoteZh": "图形、表格或公式以核对过的 IPA 官方原卷裁图为准。"
  },
  {
    "number": 30,
    "stemJa": "10Mビット／秒の回線で接続された端末間で，平均1Mバイトのファイルを，10秒ごとに転送するときの回線利用率は何%か。ここで，ファイル転送時には，転送量の20%が制御情報として付加されるものとし，1Mビット＝10^(6)ビットとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "1.2"
      },
      {
        "label": "イ",
        "textJa": "6.4"
      },
      {
        "label": "ウ",
        "textJa": "8.0"
      },
      {
        "label": "エ",
        "textJa": "9.6"
      }
    ],
    "answer": "エ",
    "id": "FE-2019-F-AM-30",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "链路利用率与单位换算",
    "explanationZh": "正确答案エ。平均1M字节＝8M比特，再加20%控制信息，单次实际传输9.6M比特；每10秒一次，平均速率为0.96M比特/秒。链路容量10M比特/秒，因此利用率0.96÷10×100%＝9.6%。ア漏乘8，イ或ウ漏计控制开销或把单位换错。题中M按10的6次方计算。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 17,
    "transcriptionNoteZh": "原卷中的分数、函数或指数排版改为等值纯文本，数值及题意未改变。"
  },
  {
    "id": "FE-2019-F-AM-31",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 31,
    "topicZh": "CSMA/CD 以太网介质访问",
    "stemJa": "CSMA/CD方式のLANに接続されたノードの送信動作として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "各ノードに論理的な順位付けを行い，送信権を順次受け渡し，これを受け取ったノードだけが送信を行う。"
      },
      {
        "label": "イ",
        "textJa": "各ノードは伝送媒体が使用中かどうかを調べ，使用中でなければ送信を行う。衝突を検出したらランダムな時間の経過後に再度送信を行う。"
      },
      {
        "label": "ウ",
        "textJa": "各ノードを環状に接続して，送信権を制御するための特殊なフレームを巡回させ，これを受け取ったノードだけが送信を行う。"
      },
      {
        "label": "エ",
        "textJa": "タイムスロットを割り当てられたノードだけが送信を行う。"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。CSMA/CD 的要点依次是侦听共享传输介质、空闲时发送、发送中检测冲突、发生冲突后等待随机退避时间再重试。イ完整包含这些步骤。ア和ウ都依赖发送权或令牌的传递，不是竞争式的 CSMA/CD；其中ウ还规定环形连接。エ用预分配的时间槽来决定谁能发送，也没有载波侦听和冲突检测。记住 CD 表示 collision detection，即检测碰撞。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 18
  },
  {
    "number": 32,
    "stemJa": "メディアコンバータ，リピータハブ，レイヤー2スイッチ，レイヤー3スイッチのうち，レイヤー3スイッチだけがもつ機能はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "データリンク層において，宛先アドレスに従って適切なLANポートにパケットを中継する機能"
      },
      {
        "label": "イ",
        "textJa": "ネットワーク層において，宛先アドレスに従って適切なLANポートにパケットを中継する機能"
      },
      {
        "label": "ウ",
        "textJa": "物理層において，異なる伝送媒体を接続し，信号を相互に変換する機能"
      },
      {
        "label": "エ",
        "textJa": "物理層において，入力信号を全てのLANポートに対して中継する機能"
      }
    ],
    "answer": "イ",
    "id": "FE-2019-F-AM-32",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "二层与三层交换",
    "explanationZh": "正确答案イ。三层交换机能依据网络层目的地址（通常是IP地址）决定转发路径，这是四种设备中只有三层交换机具备的功能。ア按数据链路层地址转发，二层交换机也能做；ウ转换不同物理介质，是媒体转换器；エ把信号发往所有端口，是中继集线器的物理层动作。先辨识OSI层，再判断设备。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 18
  },
  {
    "id": "FE-2019-F-AM-33",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 33,
    "topicZh": "NAPT 多设备共享公网地址",
    "stemJa": "LANに接続されている複数のPCをインターネットに接続するシステムがあり，装置AのWAN側インタフェースには1個のグローバルIPアドレスが割り当てられている。この1個のグローバルIPアドレスを使って複数のPCがインターネットを利用するのに必要な装置Aの機能はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "DHCP"
      },
      {
        "label": "イ",
        "textJa": "NAPT（IPマスカレード）"
      },
      {
        "label": "ウ",
        "textJa": "PPPoE"
      },
      {
        "label": "エ",
        "textJa": "パケットフィルタリング"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。NAPT 同时改写网络地址和端口号，使不同内网 PC 的连接能共用装置 A 的一个公网 IP；返回包可依据端口映射送回正确的 PC。ア DHCP 负责在局域网中分配地址，不负责让多个连接共用公网地址；ウ PPPoE 是通过以太网建立 PPP 接入会话的方式；エ包过滤根据规则放行或阻断流量，不完成地址与端口转换。题干特意给出‘多个 PC、一个全球 IP’，这正是 NAPT 的典型场景。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 19,
    "imageAssets": [
      "question-images/fe-2019-f-am-33.jpg"
    ],
    "transcriptionNoteZh": "图形、表格或公式以核对过的 IPA 官方原卷裁图为准。"
  },
  {
    "number": 34,
    "stemJa": "クライアントAがポート番号8080のHTTPプロキシサーバBを経由してポート番号80のWebサーバCにアクセスしているとき，宛先ポート番号が常に8080になるTCPパケットはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "AからBへのHTTP要求及びCからBへのHTTP応答"
      },
      {
        "label": "イ",
        "textJa": "AからBへのHTTP要求だけ"
      },
      {
        "label": "ウ",
        "textJa": "BからAへのHTTP応答だけ"
      },
      {
        "label": "エ",
        "textJa": "BからCへのHTTP要求及びCからBへのHTTP応答"
      }
    ],
    "answer": "イ",
    "id": "FE-2019-F-AM-34",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "TCP目的端口与代理",
    "explanationZh": "正确答案イ。A要向代理B的监听端口8080发起HTTP请求，因此A→B的请求报文目的端口是8080。B→A的响应目的端口是A临时分配的端口；B→C的请求目的端口是80；C→B的响应目的端口是B连接C时使用的临时端口。ア把C→B误算进去，ウ、エ的方向或端口均不对。目的端口始终指接收方的服务或会话端口。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 19
  },
  {
    "number": 35,
    "stemJa": "攻撃者が用意したサーバXのIPアドレスが，A社WebサーバのFQDNに対応するIPアドレスとして，B社DNSキャッシュサーバに記憶された。これによって，意図せずサーバXに誘導されてしまう利用者はどれか。ここで，A社，B社の各従業員は自社のDNSキャッシュサーバを利用して名前解決を行う。",
    "options": [
      {
        "label": "ア",
        "textJa": "A社WebサーバにアクセスしようとするA社従業員"
      },
      {
        "label": "イ",
        "textJa": "A社WebサーバにアクセスしようとするB社従業員"
      },
      {
        "label": "ウ",
        "textJa": "B社WebサーバにアクセスしようとするA社従業員"
      },
      {
        "label": "エ",
        "textJa": "B社WebサーバにアクセスしようとするB社従業員"
      }
    ],
    "answer": "イ",
    "id": "FE-2019-F-AM-35",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "DNS缓存投毒",
    "explanationZh": "正确答案イ。被污染的是B公司的DNS缓存，且错误记录对应A公司Web服务器的域名。B公司员工查A公司的域名时会从自家缓存拿到攻击者X的IP，于是被引向X。ア由A公司自己的缓存解析，不受这条B缓存记录影响；ウ与エ访问B公司Web域名，域名不匹配。做这类题先同时核对“谁用被污染的DNS”和“查的是哪个域名”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 20
  },
  {
    "number": 36,
    "stemJa": "マルウェアの動的解析に該当するものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "検体のハッシュ値を計算し，オンラインデータベースに登録された既知のマルウェアのハッシュ値のリストと照合してマルウェアを特定する。"
      },
      {
        "label": "イ",
        "textJa": "検体をサンドボックス上で実行し，その動作や外部との通信を観測する。"
      },
      {
        "label": "ウ",
        "textJa": "検体をネットワーク上の通信データから抽出し，さらに，逆コンパイルして取得したコードから検体の機能を調べる。"
      },
      {
        "label": "エ",
        "textJa": "ハードディスク内のファイルの拡張子とファイルヘッダーの内容を基に，拡張子が偽装された不正なプログラムファイルを検出する。"
      }
    ],
    "answer": "イ",
    "id": "FE-2019-F-AM-36",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "恶意软件动态分析",
    "explanationZh": "正确答案イ。动态分析必须让样本在受控环境里运行，并观察真实行为；沙盒执行后看进程动作及对外通信正好符合。ア比对文件哈希不运行样本；ウ逆编译取得代码属于静态分析；エ按扩展名和文件头识别也没有执行样本。沙盒隔离是为了限制样本带来的风险，不能把它当作绝对安全保证。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 20
  },
  {
    "number": 37,
    "stemJa": "WPA3はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "HTTP通信の暗号化規格"
      },
      {
        "label": "イ",
        "textJa": "TCP/IP通信の暗号化規格"
      },
      {
        "label": "ウ",
        "textJa": "Webサーバで使用するデジタル証明書の規格"
      },
      {
        "label": "エ",
        "textJa": "無線LANのセキュリティ規格"
      }
    ],
    "answer": "エ",
    "id": "FE-2019-F-AM-37",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "WPA3无线网络安全",
    "explanationZh": "正确答案エ。WPA3是Wi‑Fi无线局域网的安全规范，涉及无线接入认证与链路保护，故归在无线LAN安全。ア所指的HTTP通信保护通常用TLS并呈现为HTTPS；イ不是WPA3适用的整体TCP/IP加密规范；ウ属于Web服务器数字证书领域。先看名称中的WPA是无线网络保护体系。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 20
  },
  {
    "number": 38,
    "stemJa": "メッセージにRSA方式のデジタル署名を付与して2者間で送受信する。そのときのデジタル署名の検証鍵と使用方法はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "受信者の公開鍵であり，送信者がメッセージダイジェストからデジタル署名を作成する際に使用する。"
      },
      {
        "label": "イ",
        "textJa": "受信者の秘密鍵であり，受信者がデジタル署名からメッセージダイジェストを算出する際に使用する。"
      },
      {
        "label": "ウ",
        "textJa": "送信者の公開鍵であり，受信者がデジタル署名からメッセージダイジェストを算出する際に使用する。"
      },
      {
        "label": "エ",
        "textJa": "送信者の秘密鍵であり，送信者がメッセージダイジェストからデジタル署名を作成する際に使用する。"
      }
    ],
    "answer": "ウ",
    "id": "FE-2019-F-AM-38",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "RSA数字签名验证",
    "explanationZh": "正确答案ウ。发送者用自己的私钥对消息摘要形成签名，接收者用发送者的公钥验证签名并与收到消息重新计算的摘要核对。验证所用的键必须属于发送者，且是公开键。ア、イ把键误写成接收者的；エ虽然提到了发送者私钥，但那是签名生成用键，不是题目问的验证键。公私钥的角色随“签名”与“加密”而不同。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 21
  },
  {
    "number": 39,
    "stemJa": "情報セキュリティにおいてバックドアに該当するものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "アクセスする際にパスワード認証などの正規の手続が必要なWebサイトに，当該手続を経ないでアクセス可能なURL"
      },
      {
        "label": "イ",
        "textJa": "インターネットに公開されているサーバのTCPポートの中からアクティブになっているポートを探して，稼働中のサービスを特定するためのツール"
      },
      {
        "label": "ウ",
        "textJa": "ネットワーク上の通信パケットを取得して通信内容を見るために設けられたスイッチのLANポート"
      },
      {
        "label": "エ",
        "textJa": "プログラムが確保するメモリ領域に，領域の大きさを超える長さの文字列を入力してあふれさせ，ダウンさせる攻撃"
      }
    ],
    "answer": "ア",
    "id": "FE-2019-F-AM-39",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "后门与旁路访问",
    "explanationZh": "正确答案ア。正常访问该网站需要密码认证，而某URL绕过认证直接进入，属于隐藏或未经授权的旁路入口，即后门。イ是端口扫描工具；ウ是交换机镜像端口，供抓包查看通信；エ是缓冲区溢出攻击。后门的判断点是“绕过正规访问控制”，不只是存在一条普通链接。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 21
  },
  {
    "number": 40,
    "stemJa": "ファイルの提供者は，ファイルの作成者が作成したファイルAを受け取り，ファイルAと，ファイルAにSHA-256を適用して算出した値Bとを利用者に送信する。そのとき，利用者が情報セキュリティ上実現できることはどれか。ここで，利用者が受信した値Bはファイルの提供者から事前に電話で直接伝えられた値と同じであり，改ざんされていないことが確認できているものとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "値BにSHA-256を適用して値Bからデジタル署名を算出し，そのデジタル署名を検証することによって，ファイルAの作成者を確認できる。"
      },
      {
        "label": "イ",
        "textJa": "値BにSHA-256を適用して値Bからデジタル署名を算出し，そのデジタル署名を検証することによって，ファイルAの提供者がファイルAの作成者であるかどうかを確認できる。"
      },
      {
        "label": "ウ",
        "textJa": "ファイルAにSHA-256を適用して値を算出し，その値と値Bを比較することによって，ファイルAの内容が改ざんされていないかどうかを検証できる。"
      },
      {
        "label": "エ",
        "textJa": "ファイルAの内容が改ざんされていても，ファイルAにSHA-256を適用して値を算出し，その値と値Bの差分を確認することによって，ファイルAの内容のうち改ざんされている部分を修復できる。"
      }
    ],
    "answer": "ウ",
    "id": "FE-2019-F-AM-40",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "哈希校验与完整性",
    "explanationZh": "正确答案ウ。用户对收到的文件A重新算SHA‑256，再与通过电话确认未被改动的B比较；两者相同可用于检验传输中内容是否变化。哈希值本身不是数字签名，不能证明文件作者，所以ア、イ错误；哈希差异只能提示不一致，不能定位或修复被改的字节，エ错误。本题的结论依赖题设保证B可信。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 22
  },
  {
    "number": 41,
    "stemJa": "検索サイトの検索結果の上位に悪意のあるサイトが表示されるように細工する攻撃の名称はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "DNSキャッシュポイズニング"
      },
      {
        "label": "イ",
        "textJa": "SEOポイズニング"
      },
      {
        "label": "ウ",
        "textJa": "クロスサイトスクリプティング"
      },
      {
        "label": "エ",
        "textJa": "ソーシャルエンジニアリング"
      }
    ],
    "answer": "イ",
    "id": "FE-2019-F-AM-41",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "SEO投毒",
    "explanationZh": "正确答案イ。攻击者操纵搜索优化，让恶意页面排在搜索结果前面，叫SEO投毒。ア是把DNS缓存中的域名到IP映射污染，改变解析去向；ウ是在网页上下文注入脚本；エ是利用人的信任或疏忽获取信息的社会工程手法。题干关键词是“搜索结果排名靠前”，不是域名解析或页面脚本。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 22
  },
  {
    "number": 42,
    "stemJa": "1台のファイアウォールによって，外部セグメント，DMZ，内部セグメントの三つのセグメントに分割されたネットワークがあり，このネットワークにおいて，Webサーバと，重要なデータをもつデータベースサーバから成るシステムを使って，利用者向けのWebサービスをインターネットに公開する。インターネットからの不正アクセスから重要なデータを保護するためのサーバの設置方法のうち，最も適切なものはどれか。ここで，Webサーバでは，データベースサーバのフロントエンド処理を行い，ファイアウォールでは，外部セグメントとDMZとの間，及びDMZと内部セグメントとの間の通信は特定のプロトコルだけを許可し，外部セグメントと内部セグメントとの間の直接の通信は許可しないものとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "WebサーバとデータベースサーバをDMZに設置する。"
      },
      {
        "label": "イ",
        "textJa": "Webサーバとデータベースサーバを内部セグメントに設置する。"
      },
      {
        "label": "ウ",
        "textJa": "WebサーバをDMZに，データベースサーバを内部セグメントに設置する。"
      },
      {
        "label": "エ",
        "textJa": "Webサーバを外部セグメントに，データベースサーバをDMZに設置する。"
      }
    ],
    "answer": "ウ",
    "id": "FE-2019-F-AM-42",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "DMZ与数据库隔离",
    "explanationZh": "正确答案ウ。面向互联网的Web服务器放DMZ，重要数据库放内部网；防火墙只放行外部到DMZ、DMZ到内网所需协议，外部不能直达数据库。ア把数据库也暴露在DMZ；イ把公开Web服务放内网，不符合分区目标；エ把Web放外部、数据库放DMZ，重要数据保护更弱。DMZ是缓冲区，不等于存放所有服务器。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 23
  },
  {
    "number": 43,
    "stemJa": "SIEM(Security Information and Event Management)の機能はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "隔離された仮想環境でファイルを実行して，C&Cサーバへの通信などの振る舞いを監視する。"
      },
      {
        "label": "イ",
        "textJa": "様々な機器から集められたログを総合的に分析し，管理者による分析と対応を支援する。"
      },
      {
        "label": "ウ",
        "textJa": "ネットワーク上の様々な通信機器を集中的に制御し，ネットワーク構成やセキュリティ設定などを変更する。"
      },
      {
        "label": "エ",
        "textJa": "パケットのヘッダー情報の検査だけではなく，通信先のアプリケーションプログラムを識別して通信を制御する。"
      }
    ],
    "answer": "イ",
    "id": "FE-2019-F-AM-43",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "SIEM日志关联分析",
    "explanationZh": "正确答案イ。SIEM集中收集不同设备的日志和安全事件，做关联分析，帮助管理员发现异常并响应。ア是在隔离环境运行可疑样本的沙盒；ウ是集中改变网络设备配置的管理功能；エ是按应用识别流量并控制通信的防火墙类功能。判断SIEM要抓住“多来源日志、分析事件”，它本身并非所有安全控制的执行者。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 23
  },
  {
    "number": 44,
    "stemJa": "電子メールをドメインAの送信者がドメインBの宛先に送信するとき，送信者をドメインAのメールサーバで認証するためのものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "APOP"
      },
      {
        "label": "イ",
        "textJa": "POP3S"
      },
      {
        "label": "ウ",
        "textJa": "S/MIME"
      },
      {
        "label": "エ",
        "textJa": "SMTP-AUTH"
      }
    ],
    "answer": "エ",
    "id": "FE-2019-F-AM-44",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "邮件发送认证",
    "explanationZh": "正确答案エ。SMTP‑AUTH用于客户端向发送域的邮件服务器提交邮件时验证发送者身份，因此对应A域发送者在A域服务器认证。アAPOP与イPOP3S都与邮件接收有关；ウS/MIME用于邮件内容的签名和加密，不能替代提交邮件时的SMTP身份验证。分清SMTP负责发送，POP负责取信。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 24
  },
  {
    "id": "FE-2019-F-AM-45",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 45,
    "topicZh": "数据流图 DFD 符号",
    "stemJa": "図は，構造化分析法で用いられるDFDの例である。図中の“○”が表しているものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "アクティビティ"
      },
      {
        "label": "イ",
        "textJa": "データストア"
      },
      {
        "label": "ウ",
        "textJa": "データフロー"
      },
      {
        "label": "エ",
        "textJa": "プロセス"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。DFD 即数据流图，用圆形表示对输入数据进行加工、转换并产生输出的处理过程，也称プロセス。原卷图中数据沿箭头进入圆形节点，处理后再向下一个存储或节点流动。イ的数据存储通常用两条平行线表示；ウ的数据流用带箭头的线表示；ア的活动是其他建模图中的概念，并非此 DFD 圆形记号的名称。读 DFD 时可依次认‘外部实体、数据流、处理、数据存储’四类符号。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 24,
    "imageAssets": [
      "question-images/fe-2019-f-am-45.jpg"
    ],
    "transcriptionNoteZh": "图形、表格或公式以核对过的 IPA 官方原卷裁图为准。"
  },
  {
    "number": 46,
    "stemJa": "モジュール結合度が最も弱くなるものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "一つのモジュールで，できるだけ多くの機能を実現する。"
      },
      {
        "label": "イ",
        "textJa": "二つのモジュール間で必要なデータ項目だけを引数として渡す。"
      },
      {
        "label": "ウ",
        "textJa": "他のモジュールとデータ項目を共有するためにグローバルな領域を使用する。"
      },
      {
        "label": "エ",
        "textJa": "他のモジュールを呼び出すときに，呼び出したモジュールの論理を制御するための引数を渡す。"
      }
    ],
    "answer": "イ",
    "id": "FE-2019-F-AM-46",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "模块耦合度",
    "explanationZh": "正确答案イ。模块之间只通过参数传递确实需要的数据，属于数据耦合，依赖范围小，四项中耦合最弱。ア在一个模块塞入过多功能，是模块内部职责混杂，不会降低模块间耦合；ウ共享全局数据会产生公共耦合；エ传控制标志让被调模块改变内部逻辑，属于更强的控制耦合。目标是接口少且职责清楚。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 24
  },
  {
    "id": "FE-2019-F-AM-47",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 47,
    "topicZh": "错误植入法与缺陷数量估计",
    "stemJa": "エラー埋込法において，埋め込まれたエラー数をS，埋め込まれたエラーのうち発見されたエラー数をm，埋め込まれたエラーを含まないテスト開始前の潜在エラー数をT，発見された総エラー数をnとしたとき，S，T，m，nの関係を表す式はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "m／S＝(n－m)／T"
      },
      {
        "label": "イ",
        "textJa": "m／S＝T／(n－m)"
      },
      {
        "label": "ウ",
        "textJa": "m／S＝n／T"
      },
      {
        "label": "エ",
        "textJa": "m／S＝T／n"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。错误植入法先人为加入已知数量 S 个缺陷，再看测试发现其中 m 个，因此植入缺陷的发现比例是 m／S。测试共发现 n 个缺陷，其中 m 个是植入的，原本存在而被发现的数量就是 n－m；若原有潜在缺陷总数为 T，其发现比例为 (n－m)／T。假定两类缺陷被发现的概率相近，便令两比例相等。イ把右侧比例倒置，ウ未剔除植入缺陷，エ既未剔除又倒置，均不能表示同一发现率。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 25,
    "imageAssets": [
      "question-images/fe-2019-f-am-47.jpg"
    ],
    "transcriptionNoteZh": "图形、表格或公式以核对过的 IPA 官方原卷裁图为准。"
  },
  {
    "number": 48,
    "stemJa": "テストで使用されるドライバ又はスタブの説明のうち，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "スタブは，テスト対象のモジュールからの戻り値の表示・印刷を行う。"
      },
      {
        "label": "イ",
        "textJa": "スタブは，テスト対象モジュールを呼び出すモジュールである。"
      },
      {
        "label": "ウ",
        "textJa": "ドライバは，テスト対象モジュールから呼び出されるモジュールである。"
      },
      {
        "label": "エ",
        "textJa": "ドライバは，引数を渡してテスト対象モジュールを呼び出す。"
      }
    ],
    "answer": "エ",
    "id": "FE-2019-F-AM-48",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "单元测试的驱动与桩",
    "explanationZh": "正确答案エ。驱动模块模拟测试对象的上层调用者，准备参数并调用被测模块；桩模块模拟被测模块所调用的下层模块。ア把显示返回值当成桩的定义；イ把上层调用者错称为桩；ウ把下层被调用模块错称为驱动。画一条“驱动→被测模块→桩”的调用链，通常就不会弄反。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 25
  },
  {
    "id": "FE-2019-F-AM-49",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 49,
    "topicZh": "语句覆盖与判定覆盖",
    "stemJa": "単一の入り口をもち，入力項目を用いた複数の判断を含むプログラムのテストケースを設計する。命令網羅と判定条件網羅の関係のうち，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "判定条件網羅を満足しても，命令網羅を満足しない場合がある。"
      },
      {
        "label": "イ",
        "textJa": "判定条件網羅を満足するならば，命令網羅も満足する。"
      },
      {
        "label": "ウ",
        "textJa": "命令網羅を満足しなくても，判定条件網羅を満足する場合がある。"
      },
      {
        "label": "エ",
        "textJa": "命令網羅を満足するならば，判定条件網羅も満足する。"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。命令网罗要求各可执行语句至少执行一次；判定条件网罗要求各判断的分支结果都经历。对于题目所说的单入口程序，一旦每个判断的各分支都走过，对应可达分支中的语句也会执行，因此满足判定条件网罗就满足命令网罗。ア、ウ都声称可满足判定条件网罗却不满足命令网罗，与这一包含关系矛盾。エ反向推论不成立：即使所有语句都执行过，仍可能从未让某个判断取另一结果，例如空分支或经不同路径重复执行的情形。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 25,
    "imageAssets": [
      "question-images/fe-2019-f-am-49.jpg"
    ],
    "transcriptionNoteZh": "图形、表格或公式以核对过的 IPA 官方原卷裁图为准。"
  },
  {
    "number": 50,
    "stemJa": "XP(eXtreme Programming)において，プラクティスとして提唱されているものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "インスペクション"
      },
      {
        "label": "イ",
        "textJa": "構造化設計"
      },
      {
        "label": "ウ",
        "textJa": "ペアプログラミング"
      },
      {
        "label": "エ",
        "textJa": "ユースケースの活用"
      }
    ],
    "answer": "ウ",
    "id": "FE-2019-F-AM-50",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "XP结对编程",
    "explanationZh": "正确答案ウ。极限编程XP的典型实践之一是结对编程：两名开发者共同处理同一段代码，并持续交流和复查。ア检查评审不是此题所问的XP特有实践；イ结构化设计属于另一类设计方法；エ使用用例是需求分析常见方法，不能据此识别XP。看到XP应联想到短迭代、测试、重构和结对。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 26
  },
  {
    "number": 51,
    "stemJa": "二つのアクティビティが次の関係にあるとき，論理的な依存関係はどれか。\n\n\"システム要件定義プロセス\"が完了すれば，\"システム方式設計プロセス\"が開始できる。",
    "options": [
      {
        "label": "ア",
        "textJa": "FF関係(Finish-to-Finish)"
      },
      {
        "label": "イ",
        "textJa": "FS関係(Finish-to-Start)"
      },
      {
        "label": "ウ",
        "textJa": "SF関係(Start-to-Finish)"
      },
      {
        "label": "エ",
        "textJa": "SS関係(Start-to-Start)"
      }
    ],
    "answer": "イ",
    "id": "FE-2019-F-AM-51",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "项目活动的FS依赖",
    "explanationZh": "正确答案イ。题干说“系统需求定义完成后，系统方式设计才可以开始”，前一活动的完成Finish约束后一活动的开始Start，因此是FS关系。アFF是完成约束完成；ウSF是开始约束完成；エSS是开始约束开始。读两个英文缩写时，先写出前项和后项各发生的是开始还是结束，再连起来判断。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 26
  },
  {
    "id": "FE-2019-F-AM-52",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 52,
    "topicZh": "箭线图关键路径",
    "stemJa": "あるプロジェクトの日程計画をアローダイアグラムで示す。クリティカルパスはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "A，C，E，F"
      },
      {
        "label": "イ",
        "textJa": "A，D，G"
      },
      {
        "label": "ウ",
        "textJa": "B，E，F"
      },
      {
        "label": "エ",
        "textJa": "B，E，G"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ，即 B→E→F。沿图计算各候选路径：A→C→E→F 为 1＋3＋4＋5＝13 天；A→D→G 为 1＋3＋4＝8 天；B→E→F 为 5＋4＋5＝14 天；B→E→G 为 5＋4＋4＝13 天。虚活动没有工期，却说明 G 也要等待 E 后节点，因此不能漏掉依赖。所有路径中 B→E→F 总时长最长，决定项目最早结束的时间，也就是关键路径。ア、イ、エ对应较短路径，不能决定总工期。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 26,
    "imageAssets": [
      "question-images/fe-2019-f-am-52.jpg"
    ],
    "transcriptionNoteZh": "图形、表格或公式以核对过的 IPA 官方原卷裁图为准。"
  },
  {
    "number": 53,
    "stemJa": "ソフトウェア開発の見積方法の一つであるファンクションポイント法の説明として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "開発規模が分かっていることを前提として，工数と工期を見積もる方法である。ビジネス分野に限らず，全分野に適用可能である。"
      },
      {
        "label": "イ",
        "textJa": "過去に経験した類似のソフトウェアについてのデータを基にして，ソフトウェアの相違点を調べ，同じ部分については過去のデータを使い，異なった部分は経験に基づいて，規模と工数を見積もる方法である。"
      },
      {
        "label": "ウ",
        "textJa": "ソフトウェアの機能を入出力データ数やファイル数などによって定量的に計測し，複雑さによる調整を行って，ソフトウェア規模を見積もる方法である。"
      },
      {
        "label": "エ",
        "textJa": "単位作業項目に適用する作業量の基準値を決めておき，作業項目を単位作業項目まで分解し，基準値を適用して算出した作業量の積算で全体の作業量を見積もる方法である。"
      }
    ],
    "answer": "ウ",
    "id": "FE-2019-F-AM-53",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "功能点估算",
    "explanationZh": "正确答案ウ。功能点法从用户可见功能出发，按输入、输出、查询、内部数据等数量衡量，再考虑复杂程度估算规模；不是先按代码行数算。ア以已知规模推工期；イ使用类似项目数据类推；エ把任务拆细后按单位工作量累加。后三者都不是按功能数量计分的功能点法。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 27
  },
  {
    "number": 54,
    "stemJa": "10人のメンバーで構成されているプロジェクトチームにメンバー2人を増員する。次の条件でメンバー同士が打合せを行う場合，打合せの回数は何回増えるか。\n\n〔条件〕打合せは1対1で行う。各メンバーが，他の全てのメンバーと1回ずつ打合せを行う。",
    "options": [
      {
        "label": "ア",
        "textJa": "12"
      },
      {
        "label": "イ",
        "textJa": "21"
      },
      {
        "label": "ウ",
        "textJa": "22"
      },
      {
        "label": "エ",
        "textJa": "42"
      }
    ],
    "answer": "イ",
    "id": "FE-2019-F-AM-54",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "两两会谈的组合计数",
    "explanationZh": "正确答案イ。n个人每两人谈一次，共有n(n－1)/2组。原来10人有10×9/2＝45次；增加到12人后有12×11/2＝66次，所以新增66－45＝21次。也可数两名新人分别与原10人会面得到20次，再加两名新人之间1次。ア漏算多数组合，ウ多算1次，エ把成对会谈重复计数。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 27
  },
  {
    "number": 55,
    "stemJa": "サービスマネジメントシステムにPDCA方法論を適用するとき，Actに該当するものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "サービスの設計，移行，提供及び改善のためにサービスマネジメントシステムを導入し，運用する。"
      },
      {
        "label": "イ",
        "textJa": "サービスマネジメントシステム及びサービスのパフォーマンスを継続的に改善するための処置を実施する。"
      },
      {
        "label": "ウ",
        "textJa": "サービスマネジメントシステムを確立し，文書化し，合意する。"
      },
      {
        "label": "エ",
        "textJa": "方針，目的，計画及びサービスの要求事項について，サービスマネジメントシステム及びサービスを監視，測定及びレビューし，それらの結果を報告する。"
      }
    ],
    "answer": "イ",
    "id": "FE-2019-F-AM-55",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "PDCA的Act阶段",
    "explanationZh": "正确答案イ。PDCA中Plan制定方案，Do执行，Check监视与评价，Act依据评价结果实施纠正和持续改进。イ明确说采取措施以持续改善服务绩效，属于Act。ア描述导入和运行，是Do；ウ确立、成文、达成共识属于Plan；エ监视、测量、评审并报告属于Check。不要把所有“改善”文字都脱离上下文机械记忆。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 28
  },
  {
    "id": "FE-2019-F-AM-56",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 56,
    "topicZh": "系统迁移与回退计划",
    "stemJa": "システムの移行計画に関する記述のうち，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "移行計画書には，移行作業が失敗した場合に旧システムに戻す際の判断基準が必要である。"
      },
      {
        "label": "イ",
        "textJa": "移行するデータ量が多いほど，切替え直前に一括してデータの移行作業を実施すべきである。"
      },
      {
        "label": "ウ",
        "textJa": "新旧両システムで環境の一部を共有することによって，移行の確認が容易になる。"
      },
      {
        "label": "エ",
        "textJa": "新旧両システムを並行運用することによって，移行に必要な費用が低減できる。"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。迁移可能因数据、性能或业务问题失败，因此计划书应事先规定何时判定失败、何时回到旧系统，以及谁作出决定。没有回退标准，事故现场容易迟疑并延长停机。イ把大量数据都压到切换前才搬迁，反而增加时间风险；ウ新旧系统共享部分环境可能使影响相互牵连，不保证更易确认；エ并行运行意味着同时维护两套系统，一般增加资源和费用，不能据此说降低迁移成本。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 28
  },
  {
    "number": 57,
    "stemJa": "事業継続計画で用いられる用語であり，インシデントの発生後，次のいずれかの事項までに要する時間を表すものはどれか。\n製品又はサービスが再開される。事業活動が再開される。資源が復旧される。",
    "options": [
      {
        "label": "ア",
        "textJa": "MTBF"
      },
      {
        "label": "イ",
        "textJa": "MTTR"
      },
      {
        "label": "ウ",
        "textJa": "RPO"
      },
      {
        "label": "エ",
        "textJa": "RTO"
      }
    ],
    "answer": "エ",
    "id": "FE-2019-F-AM-57",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "RTO恢复时间目标",
    "explanationZh": "正确答案エ。RTO表示发生中断后，业务、服务或资源应在多久内恢复，题干问的是“从事件发生到恢复”的时间。アMTBF是平均故障间隔；イMTTR是平均修复时间，属可靠性统计；ウRPO是可接受的数据回退时间点，用来衡量可能丢失多少时间范围的数据。RTO管恢复要多快，RPO管数据能回退多远。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 29
  },
  {
    "id": "FE-2019-F-AM-58",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 58,
    "topicZh": "系统测试审计检查点",
    "stemJa": "システムテストの監査におけるチェックポイントのうち，最も適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "テストケースが網羅的に想定されていること"
      },
      {
        "label": "イ",
        "textJa": "テスト計画は利用者側の責任者だけで承認されていること"
      },
      {
        "label": "ウ",
        "textJa": "テストは実際に業務が行われている環境で実施されていること"
      },
      {
        "label": "エ",
        "textJa": "テストは利用者側の担当者だけで行われていること"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。系统测试的审计要确认测试计划是否覆盖功能、异常、边界等需要验证的场景，避免未测试的需求直接进入运行，因此检查测试用例的完整性最合适。イ限定只由使用方负责人批准，忽略开发和运维等相关责任人；ウ要求直接在实际生产业务环境执行测试，可能影响真实业务，测试环境通常应独立且足够接近；エ限定只有使用方人员执行测试，也不合理。审计重点是测试过程和证据是否充分，而非只看由某一方参与。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 29
  },
  {
    "id": "FE-2019-F-AM-59",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 59,
    "topicZh": "系统审计人员独立性",
    "stemJa": "情報システム部が開発して経理部が運用している会計システムの運用状況を，経営者からの指示で監査することになった。この場合におけるシステム監査人についての記述のうち，最も適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "会計システムは企業会計に関する各種基準に準拠すべきなので，システム監査人を公認会計士とする。"
      },
      {
        "label": "イ",
        "textJa": "会計システムは機密性の高い情報を扱うので，システム監査人は経理部長直属とする。"
      },
      {
        "label": "ウ",
        "textJa": "システム監査を効率的に行うために，システム監査人は情報システム部長直属とする。"
      },
      {
        "label": "エ",
        "textJa": "独立性を担保するために，システム監査人は情報システム部にも経理部にも所属しない者とする。"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。审计对象是由信息系统部开发、经财务部运行的系统，审计人需要客观评价双方的控制与运行情况，不能隶属任何一个被审计部门。イ让审计人直属财务部长，ウ让其直属信息系统部长，都可能影响独立判断。ア公认会计师资格可能与会计知识相关，但不能单靠资格替代系统审计所需能力与组织独立性。本题要求最合适的组织安排，因此选置身两部门之外的エ。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 30
  },
  {
    "number": 60,
    "stemJa": "アクセス制御を監査するシステム監査人の行為のうち，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "ソフトウェアに関するアクセス制御の管理台帳を作成し，保管した。"
      },
      {
        "label": "イ",
        "textJa": "データに関するアクセス制御の管理規程を閲覧した。"
      },
      {
        "label": "ウ",
        "textJa": "ネットワークに関するアクセス制御の管理方針を制定した。"
      },
      {
        "label": "エ",
        "textJa": "ハードウェアに関するアクセス制御の運用手続を実施した。"
      }
    ],
    "answer": "イ",
    "id": "FE-2019-F-AM-60",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "审计中的独立性",
    "explanationZh": "正确答案イ。系统审计人应检查证据、评价控制是否妥当；阅览已有的数据访问控制管理规定正是取得审计证据。ア亲自建立和保存台账、ウ制定管理方针、エ实施操作程序，都是被审计组织的管理或执行职责，审计人这样做会损害独立评价的立场。区分“检查规则是否存在且被执行”与“替单位制定、执行规则”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 30
  },
  {
    "id": "FE-2019-F-AM-61",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 61,
    "topicZh": "IT 投资组合与资源分配",
    "stemJa": "情報化投資において，リスクや投資価値の類似性でカテゴリ分けし，最適な資源配分を行う際に用いる手法はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "3C分析"
      },
      {
        "label": "イ",
        "textJa": "ITポートフォリオ"
      },
      {
        "label": "ウ",
        "textJa": "エンタープライズアーキテクチャ"
      },
      {
        "label": "エ",
        "textJa": "ベンチマーキング"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。IT 投资组合把多个信息化项目按收益价值、风险等维度放在一起比较，再平衡资源投向；题干的‘按风险和投资价值分类、优化资源分配’正是这种组合管理。ア 3C 分析研究顾客、竞争者和本公司；ウ企业架构描述业务、数据、应用和技术等整体结构；エ标杆管理比较外部优秀实践以找改进空间。后三者各有用途，但没有直接给出一组投资项目之间的风险收益配置方法。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 30
  },
  {
    "number": 62,
    "stemJa": "自社の経営課題である人手不足の解消などを目標とした業務革新を進めるために活用する，RPAの事例はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "業務システムなどのデータ入力，照合のような標準化された定型作業を，事務職員の代わりにソフトウェアで自動的に処理する。"
      },
      {
        "label": "イ",
        "textJa": "製造ラインで部品の組立てに従事していた作業員の代わりに組立作業用ロボットを配置する。"
      },
      {
        "label": "ウ",
        "textJa": "人が接客して販売を行っていた店舗を，ICタグ，画像解析のためのカメラ，電子決済システムによる無人店舗に置き換える。"
      },
      {
        "label": "エ",
        "textJa": "フォークリフトなどを用いて人の操作で保管商品を搬入・搬出していたものを，コンピュータ制御で無人化した自動倉庫システムに置き換える。"
      }
    ],
    "answer": "ア",
    "id": "FE-2019-F-AM-62",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "RPA办公流程自动化",
    "explanationZh": "正确答案ア。RPA是用软件机器人模拟或执行办公室里的标准化、重复性数字操作，如录入数据、对照信息。イ的制造线装配机器人是物理工业机器人；ウ无人商店结合传感器、图像与支付系统；エ自动仓库控制实体搬运设备。后三者是实体场景自动化，不是题目所说的软件处理定型事务。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 31
  },
  {
    "number": 63,
    "stemJa": "企業がマーケティング活動に活用するビッグデータの特徴に沿った取扱いとして，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "ソーシャルメディアで個人が発信する商品のクレーム情報などの，不特定多数によるデータは処理の対象にすべきではない。"
      },
      {
        "label": "イ",
        "textJa": "蓄積した静的なデータだけでなく，Webサイトのアクセス履歴などリアルタイム性の高いデータも含めて処理の対象とする。"
      },
      {
        "label": "ウ",
        "textJa": "データ全体から無作為にデータをサンプリングして，それらを分析することによって全体の傾向を推し量る。"
      },
      {
        "label": "エ",
        "textJa": "データの正規化が難しい非構造化データである音声データや画像データは，処理の対象にすべきではない。"
      }
    ],
    "answer": "イ",
    "id": "FE-2019-F-AM-63",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "大数据的速度与多样性",
    "explanationZh": "正确答案イ。大数据并不限于已存档的静态表格；网站访问记录等快速产生、需及时处理的数据也应纳入分析，体现数据的速度特征。ア把社交媒体数据一概排除，エ把音频和图像等非结构化数据排除，都否认了多样性；ウ只随机抽样可能是一般统计方法，但不是本题强调的大数据处理特征。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 31
  },
  {
    "number": 64,
    "stemJa": "システム開発の上流工程において，システム稼働後に発生する可能性がある個人情報の漏えいや目的外利用などのリスクに対する予防的な機能を検討し，その機能をシステムに組み込むものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "情報セキュリティ方針"
      },
      {
        "label": "イ",
        "textJa": "セキュリティレベル"
      },
      {
        "label": "ウ",
        "textJa": "プライバシーバイデザイン"
      },
      {
        "label": "エ",
        "textJa": "プライバシーマーク"
      }
    ],
    "answer": "ウ",
    "id": "FE-2019-F-AM-64",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "隐私保护设计",
    "explanationZh": "正确答案ウ。Privacy by Design要求在系统规划和设计初期就识别个人信息泄露、超目的使用等风险，把防护功能直接放进设计与实现。ア是组织层面的安全方针；イ是安全程度的描述；エ是隐私标志制度。题眼是“上游阶段预防”与“功能内建”，不能等系统上线出事后才补救。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 32
  },
  {
    "number": 65,
    "stemJa": "非機能要件の定義で行う作業はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "業務を構成する機能間の情報(データ)の流れを明確にする。"
      },
      {
        "label": "イ",
        "textJa": "システム開発で用いるプログラム言語に合わせた開発基準，標準の技術要件を作成する。"
      },
      {
        "label": "ウ",
        "textJa": "システム機能として実現する範囲を定義する。"
      },
      {
        "label": "エ",
        "textJa": "他システムとの情報授受などのインタフェースを明確にする。"
      }
    ],
    "answer": "イ",
    "id": "FE-2019-F-AM-65",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "非功能需求",
    "explanationZh": "正确答案イ。非功能需求关注系统“怎样建、怎样运行”的约束与质量要求，而不是某个业务功能做什么。与开发语言相配套的开发标准及技术要求属于技术性约束，所以选イ。ア梳理业务功能间数据流、ウ划定要实现的功能范围、エ定义与其他系统交换的信息接口，都在描述系统应提供的功能或接口。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 32
  },
  {
    "number": 66,
    "stemJa": "リレーションシップマーケティングの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "顧客との良好な関係を維持することで個々の顧客から長期間にわたって安定した売上を獲得することを目指すマーケティング手法"
      },
      {
        "label": "イ",
        "textJa": "数時間から数日間程度の短期間の時間制限を設け，その時間内だけネット上で商品を販売するマーケティング手法"
      },
      {
        "label": "ウ",
        "textJa": "スマートフォンのGPS機能を利用し，現在地に近い店舗の広告を配信するマーケティング手法"
      },
      {
        "label": "エ",
        "textJa": "テレビ，新聞，雑誌などの複数のメディアを併用し，消費者への多角的なアプローチを目指すマーケティング手法"
      }
    ],
    "answer": "ア",
    "id": "FE-2019-F-AM-66",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "关系营销",
    "explanationZh": "正确答案ア。关系营销把重点放在与已有客户保持长期良好关系，从而取得长期稳定交易。イ只在短时限卖货是限时促销；ウ按手机位置投放附近广告属于位置营销；エ组合电视、报纸、杂志属于多媒体或整合传播。辨别关键是“长期顾客关系”，不是单次曝光或短期销量。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 32
  },
  {
    "id": "FE-2019-F-AM-67",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 67,
    "topicZh": "平衡计分卡内部流程视角",
    "stemJa": "バランススコアカードの内部ビジネスプロセスの視点における戦略目標と業績評価指標の例はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "持続的成長が目標であるので，受注残を指標とする。"
      },
      {
        "label": "イ",
        "textJa": "主要顧客との継続的な関係構築が目標であるので，クレーム件数を指標とする。"
      },
      {
        "label": "ウ",
        "textJa": "製品開発力の向上が目標であるので，製品開発領域の研修受講時間を指標とする。"
      },
      {
        "label": "エ",
        "textJa": "製品の製造の生産性向上が目標であるので，製造期間短縮日数を指標とする。"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。内部业务流程视角关注组织内部的作业如何更高效、更稳定；制造生产率提高并以生产周期缩短天数衡量，目标与指标都直接落在生产流程上。ア的持续增长与在手订单更接近财务或经营成果；イ维护主要客户关系属于客户视角；ウ培训时长衡量人员能力提升，属于学习与成长视角。平衡计分卡解题关键是先判断‘被测量的活动发生在哪个层面’，再检查目标与指标是否同属该视角。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 33
  },
  {
    "number": 68,
    "stemJa": "技術経営におけるプロダクトイノベーションの説明として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "新たな商品や他社との差別化ができる商品を開発すること"
      },
      {
        "label": "イ",
        "textJa": "技術開発の成果によって事業利益を獲得すること"
      },
      {
        "label": "ウ",
        "textJa": "技術を核とするビジネスを戦略的にマネジメントすること"
      },
      {
        "label": "エ",
        "textJa": "業務プロセスにおいて革新的な改革をすること"
      }
    ],
    "answer": "ア",
    "id": "FE-2019-F-AM-68",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "产品创新与流程创新",
    "explanationZh": "正确答案ア。产品创新指创造新产品，或开发与竞争者有区别的产品；重点是市场最终看到的商品或服务本身。イ泛指研发成果获利，ウ是技术经营的管理行为，エ改善业务流程，属于流程创新而非产品创新。读“プロダクト”先定位到产出物，再与“プロセス”区分。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 33
  },
  {
    "number": 69,
    "stemJa": "デジタルディバイドを説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "PCなどの情報通信機器の利用方法が分からなかったり，情報通信機器を所有していなかったりして，情報の入手が困難な人々のことである。"
      },
      {
        "label": "イ",
        "textJa": "高齢者や障害者の情報通信の利用面での困難が，社会的又は経済的な格差につながらないように，誰もが情報通信を利活用できるように整備された環境のことである。"
      },
      {
        "label": "ウ",
        "textJa": "情報通信機器やソフトウェア，情報サービスなどを，高齢者・障害者を含む全ての人が利用可能であるか，利用しやすくなっているかの度合いのことである。"
      },
      {
        "label": "エ",
        "textJa": "情報リテラシーの有無やITの利用環境の相違などによって生じる，社会的又は経済的な格差のことである。"
      }
    ],
    "answer": "エ",
    "id": "FE-2019-F-AM-69",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "数字鸿沟",
    "explanationZh": "正确答案エ。数字鸿沟指由于信息技能、设备或网络环境不同而形成的社会或经济差距，关键词是“差距”。ア只描述难以取得信息的个体，尚未说群体之间的社会经济差距；イ描述为缩小差距而建设的可利用环境；ウ描述无障碍或易用程度，接近可访问性。不要把原因、改善措施和最终差距混为一谈。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 33
  },
  {
    "number": 70,
    "stemJa": "\"かんばん方式\"を説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "各作業の効率を向上させるために，仕様が統一された部品，半製品を調達する。"
      },
      {
        "label": "イ",
        "textJa": "効率よく部品調達を行うために，関連会社から部品を調達する。"
      },
      {
        "label": "ウ",
        "textJa": "中間在庫を極力減らすために，生産ラインにおいて，後工程の生産に必要な部品だけを前工程から調達する。"
      },
      {
        "label": "エ",
        "textJa": "より品質が高い部品を調達するために，部品の納入指定業者を複数定め，競争入札で部品を調達する。"
      }
    ],
    "answer": "ウ",
    "id": "FE-2019-F-AM-70",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "看板方式与拉动生产",
    "explanationZh": "正确答案ウ。看板方式由后工序按实际需要向前工序领取所需零件，让前工序依需求补充，目的是尽量减少中间库存。ア是标准化零件采购；イ按关联公司采购不决定拉动节奏；エ多家竞标是采购竞争方式。看板题通常抓住“后工序需要多少，前工序才供多少”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 34
  },
  {
    "number": 71,
    "stemJa": "ブロックチェーンによって実現されている仮想通貨マイニングの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "仮想通貨取引の確認や記録の計算作業に参加し，報酬として仮想通貨を得る。"
      },
      {
        "label": "イ",
        "textJa": "仮想通貨を売買することによってキャピタルゲインを得る。"
      },
      {
        "label": "ウ",
        "textJa": "個人や組織に対して，仮想通貨による送金を行う。"
      },
      {
        "label": "エ",
        "textJa": "実店舗などで仮想通貨を使った支払や決済を行う。"
      }
    ],
    "answer": "ア",
    "id": "FE-2019-F-AM-71",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "虚拟货币挖矿",
    "explanationZh": "正确答案ア。按这道2019年试题的语境，挖矿是参与交易确认及记录所需的计算工作，并按相应机制取得虚拟货币奖励。イ是买卖资产赚差价；ウ是转账；エ是用虚拟货币支付。后三者都可能发生在同一生态，但不是题目定义的挖矿。不同区块链的共识机制不同，不能把本题的计算型挖矿套到所有链。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 34
  },
  {
    "number": 72,
    "stemJa": "インターネットを活用した仕組みのうち，クラウドファンディングを説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "Webサイトに公表されたプロジェクトの事業計画に協賛して，そのリターンとなる製品や権利の入手を期待する不特定多数の個人から小口資金を調達すること"
      },
      {
        "label": "イ",
        "textJa": "Webサイトの閲覧者が掲載広告からリンク先のECサイトで商品を購入した場合，広告主からそのWebサイト運営者に成果報酬を支払うこと"
      },
      {
        "label": "ウ",
        "textJa": "企業などが，委託したい業務内容を，Webサイトで不特定多数の人に告知して募集し，適任と判断した人々に当該業務を発注すること"
      },
      {
        "label": "エ",
        "textJa": "複数のアカウント情報をあらかじめ登録しておくことによって，一度の認証で複数の金融機関の口座取引情報を一括して表示する個人向けWebサービスのこと"
      }
    ],
    "answer": "ア",
    "id": "FE-2019-F-AM-72",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "众筹与其他网络模式",
    "explanationZh": "正确答案ア。众筹是在网络上公开项目，向不特定多数人募集小额资金，出资人可能期待产品或权益回报。イ是按购买成果付费的联盟营销；ウ是面向大众征集承包者的众包；エ是汇总多个金融账户信息的服务。区分funding是筹资，sourcing是找人完成工作。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 34
  },
  {
    "number": 73,
    "stemJa": "生産現場における機械学習の活用事例として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "工場における不良品の発生原因をツリー状に分解して整理し，アナリストが統計的にその原因や解決策を探る。"
      },
      {
        "label": "イ",
        "textJa": "工場の生産設備を高速通信で接続し，ホストコンピュータがリアルタイムで制御できるようにする。"
      },
      {
        "label": "ウ",
        "textJa": "工場の生産ロボットに対して作業方法をプログラミングするのではなく，ロボット自らが学んで作業の効率を高める。"
      },
      {
        "label": "エ",
        "textJa": "累積生産量が倍増するたびに工場従業員の生産性が向上し，一定の比率で単位コストが減少する。"
      }
    ],
    "answer": "ウ",
    "id": "FE-2019-F-AM-73",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "机器学习应用",
    "explanationZh": "正确答案ウ。机器学习的核心是系统从数据或经验中改善行为，而非只执行人工写死的规则。ウ描述机器人自己学习并提高作业效率，符合此点。ア由分析师手工整理原因并统计探查；イ只是联网和实时集中控制；エ描述产量累积后单位成本下降的经验曲线，均没有机器从数据中学习的过程。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 35
  },
  {
    "number": 74,
    "stemJa": "BCP(事業継続計画)の策定，運用に関する記述として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "ITに依存する業務の復旧は，技術的に容易であることを基準に優先付けする。"
      },
      {
        "label": "イ",
        "textJa": "計画の内容は，経営戦略上の重要事項となるので，上級管理者だけに周知する。"
      },
      {
        "label": "ウ",
        "textJa": "計画の内容は，自社組織が行う範囲に限定する。"
      },
      {
        "label": "エ",
        "textJa": "自然災害に加え，情報システムの機器故障やマルウェア感染も検討範囲に含める。"
      }
    ],
    "answer": "エ",
    "id": "FE-2019-F-AM-74",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "BCP业务连续性计划",
    "explanationZh": "正确答案エ。BCP要预先考虑可使重要业务中断的各种威胁；自然灾害之外，硬件故障和恶意软件感染也在范围内。ア恢复优先级应依据业务影响和目标，而不只看技术上是否容易；イ只告知高层无法让执行人员行动；ウ限制为公司内部会漏掉供应商、外部设施等依赖。计划应能在真实中断时执行。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 35
  },
  {
    "number": 75,
    "stemJa": "CIOの果たすべき役割はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "各部門の代表として，自部門のシステム化案を情報システム部門に提示する。"
      },
      {
        "label": "イ",
        "textJa": "情報技術に関する調査，利用研究，関連部門への教育などを実施する。"
      },
      {
        "label": "ウ",
        "textJa": "全社的観点から情報化戦略を立案し，経営戦略との整合性の確認や評価を行う。"
      },
      {
        "label": "エ",
        "textJa": "豊富な業務経験，情報技術の知識，リーダーシップをもち，プロジェクトの運営を管理する。"
      }
    ],
    "answer": "ウ",
    "id": "FE-2019-F-AM-75",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "CIO职责",
    "explanationZh": "正确答案ウ。CIO是首席信息官，负责从公司整体视角制定信息化战略，并检查它是否支持经营战略及其成效。ア只代表某部门提案，范围太窄；イ偏向技术调查和培训的执行工作；エ描述具体项目的运营管理，接近项目经理职责。看到CIO要想到经营层面的信息战略，而非单一项目。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 35
  },
  {
    "id": "FE-2019-F-AM-76",
    "kind": "official",
    "year": 2019,
    "section": "AM",
    "number": 76,
    "topicZh": "线性规划与最大利润",
    "stemJa": "製品X 及びY を生産するために 2 種類の原料 A，B が必要である。製品 1 個の生産に必要となる原料の量と調達可能量は表に示すとおりである。製品XとYの1個当たりの販売利益が，それぞれ100円，150円であるとき，最大利益は何円か。\n原料 A：製品Xの1個当たりの必要量 2，製品Yの1個当たりの必要量 1，調達可能量 100。\n原料 B：製品Xの1個当たりの必要量 1，製品Yの1個当たりの必要量 2，調達可能量 80。",
    "options": [
      {
        "label": "ア",
        "textJa": "5,000"
      },
      {
        "label": "イ",
        "textJa": "6,000"
      },
      {
        "label": "ウ",
        "textJa": "7,000"
      },
      {
        "label": "エ",
        "textJa": "8,000"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ，即 7,000 日元。设生产 X 为 x 个、Y 为 y 个，目标是使 100x＋150y 最大。原料 A 限制 2x＋y≤100，原料 B 限制 x＋2y≤80，且 x、y≥0。可行区域的关键顶点有 (50,0)、(0,40)，以及两条限制线交点。联立 2x＋y＝100、x＋2y＝80 得 x＝40、y＝20。三处利润分别是 5,000、6,000、7,000，因此最大值为 7,000。エ的 8,000 虽更大，却不满足原料限制。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 36,
    "periodJa": "秋期",
    "imageAssets": [
      "question-images/fe-2019-f-am-76.jpg"
    ],
    "transcriptionNoteZh": "本题与 2022 官方科目 A 样题复用同一题干；图形以 2019 秋期原卷裁图为准。"
  },
  {
    "number": 77,
    "stemJa": "ROIを説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "一定期間におけるキャッシュフロー(インフロー，アウトフロー含む)に対して，現在価値でのキャッシュフローの合計値を求めるものである。"
      },
      {
        "label": "イ",
        "textJa": "一定期間におけるキャッシュフロー(インフロー，アウトフロー含む)に対して，合計値がゼロとなるような，割引率を求めるものである。"
      },
      {
        "label": "ウ",
        "textJa": "投資額に見合うリターンが得られるかどうかを，利益額を分子に，投資額を分母にして算出するものである。"
      },
      {
        "label": "エ",
        "textJa": "投資による実現効果によって，投資額をどれだけの期間で回収可能かを定量的に算定するものである。"
      }
    ],
    "answer": "ウ",
    "id": "FE-2019-F-AM-77",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "ROI投资回报率",
    "explanationZh": "正确答案ウ。此题的ROI以利益额作分子、投资额作分母，衡量投入能带来多少收益，例如投入100、利益20，ROI为20%。ア把未来现金流折成现值并求和，接近净现值；イ寻找净现值为零的折现率，是内部收益率；エ算多久收回投资，是回收期。四个指标都评价投资，但计算目标不同。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 36
  },
  {
    "number": 78,
    "stemJa": "売上高が100百万円のとき，変動費が60百万円，固定費が30百万円掛かる。変動費率，固定費は変わらないものとして，目標利益18百万円を達成するのに必要な売上高は何百万円か。",
    "options": [
      {
        "label": "ア",
        "textJa": "108"
      },
      {
        "label": "イ",
        "textJa": "120"
      },
      {
        "label": "ウ",
        "textJa": "156"
      },
      {
        "label": "エ",
        "textJa": "180"
      }
    ],
    "answer": "イ",
    "id": "FE-2019-F-AM-78",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "topicZh": "目标利润与边际贡献",
    "explanationZh": "正确答案イ。原销售额100、变动费60，所以变动费率60%，每增加1单位销售额留下40%作为边际贡献。目标利润18加固定费30，需要边际贡献48；所需销售额＝48÷0.4＝120百万円。ア108只得到13.2利润；ウ156和エ180都超过目标。先求贡献率，再用“固定费＋目标利润”除以它。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 36
  },
  {
    "id": "FE-2019-F-AM-79",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 79,
    "topicZh": "开封即同意的软件许可合同",
    "stemJa": "シュリンクラップ契約において，ソフトウェアの使用許諾契約が成立するのはどの時点か。",
    "options": [
      {
        "label": "ア",
        "textJa": "購入したソフトウェアの代金を支払った時点"
      },
      {
        "label": "イ",
        "textJa": "ソフトウェアの入ったDVD-ROMを受け取った時点"
      },
      {
        "label": "ウ",
        "textJa": "ソフトウェアの入ったDVD-ROMの包装を解いた時点"
      },
      {
        "label": "エ",
        "textJa": "ソフトウェアをPCにインストールした時点"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。所谓 shrink-wrap 合同，是将许可条款随商品包装呈示，并以购买者拆开封膜或包装的行为作为同意条款的方式；题目据此把成立时点设在打开 DVD-ROM 包装之时。ア付款与イ收货只完成购买或交付，并未作出题设所要求的开封同意动作；エ安装软件发生得更晚，也不是此类合同所问的成立时点。这里解释的是 2019 年考试对该合同形式的设定，答题应按原题语境判断。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 37
  },
  {
    "id": "FE-2019-F-AM-80",
    "kind": "official",
    "year": 2019,
    "periodJa": "秋期",
    "section": "AM",
    "number": 80,
    "topicZh": "制造物责任与嵌入式软件",
    "stemJa": "ソフトウェアやデータに瑕疵がある場合に，製造物責任法の対象となるものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "ROM化したソフトウェアを内蔵した組込み機器"
      },
      {
        "label": "イ",
        "textJa": "アプリケーションソフトウェアパッケージ"
      },
      {
        "label": "ウ",
        "textJa": "利用者がPCにインストールしたOS"
      },
      {
        "label": "エ",
        "textJa": "利用者によってネットワークからダウンロードされたデータ"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。制造物责任法在本题的分类中针对制造、加工过的有形动产；嵌入 ROM 软件的嵌入式设备本身是有形产品，因此即使缺陷起因于内部软件，也可能作为该设备的产品缺陷来讨论。イ的软件包中的软件内容、ウ安装到 PC 的操作系统以及エ下载的数据，作为独立的无形信息并不等同于有形制造物。此处是依据 IPA 2019 年试题与官方答案说明考点，不能把所有软件缺陷一概判断为制造物责任法所涵盖。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000dict-att/2019r01a_fe_am_ans.pdf",
    "page": 37
  },
  {
    "id": "FE-2018-S-AM-01",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 1,
    "topicZh": "补码与余数",
    "stemJa": "ある整数値を，負数を2の補数で表現する2進表記法で表すと最下位2ビットは\"11\"であった。10進表記法の下で，その整数値を4で割ったときの余りに関する記述として，適切なものはどれか。ここで，除算の商は，絶対値の小数点以下を切り捨てるものとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "その整数値が正ならば3"
      },
      {
        "label": "イ",
        "textJa": "その整数値が負ならば－3"
      },
      {
        "label": "ウ",
        "textJa": "その整数値が負ならば3"
      },
      {
        "label": "エ",
        "textJa": "その整数値の正負にかかわらず0"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。正数的二进制末两位为11，可写成4k＋3，所以除以4余3。若该补码表示负数，例如−5的末两位也是11，按题目规定商向零截断，−5＝4×(−1)−1，余数为−1。故イ所说的−3、ウ所说的正3均不成立，エ的0也不成立。关键是先分清正负，再按题给的除法规则求余。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 3
  },
  {
    "id": "FE-2018-S-AM-02",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 2,
    "page": 3,
    "topicZh": "经过指定点的最短路径",
    "stemJa": "図の線上を，点Pから点Rを通って，点Qに至る最短経路は何通りあるか。",
    "options": [
      {
        "label": "ア",
        "textJa": "16"
      },
      {
        "label": "イ",
        "textJa": "24"
      },
      {
        "label": "ウ",
        "textJa": "32"
      },
      {
        "label": "エ",
        "textJa": "60"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ，即60条。原图中从P到R的最短走法必须走两步向上、两步向右，四步中挑哪两步向上共有组合数C(4,2)＝6。R到Q必须走五步，其中三步同一方向，走法数C(5,3)＝10。每一种P到R走法都能接十种R到Q走法，因此乘起来为6×10＝60。先经过R的条件把大问题拆成两个独立路段，不能把两段走法直接相加。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p03.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-03",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 3,
    "topicZh": "深度学习",
    "stemJa": "AIにおけるディープラーニングの特徴はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "\"AならばBである\"というルールを人間があらかじめ設定して，新しい知識を論理式で表現したルールに基づく推論の結果として，解を求めるものである。"
      },
      {
        "label": "イ",
        "textJa": "厳密な解でなくてもなるべく正解に近い解を得るようにする方法であり，特定分野に特化せずに，広範囲で汎用的な問題解決ができるようにするものである。"
      },
      {
        "label": "ウ",
        "textJa": "人間の脳神経回路を模倣して，認識などの知能を実現する方法であり，ニューラルネットワークを用いて，人間と同じような認識ができるようにするものである。"
      },
      {
        "label": "エ",
        "textJa": "判断ルールを作成できる医療診断などの分野に限定されるが，症状から特定の病気に絞り込むといった，確率的に高い判断ができる。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。深度学习使用多层神经网络，从数据中学习特征与识别模式。ア是由人预先写规则的规则推理；イ把近似求解及不受领域限制的通用性混为一谈，并非深度学习定义；エ把方法限定在可人工制定诊断规则的领域，也不符合。题眼是神经网络及多层学习。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 4
  },
  {
    "id": "FE-2018-S-AM-04",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 4,
    "page": 4,
    "topicZh": "状态转换与输出序列",
    "stemJa": "入力記号，出力記号の集合が{0，1}であり，状態遷移図で示されるオートマトンがある。0011001110 を入力記号とした場合の出力記号はどれか。ここで，S 1 は初期状態を表し，グラフの辺のラベルは，入力／出力を表している。 〔状態遷移図〕",
    "options": [
      {
        "label": "ア",
        "textJa": "0001000110"
      },
      {
        "label": "イ",
        "textJa": "0001001110"
      },
      {
        "label": "ウ",
        "textJa": "0010001000"
      },
      {
        "label": "エ",
        "textJa": "0011111110"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア，即0001000110。读状态图时先站在初始状态S1，对输入串0011001110逐位处理；每条边标记是“输入／输出”，斜线右边才是本步输出，走完边后记下新状态。开始连续两个0都沿S1的0边输出0；随后每一位都要从刚到达的状态继续走，不能每步重置到S1。把十次得到的输出顺序拼接就是0001000110，原状态图见图片。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p04.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-05",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 5,
    "page": 5,
    "topicZh": "栈后进先出",
    "stemJa": "次の二つのスタック操作を定義する。 PUSH n：スタックにデータ(整数値n)をプッシュする。 POP：スタックからデータをポップする。 空のスタックに対して，次の順序でスタック操作を行った結果はどれか。 PUSH 1 → PUSH 5 → POP → PUSH 7 → PUSH 6 → PUSH 4 → POP → POP → PUSH 3",
    "options": [
      {
        "label": "ア",
        "textJa": "図：上から1，7，3"
      },
      {
        "label": "イ",
        "textJa": "図：上から3，4，6"
      },
      {
        "label": "ウ",
        "textJa": "図：上から3，7，1"
      },
      {
        "label": "エ",
        "textJa": "図：上から6，4，3"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。栈采用后进先出，POP只移除当前最上层。依次执行后：先压1、5再弹5，栈余1；压7、6、4后连续弹出4和6，栈余1、7；最后压3，得到从栈底到栈顶依次1、7、3。原卷四幅图中ウ正是这一排列。注意图的开口在上方，读图时不能把栈底和栈顶颠倒，也不能像队列那样从最早压入的1先取。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p05.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-06",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 6,
    "page": 5,
    "topicZh": "数组实现链表插入",
    "stemJa": "リストを二つの1次元配列で実現する。配列要素 box[i] と next[i] の対がリストの一つの要素に対応し，box[i] に要素の値が入り，next[i] に次の要素の番号が入る。配列が図の状態の場合，リストの3番目と4番目との間に値が H である要素を挿入したときの next[8] の値はどれか。ここで，next[0] がリストの先頭(1番目)の要素を指し，next[i] の値が0である要素はリストの最後を示し，next[i] の値が空白である要素はリストに連結されていない。",
    "options": [
      {
        "label": "ア",
        "textJa": "3"
      },
      {
        "label": "イ",
        "textJa": "5"
      },
      {
        "label": "ウ",
        "textJa": "7"
      },
      {
        "label": "エ",
        "textJa": "8"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ，即7。数组下标不是链表中的顺序，必须按next指针追踪：next[0]先到1，随后1→5→3→7，所以第3个元素在下标3，第4个在下标7。要把值H的下标8插在二者之间，应先令next[8]指向原第4个节点7，再把next[3]改为8。这样链为1→5→3→8→7；若把next[8]设成下标3，会形成错误回链。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p05.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-07",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 7,
    "topicZh": "哈希查找",
    "stemJa": "表探索におけるハッシュ法の特徴はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "2分木を用いる方法の一種である。"
      },
      {
        "label": "イ",
        "textJa": "格納場所の衝突が発生しない方法である。"
      },
      {
        "label": "ウ",
        "textJa": "キーの関数値によって格納場所を決める。"
      },
      {
        "label": "エ",
        "textJa": "探索に要する時間は表全体の大きさにほぼ比例する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。哈希法把键输入哈希函数，用计算结果确定存放位置。ア的二叉树属于另一种索引结构；イ错误，不同键可能映射到同一位置，必须处理冲突；エ把查找时间说成随表大小近似线性增长，这是顺序查找的典型描述。哈希查找通常很快，但不能无条件保证恒定时间。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2018-S-AM-08",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 8,
    "topicZh": "XML与DTD",
    "stemJa": "XML文書のDTDに記述するものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "使用する文字コード"
      },
      {
        "label": "イ",
        "textJa": "データ"
      },
      {
        "label": "ウ",
        "textJa": "バージョン情報"
      },
      {
        "label": "エ",
        "textJa": "文書型の定義"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。DTD是Document Type Definition，用来定义XML文档可使用的元素、属性及结构规则。ア的字符编码与ウ的版本通常写在XML声明中；イ所说的实际数据写在XML文档内容里。不要把定义文档结构的DTD与承载数据的XML正文混淆。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2018-S-AM-09",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 9,
    "page": 6,
    "topicZh": "取指后的命令寄存器",
    "stemJa": "図はプロセッサによってフェッチされた命令の格納順序を表している。a に当てはまるものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "アキュムレーター"
      },
      {
        "label": "イ",
        "textJa": "データキャッシュ"
      },
      {
        "label": "ウ",
        "textJa": "プログラムレジスタ(プログラムカウンター)"
      },
      {
        "label": "エ",
        "textJa": "命令レジスタ"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ，即命令寄存器。处理器按程序计数器给出的地址，从主存取出下一条指令，然后把当前指令放在命令寄存器，供译码和执行单元读取。程序计数器保存的是下一指令的地址，而非本条指令内容；数据缓存保存近期数据，累加器通常保存运算结果。原图中a位于取指路径中用于存放刚取得的指令，因此与命令寄存器对应。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p06.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-10",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 10,
    "topicZh": "内部中断",
    "stemJa": "内部割込みに分類されるものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "商用電源の瞬時停電などの電源異常による割込み"
      },
      {
        "label": "イ",
        "textJa": "ゼロで除算を実行したことによる割込み"
      },
      {
        "label": "ウ",
        "textJa": "入出力が完了したことによる割込み"
      },
      {
        "label": "エ",
        "textJa": "メモリパリティエラーが発生したことによる割込み"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。执行除零运算时由正在运行的指令触发算术异常，属于内部中断。ア的电源异常、ウ的输入输出完成、エ的存储器奇偶校验错误都来自CPU指令执行之外的设备或硬件事件，在本题分类中属于外部中断。判断关键是触发原因是否由当前程序的运算本身产生。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 7
  },
  {
    "id": "FE-2018-S-AM-11",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 11,
    "topicZh": "缓存写入策略",
    "stemJa": "キャッシュメモリに関する記述のうち，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "キャッシュメモリにヒットしない場合に割込みが生じ，プログラムによって主記憶からキャッシュメモリにデータが転送される。"
      },
      {
        "label": "イ",
        "textJa": "キャッシュメモリは，実記憶と仮想記憶とのメモリ容量の差を埋めるために採用される。"
      },
      {
        "label": "ウ",
        "textJa": "データ書込み命令を実行したときに，キャッシュメモリと主記憶の両方を書き換える方式と，キャッシュメモリだけを書き換えておき，主記憶の書換えはキャッシュメモリから当該データが追い出されるときに行う方式とがある。"
      },
      {
        "label": "エ",
        "textJa": "半導体メモリのアクセス速度の向上が著しいので，キャッシュメモリの必要性は減っている。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。写穿策略同时更新缓存与主存；写回策略先改缓存，等脏块被替换等时机再写主存。ア把缓存未命中说成必然由程序中断搬运，错误；イ混淆了CPU与主存的速度差和虚拟内存容量；エ认为缓存已无必要，也不成立。两种写入策略都围绕一致性与性能权衡。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 7
  },
  {
    "id": "FE-2018-S-AM-12",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 12,
    "page": 8,
    "topicZh": "SDXC存储卡规格",
    "stemJa": "SDメモリカードの上位規格の一つであるSDXCの特徴として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "GPS，カメラ，無線LANアダプタなどの周辺機能をハードウェアとしてカードに搭載している。"
      },
      {
        "label": "イ",
        "textJa": "SDメモリカードの4分の1以下の小型サイズで，最大32Gバイトの容量をもつ。"
      },
      {
        "label": "ウ",
        "textJa": "著作権保護技術としてAACSを採用し，従来のSDメモリカードよりもセキュリティが強化された。"
      },
      {
        "label": "エ",
        "textJa": "ファイルシステムにexFATを採用し，最大2Tバイトの容量に対応できる。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。此历史题考查SDXC的规格特征：文件系统采用exFAT，容量上限可到2TB。ア说的是具有附加周边功能的卡种，并非SDXC的定义；イ说的32GB容量不是SDXC上限；ウ把蓝光等领域的AACS著作权保护技术混入。答题时先认清SD、SDHC、SDXC属于容量规格的演进，再留意文件系统和容量范围都是题目描述的成对线索。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p08.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-13",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 13,
    "topicZh": "容错设计",
    "stemJa": "フォールトトレラントシステムを実現する上で不可欠なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "システム構成に冗長性をもたせ，部品が故障してもその影響を最小限に抑えることによって，システム全体には影響を与えずに処理を続けられるようにする。"
      },
      {
        "label": "イ",
        "textJa": "システムに障害が発生したときの原因究明や復旧のために，システム稼働中のデータベースの変更情報などの履歴を自動的に記録する。"
      },
      {
        "label": "ウ",
        "textJa": "障害が発生した場合，速やかに予備の環境に障害前の状態を復旧できるように，定期的にデータをバックアップする。"
      },
      {
        "label": "エ",
        "textJa": "操作ミスが発生しにくい容易な操作にするか，操作ミスが発生しても致命的な誤りにならないように設計する。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。容错系统的核心是在部件故障时仍能继续提供服务，所以需要冗余与故障切换。イ的日志有利于追查和恢复，ウ的备份有利于灾后恢复，但单靠它们不能保证故障当下不中断；エ是减少人为操作失误的防错设计。区分持续运行与事后恢复是本题关键。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2018-S-AM-14",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 14,
    "topicZh": "热备系统",
    "stemJa": "コンピュータを2台用意しておき，現用系が故障したときは，現用系と同一のオンライン処理プログラムをあらかじめ起動して待機している待機系のコンピュータに速やかに切り替えて，処理を続行するシステムはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "コールドスタンバイシステム"
      },
      {
        "label": "イ",
        "textJa": "ホットスタンバイシステム"
      },
      {
        "label": "ウ",
        "textJa": "マルチプロセッサシステム"
      },
      {
        "label": "エ",
        "textJa": "マルチユーザーシステム"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。备用机已预先启动与现用机相同的在线处理程序，故障时可迅速切换，这是热备。ア的冷备需要故障后才启动或准备，切换较慢；ウ的多处理器描述处理器并行，与备用机状态不同；エ的多用户仅指允许多个用户使用。题干的‘あらかじめ起動’是决定性线索。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2018-S-AM-15",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 15,
    "topicZh": "系统扩容",
    "stemJa": "システムのスケールアウトに関する記述として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "既存のシステムにサーバを追加導入することによって，システム全体の処理能力を向上させる。"
      },
      {
        "label": "イ",
        "textJa": "既存のシステムのサーバの一部又は全部を，クラウドサービスなどに再配置することによって，システム運用コストを下げる。"
      },
      {
        "label": "ウ",
        "textJa": "既存のシステムのサーバを，より高性能なものと入れ替えることによって，個々のサーバの処理能力を向上させる。"
      },
      {
        "label": "エ",
        "textJa": "一つのサーバをあたかも複数のサーバであるかのように見せることによって，システム運用コストを下げる。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。横向扩展即增加服务器台数，提升服务器群整体处理能力。イ是把部署迁移到云等环境，不直接定义扩容；ウ以更高性能机器替换原服务器，是纵向扩展；エ是一台机器虚拟成多台的虚拟化。做题时看增加的是‘机器数量’还是‘单机性能’。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 9
  },
  {
    "id": "FE-2018-S-AM-16",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 16,
    "page": 10,
    "topicZh": "优先级抢占式任务调度",
    "stemJa": "三つのタスクA～Cの優先度と，各タスクを単独で実行した場合のCPUと入出力装置(I/O)の動作順序と処理時間は，表のとおりである。A～Cが同時に実行可能状態になって3ミリ秒経過後から7ミリ秒間のスケジューリング状況を表したものはどれか。ここで，I/Oは競合せず，OSのオーバーヘッドは考慮しないものとする。また，表の()の数字は処理時間を表すものとし，解答群の中の\"待ち\"はタスクが実行可能状態にあり，CPUの割当て待ちであることを意味する。",
    "options": [
      {
        "label": "ア",
        "textJa": "原問題画像の選択肢ア（図を参照）"
      },
      {
        "label": "イ",
        "textJa": "原問題画像の選択肢イ（図を参照）"
      },
      {
        "label": "ウ",
        "textJa": "原問題画像の選択肢ウ（図を参照）"
      },
      {
        "label": "エ",
        "textJa": "原問題画像の選択肢エ（図を参照）"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。原表中A优先级最高，0～2毫秒先用CPU，2～4毫秒转I/O；期间B开始占CPU，4毫秒A的I/O结束后，A作为更高优先级任务抢占B。A于6毫秒结束，之后B继续运行并转I/O，C才能得到CPU。题目只问3毫秒后连续7毫秒的图形，要从完整时间轴截取；乌图正确表现A、B、C的CPU、I/O和等待转换。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p10.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-17",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 17,
    "topicZh": "文件路径",
    "stemJa": "ファイルシステムの絶対パス名を説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "あるディレクトリから対象ファイルに至る幾つかのパス名のうち，最短のパス名"
      },
      {
        "label": "イ",
        "textJa": "カレントディレクトリから対象ファイルに至るパス名"
      },
      {
        "label": "ウ",
        "textJa": "ホームディレクトリから対象ファイルに至るパス名"
      },
      {
        "label": "エ",
        "textJa": "ルートディレクトリから対象ファイルに至るパス名"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。绝对路径从文件系统根目录出发，完整指出目标位置。イ从当前目录出发，是相对路径；ウ以用户主目录为参照，也不等于根目录绝对路径；ア按所谓最短路径来定义，与绝对/相对的划分依据无关。关键只看路径的起点。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 11
  },
  {
    "id": "FE-2018-S-AM-18",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 18,
    "topicZh": "编译优化",
    "stemJa": "コンパイラによる最適化の主な目的はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "プログラムの実行時間を短縮する。"
      },
      {
        "label": "イ",
        "textJa": "プログラムのデバッグを容易にする。"
      },
      {
        "label": "ウ",
        "textJa": "プログラムの保守性を改善する。"
      },
      {
        "label": "エ",
        "textJa": "目的プログラムを生成する時間を短縮する。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。编译器优化在保持程序语义的前提下改进生成代码，常见目标是缩短运行时间。イ的便于调试可能需要保留信息，甚至与某些优化冲突；ウ的可维护性主要属于源代码设计；エ缩短编译器生成目标程序所花的时间，并非题目所说优化的主要目标。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 11
  },
  {
    "id": "FE-2018-S-AM-19",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 19,
    "topicZh": "开源开发工具",
    "stemJa": "ソフトウェアの統合開発環境として提供されているOSSはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "Apache Tomcat"
      },
      {
        "label": "イ",
        "textJa": "Eclipse"
      },
      {
        "label": "ウ",
        "textJa": "GCC"
      },
      {
        "label": "エ",
        "textJa": "Linux"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。Eclipse提供编辑、构建、调试等集成开发功能，是开放源码IDE。ア的Apache Tomcat是Web应用服务器；ウ的GCC是编译器工具链，不能等同于完整IDE；エ的Linux是操作系统。四者都可为开放源码软件，题目要区分的是软件的用途。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 11
  },
  {
    "id": "FE-2018-S-AM-20",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 20,
    "topicZh": "分布式数据处理",
    "stemJa": "多数のサーバで構成された大規模な分散ファイルシステム機能を提供し，MapReduceによる大規模データの分散処理を実現するOSSはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "Apache Hadoop"
      },
      {
        "label": "イ",
        "textJa": "Apache Kafka"
      },
      {
        "label": "ウ",
        "textJa": "Apache Spark"
      },
      {
        "label": "エ",
        "textJa": "Apache Storm"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。Apache Hadoop包含用于大规模分布式存储的HDFS，并与MapReduce批处理模型相联系。イ的Kafka侧重分布式消息流；ウ的Spark是分布式计算框架，可读取外部存储但题述的存储加MapReduce组合并非它；エ的Storm侧重流式处理。抓住‘分布式文件系统＋MapReduce’两项线索。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 11
  },
  {
    "id": "FE-2018-S-AM-21",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 21,
    "page": 12,
    "topicZh": "执行器的职责",
    "stemJa": "アクチュエーターの説明として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "与えられた目標量と，センサーから得られた制御量を比較し，制御量を目標量に一致させるように操作量を出力する。"
      },
      {
        "label": "イ",
        "textJa": "位置，角度，速度，加速度，力，温度などを検出し，電気的な情報に変換する。"
      },
      {
        "label": "ウ",
        "textJa": "エネルギー発生源からのパワーを，制御信号に基づき，回転，並進などの動きに変換する。"
      },
      {
        "label": "エ",
        "textJa": "マイクロフォン，センサーなどが出力する微小な電気信号を増幅する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。执行器接收控制信号，利用能源把指令变成旋转、直线移动等物理动作，例如电机推动机械臂。控制器负责比较目标值与传感值并决定控制量，对应ア；传感器把温度、位置等物理量变成电信号，对应イ；放大器放大小电信号，对应エ。把“检测—决定—执行”三个环节串起来，执行器就是最后真正让设备运动的环节。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p12.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-22",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 22,
    "topicZh": "闪存",
    "stemJa": "フラッシュメモリに関する記述として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "高速に書換えができ，CPUのキャッシュメモリに用いられる。"
      },
      {
        "label": "イ",
        "textJa": "紫外線で全データ一括消去できる。"
      },
      {
        "label": "ウ",
        "textJa": "周期的にデータの再書込みが必要である。"
      },
      {
        "label": "エ",
        "textJa": "ブロック単位で電気的に内容の消去ができる。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。闪存是非易失存储器，可用电信号按块擦除，再进行写入。ア所述CPU高速缓存通常使用SRAM；イ的紫外线整片擦除是UV-EPROM特征；ウ的周期性刷新是DRAM保存电荷的要求。闪存的‘电擦除、按块管理’是区分点。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 12
  },
  {
    "id": "FE-2018-S-AM-23",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 23,
    "page": 13,
    "topicZh": "三输入多数表决电路",
    "stemJa": "真理値表に示す3入力多数決回路はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "原問題画像の選択肢ア（図を参照）"
      },
      {
        "label": "イ",
        "textJa": "原問題画像の選択肢イ（図を参照）"
      },
      {
        "label": "ウ",
        "textJa": "原問題画像の選択肢ウ（図を参照）"
      },
      {
        "label": "エ",
        "textJa": "原問題画像の選択肢エ（図を参照）"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。真值表要求A、B、C中至少两个为1时输出1，其布尔式是(A∧B)∨(A∧C)∨(B∧C)。原卷ア图正好用三个与门形成三种“两票赞成”，再用或门汇总。可用输入011、101、110检查是否均输出1，再用001检查是否输出0。其余电路有或门、异或门或末端取反等不同组合，至少有一种输入与表中结果不符。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p13.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-24",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 24,
    "page": 13,
    "topicZh": "输入数据逻辑校验",
    "stemJa": "次のような注文データが入力されたとき，注文日が入力日以前の営業日かどうかを検査するチェックはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "シーケンスチェック"
      },
      {
        "label": "イ",
        "textJa": "重複チェック"
      },
      {
        "label": "ウ",
        "textJa": "フォーマットチェック"
      },
      {
        "label": "エ",
        "textJa": "論理チェック"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ，即逻辑校验。订单日必须是输入日当天或之前的营业日，涉及“订单日”和“输入日”之间的前后关系，还要考虑营业日规则，因此要检查数据内容在业务上是否自洽。格式校验只能确认日期写法是否合法；重复校验找同一订单是否重复；顺序校验看记录排列是否合序。即使日期格式正确，未来的订单日也可能违反题给条件。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p13.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-25",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 25,
    "topicZh": "视频编码",
    "stemJa": "H.264/MPEG-4 AVCに関する記述はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "インターネットで動画や音声データのストリーミング配信を制御するための通信方式"
      },
      {
        "label": "イ",
        "textJa": "テレビ会議やテレビ電話で双方向のビデオ配信を制御するための通信方式"
      },
      {
        "label": "ウ",
        "textJa": "テレビの電子番組案内で使用される番組内容のメタデータを記述する方式"
      },
      {
        "label": "エ",
        "textJa": "ワンセグやインターネットで用いられる動画データの圧縮符号化方式"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。H.264/MPEG-4 AVC是视频压缩编码标准，题干中的ワンセグ及网络视频是其应用例。ア描述流媒体传输控制协议，イ描述会话或双向通信控制，均不是视频编码本身；ウ描述电子节目指南的元数据。把‘编码视频内容’与‘控制传输/会话’分开辨认。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 14
  },
  {
    "id": "FE-2018-S-AM-26",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 26,
    "topicZh": "增强现实",
    "stemJa": "AR(Augmented Reality)の説明として，最も適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "過去に録画された映像を視聴することによって，その時代のその場所にいたかのような感覚が得られる。"
      },
      {
        "label": "イ",
        "textJa": "実際に目の前にある現実の映像の一部にコンピュータを使って仮想の情報を付加することによって，拡張された現実の環境が体感できる。"
      },
      {
        "label": "ウ",
        "textJa": "人にとって自然な3次元の仮想空間を構成し，自分の動作に合わせて仮想空間も変化することによって，その場所にいるかのような感覚が得られる。"
      },
      {
        "label": "エ",
        "textJa": "ヘッドマウントディスプレイなどの機器を利用し人の五感に働きかけることによって，実際には存在しない場所や世界を，あたかも現実のように体感できる。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。AR把数字信息叠加在眼前真实场景上，扩大用户所见的现实信息。ア是观看历史录像所形成的临场感；ウ与エ强调进入或感受由计算机生成的虚拟空间，属于VR相关描述。区分标准是现实画面是否仍为主体，虚拟内容只是其上叠加。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 14
  },
  {
    "id": "FE-2018-S-AM-27",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 27,
    "topicZh": "数据库权限",
    "stemJa": "DBMSが提供する機能のうち，データ機密保護を実現する手段はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "一連の処理を論理的単位としてまとめたトランザクションを管理する。"
      },
      {
        "label": "イ",
        "textJa": "データに対するユーザのアクセス権限を管理する。"
      },
      {
        "label": "ウ",
        "textJa": "データを更新するときに参照制約をチェックする。"
      },
      {
        "label": "エ",
        "textJa": "データを更新する前に専有ロックをかける。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。机密性要求只有获授权的人能访问数据，因此DBMS应管理用户对表等对象的访问权限。ア的事务管理保障一组操作的处理边界；ウ的参照约束保障数据一致性；エ的排他锁控制并发更新。后三者可能重要，但不直接阻止无权用户读取机密数据。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 15
  },
  {
    "id": "FE-2018-S-AM-28",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 28,
    "page": 15,
    "topicZh": "嵌入式SQL游标",
    "stemJa": "次の埋込みSQLを用いたプログラムの一部において，Xは何を表す名前か。",
    "options": [
      {
        "label": "ア",
        "textJa": "カーソル"
      },
      {
        "label": "イ",
        "textJa": "スキーマ"
      },
      {
        "label": "ウ",
        "textJa": "テーブル"
      },
      {
        "label": "エ",
        "textJa": "ビュー"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア，即カーソル。原程序中的X用于在SQL检索得到的多行结果中定位、依次读取当前行，这就是游标的职责。表是数据库实际存数据的对象，视图是保存查询定义形成的逻辑表，模式描述数据库的结构范围；它们都不是逐行遍历结果集的位置指针。读嵌入式SQL时看到DECLARE、OPEN、FETCH、CLOSE一类操作，通常就应想到游标。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p15.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-29",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 29,
    "topicZh": "数据库日志",
    "stemJa": "データベースの更新前や更新後の値を書き出して，データベースの更新記録として保存するファイルはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "ダンプファイル"
      },
      {
        "label": "イ",
        "textJa": "チェックポイントファイル"
      },
      {
        "label": "ウ",
        "textJa": "バックアップファイル"
      },
      {
        "label": "エ",
        "textJa": "ログファイル"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。记录数据库更新前后值或更新操作的是事务日志，可用于回滚及故障恢复。ア的转储文件是数据库内容的导出；イ的检查点记录恢复进度或一致性位置；ウ的备份文件是可恢复的数据副本。题目要求的是‘逐次更新记录’，因此选日志。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 15
  },
  {
    "id": "FE-2018-S-AM-30",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 30,
    "page": 16,
    "topicZh": "数据库锁粒度",
    "stemJa": "RDBMSのロックの粒度に関する次の記述において，a，bの組合せとして適切なものはどれか。 並行に処理される2つのトランザクションがそれぞれ一つの表内の複数の行を更新する。行単位のロックを使用する場合と表単位のロックを使用する場合とを比べると，ロックの競合がより起こりやすいのは a 単位のロックを使用する場合である。また，トランザクション実行中にロックを管理するためのRDBMSのメモリ使用領域がより多く必要になるのは b 単位のロックを使用する場合である。",
    "options": [
      {
        "label": "ア",
        "textJa": "a：行，b：行"
      },
      {
        "label": "イ",
        "textJa": "a：行，b：表"
      },
      {
        "label": "ウ",
        "textJa": "a：表，b：行"
      },
      {
        "label": "エ",
        "textJa": "a：表，b：表"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ，即a为表、b为行。表级锁一次锁住整张表，两笔事务即使改不同的行也更容易相互等待，所以竞争更高；行级锁范围小，允许更多并发，但每个被锁的行需要单独记录锁信息，管理开销及内存通常更大。题目要分别比较“竞争概率”和“锁管理内存”，不要以为两者一定随粒度同方向变化。原卷表格给出四种a、b组合。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p16.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-31",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 31,
    "topicZh": "传输时间计算",
    "stemJa": "10Mバイトのデータを100,000ビット／秒の回線を使って転送するとき，転送時間は何秒か。ここで，回線の伝送効率を50%とし，1Mバイト＝10⁶バイトとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "200"
      },
      {
        "label": "イ",
        "textJa": "400"
      },
      {
        "label": "ウ",
        "textJa": "800"
      },
      {
        "label": "エ",
        "textJa": "1,600"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。10M字节按题设等于10×10⁶字节，即80×10⁶比特；线路有效速率为100,000×50%＝50,000比特/秒。时间＝80,000,000÷50,000＝1,600秒。ア200、イ400、ウ800都比计算结果短；常见错误是忘记字节到比特乘8，或忘记传输效率减半。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 16
  },
  {
    "id": "FE-2018-S-AM-32",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 32,
    "topicZh": "IPv4子网",
    "stemJa": "次のネットワークアドレスとサブネットマスクをもつネットワークがある。このネットワークをあるPCが利用する場合，そのPCに割り振ってはいけないIPアドレスはどれか。 ネットワークアドレス: 200.170.70.16 サブネットマスク : 255.255.255.240",
    "options": [
      {
        "label": "ア",
        "textJa": "200.170.70.17"
      },
      {
        "label": "イ",
        "textJa": "200.170.70.20"
      },
      {
        "label": "ウ",
        "textJa": "200.170.70.30"
      },
      {
        "label": "エ",
        "textJa": "200.170.70.31"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。掩码255.255.255.240是/28，末段每16个地址一组。该网段为200.170.70.16～31，其中.16是网络地址，.31是广播地址，都不能分给主机；可用主机地址是.17～.30。所以ア的.17、イ的.20、ウ的.30都可分配，只有エ的.31不行。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 17
  },
  {
    "id": "FE-2018-S-AM-33",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 33,
    "topicZh": "ARP",
    "stemJa": "LANに接続されているプリンタのMACアドレスを，同一LAN上のPCから調べるときに使用するコマンドはどれか。ここで，PCはこのプリンタを直前に使用しており，プリンタのIPアドレスは分かっているものとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "arp"
      },
      {
        "label": "イ",
        "textJa": "ipconfig"
      },
      {
        "label": "ウ",
        "textJa": "netstat"
      },
      {
        "label": "エ",
        "textJa": "ping"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。PC刚使用过同一LAN的打印机，ARP缓存通常有打印机IP到MAC的对应关系，可用arp命令查看。イ的ipconfig查看本机IP配置；ウ的netstat查看网络连接等状态；エ的ping检查目标是否可达，不直接给出该IP的MAC地址。题干的‘直前に使用’解释了缓存为何已有记录。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 17
  },
  {
    "id": "FE-2018-S-AM-34",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 34,
    "topicZh": "电子邮件",
    "stemJa": "電子メールのヘッダフィールドのうち，SMTPでメッセージが転送される過程で削除されるものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "Bcc"
      },
      {
        "label": "イ",
        "textJa": "Date"
      },
      {
        "label": "ウ",
        "textJa": "Received"
      },
      {
        "label": "エ",
        "textJa": "X-Mailer"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。Bcc是密送收件人；若在投递给其他收件人的邮件头继续保留该字段，就会暴露密送名单，因此转发过程中会去除。イ的Date记载时间，ウ的Received记录邮件经过的服务器，エ的X-Mailer可标示发信软件；这些字段与密送地址保密目的不同。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 17
  },
  {
    "id": "FE-2018-S-AM-35",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 35,
    "page": 18,
    "topicZh": "CGI与动态网页",
    "stemJa": "Webサーバにおいて，クライアントからの要求に応じてアプリケーションプログラムを実行して，その結果をWebブラウザに返すなどのインタラクティブなページを実現するために，Webサーバと外部プログラムを連携させる仕組みはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "CGI"
      },
      {
        "label": "イ",
        "textJa": "HTML"
      },
      {
        "label": "ウ",
        "textJa": "MIME"
      },
      {
        "label": "エ",
        "textJa": "URL"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア，即CGI。CGI是一套让Web服务器按客户端请求调用外部应用程序、再把程序运行结果返回浏览器的接口机制，能支持表单处理等互动页面。HTML只是描述网页内容与结构；MIME标明网络内容类型；URL是资源位置地址。题干的关键动词是“执行外部程序并返回结果”，所以要找服务器与程序之间的调用约定，而不是页面格式或网址。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p18.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-36",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 36,
    "topicZh": "恶意软件下载",
    "stemJa": "ドライブバイダウンロード攻撃に該当するものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "PC内のマルウェアを遠隔操作して，PCのハードディスクドライブを丸ごと暗号化する。"
      },
      {
        "label": "イ",
        "textJa": "外部ネットワークからファイアウォールの設定の誤りを突いて侵入し，内部ネットワークにあるサーバのシステムドライブにルートキットを仕掛ける。"
      },
      {
        "label": "ウ",
        "textJa": "公開Webサイトにおいて，スクリプトをWebページ中の入力フィールドに入力し，Webサーバがアクセスするデータベース内のデータを不正にダウンロードする。"
      },
      {
        "label": "エ",
        "textJa": "利用者が公開Webサイトを閲覧したときに，その利用者の意図にかかわらず，PCにマルウェアをダウンロードさせて感染させる。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。Drive-by download指用户浏览网页时，违背其意愿下载恶意软件并可能感染。ア是以加密磁盘为结果的勒索软件行为；イ是借防火墙配置漏洞侵入并植入rootkit；ウ的输入脚本后非法取得数据库内容，更接近注入类攻击。判断重点是‘只因浏览网页而被动下载’。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 18
  },
  {
    "id": "FE-2018-S-AM-37",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 37,
    "topicZh": "端口扫描",
    "stemJa": "攻撃者がシステムに侵入するときにポートスキャンを行う目的はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "後処理の段階において，システムログに攻撃の痕跡が残っていないかどうかを調査する。"
      },
      {
        "label": "イ",
        "textJa": "権限取得の段階において，権限を奪取できそうなアカウントがあるかどうかを調査する。"
      },
      {
        "label": "ウ",
        "textJa": "事前調査の段階において，攻撃できそうなサービスがあるかどうかを調査する。"
      },
      {
        "label": "エ",
        "textJa": "不正実行の段階において，攻撃者にとって有益な利用者情報があるかどうかを調査する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。端口扫描探测主机哪些端口开放，据此推测可访问的网络服务，通常用于攻击前侦察，也可用于授权的安全检查。ア是攻击后的痕迹检查；イ是寻找账号以取得权限；エ是入侵后搜寻有用信息。后三者都不是端口扫描直接探查的对象。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 18
  },
  {
    "id": "FE-2018-S-AM-38",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 38,
    "page": 19,
    "topicZh": "公开密钥加密的解密者",
    "stemJa": "AさんがBさんの公開鍵で暗号化した電子メールを，BさんとCさんに送信した結果のうち，適切なものはどれか。ここで，Aさん，Bさん，Cさんのそれぞれの公開鍵は3人全員がもち，それぞれの秘密鍵は本人だけがもっているものとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "暗号化された電子メールを，Bさんだけが，Aさんの公開鍵で復号できる。"
      },
      {
        "label": "イ",
        "textJa": "暗号化された電子メールを，Bさんだけが，自身の秘密鍵で復号できる。"
      },
      {
        "label": "ウ",
        "textJa": "暗号化された電子メールを，Bさんも，Cさんも，Bさんの公開鍵で復号できる。"
      },
      {
        "label": "エ",
        "textJa": "暗号化された電子メールを，Bさんも，Cさんも，自身の秘密鍵で復号できる。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。A使用B的公钥加密，配对的B私钥才可还原明文；即使密文同时发给B和C，也只有持有B私钥的B能解密。A的公钥用于与A私钥配对的用途，无法解这份密文；C自己的私钥也与B公钥不配对。要区分“给谁发送密文”和“为谁的公钥加密”，前者可以多人收到，后者决定能够解密的密钥持有者。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p19.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-39",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 39,
    "page": 19,
    "topicZh": "信息安全真实性",
    "stemJa": "JIS Q 27000:2014(情報セキュリティマネジメントシステム－用語)において，\"エンティティは，それが主張するとおりのものであるという特性\"と定義されているものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "真正性"
      },
      {
        "label": "イ",
        "textJa": "信頼性"
      },
      {
        "label": "ウ",
        "textJa": "責任追跡性"
      },
      {
        "label": "エ",
        "textJa": "否認防止"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア，即真正性。原卷引用JIS Q 27000:2014，所给定义是某实体确为其自称的那个实体，例如登录者确实是其声称的账户本人。信赖性偏向预期行为和结果的一致；责任追踪性强调行为可追溯到责任主体；否认防止强调事后无法否认已发生的行为。辨认“主张的身份是真实的”这一点，就能与其他安全属性区别。此题按原卷当时的标准版本学习。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p19.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-40",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 40,
    "topicZh": "SPF邮件认证",
    "stemJa": "SPF(Sender Policy Framework)の仕組みはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "電子メールを受信するサーバが，電子メールに付与されているデジタル署名を使って，送信元ドメインの詐称がないことを確認する。"
      },
      {
        "label": "イ",
        "textJa": "電子メールを受信するサーバが，電子メールの送信元のドメイン情報と，電子メールを送信したサーバのIPアドレスから，ドメインの詐称がないことを確認する。"
      },
      {
        "label": "ウ",
        "textJa": "電子メールを送信するサーバが，送信する電子メールの送信者の上司からの承認が得られるまで，一時的に電子メールの送信を保留する。"
      },
      {
        "label": "エ",
        "textJa": "電子メールを送信するサーバが，電子メールの宛先のドメインや送信者のメールアドレスを問わず，全ての電子メールをアーカイブする。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。SPF由接收方根据发件域公开的DNS记录，检查实际连接的发信服务器IP是否被该域授权。ア用数字签名验证，更接近DKIM；ウ是内部发送审批；エ是邮件归档。SPF主要核对SMTP信封发件域与发送IP，不能单独证明邮件内容或显示的From地址一定可信。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 19
  },
  {
    "id": "FE-2018-S-AM-41",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 41,
    "topicZh": "SQL注入防护",
    "stemJa": "SQLインジェクション攻撃による被害を防ぐ方法はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "入力された文字が，データベースへの問合せや操作において，特別な意味をもつ文字として解釈されないようにする。"
      },
      {
        "label": "イ",
        "textJa": "入力にHTMLタグが含まれていたら，HTMLタグとして解釈されない他の文字列に置き換える。"
      },
      {
        "label": "ウ",
        "textJa": "入力に上位ディレクトリを指定する文字(../)を含まれているときは受け付けない。"
      },
      {
        "label": "エ",
        "textJa": "入力の全体の長さが制限を超えているときは受け付けない。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。SQL注入源于把用户输入当成SQL语法；应让输入作为数据处理，实际开发优先使用参数化查询，使引号等字符不被解释成命令。イ的HTML转义主要防XSS；ウ针对目录穿越；エ限制长度可减少某些异常输入，却不能阻止短的SQL注入载荷。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 20
  },
  {
    "id": "FE-2018-S-AM-42",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 42,
    "topicZh": "安全设计",
    "stemJa": "セキュリティバイデザインの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "開発済みのシステムに対して，第三者の情報セキュリティ専門家が，脆弱性診断を行い，システムの品質及びセキュリティを高めることである。"
      },
      {
        "label": "イ",
        "textJa": "開発済みのシステムに対して，リスクアセスメントを行い，リスクアセスメント結果に基づいてシステムを改修することである。"
      },
      {
        "label": "ウ",
        "textJa": "システムの運用において，第三者による監査結果を基にシステムを改修することである。"
      },
      {
        "label": "エ",
        "textJa": "システムの企画・設計段階からセキュリティを確保する方策のことである。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。Security by Design要求从企划和设计阶段就识别风险并设计控制措施。ア与イ都在系统开发完成后才进行诊断或改修；ウ在运营期根据审计结果补救。后三者可能有价值，但均不符合‘设计之初就纳入安全’这个时间点。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 20
  },
  {
    "id": "FE-2018-S-AM-43",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 43,
    "page": 21,
    "topicZh": "数据库最小权限",
    "stemJa": "利用者情報を格納しているデータベースから利用者情報を検索して表示する機能だけをもつアプリケーションがある。このアプリケーションがデータベースにアクセスするときに用いるアカウントに与えるデータベースへのアクセス権限として，情報セキュリティ管理上，適切なものはどれか。ここで，権限の名称と権限の範囲は次のとおりとする。 〔権限の名称と権限の範囲〕 参照権限： レコードの参照が可能 更新権限： レコードの登録，変更，削除が可能 管理者権限：テーブルの参照，登録，変更，削除が可能",
    "options": [
      {
        "label": "ア",
        "textJa": "管理者権限"
      },
      {
        "label": "イ",
        "textJa": "更新権限"
      },
      {
        "label": "ウ",
        "textJa": "更新権限と参照権限"
      },
      {
        "label": "エ",
        "textJa": "参照権限"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ，即只给参照权限。应用功能明确仅能查询并显示用户资料，需要的是读取记录；赋予更新权限会允许新增、修改或删除记录，赋予管理员权限范围更大。一旦应用凭据泄露或出现程序漏洞，额外权限会扩大破坏面。最小权限原则要求账号只拥有完成其任务所必需的操作权，而不是为了方便把高权限先全部打开。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p21.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-44",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 44,
    "page": 22,
    "topicZh": "静态防火墙SMTP端口",
    "stemJa": "社内ネットワークとインターネットの接続点に，ステートフルインスペクション機能をもたない，静的なパケットフィルタリング型のファイアウォールを設置している。このネットワーク構成において，社内のPCからインターネット上のSMTPサーバに電子メールを送信できるようにするとき，ファイアウォールで通過を許可するTCPパケットのポート番号の組合せはどれか。ここで，SMTP通信には，デフォルトのポート番号を使うものとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "PC→SMTP：送信元25，宛先1024以上／SMTP→PC：送信元1024以上，宛先25"
      },
      {
        "label": "イ",
        "textJa": "PC→SMTP：送信元110，宛先1024以上／SMTP→PC：送信元1024以上，宛先110"
      },
      {
        "label": "ウ",
        "textJa": "PC→SMTP：送信元1024以上，宛先25／SMTP→PC：送信元25，宛先1024以上"
      },
      {
        "label": "エ",
        "textJa": "PC→SMTP：送信元1024以上，宛先110／SMTP→PC：送信元110，宛先1024以上"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。SMTP默认使用服务器TCP 25端口，PC作为客户端发起连接时使用1024以上的临时源端口：出站包是PC高端口→服务器25。服务器回复时源端口和目的端口对调：服务器25→PC原高端口。题目强调静态过滤且没有状态检测，因此去程与回程都要明确放行。110是POP3常见端口，不是本题的SMTP发送端口；原表的乌组恰好两方向均正确。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p22.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-45",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 45,
    "topicZh": "生物识别",
    "stemJa": "生体認証システムを導入するときに考慮すべき点として，最も適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "本人のデジタル証明書を，信頼できる第三者機関に発行してもらう。"
      },
      {
        "label": "イ",
        "textJa": "本人を誤って拒否する確率と他人を誤って許可する確率の双方を勘案して装置を調整する。"
      },
      {
        "label": "ウ",
        "textJa": "マルウェア定義ファイルの更新が頻繁な製品を利用することによって，本人を誤って拒否する確率の低下を防ぐ。"
      },
      {
        "label": "エ",
        "textJa": "容易に推測できないような知識量と本人が覚えられる知識量とのバランスが，認証に必要な知識量の設定として重要となる。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。生物识别存在本人误拒率FRR和他人误受率FAR，阈值调整需要同时权衡安全与便利。ア的数字证书属于公钥基础设施；ウ的恶意软件定义文件更新与识别阈值无关；エ讨论记忆型凭据的复杂度与可记性，属于密码等知识因素认证。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 22
  },
  {
    "id": "FE-2018-S-AM-46",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 46,
    "topicZh": "面向对象继承",
    "stemJa": "オブジェクト指向において，あるクラスの属性や機能がサブクラスで利用できることを何というか。",
    "options": [
      {
        "label": "ア",
        "textJa": "オーバーライド"
      },
      {
        "label": "イ",
        "textJa": "カプセル化"
      },
      {
        "label": "ウ",
        "textJa": "継承"
      },
      {
        "label": "エ",
        "textJa": "多相性"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。继承使子类能沿用父类的属性和方法。ア的重写是子类重新定义已有方法；イ的封装是把内部状态与实现细节包在对象内并控制访问；エ的多态是同一调用在不同对象上呈现不同实现。题干强调‘上位类内容可供下位类使用’。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 23
  },
  {
    "id": "FE-2018-S-AM-47",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 47,
    "page": 23,
    "topicZh": "软件架构设计阶段",
    "stemJa": "開発プロセスにおいて，ソフトウェア方式設計で行うべき作業はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "顧客に意見を求めて仕様を決定する。"
      },
      {
        "label": "イ",
        "textJa": "ソフトウェア品目に対する要件を，最上位レベルの構造を表現する方式であって，かつ，ソフトウェアコンポーネントを識別する方式に変換する。"
      },
      {
        "label": "ウ",
        "textJa": "プログラムを，コード化した1行ごとの処理まで明確になるように詳細化する。"
      },
      {
        "label": "エ",
        "textJa": "要求内容を図表などの形式でまとめ，段階的に詳細化して分析する。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。软件方式设计要把已经确定的软件需求组织成最高层的结构，划分软件组件及其接口，让团队知道系统由哪些部分构成、怎样协作。ア向客户征询并确定规格属于需求确认，エ分析并逐步细化需求仍偏需求阶段，ウ细到代码每行处理已是详细设计或实现层次。看设计的抽象层级：方式设计是整体架构，不是单条语句。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p23.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-48",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 48,
    "topicZh": "黑盒测试",
    "stemJa": "ブラックボックステストのテストデータの作成方法のうち，最も適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "稼動中のシステムから実データを無作為に抽出し，テストデータを作成する。"
      },
      {
        "label": "イ",
        "textJa": "機能仕様から同値クラスや限界値を識別し，テストデータを作成する。"
      },
      {
        "label": "ウ",
        "textJa": "業務で発生するデータの発生頻度を分析し，テストデータを作成する。"
      },
      {
        "label": "エ",
        "textJa": "プログラムの流れ図を基に，分岐条件に基づいたテストデータを作成する。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。黑盒测试依据功能规格设计输入，等价类划分和边界值分析能覆盖有效、无效及临界情况。ア只随机抽实际数据容易漏掉边界；ウ只按业务发生频率抽样也会漏特殊输入；エ依程序流程图与分支设计数据属于关注内部结构的白盒方法。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 23
  },
  {
    "id": "FE-2018-S-AM-49",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 49,
    "page": 24,
    "topicZh": "多条件覆盖测试",
    "stemJa": "プログラムの流れ図で示される部分に関するテストデータを，判定条件網羅(decision coverage)によって設定した。このテストデータを複数条件網羅(multiple condition coverage)による設定に変更したとき，加えるべきテストデータのうち，適切なものはどれか。ここで，( )で囲んだ部分は，一組みのテストデータを表すものとする。 ・判定条件網羅によるテストデータ (A＝4，B＝1)，(A＝5，B＝0)",
    "options": [
      {
        "label": "ア",
        "textJa": "(A＝3，B＝0)，(A＝7，B＝2)"
      },
      {
        "label": "イ",
        "textJa": "(A＝3，B＝2)，(A＝8，B＝0)"
      },
      {
        "label": "ウ",
        "textJa": "(A＝4，B＝0)，(A＝8，B＝0)"
      },
      {
        "label": "エ",
        "textJa": "(A＝7，B＝0)，(A＝8，B＝2)"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。判定条件覆盖只要求整体判断结果出现过真和假；多条件覆盖还要求组成判定的每个基本条件的真、假组合都被测试到。先按原流程图把A、B的条件分别列为布尔值，再核对已有(A＝4,B＝1)与(A＝5,B＝0)覆盖的组合；仍缺的组合由(A＝7,B＝0)和(A＝8,B＝2)补齐。其他选项有重复已有组合或无法覆盖所缺情况，不能只看输入值是否不同。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p24.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-50",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 50,
    "topicZh": "结对编程",
    "stemJa": "エクストリームプログラミング(XP:eXtreme Programming)のプラクティスのうち，プログラム開発において，相互に役割を交替し，チェックし合うことによって，コミュニケーションを円滑にし，プログラムの品質向上を図るものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "計画ゲーム"
      },
      {
        "label": "イ",
        "textJa": "コーディング標準"
      },
      {
        "label": "ウ",
        "textJa": "テスト駆動開発"
      },
      {
        "label": "エ",
        "textJa": "ペアプログラミング"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。结对编程由两人协作编写同一代码，并轮换编写和审查角色，符合题干的相互检查。ア的计划游戏讨论需求及迭代计划；イ的编码标准规定统一写法；ウ的测试驱动开发先写测试再实现。它们都是XP实践，但只有结对编程以双人轮换为特征。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 24
  },
  {
    "id": "FE-2018-S-AM-51",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 51,
    "page": 25,
    "topicZh": "关键路径压缩",
    "stemJa": "図のアローダイアグラムにおいて，プロジェクト全体の期間を短縮するために，作業A～Eの幾つかを1日ずつ短縮する。プロジェクト全体を2日短縮できる作業の組合せはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "A，C，E"
      },
      {
        "label": "イ",
        "textJa": "A，D"
      },
      {
        "label": "ウ",
        "textJa": "B，C，E"
      },
      {
        "label": "エ",
        "textJa": "B，D"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ，即B和D各缩短1天。原图三个主要路径的工期分别为A→D的8天、B→C→D的9天、B→E→F的8天，故原总工期9天。B和D各减1天后，这三条路径依次成为7、7、7天，项目才真正缩短2天。若只缩短关键路径上的一项，还可能由另一条原本8天的路径接替成为新瓶颈，所以压缩项目要重新算全部路径的最大值。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p25.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-52",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 52,
    "page": 25,
    "topicZh": "按工数权重计算进度",
    "stemJa": "あるプロジェクトの工数配分は表のとおりである。基本設計からプログラム設計までは計画どおり終了した。現在はプログラミング段階であり，3,000本のプログラムのうち1,200本が完成したところである。プロジェクト全体の進捗度は何％か。 ここで，各プログラムの開発工数は，全て等しいものとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "40"
      },
      {
        "label": "イ",
        "textJa": "44"
      },
      {
        "label": "ウ",
        "textJa": "54"
      },
      {
        "label": "エ",
        "textJa": "59"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ，即54%。基本设计至程序设计三个已完成阶段在原表的工数占比为0.08＋0.16＋0.20＝0.44。当前编程阶段完成1200÷3000＝0.4，而该阶段占项目总工数0.25，因此又贡献0.4×0.25＝0.10。总进度为0.44＋0.10＝0.54。不要把“编程完成40%”直接加到项目已完成44%，两个百分比的分母不同。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p25.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-53",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 53,
    "page": 25,
    "topicZh": "立方根与开发期间",
    "stemJa": "システム開発において，工数(人月)と期間(月)の関係が次の近似式で示されるとき，工数が4,096人月のときの期間は何か月か。 期間＝2.5×工数^(1/3)",
    "options": [
      {
        "label": "ア",
        "textJa": "16"
      },
      {
        "label": "イ",
        "textJa": "40"
      },
      {
        "label": "ウ",
        "textJa": "64"
      },
      {
        "label": "エ",
        "textJa": "160"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ，即40个月。把4096人月代入题给近似式“期间＝2.5×工数的三分之一次方”。因为4096＝16的三次方，三次方根正好是16，所以期间＝2.5×16＝40个月。人月表示工作量，不是能直接当成历时月数；题设用非线性关系表达增加人数和工期之间并非简单的一比一关系，必须按公式计算。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p25.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-54",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 54,
    "page": 26,
    "topicZh": "功能点加权计算",
    "stemJa": "あるソフトウェアにおいて，機能の個数と機能の複雑度に対する重み付け係数は表のとおりである。このソフトウェアのファンクションポイント値は幾らか。ここで，ソフトウェアの全体的な複雑さの補正係数は0.75とする。",
    "options": [
      {
        "label": "ア",
        "textJa": "18"
      },
      {
        "label": "イ",
        "textJa": "24"
      },
      {
        "label": "ウ",
        "textJa": "30"
      },
      {
        "label": "エ",
        "textJa": "32"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア，即18 FP。按原表逐类把功能个数与复杂度权重相乘再相加：1×4＋2×5＋1×10＝24。最后应用题给的整体复杂度补正系数0.75，得到24×0.75＝18。功能点衡量的是功能规模，不能只数功能总个数，也不能把补正系数加到24上；权重反映不同功能类型的相对工作量，所有项都必须先汇总。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p26.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-55",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 55,
    "topicZh": "问题管理",
    "stemJa": "ITサービスマネジメントにおける問題管理で実施する活動のうち，事前予防的な活動はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "インシデントの発生傾向を分析して，将来のインシデントを予防する方策を提案する。"
      },
      {
        "label": "イ",
        "textJa": "検出して記録した問題を分類して，対応の優先度を設定する。"
      },
      {
        "label": "ウ",
        "textJa": "重大な問題に対する解決策の有効性を評価する。"
      },
      {
        "label": "エ",
        "textJa": "問題解決後の一定期間，インシデントの再発の有無を監視する。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。预防性问题管理要从已有事件的趋势推测未来风险，并在新事件出现前提出对策。イ对已发现问题分类并排优先级，ウ评价重大问题的现有解法，エ在问题解决后观察复发，都是针对已发生事项的处理或追踪。题眼是‘将来的事件预防’。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 26
  },
  {
    "id": "FE-2018-S-AM-56",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 56,
    "page": 27,
    "topicZh": "本地服务台",
    "stemJa": "サービスデスク組織の構造とその特徴のうち，ローカルサービスデスクのものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "サービスデスクを1拠点又は少数の場所に集中することによって，サービス要員を効率的に配置したり，大量のコールに対応したりすることができる。"
      },
      {
        "label": "イ",
        "textJa": "サービスデスクを利用者の近くに配置することによって，言語や文化の異なる利用者への対応，専用要員によるVIP対応などができる。"
      },
      {
        "label": "ウ",
        "textJa": "サービス要員が複数の地域や部門に分散していても，通信技術を利用によって単一のサービスデスクであるかのようにサービスが提供できる。"
      },
      {
        "label": "エ",
        "textJa": "分散拠点のサービス要員を含めた全員を中央で統括して管理することによって，統制の取れたサービスが提供できる。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。ローカルサービスデスク设在用户所在地点或附近，便于面对面支持，也便于适应当地语言、文化和特有设备。ア把人员集中在少数地点，更接近中央服务台；ウ靠通信技术让分散人员像一个台运行，属于虚拟服务台；エ强调中央统筹分布式人员。题目问结构特点而非服务质量高低，抓住“利用者の近くに配置”即可定位。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p27.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-57",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 57,
    "topicZh": "数据备份",
    "stemJa": "サーバに接続されたディスクのデータのバックアップに関する記述として，最も適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "一定の期間を過ぎて利用頻度が低くなったデータは，現在のディスクから消去するとともに，バックアップしておいたデータも消去する。"
      },
      {
        "label": "イ",
        "textJa": "システムの本稼働開始日に全てのデータをバックアップし，それ以降は作業時間を短縮するために，更新頻度が高いデータだけをバックアップする。"
      },
      {
        "label": "ウ",
        "textJa": "重要データは，バックアップの媒体を取り違えないように，同一の媒体に上書きでバックアップする。"
      },
      {
        "label": "エ",
        "textJa": "複数のファイルに分散して格納されているデータは，それぞれのファイルへの一連の更新処理が終了した時点でバックアップする。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。跨多个文件的一组更新尚未全部完成时备份，可能得到彼此不一致的数据；应在整组处理完成并达到一致状态后备份。ア仅因访问变少就连备份一起删除，可能失去恢复资料；イ只备份高频更新会漏掉低频变更；ウ反复覆盖同一介质会失去历史版本且增加单点风险。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 27
  },
  {
    "id": "FE-2018-S-AM-58",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 58,
    "topicZh": "系统审计",
    "stemJa": "システム監査人の行為のうち，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "調査が不十分な事項について，過去の経験に基づいて監査意見をまとめた。"
      },
      {
        "label": "イ",
        "textJa": "調査によって発見した問題点について，改善指摘を行った。"
      },
      {
        "label": "ウ",
        "textJa": "調査の過程で発見した問題点について，その都度，改善を命令した。"
      },
      {
        "label": "エ",
        "textJa": "調査の途中で当初計画していた期限がきたので，監査報告書の作成に移った。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。审计员基于调查发现的问题提出改进建议，属于审计职责。ア没有充分证据却凭经验下结论，缺少客观依据；ウ直接命令被审单位改善，越过审计员的职责边界；エ调查尚未完成就仅因期限到了转写报告，可能导致结论缺乏充分证据。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 28
  },
  {
    "id": "FE-2018-S-AM-59",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 59,
    "page": 28,
    "topicZh": "系统审计的独立性",
    "stemJa": "システム監査実施体制のうち，システム監査人の独立性の観点から 避けるべきもの はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "監査チームメンバーに任命された総務部のAさんが，ほかのメンバーと一緒に，総務部の入退室管理の状況を監査する。"
      },
      {
        "label": "イ",
        "textJa": "監査部のBさんが，個人情報を取り扱う業務を委託している外部企業の個人情報管理状況を監査する。"
      },
      {
        "label": "ウ",
        "textJa": "情報システム部の開発管理者から5年前に監査部に異動したCさんが，マーケティング部におけるインターネットの利用状況を監査する。"
      },
      {
        "label": "エ",
        "textJa": "法務部のDさんが，監査部からの依頼によって，外部委託契約の妥当性の監査において，監査人に協力する。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。审计团队里的总务部A又去审查本部门的出入室管理，相当于审自己负责或隶属领域的控制措施，难以保持外观与判断上的独立性，应避免。监查部B审外包企业、曾在五年前转部门的C审其他部门，以及法务部D就合同提供专业协助，在题给情境下都没有同样直接的自我审查问题。独立性不仅看个人主观是否公正，也看组织关系。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p28.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-60",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 60,
    "topicZh": "信息安全三要素",
    "stemJa": "情報セキュリティ監査において，可用性を確認するチェック項目はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "外部記憶媒体の無断持出しが禁止されていること"
      },
      {
        "label": "イ",
        "textJa": "中断時間を定めたSLAの水準が保たれるように管理されていること"
      },
      {
        "label": "ウ",
        "textJa": "データ入力時のエラーチェックが適切に行われていること"
      },
      {
        "label": "エ",
        "textJa": "データベースが暗号化されていること"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。可用性关注服务在需要时是否可使用，含中断时间要求的SLA正是衡量和管理可用性的例子。ア禁止擅自带走存储介质与エ加密数据库主要保护机密性；ウ输入错误检查主要保护数据完整性。可用性、机密性、完整性是不同的检查目标。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 28
  },
  {
    "id": "FE-2018-S-AM-61",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 61,
    "page": 29,
    "topicZh": "机器学习辅助客服",
    "stemJa": "蓄積されたデータに対してパターン認識機能や機械学習機能を適用することによって，コールセンターにおける顧客応対業務の質的向上が可能となる事例はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "応対マニュアルや顧客の基本情報を電子化したものを，オペレーターの要求時に応対用の画面にポップアップ画面として表示する。"
      },
      {
        "label": "イ",
        "textJa": "顧客の問合せの内容に応じて，関連資料や過去の応対に関する全履歴から，最適な回答をリアルタイムで導き出す。"
      },
      {
        "label": "ウ",
        "textJa": "電話応対中のオペレーターが回答に窮したときに，その電話や応対画面をベテランのオペレーターや専門要員に転送する。"
      },
      {
        "label": "エ",
        "textJa": "ベテランのオペレーターが講師となり，応対マニュアルを教材にして，新人オペレーターに対するロールプレイング研修を繰り返して実施する。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。把用户问题与积累的历史应答和资料匹配，再实时推导最适合的回答，才体现题干要求的模式识别及机器学习：系统利用已有大量数据识别当前询问的类型与关联案例。ア只是按需弹出电子化手册，ウ转给资深人工客服，エ是人工角色扮演培训；这些可能改善服务，但没有让系统从历史数据中学习并推断答案。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p29.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-62",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 62,
    "topicZh": "服务导向架构",
    "stemJa": "SOAの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "売上・利益の増加や，顧客満足度の向上のために，営業活動にITを活用して営業の効率と品質を高める概念のこと"
      },
      {
        "label": "イ",
        "textJa": "経営資源をコアビジネスに集中させるために，社内業務のうちコアビジネス以外の業務を外部に委託すること"
      },
      {
        "label": "ウ",
        "textJa": "コスト，品質，サービス，スピードを革新的に改善させるために，ビジネスプロセスをデザインし直す概念のこと"
      },
      {
        "label": "エ",
        "textJa": "ソフトウェアの機能をサービスという部品とみなし，そのサービスを組み合わせることでシステムを構築する概念のこと"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。SOA把功能划分为可组合的服务，通过服务协作构建系统。ア是利用IT提升销售活动的SFA；イ把非核心业务外包，是BPO；ウ重新设计业务流程以显著改善绩效，是BPR。题干应抓住‘功能作为服务部件’与‘组合系统’。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 29
  },
  {
    "id": "FE-2018-S-AM-63",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 63,
    "page": 30,
    "topicZh": "大数据第四阶段：采取措施",
    "stemJa": "ビッグデータ活用の発展過程を次の4段階に分類した場合，第4段階に該当する活用事例はどれか。 〔ビッグデータ活用の発展段階〕 第1段階: 過去や現在の事実の確認(どうだったのか) 第2段階: 過去や現在の状況の解釈(どうしてそうだったのか) 第3段階: 将来生じる可能性がある事象の予測(どうなりそうなのか) 第4段階: 将来の施策への展開(どうしたら良いのか)",
    "options": [
      {
        "label": "ア",
        "textJa": "製品のインターネット接続機能を用いて，販売後の製品からの多数の利用者による操作履歴をビッグデータに蓄積し，機能の使用割合を明らかにする。"
      },
      {
        "label": "イ",
        "textJa": "多数の利用者による操作履歴が蓄積されたビッグデータの分析結果を基に，当初，メーカーが想定していなかった利用者の誤操作とその原因を見つけ出す。"
      },
      {
        "label": "ウ",
        "textJa": "ビッグデータを基に，利用者の誤操作の原因と，それによる故障率の増加を推定し，利用者の誤操作を招きにくいユーザーインタフェースに改良する。"
      },
      {
        "label": "エ",
        "textJa": "利用者の誤操作が続いた場合に想定される製品の故障率の増加を，ビッグデータを用いたシミュレーションで推定する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。题目把分析分成“发生了什么、为何如此、将会怎样、应该怎么做”四层。ウ不仅根据数据推测误操作原因与故障风险，还提出使误操作更少的产品改进，因此进入面向未来的施策阶段。ア是收集并确认事实，イ是分析过去使用状况，エ用模拟预测持续误操作后的故障率，仍停在第三阶段。判断第四阶段要看到具体行动建议。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p30.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-64",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 64,
    "topicZh": "UML活动图",
    "stemJa": "UMLをビジネスモデリングに用いる場合，ビジネスプロセスの実行順序や条件による分岐などのワークフローを表すことができる図はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "アクティビティ図"
      },
      {
        "label": "イ",
        "textJa": "オブジェクト図"
      },
      {
        "label": "ウ",
        "textJa": "クラス図"
      },
      {
        "label": "エ",
        "textJa": "コンポーネント図"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。UML活动图表达业务步骤、执行顺序、条件分支等流程，适合画工作流。イ的对象图呈现某时刻对象实例之间的关系；ウ的类图呈现类、属性与静态结构；エ的组件图呈现软件组件及依赖。题目问的是动态流程，而非静态结构。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 30
  },
  {
    "id": "FE-2018-S-AM-65",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 65,
    "page": 31,
    "topicZh": "绿色采购",
    "stemJa": "国や地方公共団体などが，環境への配慮を積極的に行っていると評価されている製品・サービスを選んでいる。この取組みを何というか。",
    "options": [
      {
        "label": "ア",
        "textJa": "CSR"
      },
      {
        "label": "イ",
        "textJa": "エコマーク認定"
      },
      {
        "label": "ウ",
        "textJa": "環境アセスメント"
      },
      {
        "label": "エ",
        "textJa": "グリーン購入"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ，即グリーン購入。题中主体在购买产品或服务时主动选择环境负荷更低的选项，这个采购行为本身就叫绿色采购。CSR是企业承担社会责任的宽泛概念；生态标志认证是给产品贴环保评价标志，不等同于采购；环境评估通常评价工程或计划对环境的影响。抓住“选购”的动作，比只看“环保”两个字更能准确区分。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p31.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-66",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 66,
    "topicZh": "利基战略",
    "stemJa": "企業経営におけるニッチ戦略はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "キャッシュフローの重視"
      },
      {
        "label": "イ",
        "textJa": "市場の特定化"
      },
      {
        "label": "ウ",
        "textJa": "垂直統合"
      },
      {
        "label": "エ",
        "textJa": "リードタイムの短縮"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。利基战略选择范围较窄、需求明确的细分市场，集中满足该群体，故称市场特定化。ア强调现金流管理；ウ把上下游业务整合，是垂直整合；エ缩短从开始到交付的时间，是缩短前置时间。它们都不是针对特定小市场的竞争战略。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 31
  },
  {
    "id": "FE-2018-S-AM-67",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 67,
    "page": 31,
    "topicZh": "规模经济与协同效应",
    "stemJa": "あるメーカーがビールと清涼飲料水を生産する場合，表に示すように6種類のケース(A～F)によって異なるコストが掛かる。このメーカーの両製品の生産活動におけるスケールメリットとシナジー効果についての記述のうち，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "スケールメリットはあるが，シナジー効果はない。"
      },
      {
        "label": "イ",
        "textJa": "スケールメリットはないが，シナジー効果はある。"
      },
      {
        "label": "ウ",
        "textJa": "スケールメリットとシナジー効果がともにある。"
      },
      {
        "label": "エ",
        "textJa": "スケールメリットとシナジー効果がともにない。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ，即没有规模经济，但有协同效应。看原表：仅生产啤酒20万本成本1500，扩至40万本成本3300，单位成本没有下降；清凉饮料10万本成本500，扩至20万本成本1100，也没有下降，故无规模经济。联合生产20万啤酒和10万饮料成本1900，低于分别生产的1500＋500＝2000，显示共用资源带来协同。两种效应的比较基准不同，不能混算。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p31.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-68",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 68,
    "topicZh": "产品生命周期",
    "stemJa": "プロダクトライフサイクルにおける成熟期の特徴はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "市場が商品の価値を理解し始める。商品ラインもチャネルも拡大しなければならない。この時期は売上も伸びるが，投資も必要である。"
      },
      {
        "label": "イ",
        "textJa": "需要が大きくなり，製品の差別化や市場の細分化が明確になってくる。競争者間の競争も激化し，新品種の追加やコストダウンが重要となる。"
      },
      {
        "label": "ウ",
        "textJa": "需要が減ってきて，撤退する企業も出てくる。この時期の強者になれるかどうかを判断し，代替市場への進出なども考える。"
      },
      {
        "label": "エ",
        "textJa": "需要は部分的で，新規需要開拓が勝負である。特定ターゲットに対する信念に満ちた説得が必要である。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。产品生命周期成熟期需求已较大，竞争变激烈，因此常需差异化、细分、新品种或降成本。ア描述销量上升且仍需扩大渠道与投资的成长期；ウ需求下降且考虑退出，是衰退期；エ需开辟初始需求并说服目标顾客，是导入期。按需求变化判断阶段。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 32
  },
  {
    "id": "FE-2018-S-AM-69",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 69,
    "topicZh": "成本加成定价",
    "stemJa": "コストプラス価格決定法を説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "買い手が認める品質や価格をリサーチし，訴求力のある価格を決定する。"
      },
      {
        "label": "イ",
        "textJa": "業界の平均水準や競合企業の設定価格を参考に，競争力のある価格を決定する。"
      },
      {
        "label": "ウ",
        "textJa": "製造原価又は仕入原価に一定のマージンを乗せて価格を決定する。"
      },
      {
        "label": "エ",
        "textJa": "目標販売量を基に，総費用吸収後に一定の利益率を確保できる価格を決定する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。成本加成定价从制造或采购成本出发，加上预定利润率或加价额来定售价。ア先调查买方认可的价值与价格，属于需求/价值导向；イ参考竞争者价格，属于竞争导向；エ从目标销量、总费用和目标利润反推价格，属于目标利润定价。关键是‘成本＋固定加成’。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 32
  },
  {
    "id": "FE-2018-S-AM-70",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 70,
    "topicZh": "知识管理",
    "stemJa": "ナレッジマネジメントを説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "企業内に散在している知識を共有化し，全体の問題解決力を高める経営を行う。"
      },
      {
        "label": "イ",
        "textJa": "迅速な意思決定のために，組織の階層をできるだけ少なくしたフラット型の組織構造によって経営を行う。"
      },
      {
        "label": "ウ",
        "textJa": "優れた業績を上げている企業との比較分析から，自社の経営革新を行う。"
      },
      {
        "label": "エ",
        "textJa": "他社にはまねのできない，企業独自のノウハウや技術などの強みを核とした経営を行う。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。知识管理把组织中分散的经验、诀窍和文档分享并复用，提高整体解决问题能力。イ是减少管理层级的扁平化组织；ウ与优秀企业比较寻找改进机会，是标杆管理；エ围绕企业难以模仿的强项经营，是核心能力战略。题干的‘知识共享’指向知识管理。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 32
  },
  {
    "id": "FE-2018-S-AM-71",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 71,
    "page": 33,
    "topicZh": "物联网的连接要件",
    "stemJa": "IoT(Internet of Things)の実用例として， 適切でないもの はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "インターネットにおけるセキュリティの問題を回避する目的で，サーバに接続せず，単独でファイルの管理，演算処理，印刷処理などの作業を行うコンピュータ"
      },
      {
        "label": "イ",
        "textJa": "大型の機械などにセンサーと通信機能を内蔵して，稼働状況，故障箇所，交換が必要な部品などを，製造元がインターネットを介してリアルタイムに把握できるシステム"
      },
      {
        "label": "ウ",
        "textJa": "検針員に代わって，電力会社と通信して電力使用量を送信する電力メーター"
      },
      {
        "label": "エ",
        "textJa": "自動車同士及び自動車と路側機が通信することによって，自動車の位置情報をリアルタイムに収集して，渋滞情報を配信するシステム"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア是“不适切”项。ア描述为回避网络安全问题而完全不连接服务器、只单机管理文件和演奏，不具备题目所说的物联网通信与远程数据利用。イ是设备通过传感器与网络向厂家报状态；ウ是智能电表远传用电量；エ是车辆与路侧机交换位置资料，均有“物”通过通信参与系统。IoT的关键是连接和数据交互，单独自动运行不足以构成此例。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p33.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-72",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 72,
    "page": 33,
    "topicZh": "顾客ID关联POS数据",
    "stemJa": "コンビニエンスストアにおいて，ポイントカードなどの個人情報と結び付けられた顧客ID付きPOSデータを収集・分析することによって確認できるものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "商品の最終的な使用者"
      },
      {
        "label": "イ",
        "textJa": "商品の店舗までの流通経路"
      },
      {
        "label": "ウ",
        "textJa": "商品を購入する動機"
      },
      {
        "label": "エ",
        "textJa": "同一商品の購入頻度"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ，即同一商品的购买频率。POS记录每次结算的商品、时间等资料，结合积分卡的顾客ID，可以把同一顾客历次买同一商品的次数和间隔算出来。记录的是购买者与销售交易，不一定知道最终使用者；商品到店前的物流路径不在销售流水中；购买动机也无法仅凭结算记录直接确认。数据分析前先看每个字段实际采集了什么。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p33.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-73",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 73,
    "topicZh": "单元生产",
    "stemJa": "セル生産方式の利点が生かせる対象はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "生産性を上げるために，大量生産が必要なもの"
      },
      {
        "label": "イ",
        "textJa": "製品の仕様が長期間変わらないもの"
      },
      {
        "label": "ウ",
        "textJa": "多種類かつフレキシブルな生産が求められるもの"
      },
      {
        "label": "エ",
        "textJa": "標準化，単純化，専門化による分業が必要なもの"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。单元生产由一人或小组承担多道工序，换线灵活，适合多品种、需求变化快的产品。ア的大批量生产、イ的规格长期稳定，更适合标准化流水线；エ强调高度分工和专业化，也与单元生产的多技能作业方式不同。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 33
  },
  {
    "id": "FE-2018-S-AM-74",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 74,
    "topicZh": "长尾理论",
    "stemJa": "ロングテールの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "Webコンテンツを構成するテキストや画像などのデジタルコンテンツに，統合的・体系的な管理，配信などの必要な処理を行うこと"
      },
      {
        "label": "イ",
        "textJa": "インターネットショッピングで，売上の全体に対して，あまり売れない商品群の売上合計が無視できない割合になっていること"
      },
      {
        "label": "ウ",
        "textJa": "自分のWebサイトやブログに企業へのリンクを掲載し，他者がこれらのリンクを経由して商品を購入したときに，企業が紹介料を支払うこと"
      },
      {
        "label": "エ",
        "textJa": "メーカーや卸売業者から商品を直接発送することによって，在庫リスクを負うことなく自分のWebサイトで商品が販売できること"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。长尾现象指大量单项销量不高的商品合计后可形成不可忽视的销售额，网络商店可借丰富目录发挥它。ア是内容管理系统CMS；ウ是通过链接成交获取佣金的联盟营销；エ由供应商直接发货、店家不持库存，是代发货模式。不要把长尾与单件爆款混淆。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 34
  },
  {
    "id": "FE-2018-S-AM-75",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 75,
    "topicZh": "ABC分析",
    "stemJa": "ABC分析手法の説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "地域を格子状の複数の区画に分け，様々なデータ(人口，購買力など)に基づいて，より細かに地域分析をする。"
      },
      {
        "label": "イ",
        "textJa": "何回も同じパネリスト(回答者)に反復調査する。そのデータで地域の傾向や購入層の変化を把握する。"
      },
      {
        "label": "ウ",
        "textJa": "販売金額，粗利益金額などが高い商品から順番に並べ，その累計比率によって商品を幾つかの階層に分け，高い階層に属する商品の販売量の拡大を図る。"
      },
      {
        "label": "エ",
        "textJa": "複数の調査データを要因ごとに区分し，集計することによって，販売力の分析や同一商品の購入状況などを分析する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。ABC分析按销售额、毛利等指标从高到低排列，计算累计占比并分成重点程度不同的组，以便分层管理。ア按地理网格分析区域；イ对固定样本反复调查，是面板调查；エ按多个因素分类汇总数据，并非按贡献累计比例分层。辨认‘排序＋累计比率＋分组’。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "page": 34
  },
  {
    "id": "FE-2018-S-AM-76",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 76,
    "page": 34,
    "topicZh": "抽样检验OC曲线",
    "stemJa": "抜取り検査において，ある不良率のロットがどれだけの確率で合格するかを知ることができるものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "OC曲線"
      },
      {
        "label": "イ",
        "textJa": "ゴンペルツ曲線"
      },
      {
        "label": "ウ",
        "textJa": "バスタブ曲線"
      },
      {
        "label": "エ",
        "textJa": "ロジスティック曲線"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア，即OC曲线。OC是检验特性曲线，横轴通常放批次实际不良率，纵轴表示在规定抽样方案下该批被判合格的概率，所以正对题问“某不良率的批次有多大概率合格”。龚珀兹曲线与增长过程有关，浴盆曲线描绘设备故障率随寿命变化，逻辑斯蒂曲线常表示S形增长。先认准两个变量：不良率与接收概率。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p34.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-77",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 77,
    "page": 35,
    "topicZh": "资产负债表的净资产",
    "stemJa": "貸借対照表の純資産の部に表示される項目はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "売掛金"
      },
      {
        "label": "イ",
        "textJa": "資本金"
      },
      {
        "label": "ウ",
        "textJa": "社債"
      },
      {
        "label": "エ",
        "textJa": "投資有価証券"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ，即資本金。资产负债表由资产、负债、净资产组成，净资产体现企业由出资人投入并由经营留存的权益；股东投入的资本金属于这一栏。売掛金是尚未收回的销售债权，列资产；投资有价证券也是资产；社债是公司对债券持有人的偿还义务，列负债。可用“企业拥有的、欠别人的、归所有者的”三类先作归属判断。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p35.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-78",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 78,
    "page": 35,
    "topicZh": "先进先出法期末库存",
    "stemJa": "商品Aの当月分の全ての受払いを表に記載した。商品Aを先入先出法で評価した場合，当月末の在庫の評価額は何円か。",
    "options": [
      {
        "label": "ア",
        "textJa": "3,300"
      },
      {
        "label": "イ",
        "textJa": "3,600"
      },
      {
        "label": "ウ",
        "textJa": "3,660"
      },
      {
        "label": "エ",
        "textJa": "3,700"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ，即3700日元。按原表，期初10个每个100，4日进货40个每个120，7日进货30个每个130，10日进货10个每个110；5日售出30个，30日再售出30个。先进先出让最早批次先耗尽，共售60个后留下7日批次的20个及10日批次的10个。期末估值＝20×130＋10×110＝3700日元，不能按最后进货单价给全部库存估值。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p35.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-79",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 79,
    "page": 35,
    "topicZh": "委托开发程序著作权",
    "stemJa": "A社は，B社と著作物の権利に関する特段の取決めをせず，A社の要求仕様に基づいて，販売管理システムのプログラム作成をB社に委託した。この場合のプログラム著作権の原始的帰属はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "A社とB社が話し合って決定する。"
      },
      {
        "label": "イ",
        "textJa": "A社とB社の共有となる。"
      },
      {
        "label": "ウ",
        "textJa": "A社に帰属する。"
      },
      {
        "label": "エ",
        "textJa": "B社に帰属する。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ，即B公司。题设明确A委托B按需求开发程序，双方没有特别约定权利归属；原始著作权原则上归实际创作程序的一方B，而不是仅提出需求或支付费用的一方A。若希望著作财产权转让给委托方，应在合同中另作明确约定。此题只回答2018年原卷所设的默认归属情境，不能凭“出钱的人拥有成果”的日常直觉选A。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p35.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-S-AM-80",
    "kind": "official",
    "year": 2018,
    "periodJa": "春期",
    "section": "AM",
    "number": 80,
    "page": 36,
    "topicZh": "劳动者派遣的指挥关系",
    "stemJa": "労働者派遣法に基づく，派遣先企業と労働者との関係(図の太線部分)はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "請負契約関係"
      },
      {
        "label": "イ",
        "textJa": "雇用関係"
      },
      {
        "label": "ウ",
        "textJa": "指揮命令関係"
      },
      {
        "label": "エ",
        "textJa": "労働者派遣契約関係"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ，即指揮命令関係。派遣劳动者与派遣元企业存在雇佣关系，派遣元与派遣先企业签劳动者派遣合同，而劳动者在派遣先日常工作时接受派遣先的业务指挥和命令。题目粗线连接的是派遣先与劳动者，因此对应指挥命令，而不是雇佣、承包或两公司之间的派遣合同。把三方关系画成三角形，再分别标每条边，便不易混淆。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fabr-att/2018h30h_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-s-am-p36.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-01",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 1,
    "page": 3,
    "topicZh": "十六进制小数换算",
    "stemJa": "16進数の小数0.248を10進数の分数で表したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "31/32"
      },
      {
        "label": "イ",
        "textJa": "31/125"
      },
      {
        "label": "ウ",
        "textJa": "31/512"
      },
      {
        "label": "エ",
        "textJa": "73/512"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。十六进制小数 0.248 表示 2×16 的负一次方、4×16 的负二次方、8×16 的负三次方相加。通分到 4096 后为 512/4096＋64/4096＋8/4096＝584/4096＝73/512。容易错在把小数点后的“248”按十进制 248 理解；每向右一位，位权应再除以 16。还可把每个十六进制位写成四位二进制检查。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-02",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 2,
    "page": 3,
    "topicZh": "位运算提取最低位",
    "stemJa": "次に示す手順は，列中の少なくとも一つは1であるビット列が与えられたとき，最も右にある1を残し，他のビットを全て0にするアルゴリズムである。例えば,00101000が与えられたとき,00001000が求まる。aに入る論理演算はどれか。 手順1 与えられたビット列Aを符号なしの2進数と見なし，Aから1を引き，結果をBとする。 手順2 AとBの排他的論理和(XOR)を求め，結果をCとする。 手順3 AとCの a を求め，結果をAとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "排他的論理和(XOR)"
      },
      {
        "label": "イ",
        "textJa": "否定論理積(NAND)"
      },
      {
        "label": "ウ",
        "textJa": "論理積(AND)"
      },
      {
        "label": "エ",
        "textJa": "論理和(OR)"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。按题给的例子逐步算：A＝00101000，A减1成为B＝00100111；A与B逐位异或得到C＝00001111。最后A与C逐位做AND，只有原本的最右侧1仍为1，结果00001000。一般情况下，减1会使最右侧1变0，并让其右边的0变1；异或恰好标出这些发生变化的位置，再与原A相交即可只保留那个1。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p03.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-03",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 3,
    "page": 3,
    "topicZh": "机器学习",
    "stemJa": "AIにおける機械学習の説明として，最も適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "記憶したデータから特定のパターンを見つけ出すなどの，人が自然に行っている学習能力をコンピュータにもたせるための技術"
      },
      {
        "label": "イ",
        "textJa": "コンピュータ，機械などを使って，生命現象や進化のプロセスを再現するための技術"
      },
      {
        "label": "ウ",
        "textJa": "特定の分野の専門知識をコンピュータに入力し，入力された知識を用いてコンピュータが推論する技術"
      },
      {
        "label": "エ",
        "textJa": "人が双方向学習を行うために，Webシステムなどの情報技術を用いて，教材や学習管理能力をコンピュータにもたせるための技術"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。机器学习是让计算机从已有数据中发现规律，并把学到的模式用于新的数据，例如从大量邮件学习识别垃圾邮件。它强调“从数据学习”，不必由人把每条判断规则逐一写死。イ说的是模拟生命与进化，ウ是把专家知识和推理规则输入系统的专家系统，エ是利用网络开展教学的电子学习。先抓住题干的“記憶したデータからパターン”这一线索。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-04",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 4,
    "page": 4,
    "topicZh": "哈夫曼编码与前缀",
    "stemJa": "出現頻度の異なるA，B，C，D，Eの5文字で構成される通信データを，ハフマン符号化を使って圧縮するために，符号表を作成した。aに入る符号として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "001"
      },
      {
        "label": "イ",
        "textJa": "010"
      },
      {
        "label": "ウ",
        "textJa": "101"
      },
      {
        "label": "エ",
        "textJa": "110"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ，即110。哈夫曼编码必须能够从左到右无歧义地切分，所以任何已分配字符的码字都不能成为另一个码字的前缀。原表中00、01、10和111已经分配；001以前缀00开头，010以前缀01开头，101以前缀10开头，都会产生歧义。110不以任何已有完整码字开头，也不是111的前缀，因此可填入空位。原表及编码串见原卷图。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p04.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-05",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 5,
    "page": 4,
    "topicZh": "队列先进先出",
    "stemJa": "待ち行列に対する操作を，次のとおり定義する。\nENQ n：待ち行列にデータnを挿入する。\nDEQ：待ち行列からデータを取り出す。\n空の待ち行列に対し，ENQ 1，ENQ 2，ENQ 3，DEQ，ENQ 4，ENQ 5，DEQ，ENQ 6，DEQ，DEQの操作を行った。次にDEQ操作を行ったとき，取り出されるデータはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "1"
      },
      {
        "label": "イ",
        "textJa": "2"
      },
      {
        "label": "ウ",
        "textJa": "5"
      },
      {
        "label": "エ",
        "textJa": "6"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ，即 5。队列遵守先进先出：先放入 1、2、3，第一次 DEQ 取走 1；再放入 4、5，第二次 DEQ 取走 2；放入 6 后两次 DEQ 依次取走 3 和 4。此时队首是 5，题目“次に DEQ”要的是下一次取出，因此为 5，而不是刚加入的 6。每步画出从队首到队尾的序列可以避免把队列误当成后进先出的栈。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-06",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 6,
    "page": 5,
    "topicZh": "快速排序",
    "stemJa": "クイックソートの処理方法を説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "既に整列済みのデータ列の正しい位置に、データを追加する操作を繰り返していく方法である。"
      },
      {
        "label": "イ",
        "textJa": "データ中の最小値を求め、次にそれを除いた部分の中から最小値を求める。 この操作を繰り返していく方法である。"
      },
      {
        "label": "ウ",
        "textJa": "適当な基準値を選び、それよりも小さな値のグループと大きな値のグループにデータを分割する。 同様にして、グループの中で基準値を選び、それぞれのグループを分割する。 この操作を繰り返していく方法である。"
      },
      {
        "label": "エ",
        "textJa": "隣り合ったデータの比較と入替えを繰り返すことによって、 小さな値のデータを次第に端の方に移していく方法である。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。快速排序先选一个基准值，把小于它和大于它的数据分成两组，然后对每组重复同样的步骤，直到组内不需再分。关键动作是“选基准、分组、递归处理”。ア是插入排序，把新数据插到已有有序序列的正确位置；イ反复取最小值是选择排序；エ反复比较相邻元素是冒泡排序。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-07",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 7,
    "page": 5,
    "topicZh": "编码规范与错误处理",
    "stemJa": "プログラムのコーディング規約に規定する事項のうち、適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "局所変数は、用途が異なる場合でもデータ型が同じならば、 できるだけ同一の変数を使うようにする。"
      },
      {
        "label": "イ",
        "textJa": "処理性能を向上させるために、ループの制御変数には浮動小数点型変数を使用する。"
      },
      {
        "label": "ウ",
        "textJa": "同様の計算を何度も繰り返すときは、関数の再帰呼び出しを用いる。"
      },
      {
        "label": "エ",
        "textJa": "領域割付け関数を使用するときは、割付けができなかったときの処理を記述する。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。内存分配可能失败，程序应检查返回结果并规定失败后的处理，否则继续访问无效区域可能导致异常或数据损坏。编码规范就是把这种应共同遵守的写法固定下来。ア把用途不同的局部变量混用会降低可读性；イ用浮点数作循环控制可能引入精度问题；ウ递归并非重复计算的通用性能优化办法。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-08",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 8,
    "page": 6,
    "topicZh": "Java 与垃圾回收",
    "stemJa": "Javaの特徴はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "オブジェクト指向言語であり、複数のスーパクラスを指定する多重継承が可能である。"
      },
      {
        "label": "イ",
        "textJa": "整数や文字は常にクラスとして扱われる。"
      },
      {
        "label": "ウ",
        "textJa": "ポインタ型があるので、メモリ上のアドレスを直接参照できる。"
      },
      {
        "label": "エ",
        "textJa": "メモリ管理のためのガーベージコレクションの機能がある。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。Java 运行环境有垃圾回收机制，会回收程序不再使用的对象所占内存；这并不表示开发者完全不用考虑资源释放。ア错误在于 Java 类不能指定多个父类作多重继承；イ把所有整数和字符都说成类也错，存在基本类型；ウ错误在于 Java 没有让程序直接操作任意内存地址的指针类型。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-09",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 9,
    "page": 6,
    "topicZh": "MIPS与平均时钟周期",
    "stemJa": "動作クロック周波数が700MHzのCPUで，命令の実行に必要なクロック数とその命令の出現率が表に示す値である場合，このCPUの性能は約何MIPSか。",
    "options": [
      {
        "label": "ア",
        "textJa": "10"
      },
      {
        "label": "イ",
        "textJa": "50"
      },
      {
        "label": "ウ",
        "textJa": "70"
      },
      {
        "label": "エ",
        "textJa": "100"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ，即约100 MIPS。先按原表的出现率计算每条指令平均使用的时钟数：4×0.3＋8×0.6＋10×0.1＝7。CPU每秒产生700百万个时钟周期，每条指令平均用7个周期，所以每秒约执行100百万条指令，即100 MIPS。MIPS的“百万”要与MHz的“百万”同时约去；不能只看最短或最长一类指令的周期数。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p06.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-10",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 10,
    "page": 6,
    "topicZh": "中断与程序计数器",
    "stemJa": "割込み処理の終了後に、割込みによって中断された処理を割り込まれた場所から再開するために、 割込み発生時にプロセッサが保存するものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "インデックスレジスタ"
      },
      {
        "label": "イ",
        "textJa": "データレジスタ"
      },
      {
        "label": "ウ",
        "textJa": "プログラムカウンタ"
      },
      {
        "label": "エ",
        "textJa": "命令レジスタ"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。程序计数器保存下一条要执行指令的位置；发生中断时，处理器要保留这个位置以及必要的状态，处理完中断后才能回到原程序的正确位置继续。索引寄存器主要辅助地址计算，数据寄存器存放数据，指令寄存器保存当前取出的指令，它们都不是本题要求的“恢复执行位置”的核心答案。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-11",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 11,
    "page": 7,
    "topicZh": "ECC 冗余位",
    "stemJa": "メモリのエラー検出及び訂正にECCを利用している。データバス幅2ⁿビットに対して冗長ビットがn＋2ビット必要なとき，128ビットのデータバス幅に必要な冗長ビットは何ビットか。",
    "options": [
      {
        "label": "ア",
        "textJa": "7"
      },
      {
        "label": "イ",
        "textJa": "8"
      },
      {
        "label": "ウ",
        "textJa": "9"
      },
      {
        "label": "エ",
        "textJa": "10"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ，即 9 位。题目给定 ECC 的冗余位数为 n＋2，且数据总线宽度为 2 的 n 次方位。128＝2 的 7 次方，所以 n＝7，代回公式得 7＋2＝9。不要把数据位数 128 直接代入 n，也不要只记住“多两位”而忘记先求指数。这里按题目给出的简化关系计算，不需要另外推导一般 ECC 编码公式。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-12",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 12,
    "page": 7,
    "topicZh": "USB 3.0",
    "stemJa": "USB 3.0の説明として、適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "1クロックで2ビットの情報を伝送する4対の信号線を使用し、 最大1Gビット／秒のスループットをもつインタフェースである。"
      },
      {
        "label": "イ",
        "textJa": "PCと周辺機器とを接続するATA仕様をシリアル化したものである。"
      },
      {
        "label": "ウ",
        "textJa": "音声、映像などに適したアイソクロナス転送を採用しており、 ブロードキャスト転送モードをもつシリアルインタフェースである。"
      },
      {
        "label": "エ",
        "textJa": "スーパースピードと呼ばれる5Gビット／秒のデータ転送モードをもつシリアルインタフェースである。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。题目考查的是当时 USB 3.0 的 SuperSpeed 模式，其标称传输速率为 5 Gbit/s，且属于串行接口。请留意“标称速率”不等于实际文件传输速度，协议开销和设备性能都会影响实测值。イ描述的是串行 ATA；ウ把其他接口的广播传输特征混入；ア给出的信号线与速率组合也不是 USB 3.0 的定义。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-13",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 13,
    "page": 8,
    "topicZh": "Web 与应用服务器分工",
    "stemJa": "Webシステムにおいて、Webサーバとアプリケーション（AP）サーバを異なる物理サーバに 配置する場合のメリットとして、適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "Webサーバにクライアントの実行環境が実装されているので、 リクエストのたびにクライアントとAPサーバの間で画面データをやり取りする必要がなく、 データ通信量が少なくて済む。"
      },
      {
        "label": "イ",
        "textJa": "Webブラウザの文字コード体系とAPサーバの文字コード体系の違いを Webサーバが吸収するので、文字化けが発生しない。"
      },
      {
        "label": "ウ",
        "textJa": "データへのアクセスを伴う業務ロジックは、 Webサーバのプログラムに配置されているので、業務ロジックの変更に伴って、 APサーバのプログラムを変更する必要がない。"
      },
      {
        "label": "エ",
        "textJa": "負荷が軽い静的コンテンツへのリクエストはWebサーバで処理し、 負荷が重い動的コンテンツへのリクエストはAPサーバで処理するように、 クライアントからのリクエストの種類に応じて処理を分担できる。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。把 Web 服务器与应用服务器放在不同物理机器时，可按请求性质分工：简单的静态文件由 Web 服务器处理，需要业务计算和数据访问的动态请求交给应用服务器。这样能分别配置和扩展两类负载。ア凭空假设客户端执行环境在 Web 服务器；イ不能保证自动解决字符编码问题；ウ把业务逻辑放到 Web 服务器，与题设分层相反。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-14",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 14,
    "page": 9,
    "topicZh": "容量规划步骤",
    "stemJa": "稼働状況が継続的に監視されているシステムがある。 稼働して数年後に新規業務をシステムに適用する場合に実施する、 キャパシティプランニングの作業項目の順序として、適切なものはどれか。\n〔キャパシティプランニングの作業項目〕\n①システムの構成の案について、適切なものかどうかを評価し、必要があれば見直しを行う。\n②システム特性に合わせて、サーバの台数、並列分散処理の実施の有無など、 必要なシステム構成の案を検討する。\n③システムの稼働状況から、ハードウェアの性能情報やシステム固有の環境を把握する。\n④利用者などに新規業務をヒアリングし、 想定される処理件数や処理に要する時間といったシステムに求められる要件を把握する。",
    "options": [
      {
        "label": "ア",
        "textJa": "③、②、④、①"
      },
      {
        "label": "イ",
        "textJa": "③、④、②、①"
      },
      {
        "label": "ウ",
        "textJa": "④、②、①、③"
      },
      {
        "label": "エ",
        "textJa": "④、③、①、②"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ，顺序是③→④→②→①。先调查已有系统的性能和运行环境，才知道当前资源基线；再访谈新业务的处理量和时间要求，明确新增负载；根据两方面资料设计服务器数量等配置；最后评估方案，必要时修改。若先选配置再收集需求，就无法判断方案能否满足新业务。题中“稼働状況が継続的に監視”说明可先利用现有监测信息。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-15",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 15,
    "page": 9,
    "topicZh": "串并联系统可用率",
    "stemJa": "東京と福岡を結ぶ実線の回線がある。東京と福岡の間の信頼性を向上させるために，大阪を経由する破線の迂回回線を追加した。迂回回線追加後における，東京と福岡の間の稼働率は幾らか。ここで，回線の稼働率は，東京と福岡，東京と大阪，大阪と福岡の全てが0.9とする。",
    "options": [
      {
        "label": "ア",
        "textJa": "0.729"
      },
      {
        "label": "イ",
        "textJa": "0.810"
      },
      {
        "label": "ウ",
        "textJa": "0.981"
      },
      {
        "label": "エ",
        "textJa": "0.999"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ，即0.981。东京到福冈的直达线路可用率为0.9；经大阪的两段线路都要正常才通，因此旁路可用率为0.9×0.9＝0.81。两条路径只要任一条可用，整体就可用，反过来算“全部不可用”的概率为(1－0.9)×(1－0.81)＝0.019，再用1减掉它得到0.981。串联乘可用率，并联用失效概率相乘。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p09.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-16",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 16,
    "page": 10,
    "topicZh": "优先级调度时间轴",
    "stemJa": "三つのタスクの優先度と，各タスクを単独で実行した場合のCPUと入出力装置(I/O)の動作順序と処理時間は，表のとおりである。優先度方式のタスクスケジューリングを行うOSの下で，三つのタスクが同時に実行可能状態になってから，全てのタスクの実行が終了するまでの，CPUの遊休時間は何ミリ秒か。ここで，CPUは1個であり，1CPUは1コアで構成され，I/Oは競合せず，OSのオーバーヘッドは考慮しないものとする。また，表の（ ）内の数字は処理時間を示すものとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "2"
      },
      {
        "label": "イ",
        "textJa": "3"
      },
      {
        "label": "ウ",
        "textJa": "4"
      },
      {
        "label": "エ",
        "textJa": "5"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ，即3毫秒。先根据原表中各任务的优先级、CPU段与I/O段，沿时间轴安排：可运行任务里始终让优先级最高者占CPU；进入I/O期间该任务暂不占CPU，其他可运行任务可继续。逐段追踪后，CPU在6～8毫秒空闲2毫秒，又在10～11毫秒空闲1毫秒，合计3毫秒。I/O无竞争意味着并行的I/O不必排队；不能把I/O时间全都加为CPU空闲。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p10.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-17",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 17,
    "page": 10,
    "topicZh": "假脱机处理",
    "stemJa": "スプーリング機能の説明として、適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "あるタスクを実行しているときに、入出力命令の実行によってCPUが遊休（アイドル） 状態になると、他のタスクにCPUを割り当てる。"
      },
      {
        "label": "イ",
        "textJa": "実行中のプログラムを一時中断して、制御プログラムに制御を移す。"
      },
      {
        "label": "ウ",
        "textJa": "主記憶装置と低速の入出力装置との間のデータ転送を、 補助記憶装置を介して行うことによって、システム全体の処理能力を高める。"
      },
      {
        "label": "エ",
        "textJa": "多数のバッファから成るバッファプールを用意し、 主記憶装置にあるバッファにアクセスする確率を上げることによって、 補助記憶装置のアクセス時間を短縮する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。假脱机把主存与打印机等慢速输入输出设备之间的数据暂存到磁盘等辅助存储，应用程序可以先交出数据继续运行，由后台按设备速度处理，从而减少等待并提高整体吞吐。ア描述的是 CPU 调度，イ是中断控制，エ偏向缓冲池和缓存命中；它们都没有“借助辅助存储协调慢速设备”这个关键特征。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-18",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 18,
    "page": 11,
    "topicZh": "轮转调度",
    "stemJa": "スケジューリングに関する記述のうち、ラウンドロビン方式の説明として、適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "各タスクに、均等にCPU時間を割り当てて実行させる方式である。"
      },
      {
        "label": "イ",
        "textJa": "各タスクに、ターンアラウンドタイムに比例したCPU時間を割り当てて実行させる方式である。"
      },
      {
        "label": "ウ",
        "textJa": "各タスクの実行イベント発生に応じて、リアルタイムに実行させる方式である。"
      },
      {
        "label": "エ",
        "textJa": "各タスクを、優先度の高い順に実行させる方式である。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。轮转法把 CPU 时间切成时间片，让就绪任务依次获得相同长度的运行机会；时间片用完还没结束的任务回到队列等待下一轮。因此它强调公平轮流，而不是按任务的总耗时、实时事件或优先级分配。イ与周转时间挂钩，ウ描述实时响应，エ是优先级调度。理解“round robin”就是按顺序轮一圈。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-19",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 19,
    "page": 11,
    "topicZh": "编译器处理顺序",
    "stemJa": "手続型言語のコンパイラが行う処理のうち、最初に行う処理はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "意味解析"
      },
      {
        "label": "イ",
        "textJa": "構文解析"
      },
      {
        "label": "ウ",
        "textJa": "最適化"
      },
      {
        "label": "エ",
        "textJa": "字句解析"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。编译器最先把源代码字符流切成关键字、标识符、数字等记号，这一步叫词法分析。随后才把记号组成符合语法的结构，即语法分析；再检查变量类型、名称等意义，即语义分析；优化通常更靠后。若尚未分出词，就无法可靠地分析句法或语义，因此ア、イ、ウ都不是最先一步。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-20",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 20,
    "page": 11,
    "topicZh": "链接器",
    "stemJa": "リンカの機能として、適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "作成したプログラムをライブラリに登録する。"
      },
      {
        "label": "イ",
        "textJa": "実行に先立ってロードモジュールを主記憶にロードする。"
      },
      {
        "label": "ウ",
        "textJa": "相互参照の解決などを行い、複数の目的モジュールなどから一つのロードモジュールを生成する。"
      },
      {
        "label": "エ",
        "textJa": "プログラムの実行を監視し、ステップごとに実行結果を記録する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。编译后得到的多个目标模块可能互相调用函数或引用数据，链接器负责解析这些相互引用，并把模块和所需库组合成可装载的模块。它解决的是“这些模块怎样接成一个程序”。ア是库管理动作；イ把模块载入内存是装载器的工作；エ逐步监控执行更接近调试器，不是链接器。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-21",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 21,
    "page": 12,
    "topicZh": "DRAM 与刷新",
    "stemJa": "DRAMの説明として、適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "1バイト単位でデータの消去及び書込みが可能な不揮発性のメモリであり、 電源遮断時もデータ保持が必要な用途に用いられる。"
      },
      {
        "label": "イ",
        "textJa": "不揮発性のメモリでNAND型又はNOR型があり、SSDに用いられる。"
      },
      {
        "label": "ウ",
        "textJa": "メモリセルはフリップフロップで構成され、キャッシュメモリに用いられる。"
      },
      {
        "label": "エ",
        "textJa": "リフレッシュ動作が必要なメモリであり、PCの主記憶として用いられる。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。DRAM 用电容保存每一位，电荷会逐渐泄漏，所以需要周期性刷新；容量和成本特点使它常用作 PC 主存。ウ说的由触发器构成、用于高速缓存的是 SRAM。イ的 NAND/NOR 和 SSD 指向闪存，它不依靠刷新且断电仍能保存数据；ア也描述非易失存储。先看“是否刷新、是否断电保存”最容易区分。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-22",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 22,
    "page": 12,
    "topicZh": "用二输入NAND搭四输入NAND",
    "stemJa": "2入力NAND素子を用いて4入力NAND回路を構成したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "原問題画像の選択肢ア（回路図を参照）"
      },
      {
        "label": "イ",
        "textJa": "原問題画像の選択肢イ（回路図を参照）"
      },
      {
        "label": "ウ",
        "textJa": "原問題画像の選択肢ウ（回路図を参照）"
      },
      {
        "label": "エ",
        "textJa": "原問題画像の選択肢エ（回路図を参照）"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。NAND对两个输入先做AND再取反；需要的四输入NAND是¬(A∧B∧C∧D)，四个输入全为1时才输出0。看原卷的四幅电路，イ先把两两输入合并，并利用输入短接的NAND当作反相器，最后合成¬((A∧B)∧(C∧D))。可用全1输入检查，再用包含0的输入排除其他候选；仅看门的数量或外形并不能确定逻辑功能。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p12.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-23",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 23,
    "page": 12,
    "topicZh": "一次电池与二次电池",
    "stemJa": "二次電池（充電式電池）はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "アルカリマンガン乾電池"
      },
      {
        "label": "イ",
        "textJa": "酸化銀電池"
      },
      {
        "label": "ウ",
        "textJa": "燃料電池"
      },
      {
        "label": "エ",
        "textJa": "リチウムイオン電池"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。二次电池指可以通过充电反复使用的电池，锂离子电池是典型例子。碱性锰干电池和氧化银电池通常作为一次电池使用，电量耗尽后不按普通充电电池方式补充；燃料电池通过持续供应燃料和氧化剂发电，不属于题目所说的可充电二次电池。判断时抓住“充電式”而不是是否能持续供电。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-24",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 24,
    "page": 13,
    "topicZh": "自然语言界面",
    "stemJa": "列車の予約システムにおいて、人間とコンピュータが音声だけで次のようなやり取りを行う。 この場合に用いられるインタフェースの種類はどれか。\n〔凡例〕\nP：人間\nC:コンピュータ\nP：“5月28日の名古屋駅から東京駅までをお願いします。”\nC：“ご乗車人数をどうぞ。”\nP：“大人2名でお願いします。”\nC：“ご希望の発車時刻をどうぞ。”\nP：“午前9時頃を希望します。”\nC：“午前9時3分発、午前10時43分着の列車ではいかがでしょうか。”\nP：“それでお願いします。”\nC：“確認します。大人2名で、5月28日の名古屋駅午前9時3分発、東京駅午前10時43分着の列車でよろしいでしょうか。”\nP：“はい。”",
    "options": [
      {
        "label": "ア",
        "textJa": "感性インタフェース"
      },
      {
        "label": "イ",
        "textJa": "自然言語インタフェース"
      },
      {
        "label": "ウ",
        "textJa": "ノンバーバルインタフェース"
      },
      {
        "label": "エ",
        "textJa": "マルチモーダルインタフェース"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。例子中人和系统用普通日语对话表达出发地、人数、时间，系统也用自然语言追问和确认，因而是自然语言界面。题干明确只有声音，但“声音”只是输入输出媒介，真正的分类依据是可理解日常语言。ノンバーバル指非语言线索；マルチモーダル通常结合多种输入输出形式；感性界面侧重人的情绪或感受。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-25",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 25,
    "page": 13,
    "topicZh": "抗锯齿",
    "stemJa": "液晶ディスプレイなどの表示装置において、傾いた直線の境界を滑らかに表示する手法はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "アンチエイリアシング"
      },
      {
        "label": "イ",
        "textJa": "シェーディング"
      },
      {
        "label": "ウ",
        "textJa": "テクスチャマッピング"
      },
      {
        "label": "エ",
        "textJa": "バンプマッピング"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。斜线在由方形像素组成的屏幕上容易出现台阶状边缘；抗锯齿通过调整边界附近像素的颜色或亮度，让视觉上的过渡更平滑。シェーディング处理物体明暗，テクスチャマッピング把纹理贴到表面，バンプマッピング模拟表面凹凸。看到“傾いた直線の境界を滑らかに”就应想到边缘平滑。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-26",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 26,
    "page": 14,
    "topicZh": "UML多重度",
    "stemJa": "UMLを用いて表した図のデータモデルのa，bに入れる多重度はどれか。 〔条件〕 部門には1人以上の社員が所属する。 社員はいずれか一つの部門に所属する。 社員が部門に所属した履歴を所属履歴として記録する。",
    "options": [
      {
        "label": "ア",
        "textJa": "a：0..*，b：0..*"
      },
      {
        "label": "イ",
        "textJa": "a：0..*，b：1..*"
      },
      {
        "label": "ウ",
        "textJa": "a：1..*，b：0..*"
      },
      {
        "label": "エ",
        "textJa": "a：1..*，b：1..*"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ，即a和b都为1..*。多重度写在关联的一端，表示另一端的一个对象能对应这里多少个对象。原图中一个部门有一人以上员工，因而至少存在一条对应的所属履历，a至少为1；一个员工必属于某个部门，故至少有一条履历，调部门时会增加履历，b可以有多条。1..*表示一条或多条，0..*允许零条，与题设“所属”条件不合。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p14.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-27",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 27,
    "page": 15,
    "topicZh": "数据项命名规范的边界",
    "stemJa": "データ項目の命名規約を設ける場合，次の命名規約だけでは回避できない事象はどれか。 〔命名規約〕 データ項目名の末尾には必ず\"名\"，\"コード\"，\"数\"，\"金額\"，\"年月日\"などの区分語を付与し，区分語ごとに定めたデータ型にする。 データ項目名と意味を登録した辞書を作成し，異音同義語や同音異義語が発生しないようにする。",
    "options": [
      {
        "label": "ア",
        "textJa": "データ項目\"受信年月日\"のデータ型として，日付型と文字列型が混在する。"
      },
      {
        "label": "イ",
        "textJa": "データ項目\"受注金額\"の取り得る値の範囲がテーブルによって異なる。"
      },
      {
        "label": "ウ",
        "textJa": "データ項目\"賞与金額\"と同じ意味で\"ボーナス金額\"というデータ項目がある。"
      },
      {
        "label": "エ",
        "textJa": "データ項目\"取引先\"が，\"取引先コード\"か\"取引先名\"か，判別できない。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。题设规则规定词尾区分语对应的数据类型，并用字典统一名称和意义，因此能防止同名不同型、同义不同名及含糊的“取引先”。但数据类型相同并不等于允许的数值范围相同：两个表的“受注金額”都可能是金额型，却一个只允许小额、另一个允许大额。数值范围需要另设约束、检查规则或字段定义，单靠命名规范推不出来。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p15.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-28",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 28,
    "page": 15,
    "topicZh": "关系代数的选择与投影",
    "stemJa": "関係XとYを自然結合した後，関係Zを得る関係代数演算はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "射影と和"
      },
      {
        "label": "イ",
        "textJa": "選択"
      },
      {
        "label": "ウ",
        "textJa": "選択と射影"
      },
      {
        "label": "エ",
        "textJa": "選択と和"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。先按共同属性“学部コード”自然连接关系X和Y，得到同时含学生资料与学部名称的行。再观察原卷中的关系Z：它只留下学部代码为B的行，这一步是“选择”，即筛行；同时只保留学生番号、氏名和学部名等列，这一步是“投影”，即选列。自然连接本身不会自动消除其他学部的行，也不会只留下指定列；并集用于合并同结构关系，此处不需要。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p15.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-29",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 29,
    "page": 16,
    "topicZh": "数据库锁粒度",
    "stemJa": "ロックの粒度に関する説明のうち、適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "データを更新するときに、粒度を大きくすると、 他のトランザクションの待ちが多くなり、全体のスループットが低下する。"
      },
      {
        "label": "イ",
        "textJa": "同一のデータを更新するトランザクション数が多いときに、 粒度を大きくすると、同時実行できるトランザクション数が増える。"
      },
      {
        "label": "ウ",
        "textJa": "表の全データを参照するときに、粒度を大きくすると、 他のトランザクションのデータ参照を防げないようにできる。"
      },
      {
        "label": "エ",
        "textJa": "粒度を大きくすると、含まれるデータ数が多くなるので、 一つのトランザクションでかけるロックの個数が大きくなる。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。锁粒度大表示一次锁住的范围更广，例如锁整张表而非一行；更新时其他事务更容易碰到被锁数据，只能等待，整体吞吐可能下降。反过来，细粒度有利于并发，但要管理更多锁。イ说并发会增加，方向相反；ウ说不能阻止其他事务访问也不对；エ把“大范围锁”误说成锁的个数增加，实际可能减少个数。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-30",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 30,
    "page": 16,
    "topicZh": "数据库前滚恢复",
    "stemJa": "データベースが格納されている記憶媒体に故障が発生した場合、 バックアップファイルとログを用いてデータベースを回復する操作はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "アーカイブ"
      },
      {
        "label": "イ",
        "textJa": "コミット"
      },
      {
        "label": "ウ",
        "textJa": "チェックポイントダンプ"
      },
      {
        "label": "エ",
        "textJa": "ロールフォワード"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。存储介质故障后，先用备份还原出较早的数据库，再按日志中已完成的更新顺序向前重放，把状态推进到故障前尽可能近的位置，这叫ロールフォワード。ア是归档，イ是提交事务，ウ是生成检查点相关转储；它们都不能单独概括“备份加日志向前重做”。注意与回滚未提交事务的方向不同。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-31",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 31,
    "page": 16,
    "topicZh": "传输时间与有效速率",
    "stemJa": "1.5 Mビット／秒の伝送路を用いて12 Mバイトのデータを転送するのに必要な伝送時間は何秒か。ここで，伝送路の伝送効率を50%とする。",
    "options": [
      {
        "label": "ア",
        "textJa": "16"
      },
      {
        "label": "イ",
        "textJa": "32"
      },
      {
        "label": "ウ",
        "textJa": "64"
      },
      {
        "label": "エ",
        "textJa": "128"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ，即 128 秒。先统一单位：12 M 字节乘每字节 8 位，是 96 M 位。线路标称为每秒 1.5 M 位，效率 50% 后实际有效数据速率只有每秒 0.75 M 位。传输时间＝数据量÷有效速率＝96÷0.75＝128 秒。常见错误是把字节和位直接相除，或只用标称速率而忘记乘传输效率。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-32",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 32,
    "page": 17,
    "topicZh": "LAN 中继设备",
    "stemJa": "LAN間接続装置に関する記述のうち，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "ゲートウェイは，OSI基本参照モデルにおける第1～3層だけのプロトコルを変換する。"
      },
      {
        "label": "イ",
        "textJa": "ブリッジは，IPアドレスを基にしてフレームを中継する。"
      },
      {
        "label": "ウ",
        "textJa": "リピータは，同種のセグメント間で信号を増幅することによって伝送距離を延長する。"
      },
      {
        "label": "エ",
        "textJa": "ルータは，MACアドレスを基にしてフレームを中継する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。中继器在物理层对变弱的信号进行再生、整形或放大，因而可在相同类型网段之间延长可传输距离。网桥按 MAC 地址转发帧，不按 IP 地址；路由器主要根据 IP 等网络层信息选择转发路径，不根据 MAC 地址作本题所述判断；网关也不能简单概括为只转换 OSI 第 1～3 层的协议。先分清物理、数据链路、网络三个层次。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-33",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 33,
    "page": 17,
    "topicZh": "DNS",
    "stemJa": "TCP/IPネットワークでDNSが果たす役割はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "PCやプリンタなどからのIPアドレス付与の要求に対して、 サーバに登録してあるIPアドレスの中から使用されていないIPアドレスを割り当てる。"
      },
      {
        "label": "イ",
        "textJa": "サーバにあるプログラムを、サーバのIPアドレスを意識することなく、 プログラム名の指定だけで呼び出すようにする。"
      },
      {
        "label": "ウ",
        "textJa": "社内のプライベートIPアドレスをグローバルIPアドレスに変換し、 インターネットへのアクセスを可能にする。"
      },
      {
        "label": "エ",
        "textJa": "ドメイン名やホスト名などとIPアドレスを対応付ける。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。DNS 把人容易记住的域名或主机名映射到网络通信使用的 IP 地址，应用访问网站时常先查询名称对应的地址。ア按请求分配可用 IP 更接近 DHCP；ウ把私有地址转换为公网地址是 NAT；イ描述按程序名调用服务，不是 DNS 的核心作用。记忆口诀是“名字找地址”，而不是“分配地址”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-34",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 34,
    "page": 17,
    "topicZh": "电子邮件 MIME",
    "stemJa": "インターネットにおける電子メールの規約で、ヘッダフィールドの拡張を行い、 テキストだけでなく、音声、画像なども扱えるようにしたものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "HTML"
      },
      {
        "label": "イ",
        "textJa": "MHS"
      },
      {
        "label": "ウ",
        "textJa": "MIME"
      },
      {
        "label": "エ",
        "textJa": "SMTP"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。MIME 扩展邮件头部并定义内容类型、编码和多部分结构，使邮件除了纯文本还能承载图片、声音等内容。SMTP 负责邮件传送，不负责把多媒体表示成邮件内容；HTML 是网页标记语言；MHS 是另一类消息处理系统名称。看到邮件中的 Content-Type、附件或多部分正文，就应联想到 MIME。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-35",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 35,
    "page": 18,
    "topicZh": "LTE 通信",
    "stemJa": "携帯電話網で使用される通信規格の名称であり、次の三つの特徴をもつものはどれか。\n  (1) 全ての通信をパケット交換方式で処理する。\n  (2) 複数のアンテナを使用するMIMOと呼ばれる通信方式が利用可能である。\n  (3) 国際標準化プロジェクト3GPP（3rd Generation Partnership Project）で標準化されている。",
    "options": [
      {
        "label": "ア",
        "textJa": "LTE（Long Term Evolution）"
      },
      {
        "label": "イ",
        "textJa": "MAC（Media Access Control）"
      },
      {
        "label": "ウ",
        "textJa": "MDM（Mobile Device Management）"
      },
      {
        "label": "エ",
        "textJa": "VoIP（Voice over Internet Protocol）"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。题目给出的三个线索是分组交换、可使用多天线的 MIMO，以及由 3GPP 标准化；在这组选项中共同指向 LTE。MAC 是媒体访问控制概念，MDM 是移动设备管理，VoIP 是借网络传语音的技术，都不是这里的蜂窝移动通信制式。此题属于 2018 年原卷，学习时要把它当作当年技术术语题。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-36",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 36,
    "page": 18,
    "topicZh": "软件数字签名",
    "stemJa": "アプリケーションソフトウェアにディジタル署名を施す目的はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "アプリケーションソフトウェアの改ざんを利用者が検知できるようにする。"
      },
      {
        "label": "イ",
        "textJa": "アプリケーションソフトウェアの使用を特定の利用者に制限する。"
      },
      {
        "label": "ウ",
        "textJa": "アプリケーションソフトウェアの著作権が作成者にあることを証明する。"
      },
      {
        "label": "エ",
        "textJa": "アプリケーションソフトウェアの利用者による修正や改変を不可能にする。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。发布者对软件作数字签名，用户可用相应公钥验证签名；如果软件内容被篡改，验证就不能按原签名通过，因此可检测完整性问题。签名也有助于验证签名者身份，但不等于限制谁能使用软件。イ是访问控制问题，ウ不能单凭签名解决版权归属的全部法律问题，エ更不可能阻止别人修改文件本身。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-37",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 37,
    "page": 18,
    "topicZh": "AES-256 密钥穷举",
    "stemJa": "AES-256で暗号化されていることが分かっている暗号文が与えられているとき，ブルートフォース攻撃で鍵と解読した平文を得るまでに必要な試行回数の最大値はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "256"
      },
      {
        "label": "イ",
        "textJa": "2¹²⁸"
      },
      {
        "label": "ウ",
        "textJa": "2²⁵⁵"
      },
      {
        "label": "エ",
        "textJa": "2²⁵⁶"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ，即 2 的 256 次方。AES-256 的“256”指密钥长度为 256 位，每一位可取 0 或 1，两种选择相乘 256 次，候选密钥总数是 2^256。题问最坏情况下得到密钥前需要尝试的最大次数，可能要试遍全部候选。2^255 可近似理解为平均尝试次数的量级，而不是最坏上限；256 只是位数，不是候选数。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-38",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 38,
    "page": 19,
    "topicZh": "对称密钥加密",
    "stemJa": "共通鍵暗号方式の特徴はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "暗号化通信に使用する場合、鍵を相手と共有する必要があり、事前に平文で送付することが推奨されている。"
      },
      {
        "label": "イ",
        "textJa": "暗号化通信をする相手が1人の場合、使用する鍵の個数は公開鍵暗号方式よりも多い。"
      },
      {
        "label": "ウ",
        "textJa": "同じ程度の暗号強度を持つ鍵長を選んだ場合、公開鍵暗号方式と比較して、暗号化や復号に必要な時間が短い。"
      },
      {
        "label": "エ",
        "textJa": "鍵のペアを生成し、一方の鍵で文書を暗号化すると、他方の鍵でだけ復号することができる。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。共通鍵暗号方式即对称密钥加密，通信双方使用同一把秘密密钥；在相近安全强度下，其加解密通常比公钥方式更快，适合加密大量数据。ア错在建议明文发送密钥，密钥一旦泄漏就失去保密性。イ一个通信对象时不需要比公钥方式更多钥匙。エ的一对不同钥匙分别加密解密是公钥密码的特征。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-39",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 39,
    "page": 19,
    "topicZh": "真实性与可靠性",
    "stemJa": "JIS Q 27000:2014（情報セキュリティマネジメントシステム－用語）における真正性及び信頼性に対する定義a～dの組みのうち，適切なものはどれか。\n〔定義〕\na　意図する行動と結果とが一貫しているという特性\nb　エンティティは，それが主張するとおりのものであるという特性\nc　認可されたエンティティが要求したときに，アクセス及び使用が可能であるという特性\nd　認可されていない個人，エンティティ又はプロセスに対して，情報を使用させず，また，開示しないという特性",
    "options": [
      {
        "label": "ア",
        "textJa": "真正性：a，信頼性：c"
      },
      {
        "label": "イ",
        "textJa": "真正性：b，信頼性：a"
      },
      {
        "label": "ウ",
        "textJa": "真正性：b，信頼性：d"
      },
      {
        "label": "エ",
        "textJa": "真正性：d，信頼性：a"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ，即真正性对应b，信頼性对应a。原卷引用JIS Q 27000:2014，b说实体确为其所声称的身份，是“真实性”；a说预期的行为与结果一致，是“可靠性”。c强调获授权者需要时能够访问，属于可用性；d强调不向未授权方泄露，属于机密性。四个术语只差几个字，但判别时可分别抓“身份、结果一致、可访问、不泄露”这些关键词。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p19.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-40",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 40,
    "page": 20,
    "topicZh": "CSIRT 材料",
    "stemJa": "組織的なインシデント対応体制の構築や運用を支援する目的でJPCERT/CCが作成したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "CSIRTマテリアル"
      },
      {
        "label": "イ",
        "textJa": "ISMSユーザーズガイド"
      },
      {
        "label": "ウ",
        "textJa": "証拠保全ガイドライン"
      },
      {
        "label": "エ",
        "textJa": "組織における内部不正防止ガイドライン"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。题目限定了“JPCERT/CC 制作”和“支援组织建立、运营事件响应体制”两个条件，符合 CSIRT マテリアル。CSIRT 是处理网络安全事件的团队，材料用于规划职责和运作方式。ISMS 用户指南、证据保全指南和内部不正防止指南分别关注管理体系、取证和内部风险，名称与本题的 CSIRT 体制建设目的不同。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-41",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 41,
    "page": 20,
    "topicZh": "僵尸网络指挥控制",
    "stemJa": "ボットネットにおけるC＆Cサーバの役割として、適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "Webサイトのコンテンツをキャッシュし、本来のサーバに代わってコンテンツを利用することによって、 ネットワークやサーバの負荷を軽減する。"
      },
      {
        "label": "イ",
        "textJa": "外部からインターネットを経由して社内ネットワークにアクセスする際に、 CHAPなどのプロトコルを用いることによって、利用者認証時のパスワードの盗聴を防止する。"
      },
      {
        "label": "ウ",
        "textJa": "外部からインターネットを経由して社内ネットワークにアクセスする際に、 チャレンジレスポンス方式を採用したワンタイムパスワードを用いることによって、 利用者認証時のパスワードの盗聴を防止する。"
      },
      {
        "label": "エ",
        "textJa": "侵入して乗っ取ったコンピュータに対して、 他のコンピュータへの攻撃などの不正な操作をするよう、 外部から命令を出したり応答を受け取ったりする。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。C&C 是 Command and Control，即指挥控制。攻击者通过该服务器向已被控制的主机下达攻击、发送垃圾邮件等命令，并接收执行结果或状态。ア是内容缓存服务器；イ和ウ谈的是远程访问时的认证与防窃听，均不负责指挥被感染设备。理解僵尸网络时可区分“被控制的机器”和“发号施令的服务器”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-42",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 42,
    "page": 21,
    "topicZh": "入侵检测系统 IDS",
    "stemJa": "IDSの機能はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "PCにインストールされているソフトウェア製品が最新のバージョンであるかどうかを確認する。"
      },
      {
        "label": "イ",
        "textJa": "検査対象の製品にテストデータを送り、製品の応答や挙動から脆弱性を検出する。"
      },
      {
        "label": "ウ",
        "textJa": "サーバやネットワークを監視し、侵入や障害を検知した場合に管理者へ通知する。"
      },
      {
        "label": "エ",
        "textJa": "情報システムの運用状況などの情報セキュリティ対策状況と企業情報を入力し、 組織の情報セキュリティへの取組み状況を自己診断する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。IDS 会观察服务器或网络的活动，发现可疑入侵或异常后向管理员告警；它的关键词是“监测与通知”。ア是软件版本检查，イ是主动探测产品弱点的漏洞扫描，エ是组织安全措施的自评。IDS 不应被误记成一定会自动阻断攻击，自动阻断更常与 IPS 等机制关联。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-43",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 43,
    "page": 21,
    "topicZh": "安全启动",
    "stemJa": "セキュアブートの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "BIOSにパスワードを設定し、PC起動時にBIOSのパスワード入力を要求することによって、 OSの不正な起動を防ぐ技術"
      },
      {
        "label": "イ",
        "textJa": "HDDにパスワードを設定し、PC起動時にHDDのパスワード入力を要求することによって、 OSの不正な起動を防ぐ技術"
      },
      {
        "label": "ウ",
        "textJa": "PCの起動時にOSやドライバのディジタル署名を検証し、 許可されていないものを実行しないようにすることによって、 OS起動前のマルウェアの実行を防ぐ技術"
      },
      {
        "label": "エ",
        "textJa": "マルウェア対策ソフトをスタートアッププログラムに登録し、 OS起動時に自動的にマルウェアスキャンを行うことによって、マルウェアの被害を防ぐ技術"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。安全启动在计算机开机的早期阶段验证操作系统、驱动等启动组件的数字签名，只让被允许的组件继续执行，从而降低启动链被恶意代码替换的风险。ア和イ只是启动口令或磁盘口令，不能核验启动代码本身；エ要等操作系统启动后才运行杀毒扫描，无法替代启动前的完整性检查。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-44",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 44,
    "page": 22,
    "topicZh": "公共无线局域网终端隔离",
    "stemJa": "公衆無線LANのアクセスポイントを設置するときのセキュリティ対策と効果の組みのうち，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "MACアドレスフィルタリングを設定する。／正規の端末のMACアドレスに偽装した攻撃者の端末からの接続を遮断し，利用者のなりすましを防止する。"
      },
      {
        "label": "イ",
        "textJa": "SSIDを暗号化する。／SSIDを秘匿して，SSIDの盗聴を防止する。"
      },
      {
        "label": "ウ",
        "textJa": "自社がレジストラに登録したドメインを，アクセスポイントのSSIDに設定する。／正規のアクセスポイントと同一のSSIDを設定した，悪意のあるアクセスポイントの設置を防止する。"
      },
      {
        "label": "エ",
        "textJa": "同一のアクセスポイントに無線で接続している端末同士の通信を，アクセスポイントで遮断する。／同一のアクセスポイントに無線で接続している他の端末に，公衆無線LANの利用者がアクセスポイントを経由して無断でアクセスすることを防止する。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。原卷表中エ的措施是在接入点阻断同一接入点下无线终端之间的通信，效果是阻止其他同网用户经接入点访问自己的终端，二者确实对应。MAC地址可以被伪装，过滤不能保证拦下冒充者；SSID本身不是通过“加密SSID”来保密；把自家注册域名写成SSID也不能阻止攻击者设置同名热点。公共Wi-Fi多人共用时，终端隔离尤其有用。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p22.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-45",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 45,
    "page": 23,
    "topicZh": "邮件服务器第三方中继",
    "stemJa": "自社の中継用メールサーバで，接続元IPアドレス，電子メールの送信者のメールアドレスのドメイン名，及び電子メールの受信者のメールアドレスのドメイン名から成るログを取得するとき，外部ネットワークからの第三者中継と判断できるログはどれか。ここで，AAA.168.1.5 と AAA.168.1.10 は自社のグローバルIPアドレスとし，BBB.45.67.89 と BBB.45.67.90 は社外のグローバルIPアドレスとする。a.b.c は自社のドメイン名とし，a.b.d と a.b.e は他社のドメイン名とする。また，IPアドレスとドメイン名は詐称されていないものとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "接続元AAA.168.1.5／送信者a.b.c／受信者a.b.d"
      },
      {
        "label": "イ",
        "textJa": "接続元AAA.168.1.10／送信者a.b.c／受信者a.b.c"
      },
      {
        "label": "ウ",
        "textJa": "接続元BBB.45.67.89／送信者a.b.d／受信者a.b.e"
      },
      {
        "label": "エ",
        "textJa": "接続元BBB.45.67.90／送信者a.b.d／受信者a.b.c"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。所谓第三方中继，是外部来源把邮件交给本公司服务器，再让它转给另一个外部域；本公司既非发送方也非收件方。原表ウ的连接IP为BBB.45.67.89，属于外部；发送域a.b.d和接收域a.b.e也都是外部，所以符合。エ虽然外部来源且发件域外部，但收件域a.b.c是本公司，属于投递到本公司的邮件；ア、イ连接源则为本公司。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p23.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-46",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 46,
    "page": 23,
    "topicZh": "UML交互图共同元素",
    "stemJa": "UML2.0のシーケンス図とコミュニケーション図のどちらにも表現されるものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "イベントとオブジェクトの状態"
      },
      {
        "label": "イ",
        "textJa": "オブジェクトがある状態にとどまる最短時間及び最長時間"
      },
      {
        "label": "ウ",
        "textJa": "オブジェクトがメッセージを処理している期間"
      },
      {
        "label": "エ",
        "textJa": "オブジェクト間で送受信されるメッセージ"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。时序图和通信图都描述对象之间如何交互，因此都要表现对象间发送和接收的消息。时序图着重时间顺序和生命线，通信图着重对象之间的连接及编号；表达视角不同，但消息这一核心内容相同。对象停留在某状态的最短或最长时间属于时间约束，消息处理持续期并非两类图必备共同元素，题目问的是“どちらにも”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p23.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-47",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 47,
    "page": 24,
    "topicZh": "类与实例",
    "stemJa": "オブジェクト指向におけるクラスとインスタンスとの関係のうち、適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "インスタンスはクラスの仕様を定義したものである。"
      },
      {
        "label": "イ",
        "textJa": "クラスの定義に基づいてインスタンスが生成される。"
      },
      {
        "label": "ウ",
        "textJa": "一つのインスタンスに対して、複数のクラスが対応する。"
      },
      {
        "label": "エ",
        "textJa": "一つのクラスに対して、インスタンスはただ一つ存在する。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。类描述对象共有的属性和操作，实例是按类定义实际创建的具体对象；例如“学生”类可以创建多个不同学生实例。ア把类和实例颠倒；ウ说一个实例对应多个类，不符合本题的基本关系；エ把一类限制为唯一实例也错，单例是额外设计约束，普通类可以有很多实例。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-48",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 48,
    "page": 24,
    "topicZh": "模块数据耦合",
    "stemJa": "モジュール間の情報の受渡しがパラメタだけで行われる、 結合度が最も弱いモジュール結合はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "共通結合"
      },
      {
        "label": "イ",
        "textJa": "制御結合"
      },
      {
        "label": "ウ",
        "textJa": "データ結合"
      },
      {
        "label": "エ",
        "textJa": "内容結合"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。两个模块仅通过参数传递需要的数据、彼此不直接依赖对方内部实现时，称为数据结合，在题列的四种结合中最弱。共通结合依赖共享数据，控制结合传控制标志使对方改变流程，内容结合更直接触及另一模块内部。一般来说，依赖越少越容易单独修改和测试；注意“只经参数”还须看传的是普通数据还是控制指令。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-49",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 49,
    "page": 24,
    "topicZh": "对象委托",
    "stemJa": "オブジェクト指向における“委譲”に関する説明として、適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "あるオブジェクトに対して操作を適用したとき、 関連するオブジェクトに対してもその操作が自動的に適用される仕組み"
      },
      {
        "label": "イ",
        "textJa": "あるオブジェクトに対する操作を、その内部で他のオブジェクトに依頼する仕組み"
      },
      {
        "label": "ウ",
        "textJa": "下位のクラスが上位のクラスの属性や操作を引き継ぐ仕組み"
      },
      {
        "label": "エ",
        "textJa": "複数のオブジェクトを部分として用いて、新たな一つのオブジェクトを生成する仕組み"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。委托是某对象收到操作请求后，把其中的工作交给另一个对象处理；外部仍向原对象发消息，原对象在内部调用被委托对象。ウ是继承，子类沿用父类的属性和方法；エ是由多个对象组合成新对象；ア描述操作向相关对象自动传播，和本题所问的内部委托不同。理解委托时关注“请求转交给谁执行”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-50",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 50,
    "page": 25,
    "topicZh": "极限编程实践",
    "stemJa": "XP（Extreme Programming）のプラクティスの説明のうち、適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "顧客は単体テストの仕様に責任をもつ。"
      },
      {
        "label": "イ",
        "textJa": "コードの結合とテストを継続的に繰り返す。"
      },
      {
        "label": "ウ",
        "textJa": "コードを作成して結合できることを確認した後、テストケースを作成する。"
      },
      {
        "label": "エ",
        "textJa": "テストを通過したコードは、次のイテレーションまでリファクタリングしない。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。XP 提倡持续集成：代码频繁合并，并不断运行测试，尽早发现接口冲突或回归错误。ア把单元测试规格责任推给客户不妥；客户通常参与验收条件。ウ先写代码后考虑测试，与测试先行的实践相反；エ说通过测试的代码不能在下次迭代前重构，也与持续改进代码结构的做法不符。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-51",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 51,
    "page": 25,
    "topicZh": "工作分解结构 WBS",
    "stemJa": "ソフトウェア開発プロジェクトにおいてWBS（Work Breakdown Structure）を使用する目的として、 適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "開発の期間と費用がトレードオフの関係にある場合に、総費用の最適化を図る。"
      },
      {
        "label": "イ",
        "textJa": "作業の順序関係を明確にして、重点管理すべきクリティカルパスを把握する。"
      },
      {
        "label": "ウ",
        "textJa": "作業の日程を横棒（バー）で表して、作業の開始時点や終了時点、現時点の進捗を明確にする。"
      },
      {
        "label": "エ",
        "textJa": "作業を階層的に詳細化して、管理可能な大きさに細分化する。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。WBS 把项目交付物或工作逐层拆小，直到能分配负责人、估算工时并管理的工作包。它回答“有哪些工作、各部分如何拆分”。イ找关键路径需要网络图等进度分析；ウ用横条显示起止和进度是甘特图；ア按时间和成本权衡优化费用也不是 WBS 本身的目的。先分解工作，之后才能安排日程。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-52",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 52,
    "page": 25,
    "topicZh": "关键路径与项目日数",
    "stemJa": "図のプロジェクトの日程計画において，プロジェクトの所要日数は何日か。",
    "options": [
      {
        "label": "ア",
        "textJa": "40"
      },
      {
        "label": "イ",
        "textJa": "45"
      },
      {
        "label": "ウ",
        "textJa": "50"
      },
      {
        "label": "エ",
        "textJa": "55"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ，即55日。箭线图中项目必须等所有前置活动完成才能结束，因此总工期取从起点到终点的最长路径，称关键路径。按原图列出可能路径，A→D→上方虚作业→E→H为10＋15＋0＋20＋10＝55日；A→C→E→H和A→D→F→H均为50日，其他路径更短。虚作业虽耗时0，却表达依赖关系，不能删掉后误算并行。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p25.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-53",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 53,
    "page": 26,
    "topicZh": "开发剩余工作量",
    "stemJa": "表は，1人で行うプログラム開発の開始時点での計画表である。6月1日に開発を開始し，6月11日の終了時点でコーディング作業の25%が終了した。6月11日の終了時点で残っている作業量は全体の約何%か。ここで，開発は，土曜日と日曜日を除く週5日間で行うものとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "30"
      },
      {
        "label": "イ",
        "textJa": "47"
      },
      {
        "label": "ウ",
        "textJa": "52"
      },
      {
        "label": "エ",
        "textJa": "53"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ，约47%。原计划各项工作量相加为17人日。到6月11日结束，已完成设计等前三项2＋5＋1人日，编码4人日的25%又完成1人日，所以已完成9人日，剩余8人日。所问是“剩余占全部”的比例，8÷17约为0.4706，即47%。日期与周末用于说明当前进度，不能只用日历天数去代替各工作阶段的工作量。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p26.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-54",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 54,
    "page": 26,
    "topicZh": "功能点换算总工数",
    "stemJa": "ある新規システムの機能規模を見積もったところ，500FP(ファンクションポイント)であった。このシステムを構築するプロジェクトには，開発工数のほかに，システム導入と開発者教育の工数が，合計で10人月必要である。また，プロジェクト管理に，開発と導入・教育を合わせた工数の10%を要する。このプロジェクトに要する全工数は何人月か。ここで，開発の生産性は1人月当たり10FPとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "51"
      },
      {
        "label": "イ",
        "textJa": "60"
      },
      {
        "label": "ウ",
        "textJa": "65"
      },
      {
        "label": "エ",
        "textJa": "66"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ，即66人月。开发生产率每人月10 FP，所以500 FP的开发需要500÷10＝50人月。导入和开发者教育再加10人月，基本工数共60人月。项目管理还需这两部分合计工数的10%，即6人月，故总计66人月。容易误将管理的10%只乘开发工数，或把FP与人月直接相加；先统一为人月最清楚。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p26.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-55",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 55,
    "page": 27,
    "topicZh": "容量管理趋势分析",
    "stemJa": "キャパシティ管理における将来のコンポーネント，並びにサービスの容量・能力及びパフォーマンスを予想する活動のうち，傾向分析はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "特定の資源の利用状況を時系列に把握して，将来における利用の変化を予測する。"
      },
      {
        "label": "イ",
        "textJa": "待ち行列理論などの数学的技法を利用して，サービスの応答時間及びスループットを予測する。"
      },
      {
        "label": "ウ",
        "textJa": "模擬的にトランザクションを発生させて，サービスの応答時間及びスループットを予測する。"
      },
      {
        "label": "エ",
        "textJa": "モデル化の第一段階として，現在達成されているパフォーマンスを正確に反映したモデルを作成する。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。趋势分析先按时间顺序记录某项资源的使用量，例如每月存储占用或CPU峰值，再依据上升、下降或季节变化推测将来需求。イ是用排队论等数学模型预测响应时间，ウ是通过模拟交易测量服务性能，エ是建立当前性能的基准模型。它们都可能服务于容量管理，但题目限定“傾向分析”，关键是同一指标的时间序列。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p27.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-56",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 56,
    "page": 27,
    "topicZh": "冷启动与恢复",
    "stemJa": "システム障害が発生したときにシステムを初期状態に戻して再開する方法であり，更新前コピー又は更新後コピーの前処理を伴わないシステム開始のことであって，初期プログラムロードとも呼ばれるものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "ウォームスタート"
      },
      {
        "label": "イ",
        "textJa": "コールドスタート"
      },
      {
        "label": "ウ",
        "textJa": "ロ－ルバック"
      },
      {
        "label": "エ",
        "textJa": "ロールフォワード"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ，即コールドスタート。冷启动把系统当作从初始状态开始装入和启动，也称初始程序装入；题干特别说明不伴随更新前镜像或更新后镜像的预处理。温启动是在保留部分运行状态的前提下重新启动；回滚依据更新前资料撤销未完成事务，前滚依据日志重做已提交更新。看是否利用先前状态和日志恢复，是区分这些术语的关键。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p27.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-57",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 57,
    "page": 27,
    "topicZh": "SLA可用率与最长停机",
    "stemJa": "次の条件でITサービスを提供している。SLAを満たすことのできる，1か月のサービス時間帯中の停止時間は最大何時間か。ここで，1か月の営業日数は30日とし、サービス時間帯中は，保守などのサービス計画停止は行わないものとする。 〔SLAの条件〕 サービス時間帯は，営業日の午前8時から午後10時までとする。 可用性を99.5%以上とする。",
    "options": [
      {
        "label": "ア",
        "textJa": "0.3"
      },
      {
        "label": "イ",
        "textJa": "2.1"
      },
      {
        "label": "ウ",
        "textJa": "3.0"
      },
      {
        "label": "エ",
        "textJa": "3.6"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ，即2.1小时。服务每天从8点到22点，一天14小时，30个营业日总服务时间14×30＝420小时。可用率99.5%意味着允许不可用的比例为0.5%＝0.005；最长计划外停机时间为420×0.005＝2.1小时。题设说明服务时间内没有计划维护停机，所以无需另行从分母扣除维护时段；先确定SLA计算的时间窗口。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p27.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-58",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 58,
    "page": 28,
    "topicZh": "ISMS内部审计与风险接受",
    "stemJa": "JIS Q 27001:2014(情報セキュリティマネジメントシステム－要求事項)に基づいてISMS内部監査を行った結果として判明した状況のうち，監査人が指摘事項として監査報告書に記載すべきものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "USBメモリの使用を，定められた手順に従って許可していた。"
      },
      {
        "label": "イ",
        "textJa": "個人情報の誤廃棄事故を主務官庁などに，規定されたとおりに報告していた。"
      },
      {
        "label": "ウ",
        "textJa": "マルウェアスキャンでスパイウェアが検知され，駆除されていた。"
      },
      {
        "label": "エ",
        "textJa": "リスクアセスメントを実施した後に，リスク受容基準を決めた。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。风险接受标准应在风险评估之前设定，作为判断风险能否接受及如何处理的依据；题中的做法是在评估后才定标准，容易按结果反推门槛，应作为审计发现记录。ア按规定许可U盘、イ按规定报告事故、ウ扫描发现后清除间谍软件，均体现控制措施正常执行。审计不是找任何发生过的安全事件，而是识别偏离既定要求的行为。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p28.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-59",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 59,
    "page": 28,
    "topicZh": "备份介质外部保管",
    "stemJa": "外部保管のために専門業者にバックアップ媒体を引き渡す際の安全性について，セキュリティ監査を実施した。その結果として判明した状況のうち，監査人が指摘事項として監査報告書に記載すべきものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "委託元責任者が，一定期間ごとに，専門業者における媒体保管状況を確認する契約を結んだ上で引き渡している。"
      },
      {
        "label": "イ",
        "textJa": "委託元責任者が，専門業者との間で，機密保持条項を盛り込んだ業務委託契約を結んだ上で引き渡している。"
      },
      {
        "label": "ウ",
        "textJa": "委託元担当者が，専用の記録簿に，引渡しの都度，日付と内容を記入し，専門業者から受領印をもらっている。"
      },
      {
        "label": "エ",
        "textJa": "委託元担当者が，バックアップ媒体を段ボール箱に入れ，それを専門業者に引き渡している。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。把备份介质装进普通纸箱直接交给外部保管商，不能有效防止运输途中拆封、调包、损坏或非授权接触，交接保护不足，应写入审计报告。ア有定期核查保管状况的约定，イ有保密条款，ウ每次登记并获取收讫章，分别覆盖持续监督、保密义务和交接留痕。三项都不能替代包装与运输安全，但本题问的是已发现的明显缺口。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p28.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-60",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 60,
    "page": 28,
    "topicZh": "内部控制最终责任",
    "stemJa": "我が国の証券取引所に上場している企業において，内部統制の整備及び運用に最終的な責任を負っている者は誰か。",
    "options": [
      {
        "label": "ア",
        "textJa": "株主"
      },
      {
        "label": "イ",
        "textJa": "監査役"
      },
      {
        "label": "ウ",
        "textJa": "業務担当者"
      },
      {
        "label": "エ",
        "textJa": "経営者"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ，即経営者。内部控制要通过制度、职责分离、监督和持续改进来保证财务报告及业务过程可靠，最终负责建立与运行这些安排的是经营者。业务担当者负责执行被分配的控制，监查役负责监督，股东拥有公司权益并行使表决权，却不直接承担日常内部控制的最终实施责任。注意题问“整備及び運用に最終的な責任”，不是谁参与或监督。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p28.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-61",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 61,
    "page": 29,
    "topicZh": "IT投资事前评价",
    "stemJa": "IT投資評価を，個別プロジェクトの計画，実施，完了に応じて，事前評価，中間評価，事後評価を行う。事前評価について説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "計画と実績との差異及び原因を詳細に分析し，投資額や効果目標の変更が必要かどうかを判断する。"
      },
      {
        "label": "イ",
        "textJa": "事前に設定した効果目標の達成状況を評価し，必要に応じて目標を達成するための改善策を検討する。"
      },
      {
        "label": "ウ",
        "textJa": "投資効果の実現時期と評価に必要なデータ収集方法を事前に計画し，その時期に合わせて評価を行う。"
      },
      {
        "label": "エ",
        "textJa": "投資目的に基づいた効果目標を設定し，実施可否判断に必要な情報を上位マネジメントに提供する。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。事前评价发生在决定是否实施项目之前，要根据投资目的设定效益目标，并向上层管理者提供判断立项所需信息。ア比较计划与实绩、决定是否调整，属于进行中的中间评价；イ检查已设目标的达成情况，属于事后评价；ウ描述预先安排未来效果测量时间与数据收集方式，却不是题目所问的“事前评价本身”的核心活动。分清评价发生的时间点。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p29.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-62",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 62,
    "page": 29,
    "topicZh": "业务流程外包 BPO",
    "stemJa": "BPOを説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "自社ではサーバを所有せずに、 通信事業者などが保有するサーバの処理能力や記憶容量の一部を借りてシステムを運用することである。"
      },
      {
        "label": "イ",
        "textJa": "自社ではソフトウェアを所有せずに、 外部の専門業者が提供するソフトウェアの機能をネットワーク経由で活用することである。"
      },
      {
        "label": "ウ",
        "textJa": "自社の管理部門やコールセンタなど特定部門の業務プロセス全般を、 業務システムの運用などと一体として外部の専門業者に委託することである。"
      },
      {
        "label": "エ",
        "textJa": "自社よりも人件費が安い派遣会社の社員を活用することによって、 ソフトウェア開発の費用を低減させることである。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。BPO 是把某一业务流程整体交给外部专业方承担，例如呼叫中心或后台管理，并可连同支撑该流程的系统运营一起委托。ア只租用服务器资源，イ通过网络使用外部软件功能，均不是把“业务流程”整体外包。エ只是使用外部人员降低开发人力成本，也没有把部门流程的责任整体委托出去。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-63",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 63,
    "page": 30,
    "topicZh": "面向服务架构 SOA",
    "stemJa": "SOAを説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "業務体系、データ体系、適用処理体系、技術体系の四つの主要概念から構成され、 業務とシステムの最適化を図る。"
      },
      {
        "label": "イ",
        "textJa": "サービスというコンポーネントからソフトウェアを構成することによって、 ビジネス変化に対応しやすくする。"
      },
      {
        "label": "ウ",
        "textJa": "データフローダイアグラムを用い、情報に関するモデルと機能に関するモデルを同時に作成する。"
      },
      {
        "label": "エ",
        "textJa": "連接、選択、反復の三つの理論構造の組合せで、コンポーネントレベルの設計を行う。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。SOA 把业务能力封装成可被调用的服务，再通过服务组合构建系统，目的是在业务变化时更容易调整或复用能力。ア说的是从业务、数据、应用和技术等视角规划的体系；ウ是数据流图建模；エ描述用顺序、选择、重复构成程序控制结构。题目中的关键字是“サービスというコンポーネント”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-64",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 64,
    "page": 30,
    "topicZh": "系统化计划",
    "stemJa": "システム化計画の立案において実施すべき事項はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "画面や帳票などのインタフェースを決定し、設計書に記載するために、要件定義書を基に作業する。"
      },
      {
        "label": "イ",
        "textJa": "システム構築の組織体制を策定するとき、業務部門、情報システム部門の役割分担を明確にし、 費用の検討においては開発、運用及び保守の費用の算出基礎を明確にしておく。"
      },
      {
        "label": "ウ",
        "textJa": "システムの起動・終了、監視、ファイルメンテナンスなどを計画的に行い、 業務が円滑に遂行していることを確認する。"
      },
      {
        "label": "エ",
        "textJa": "システムを業務及び環境に適合するように維持管理を行い、 修正依頼が発生した場合は、その内容を分析し、影響を明らかにする。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。系统化计划阶段要考虑谁负责建设与使用、开发和运维需要多少成本，因此应明确业务部门与信息系统部门的分工，并说明费用估算依据。ア已进入界面和报表设计；ウ是系统运行作业；エ属于系统维护和变更影响分析。区分阶段时先问“此时是在计划要建什么，还是已经设计、运行或维修”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-65",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 65,
    "page": 31,
    "topicZh": "需求定义",
    "stemJa": "企画、要件定義、システム開発、ソフトウェア実装、ハードウェア実装、 保守から成る一連のプロセスにおいて、要件定義プロセスで実施すべきものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "システムに関わり合いをもつ利害関係者の種類を識別し、 利害関係者のニーズ及び要望並びに課せられる制約条件を識別する。"
      },
      {
        "label": "イ",
        "textJa": "事業の目的、目標を達成するために必要なシステム化の方針、 及びシステムを実現するための実施計画を立案する。"
      },
      {
        "label": "ウ",
        "textJa": "目的とするシステムを得るために、システムの機能及び能力を定義し、 システム方式設計によってハードウェア、ソフトウェアなどによる実現方式を確立する。"
      },
      {
        "label": "エ",
        "textJa": "利害関係者の要件を満足するソフトウェア製品又はソフトウェアサービスを得るための、 方式設計と適格性の確認を実施する。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。需求定义的起点是识别利害关系者及其需要、希望和约束，例如使用者、运营人员、法规或预算要求；这些信息构成后续系统需求的基础。イ拟定系统化方针和实施计划是企划；ウ已进一步定义系统功能并进入实现方式设计；エ涉及软件产品方式设计和确认。不要把“收集需求”与“设计如何实现”混成同一步。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-66",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 66,
    "page": 31,
    "topicZh": "系统采购RFI与RFP",
    "stemJa": "図に示す手順で情報システムを調達するとき，bに入れるものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "RFI"
      },
      {
        "label": "イ",
        "textJa": "RFP"
      },
      {
        "label": "ウ",
        "textJa": "供給者の選定"
      },
      {
        "label": "エ",
        "textJa": "契約の締結"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ，b是RFP。采购流程先用RFI向供应商请求技术、经验等信息，再把具体需求整理为RFP，向候选供应商请求方案；接着评估提案并选择供应商，最后签合同。图中b处位于初期信息收集之后、供应商选择之前，正是提案依赖的阶段。RFI偏“了解能做什么”，RFP偏“请针对这些要求提出方案”，二者不能互换。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p31.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-67",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 67,
    "page": 32,
    "topicZh": "产品生命周期成长期",
    "stemJa": "プロダクトライフサイクルにおける成長期の特徴はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "市場が製品の価値を理解し始める。製品ラインもチャネルも拡大しなければならない。 この時期は売上も伸びるが、投資も必要である。"
      },
      {
        "label": "イ",
        "textJa": "需要が大きくなり、製品の差別化や市場の細分化が明確になってくる。 競争者間の競争も激化し、新品種の追加やコストダウンが必要となる。"
      },
      {
        "label": "ウ",
        "textJa": "需要が減ってきて、撤退する企業も出てくる。 この時期の強者になれるかどうかを判断し、代替市場への進出なども考える。"
      },
      {
        "label": "エ",
        "textJa": "需要は部分的で、新規需要開拓が勝負である。 特定ターゲットに対する信念に満ちた説得が必要である。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。成长期里市场开始认可产品，销量扩大，企业要扩展产品线和销售渠道，同时继续投入资金。エ强调需求局部且需要开拓新市场，更像导入期；イ提到竞争激化、产品差异和成本下降，更接近成熟期；ウ需求减少和企业退出，是衰退期。判断生命周期时按“需求量与竞争状态”依次排阶段。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-68",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 68,
    "page": 32,
    "topicZh": "线性价格需求函数",
    "stemJa": "ある製品の設定価格と需要の関係が1次式で表せるとき，aに入れる適切な数値はどれか。 設定価格を3,000円にすると，需要は0個になる。 設定価格を1,000円にすると，需要は60,000個になる。 設定価格を1,500円にすると，需要は a 個になる。",
    "options": [
      {
        "label": "ア",
        "textJa": "30,000"
      },
      {
        "label": "イ",
        "textJa": "35,000"
      },
      {
        "label": "ウ",
        "textJa": "40,000"
      },
      {
        "label": "エ",
        "textJa": "45,000"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ，即45,000个。价格从1000日元升到3000日元，增加2000日元时需求从60000降到0，斜率为每增加1日元减少30个。现在价格从1000升到1500，只增加500日元，所以需求减少500×30＝15000个，剩60000－15000＝45000个。也可用两点式画直线；题设明确“1次式”，因此不能按反比例或固定百分比下降。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p32.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-69",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 69,
    "page": 33,
    "topicZh": "客户转移比例计算",
    "stemJa": "T社では3種類の商品A，B，Cを販売している。現在のところ，それぞれの商品には毎月10,000人，20,000人，80,000人の購入者がいる。来年から商品体系を変更して，4種類の新商品P，Q，R，Sを販売する予定である。そこで，既存の顧客が新商品を購入する割合と新規の顧客数を試算した。この試算について，適切な記述はどれか。ここで，表の各行に記載されている小数第1位までの数値が，該当する旧商品から新商品に乗り換える人の割合を表す。",
    "options": [
      {
        "label": "ア",
        "textJa": "商品Aの購入者のうち，1,000人が新商品Qを購入すると予想している。"
      },
      {
        "label": "イ",
        "textJa": "商品Bの購入者は，新商品P，Q，R，Sのどれかを購入すると予想している。"
      },
      {
        "label": "ウ",
        "textJa": "新商品Pの購入見込者の5割は，商品Aの購入者であると予想している。"
      },
      {
        "label": "エ",
        "textJa": "新商品Sの新規顧客数は，商品Cの購入者のうち新商品Sを購入する人数より少ないと予想している。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。原表中旧商品C的8万人有30%预计改买新商品S，即80000×0.3＝24000人；新商品S的新增顾客为23000人，确实比24000少。ア把A到Q的30%误算成1000，实际是3000；イ中B行比例合计0.9，不能断言人人都买新商品；ウ中新商品P总顾客20000，来自A的5000只占25%，不是一半。比选项时要统一分母。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p33.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-70",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 70,
    "page": 33,
    "topicZh": "技术 S 曲线",
    "stemJa": "技術は、理想とする技術を目指す過程において、導入期、成長期、成熟期、衰退期、 そして次の技術フェーズに移行するという進化の過程をたどる。 この技術進化過程を表すものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "技術のSカーブ"
      },
      {
        "label": "イ",
        "textJa": "需要曲線"
      },
      {
        "label": "ウ",
        "textJa": "バスタブ曲線"
      },
      {
        "label": "エ",
        "textJa": "ラーニングカーブ"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。技术性能常先缓慢改善，随后因经验和投入快速上升，接近技术极限时又趋缓，整体像字母 S；旧技术成熟后可能切换到新的技术曲线。需求曲线讲价格和需求量，浴盆曲线常用于故障率随时间变化，学习曲线表示经验积累与成本或效率的关系。题目说的是“技术进化过程”，所以选 S 曲线。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-71",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 71,
    "page": 34,
    "topicZh": "物联网对象范围",
    "stemJa": "IoTの構成要素に関する記述として、適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "アナログ式の機器を除く、ディジタル式の機器が対象となる。"
      },
      {
        "label": "イ",
        "textJa": "インターネット又は閉域網に接続できる全てのものが対象となる。"
      },
      {
        "label": "ウ",
        "textJa": "自律的にデータを収集してデータ分析を行う機器だけが対象となる。"
      },
      {
        "label": "エ",
        "textJa": "人や生物を除く、形のある全てのものが対象となる。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ。官方答案表为イ。IoT 关注能够通过互联网或封闭网络接入并参与数据交换的“物”，并不限定只有数字式设备，也不要求每台设备都独自完成采集和分析。ア把模拟设备一概排除过于绝对；ウ把范围缩为自主分析设备；エ把所有有形物都算进去，又忽视了可连接这一条件。此题按 2018 年原卷语境理解。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-72",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 72,
    "page": 34,
    "topicZh": "RFID 标签",
    "stemJa": "ICタグ（RFID）の特徴はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "GPSを利用し、現在地の位置情報や属性情報を表示する。"
      },
      {
        "label": "イ",
        "textJa": "専用の磁気読取り装置に挿入して使用する。"
      },
      {
        "label": "ウ",
        "textJa": "大量の情報を扱うので、情報の記憶には外部記憶装置を使用する。"
      },
      {
        "label": "エ",
        "textJa": "汚れに強く、記録された情報を梱包の外から読むことができる。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。RFID 通过无线电读取标签中的信息，读取器通常不必像磁条卡那样把标签插入设备，因此即使外包装有污渍，也可能从包装外识别商品。ア把 RFID 和 GPS 定位混淆；イ描述插入磁读取装置；ウ说必须靠外部存储保存大量信息，也不是标签特点。RFID 的核心是无线识别，不是定位或大容量存储。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-73",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 73,
    "page": 34,
    "topicZh": "线上线下联动 O to O",
    "stemJa": "ネットビジネスでのO to Oの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "基本的なサービスや製品を無料で提供し、 高度な機能や特別な機能については料金を課金するビジネスモデルである。"
      },
      {
        "label": "イ",
        "textJa": "顧客仕様に応じたカスタマイズを実現するために、 顧客からの注文後に最終製品の生産を始める方式である。"
      },
      {
        "label": "ウ",
        "textJa": "電子商取引で、代金を払ったのに商品が届かない、 商品を送ったのに代金が支払われないなどのトラブルが防止できる仕組みである。"
      },
      {
        "label": "エ",
        "textJa": "モバイル端末などを利用している顧客を、仮想店舗から実店舗に、 又は実店舗から仮想店舗に誘導しながら、購入につなげる仕組みである。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。O to O 在此指通过手机等渠道，让顾客在网上店铺与实体店铺之间流转，最终促成购买，例如线上查看优惠后到店消费。ア是基础免费、增值付费模式；イ是接单后才开始最终生产的按订单生产；ウ是防止买卖双方付款或交货纠纷的交易保障机制。题目的辨识点是“仮想店舗と実店舗を相互に誘導”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-74",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 74,
    "page": 35,
    "topicZh": "首席信息官 CIO",
    "stemJa": "CIOの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "経営戦略の立案及び業務執行を統括する最高責任者"
      },
      {
        "label": "イ",
        "textJa": "資金調達、財務報告などの財務面での戦略策定及び執行を統括する最高責任者"
      },
      {
        "label": "ウ",
        "textJa": "自社の技術戦略や研究開発の立案及び執行を統括する最高責任者"
      },
      {
        "label": "エ",
        "textJa": "情報管理、情報システムに関する戦略立案及び執行を統括する最高責任者"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。CIO 负责企业的信息管理和信息系统战略，并统筹相关决策与执行。ア侧重整体经营和业务执行，通常是 CEO；イ负责筹资与财务报告，通常是 CFO；ウ负责技术战略和研发，通常是 CTO。英文缩写里的 I 是 Information，看到“信息系统战略”就能与财务、研发和总体经营职责区分。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-75",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 75,
    "page": 35,
    "topicZh": "期望利润与订货量",
    "stemJa": "商品の1日当たりの販売個数の予想確率が表のとおりであるとき，1個当たりの利益を1,000円とすると，利益の期待値が最大になる仕入個数は何個か。ここで，仕入れた日に売れ残った場合，1個当たり300円の廃棄ロスが出るものとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "4"
      },
      {
        "label": "イ",
        "textJa": "5"
      },
      {
        "label": "ウ",
        "textJa": "6"
      },
      {
        "label": "エ",
        "textJa": "7"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ，即仕入6个。某天卖出的数量是库存与需求的较小者，日利润＝1000×实际卖出量－300×未售数量。按原表各销量概率，进4个的期望为4000，进5个为4610，进6个为4830，进7个为4660日元；最大是4830。比如进6个而只卖4个，利润是4000－2×300＝3400。不要把“最可能销量”直接当成最优进货量，还要算剩货损失。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p35.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-76",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 76,
    "page": 36,
    "topicZh": "关联图法",
    "stemJa": "連関図法を説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "事態の進展とともに様々な事象が想定される問題について、 対応策を検討して望ましい結果に至るプロセスを定める方法である。"
      },
      {
        "label": "イ",
        "textJa": "収集した情報を相互の関連によってグループ化し、解決すべき問題点を明確にする方法である。"
      },
      {
        "label": "ウ",
        "textJa": "複雑な要因の絡み合う事象について、その事象間の因果関係を明らかにする方法である。"
      },
      {
        "label": "エ",
        "textJa": "目的・目標を達成するための手段・方策を順次展開し、最適な手段・方策を追求していく方法である。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案ウ。关联图法把多个相互影响的原因和结果用箭头等关系连起来，适合找出复杂问题背后的因果结构。ア侧重面对事态演变预想多条路径，属于过程决策类方法；イ把收集的事项按相近关系归组，类似亲和图法；エ逐层展开达成目标的手段，属于系统图法。抓住题干“複雑な要因”“因果関係”即可判断。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-77",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 77,
    "page": 36,
    "topicZh": "先进先出法计算销货成本",
    "stemJa": "ある商品の前月繰越と受払いが表のとおりであるとき，先入先出法によって算出した当月度の売上原価は何円か。",
    "options": [
      {
        "label": "ア",
        "textJa": "26,290"
      },
      {
        "label": "イ",
        "textJa": "26,450"
      },
      {
        "label": "ウ",
        "textJa": "27,250"
      },
      {
        "label": "エ",
        "textJa": "27,586"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案イ，即26,450日元。原表显示本月售出70个和60个，共130个；按先进先出，先用上月结转的100个，单价200日元，再用5日进货的30个，单价215日元。销售成本＝100×200＋30×215＝20000＋6450＝26450日元。先入先出说的是成本归属顺序，不要求现实仓库一定按同顺序搬货；之后入库批次不应提前计入本月这130件的成本。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf",
    "imageAssets": [
      "question-images/fe-2018-f-am-p36.jpg"
    ],
    "transcriptionNoteZh": "图表、公式及原卷排版以所附 IPA 官方试卷原页为准；下方日文题干和选项为文字录入。"
  },
  {
    "id": "FE-2018-F-AM-78",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 78,
    "page": 37,
    "topicZh": "2018 年病毒制作题",
    "stemJa": "コンピュータウイルスを作成する行為を処罰の対象とする法律はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "刑法"
      },
      {
        "label": "イ",
        "textJa": "不正アクセス禁止法"
      },
      {
        "label": "ウ",
        "textJa": "不正競争防止法"
      },
      {
        "label": "エ",
        "textJa": "プロバイダ責任制限法"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。2018 年 IPA 原卷的答案是刑法。日本刑法中有针对制作和提供不正指令电磁记录等行为的规定，所以不能把“制作病毒”简单等同于非法登录。イ主要针对未获授权访问，ウ针对不正竞争行为，エ涉及网络服务提供者的责任。本题作为历史真题学习法律分类；现实法律适用需以现行法及具体行为为准。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-79",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 79,
    "page": 37,
    "topicZh": "个人信息与匿名加工信息",
    "stemJa": "個人情報保護委員会 “個人情報の保護に関する法律についてのガイドライン（通則編）平成28年11月（平成29年3月一部改正）” によれば、個人情報に該当しないものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "受付に設置した監視カメラに録画された、本人が判別できる映像データ"
      },
      {
        "label": "イ",
        "textJa": "個人番号の記載がない、社員に交付する源泉徴収票"
      },
      {
        "label": "ウ",
        "textJa": "指紋認証のための指紋データのバックアップデータ"
      },
      {
        "label": "エ",
        "textJa": "匿名加工情報に加工された利用者アンケート情報"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案エ。题目引用的是当时个人信息保护委员会的指南；按该题前提，已按要求加工到不能识别特定个人的匿名加工信息，不作为个人信息。ア能辨认本人的摄像录像、イ虽无个人编号但能对应员工的源泉征收票、ウ用于指纹认证的数据备份，都可能识别个人。关键不是资料有没有姓名，而是能否识别特定个人。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2018-F-AM-80",
    "kind": "official",
    "year": 2018,
    "periodJa": "秋期",
    "section": "AM",
    "number": 80,
    "page": 37,
    "topicZh": "承包与派遣的界限",
    "stemJa": "請負契約を締結していても、労働者派遣とみなされる受託者の行為はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "休暇取得の承認を発注者側の指示に従って行う。"
      },
      {
        "label": "イ",
        "textJa": "業務の遂行に関する指導や評価を自ら実施する。"
      },
      {
        "label": "ウ",
        "textJa": "勤務に関する規律や職場秩序の保持を実施する。"
      },
      {
        "label": "エ",
        "textJa": "発注者の業務上の要請を受託者側の責任者が窓口となって受け付ける。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案ア。即使合同写成承包，如果发包方直接指示受托方劳动者的休假批准等劳动管理事项，就可能实质上形成劳动者派遣。イ由受托方自行指导和评价工作，ウ由其维护劳动纪律，エ由受托方负责人作为发包请求的窗口，都是承包方自行管理的方向。判断此历史真题时要看实际指挥命令关系，而非只看合同标题。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000f01f-att/2018h30a_fe_am_ans.pdf"
  },
  {
    "id": "FE-2017-F-AM-01",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 1,
    "topicZh": "二进制位移",
    "stemJa": "数値を2進数で表すレジスタがある。このレジスタに格納されている正の整数xを10倍する操作はどれか。ここで、桁あふれは、起こらないものとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "xを2ビット左にシフトした値にxを加算し、更に1ビット左にシフトする。"
      },
      {
        "label": "イ",
        "textJa": "xを2ビット左にシフトした値にxを加算し、更に2ビット左にシフトする。"
      },
      {
        "label": "ウ",
        "textJa": "xを3ビット左にシフトした値と、xを2ビット左にシフトした値を加算する。"
      },
      {
        "label": "エ",
        "textJa": "xを3ビット左にシフトした値にxを加算し、更に1ビット左にシフトする。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。二进制整数左移一位等于乘2，左移两位等于乘4；前提是题目所说的“不溢出”。ア先得到4x，再加x成为5x，最后左移一位得到10x。イ最后左移两位会得到20x；ウ是8x＋4x＝12x；エ是(8x＋x)×2＝18x。做这类题可把每次左移直接换成乘2的幂，再按括号顺序计算。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 3
  },
  {
    "id": "FE-2017-F-AM-02",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 2,
    "topicZh": "CRC 错误检测",
    "stemJa": "送信側では、ビット列をある生成多項式で割った余りをそのビット列に付加して送信し、受信側では、受信したビット列が同じ生成多項式で割り切れるか否かで誤りの発生を判断する誤り検査方式はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "CRC方式"
      },
      {
        "label": "イ",
        "textJa": "垂直パリティチェック方式"
      },
      {
        "label": "ウ",
        "textJa": "水平パリティチェック方式"
      },
      {
        "label": "エ",
        "textJa": "ハミング符号方式"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。CRC（循环冗余校验）把比特串看成多项式，用约定的生成多项式求余；发送方附上余数，接收方再除一次，借余数判断传输差错。イ和ウ分别是纵向、横向奇偶校验，核心是统计1的奇偶个数，并不使用生成多项式除法。エ是汉明码，利用多个校验位定位并纠正部分错误。题眼是“生成多項式”和“余り”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 3
  },
  {
    "id": "FE-2017-F-AM-03",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 3,
    "topicZh": "反馈控制",
    "stemJa": "フィードバック制御の説明として、適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "あらかじめ定められた順序で制御を行う。"
      },
      {
        "label": "イ",
        "textJa": "外乱の影響が出力に現れる前に制御を行う。"
      },
      {
        "label": "ウ",
        "textJa": "出力結果と目標値とを比較して、一致するように制御を行う。"
      },
      {
        "label": "エ",
        "textJa": "出力結果を使用せず制御を行う。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案是ウ。反馈控制先观察实际输出，再与目标值比较，根据偏差调整下一步控制量。例如空调测到室温高于设定温度，就加强制冷。ア只按事先安排的顺序工作，没有根据输出调整；イ强调扰动影响出现前就采取措施，是前馈控制的思路；エ明确不使用输出结果，属于开环控制。识别反馈的两个动作：测量结果、与目标比较。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 3
  },
  {
    "id": "FE-2017-F-AM-04",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 4,
    "topicZh": "循线机器人与反馈控制",
    "stemJa": "図のような黒色で描かれた円に沿って車が走るように，左右の後輪に独立に取り付けられたモータL及びRの回転速度を制御する。センサL及びRは反射型光センサであり，センサが黒色に掛かる比率が大きいと出力値が小さくなり，黒色に掛かる比率が小さいと出力値が大きくなる。この車を円に沿って走行させるためのモータ回転速度の制御方法として，適切なものはどれか。ここで，二つのセンサの出力値が一致するときには，二つのモータの回転速度を初期値に戻すものとする。",
    "options": [
      {
        "label": "ア",
        "textJa": "L出力値＞R出力値：モータLを上げ，Rを下げる。L出力値＜R出力値：モータLを上げ，Rを下げる。"
      },
      {
        "label": "イ",
        "textJa": "L出力値＞R出力値：モータLを上げ，Rを下げる。L出力値＜R出力値：モータLを下げ，Rを上げる。"
      },
      {
        "label": "ウ",
        "textJa": "L出力値＞R出力値：モータLを下げ，Rを上げる。L出力値＜R出力値：モータLを上げ，Rを下げる。"
      },
      {
        "label": "エ",
        "textJa": "L出力値＞R出力値：モータLを下げ，Rを上げる。L出力値＜R出力値：モータLを下げ，Rを上げる。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案是イ。先把传感器读数反过来理解：读数大表示该侧较少压到黑线。若L读数大于R，黑线更偏右，车必须向右修正；差速车要右转，就让左轮更快、右轮更慢。若L读数小于R，黑线偏左，需要左轮更慢、右轮更快。ア和エ两种偏差都朝同一方向转，无法双向纠偏；ウ的两个方向恰好相反，会越偏越远。两读数相等时按题意恢复初始速度。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 4,
    "imageAssets": [
      "question-images/fe-2017-f-am-04.jpg"
    ],
    "transcriptionNoteZh": "原卷含图表，已附上 IPA 官方试卷该题的完整裁图；文字为便于阅读的线性转录，图形与原版排版以裁图为准。"
  },
  {
    "id": "FE-2017-F-AM-05",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 5,
    "topicZh": "栈的后进先出",
    "stemJa": "A、B、C、Dの順に到着するデータに対して、一つのスタックだけを用いて出力可能なデータ列はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "A、D、B、C"
      },
      {
        "label": "イ",
        "textJa": "B、D、A、C"
      },
      {
        "label": "ウ",
        "textJa": "C、B、D、A"
      },
      {
        "label": "エ",
        "textJa": "D、C、A、B"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案是ウ。栈只能从顶部取出最后放入的数据。按A、B、C依次入栈，可依次弹出C、B；随后D入栈并弹出，最后弹出A，所以C、B、D、A可实现。ア在输出A后想先输出D再输出B，但C压在B上面；イ输出B、D后想先输出A，C仍挡在A前；エ输出D、C后想先输出A，B仍挡在A前。判断时可画一列栈，逐项模拟入栈和出栈。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2017-F-AM-06",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 6,
    "topicZh": "递归调用",
    "stemJa": "再帰呼出しの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "あらかじめ決められた順番ではなく、起きた事象に応じた処理を行うこと"
      },
      {
        "label": "イ",
        "textJa": "関数の中で自分自身を用いた処理を行うこと"
      },
      {
        "label": "ウ",
        "textJa": "処理が終了した関数をメモリから消去せず、必要になったとき再び用いること"
      },
      {
        "label": "エ",
        "textJa": "処理に失敗したときに、その処理を呼び出す直前の状態に戻すこと"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案是イ。递归是函数在自己的执行过程中再次调用自己，直接调用或经过其他函数间接调用都属于这一思路；通常需要终止条件，避免无限调用。ア是在事件发生时决定处理内容的事件驱动方式；ウ说的是保留已结束函数供以后重用，与调用自己不同；エ失败后恢复到调用前状态，是回滚的思路。看到“函数内部使用自身”就联想到递归。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2017-F-AM-07",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 7,
    "topicZh": "面向对象与方法重写",
    "stemJa": "オブジェクト指向プログラミングにおける、多相性を実現するためのオーバーライドの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "オブジェクト内の詳細な仕様や構造を外部から隠蔽すること"
      },
      {
        "label": "イ",
        "textJa": "スーパークラスで定義されたメソッドをサブクラスで再定義すること"
      },
      {
        "label": "ウ",
        "textJa": "同一クラス内に、メソッド名が同一で、引数の型、個数、並び順が異なる複数のメソッドを定義すること"
      },
      {
        "label": "エ",
        "textJa": "複数のクラスの共通する性質をまとめて、抽象化したクラスを作ること"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案是イ。子类继承父类后，用同名方法给出自己的实现，叫オーバーライド（方法重写）。例如父类的“显示”方法在子类里改成更具体的显示方式，调用时可按对象实际类型执行不同实现。ア是隐藏内部细节的封装；ウ是在同一类中按参数类型或个数区分同名方法，叫重载；エ是抽取共性形成抽象类。区分重写与重载：前者跨父子类，后者靠参数差异。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 5
  },
  {
    "id": "FE-2017-F-AM-08",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 8,
    "topicZh": "Perl 程序执行",
    "stemJa": "Perlの実行に関する記述のうち，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "UNIX用として開発されており，Windows用の言語処理系はない。"
      },
      {
        "label": "イ",
        "textJa": "実行にWebサーバを必要とする言語であり，CGIの開発に適している。"
      },
      {
        "label": "ウ",
        "textJa": "動的デバッグは，言語処理系から独立したプログラムを実行して行う。"
      },
      {
        "label": "エ",
        "textJa": "プログラムをコンパイルしたファイルを事前に用意する必要はない。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。Perl 程序通常由 Perl 解释器读取源代码并执行，无需事先另备编译好的可执行文件。ア错在说 Windows 没有 Perl 运行环境；イ虽提到 Perl 可用于 CGI，却错误地把 Web 服务器说成运行 Perl 的必需条件，命令行也能运行；ウ错在把动态调试限定为独立于语言处理系统的程序。区分“可用于某种场景”与“运行必须依赖该场景”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2017-F-AM-09",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 9,
    "topicZh": "MIPS 性能计算",
    "stemJa": "平均命令実行時間が20ナノ秒のコンピュータがある。このコンピュータの性能は何MIPSか。",
    "options": [
      {
        "label": "ア",
        "textJa": "5"
      },
      {
        "label": "イ",
        "textJa": "10"
      },
      {
        "label": "ウ",
        "textJa": "20"
      },
      {
        "label": "エ",
        "textJa": "50"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。MIPS 表示每秒执行多少百万条指令。平均一条指令用20纳秒，即20×10⁻⁹秒；每秒指令数为1÷(20×10⁻⁹)＝50,000,000条，所以是50 MIPS。ア的5、イ的10、ウ的20均低于这个计算结果。容易错在单位：1纳秒是十亿分之一秒，最后还需除以一百万，才得到“M”IPS。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2017-F-AM-10",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 10,
    "topicZh": "外部中断",
    "stemJa": "外部割込みに分類されるものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "インターバルタイマによって、指定時間経過時に生じる割込み"
      },
      {
        "label": "イ",
        "textJa": "演算結果のオーバフローやゼロによる除算で生じる割込み"
      },
      {
        "label": "ウ",
        "textJa": "仮想記憶管理において、存在しないページへのアクセスによって生じる割込み"
      },
      {
        "label": "エ",
        "textJa": "ソフトウェア割込み命令の実行によって生じる割込み"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。外部中断的触发源在当前指令执行流程之外。间隔定时器到达指定时间后发出信号，属于典型的外部中断。イ的溢出和除零由正在执行的运算引起；ウ的缺页由程序访问尚未装入的页引起；エ由软件中断指令主动触发，三者都不是本题所指的外部中断。判断时先问：触发信号来自外设或定时器，还是来自指令执行本身？",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 6
  },
  {
    "id": "FE-2017-F-AM-11",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 11,
    "topicZh": "USB Type-C 接头外形",
    "stemJa": "USB Type-Cのプラグ側コネクタの断面図はどれか。ここで，図の縮尺は同一ではない。",
    "options": [
      {
        "label": "ア",
        "textJa": "図のアのコネクタ断面図"
      },
      {
        "label": "イ",
        "textJa": "図のイのコネクタ断面図"
      },
      {
        "label": "ウ",
        "textJa": "図のウのコネクタ断面図"
      },
      {
        "label": "エ",
        "textJa": "図のエのコネクタ断面図"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案是イ。原卷四幅截面图中，イ是上下近乎对称的扁圆形，内部上下两排触点，这种对称设计让 USB Type-C 插头可以正反插。ア是较宽的矩形且一排接点；ウ、エ的外壳带明显不对称的梯形或缺口形状，插入方向受限。此题判断依据是原卷的外形与接点布局，图片已保留，不能仅凭接口名称猜图。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 6,
    "imageAssets": [
      "question-images/fe-2017-f-am-11.jpg"
    ],
    "transcriptionNoteZh": "原卷含图表，已附上 IPA 官方试卷该题的完整裁图；文字为便于阅读的线性转录，图形与原版排版以裁图为准。"
  },
  {
    "id": "FE-2017-F-AM-12",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 12,
    "topicZh": "RAID 5 磁盘阵列",
    "stemJa": "RAID5の記録方式に関する記述のうち、適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "複数の磁気ディスクに分散してバイト単位でデータを書き込み、さらに、1台の磁気ディスクにパリティを書き込む。"
      },
      {
        "label": "イ",
        "textJa": "複数の磁気ディスクに分散してビット単位でデータを書き込み、さらに、複数の磁気ディスクにエラー訂正符号(ECC)を書き込む。"
      },
      {
        "label": "ウ",
        "textJa": "複数の磁気ディスクに分散してブロック単位でデータを書き込み、さらに、複数の磁気ディスクに分散してパリティを書き込む。"
      },
      {
        "label": "エ",
        "textJa": "ミラーディスクを構成するために、磁気ディスク2台に同じ内容を書き込む。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案是ウ。RAID 5把数据按块分散写在多块磁盘上，也把用于故障恢复的奇偶校验信息分散存放，而不是固定放在一块盘上。ア把数据按字节分散且把校验信息集中在一块盘，与RAID 5不符；イ强调按位分散并使用ECC，描述另一种阵列思路；エ把同一内容写到两块盘，是镜像式RAID 1。记住RAID 5的两个“分散”：数据分块、校验分布。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 7
  },
  {
    "id": "FE-2017-F-AM-13",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 13,
    "topicZh": "双重系统与备用系统",
    "stemJa": "デュアルシステムの説明として、最も適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "同じ処理を行うシステムを二重に用意し、処理結果を照合することで処理の正しさを確認する。どちらかのシステムに障害が発生した場合は、縮退運転によって処理を継続する。"
      },
      {
        "label": "イ",
        "textJa": "オンライン処理を行う現用系と、バッチ処理などを行いながら待機させる待機系を用意し、現用系に障害が発生した場合は待機系に切り替え、オンライン処理を続行する。"
      },
      {
        "label": "ウ",
        "textJa": "待機系に現用系のオンライン処理プログラムをロードして待機させておき、現用系に障害が発生した場合は、即時に待機系に切り替えて処理を続行する。"
      },
      {
        "label": "エ",
        "textJa": "プロセッサ、メモリ、チャネル、電源系などを二重に用意しておき、それぞれの装置で片方に障害が発生した場合でも、処理を継続する。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。デュアルシステム让两套系统同时处理同一事务，并比对结果；一套故障时可由另一套继续处理，可能以降级方式运行。イ让备用系统平时执行别的任务，ウ让已装好程序的备用系统随时接替，这两项都是现用与备用的切换模式，没有同时比对处理结果。エ是在处理器、内存等硬件部件层面做冗余，也没有描述两套系统并行核对。抓住“同一处理＋结果照合”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 7
  },
  {
    "id": "FE-2017-F-AM-14",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 14,
    "topicZh": "云服务 IaaS/PaaS/SaaS",
    "stemJa": "社内業務システムをクラウドサービスへ移行することによって得られるメリットはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "PaaSを利用すると、プラットフォームの管理やOSのアップデートは、サービスを提供するプロバイダが行うので、導入や運用の負担を軽減することができる。"
      },
      {
        "label": "イ",
        "textJa": "オンプレミスで運用していた社内固有の機能を有する社内業務システムをSaaSで提供されるシステムへ移行する場合、社内固有の機能の移行も容易である。"
      },
      {
        "label": "ウ",
        "textJa": "社内業務システムの開発や評価で一時的に使う場合、SaaSを利用することによって自由度の高い開発環境が整えられる。"
      },
      {
        "label": "エ",
        "textJa": "非常に高い可用性が求められる社内業務システムをIaaSに移行する場合、いずれのプロバイダも高可用性を保証しているので移行が容易である。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。PaaS提供应用运行所需的平台，平台和操作系统的维护、更新由服务提供方承担，使用方可减少这部分运维工作。イ把有大量本企业专有功能的系统迁到标准SaaS，功能适配未必容易；ウ需要自由配置开发环境时，SaaS通常不如PaaS/IaaS灵活；エ说所有IaaS提供方都保证高可用性，绝对化且不成立。先判断各服务层交付什么，再判断责任由谁承担。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2017-F-AM-15",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 15,
    "topicZh": "可用率与串联系统",
    "stemJa": "MTBFが45時間でMTTRが5時間の装置がある。この装置を二つ直列に接続したシステムの稼働率は幾らか。",
    "options": [
      {
        "label": "ア",
        "textJa": "0.81"
      },
      {
        "label": "イ",
        "textJa": "0.90"
      },
      {
        "label": "ウ",
        "textJa": "0.95"
      },
      {
        "label": "エ",
        "textJa": "0.99"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。单台设备的可用率＝平均正常工作时间MTBF÷(MTBF＋平均修复时间MTTR)＝45÷(45＋5)＝0.90。两台串联时必须两台同时正常；按题目的独立同类设备计算，可用率为0.90×0.90＝0.81。イ的0.90只算了一台；ウ、エ高于单台的0.90，不符合串联任一台故障就停机的特点。串联相乘、并联“至少一台可用”，不要混淆。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2017-F-AM-16",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 16,
    "topicZh": "内存泄漏",
    "stemJa": "メモリリークの説明として、適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "OSやアプリケーションのバグなどが原因で、動作中に確保した主記憶が解放されないことであり、これが発生すると主記憶中の利用可能な部分が減少する。"
      },
      {
        "label": "イ",
        "textJa": "アプリケーションの同時実行数を増やした場合に、主記憶容量が不足し、処理時間のほとんどがページングに費やされ、スループットの極端な低下を招くことである。"
      },
      {
        "label": "ウ",
        "textJa": "実行時のプログラム領域の大きさに制限があるときに、必要になったモジュールを主記憶に取り込む手法である。"
      },
      {
        "label": "エ",
        "textJa": "主記憶で利用可能な空き領域の総量は足りているのに、主記憶中に不連続で散在しているので、大きなプログラムをロードする領域が確保できないことである。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。程序运行中申请内存，使用完却没有释放，就会使可用内存逐渐减少；这叫内存泄漏，例如每处理一次请求都遗留一块内存。イ是因频繁换页而性能骤降的抖动（thrashing）；ウ是按需装入程序模块的覆盖技术；エ是空闲空间分散导致难以分配大块连续空间的碎片化。泄漏的关键是“已占用的内存没有归还”，而不是总量不足本身。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 8
  },
  {
    "id": "FE-2017-F-AM-17",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 17,
    "topicZh": "轮询控制",
    "stemJa": "ソフトウェア制御における、ポーリング制御はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "CPUが状態レジスタ又はビジー信号などを読み出して、入出力装置の状態を監視する。"
      },
      {
        "label": "イ",
        "textJa": "実行中の処理を一時的に中断して、緊急度の高い別の処理を実行する。"
      },
      {
        "label": "ウ",
        "textJa": "送信側のタスクがメモリにデータを格納し、受信側のタスクにそのアドレスを伝える。"
      },
      {
        "label": "エ",
        "textJa": "複数のタスクが利用する共有資源を、一つのタスクが占有できるようにする。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。ポーリング（轮询）指CPU主动反复读取设备的状态寄存器或忙碌信号，检查设备是否完成操作；像每隔一会儿主动查看一次快递状态。イ是用中断暂时转去处理更紧急的工作；ウ描述任务间传递数据所在地址；エ描述对共享资源的互斥占用。轮询的识别点是“CPU主动查询”，设备主动通知CPU则更接近中断。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 9
  },
  {
    "id": "FE-2017-F-AM-18",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 18,
    "topicZh": "抢占式优先级调度",
    "stemJa": "優先度に基づくプリエンプティブなスケジューリングを行うリアルタイムOSで、二つのタスクA、Bをスケジューリングする。Aの方がBより優先度が高い場合にリアルタイムOSが行う動作のうち、適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "Aの実行中にBに起動がかかると、Aを実行可能状態にしてBを実行する。"
      },
      {
        "label": "イ",
        "textJa": "Aの実行中にBに起動がかかると、Aを待ち状態にしてBを実行する。"
      },
      {
        "label": "ウ",
        "textJa": "Bの実行中にAに起動がかかると、Bを実行可能状態にしてAを実行する。"
      },
      {
        "label": "エ",
        "textJa": "Bの実行中にAに起動がかかると、Bを待ち状態にしてAを実行する。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案是ウ。抢占式调度允许更高优先级任务变为可运行时立即接管CPU。B正在运行而更高优先级的A被唤起，就把B从运行态改成可运行态，让A运行。ア、イ让低优先级B抢走正在运行的A，违反优先级；エ虽然让A运行，却把原本仍可运行的B放入“等待态”。等待态通常意味着在等I/O或事件；仅失去CPU应回到可运行态。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 9
  },
  {
    "id": "FE-2017-F-AM-19",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 19,
    "topicZh": "内存紧凑与搬移时间",
    "stemJa": "図のメモリマップで，セグメント2が解放されたとき，セグメントを移動（動的再配置）し，分散する空き領域を集めて一つの連続領域にしたい。1回のメモリアクセスは4バイト単位で行い，読取り，書込みがそれぞれ30ナノ秒とすると，動的再配置をするために必要なメモリアクセス時間は合計何ミリ秒か。ここで，1kバイトは1,000バイトとし，動的再配置に要する時間以外のオーバヘッドは考慮しないものとする。図の配置は，セグメント1＝500kバイト，セグメント2＝100kバイト，セグメント3＝800kバイト，空き＝800kバイトである。",
    "options": [
      {
        "label": "ア",
        "textJa": "1.5"
      },
      {
        "label": "イ",
        "textJa": "6.0"
      },
      {
        "label": "ウ",
        "textJa": "7.5"
      },
      {
        "label": "エ",
        "textJa": "12.0"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。段2释放后，其100k字节空洞夹在段1与段3之间。要把两块空闲空间合并，需把800k字节的段3左移100k字节；段1不动，原来末尾的800k空闲区也不用搬。每次访问搬4字节，因此搬移次数为800,000÷4＝200,000；一次搬移要读30纳秒再写30纳秒，共60纳秒。总计200,000×60＝12,000,000纳秒＝12毫秒。ア、イ、ウ均漏算了搬移数据量或读写次数。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 10,
    "imageAssets": [
      "question-images/fe-2017-f-am-19.jpg"
    ],
    "transcriptionNoteZh": "原卷含图表，已附上 IPA 官方试卷该题的完整裁图；文字为便于阅读的线性转录，图形与原版排版以裁图为准。"
  },
  {
    "id": "FE-2017-F-AM-20",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 20,
    "topicZh": "缺页异常",
    "stemJa": "ページング方式の仮想記憶において、ページフォールトの発生回数を増加させる要因はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "主記憶に存在しないページへのアクセスが増加すること"
      },
      {
        "label": "イ",
        "textJa": "主記憶に存在するページへのアクセスが増加すること"
      },
      {
        "label": "ウ",
        "textJa": "主記憶のページのうち、更新されたページの比率が高くなること"
      },
      {
        "label": "エ",
        "textJa": "長時間アクセスしなかった主記憶のページをアクセスすること"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。虚拟内存把页面按需放进主存；CPU访问的页面当前不在主存，就发生页面故障（ページフォールト），系统需要把它调入。因此，访问不在主存的页越多，故障次数越可能增加。イ访问已在主存的页不会因该次访问缺页；ウ“页被更新”的比例与“页是否在主存”不同；エ是访问长期没用但题目明确仍在主存的页，也不会因此缺页。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 10
  },
  {
    "id": "FE-2017-F-AM-21",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 21,
    "topicZh": "DRAM 与 SRAM",
    "stemJa": "コンデンサに蓄えた電荷の有無で情報を記憶するメモリはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "EEPROM"
      },
      {
        "label": "イ",
        "textJa": "SDRAM"
      },
      {
        "label": "ウ",
        "textJa": "SRAM"
      },
      {
        "label": "エ",
        "textJa": "フラッシュメモリ"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案是イ。SDRAM是一种与时钟同步工作的DRAM；DRAM单元通过电容是否存有电荷来表示信息，电荷会泄漏，因此需要刷新。ア的EEPROM和エ的闪存属于可电擦写的非易失存储，不靠题述的DRAM电容存储机理；ウ的SRAM通常用双稳态电路保持状态，不需要DRAM式刷新。题干的“コンデンサに蓄えた電荷”直接指向DRAM。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 10
  },
  {
    "id": "FE-2017-F-AM-22",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 22,
    "topicZh": "执行器与传感器",
    "stemJa": "アクチュエータの機能として、適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "アナログ電気信号を、コンピュータが処理可能なディジタル信号に変える。"
      },
      {
        "label": "イ",
        "textJa": "キーボード、タッチパネルなどに使用され、コンピュータに情報を入力する。"
      },
      {
        "label": "ウ",
        "textJa": "コンピュータが出力した電気信号を力学的な運動に変える。"
      },
      {
        "label": "エ",
        "textJa": "物理量を検出して、電気信号に変える。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案是ウ。アクチュエータ（执行器）接收控制器发出的电信号，将它变成可作用于外界的机械运动，例如让电机旋转或阀门移动。ア把模拟电信号变成数字信号，是A/D转换；イ是键盘、触摸屏等输入装置；エ把温度、压力等物理量变成电信号，是传感器。可把控制链记为：传感器测量→计算机判断→执行器动作。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 11
  },
  {
    "id": "FE-2017-F-AM-23",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 23,
    "topicZh": "逻辑电路与异或",
    "stemJa": "図に示すディジタル回路と等価な論理式はどれか。ここで，論理式中の「・」は論理積を，「＋」は論理和を，Xの上線はXの否定を表す。",
    "options": [
      {
        "label": "ア",
        "textJa": "X＝A・B＋¬(A・B)"
      },
      {
        "label": "イ",
        "textJa": "X＝A・B＋¬A・¬B"
      },
      {
        "label": "ウ",
        "textJa": "X＝A・¬B＋¬A・B"
      },
      {
        "label": "エ",
        "textJa": "X＝(¬A＋B)・(A＋¬B)"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案是ウ。图中 A、B 各自先取反再做或，得到¬A＋¬B；这一路分别与原始 A、B 做与，最后两个结果做或，所以 X＝A(¬A＋¬B)＋B(¬A＋¬B)＝A¬B＋¬AB。它在两输入不同的时候为1，也就是异或。イ和エ在两输入相同的时候为1，属于同或；ア把 A·B 与它的否定相或，恒为1。原卷逻辑门和上划线的精确形状见配图。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 11,
    "imageAssets": [
      "question-images/fe-2017-f-am-23.jpg"
    ],
    "transcriptionNoteZh": "原卷含图表，已附上 IPA 官方试卷该题的完整裁图；文字为便于阅读的线性转录，图形与原版排版以裁图为准。"
  },
  {
    "id": "FE-2017-F-AM-24",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 24,
    "topicZh": "校验位计算",
    "stemJa": "次の方式によって求められるチェックディジットを付加した結果はどれか。ここで，データを7394，重み付け定数を1234，基数を11とする。方式：(1)データと重み付け定数の，対応する桁ごとの積を求め，それらの和を求める。(2)和を基数で割って，余りを求める。(3)基数から余りを減じ，その結果の1の位をチェックディジットとしてデータの末尾に付加する。",
    "options": [
      {
        "label": "ア",
        "textJa": "73940"
      },
      {
        "label": "イ",
        "textJa": "73941"
      },
      {
        "label": "ウ",
        "textJa": "73944"
      },
      {
        "label": "エ",
        "textJa": "73947"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。按题设的位权对应相乘：7×1＋3×2＋9×3＋4×4＝7＋6＋27＋16＝56。56除以基数11，余数为1；再用11－1＝10，只取结果个位得到校验数字0。把0接在原始数据7394后面就是73940。イ、ウ、エ分别附加1、4、7，没有按照“基数减余数，再取个位”的完整步骤计算。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 12
  },
  {
    "id": "FE-2017-F-AM-25",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 25,
    "topicZh": "三维图形的遮挡处理",
    "stemJa": "3次元CGのレンダリングにおける、隠線消去及び隠面消去の説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "光源の位置と対象物体への光の当たり具合とを解析し、どのような色・明るさで見えるのかを決定する。"
      },
      {
        "label": "イ",
        "textJa": "指定された視点から見える部分だけを描くようにする。"
      },
      {
        "label": "ウ",
        "textJa": "生成された画像について、表示する画面に収まる部分だけを表示する。"
      },
      {
        "label": "エ",
        "textJa": "物体の表面だけでなく物体の内部や背後に隠れた部分の形状も、半透明表示などによって画像として生成する。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案是イ。三维物体投影到画面时，有些线条或表面被前面的物体挡住；隠線消去、隠面消去就是从指定视点只画能看见的部分。ア计算光照后决定颜色与明暗，属于着色处理；ウ只截取显示范围内的图像，偏向裁剪，与前后遮挡不同；エ通过半透明把内部或后方也显示出来，恰好不是消去隐藏部分。辨认题眼是“从视点能否看到”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 12
  },
  {
    "id": "FE-2017-F-AM-26",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 26,
    "topicZh": "数据库存储过程",
    "stemJa": "クライアントサーバシステムにおいて、利用頻度の高い命令群をあらかじめサーバ上のDBMSに格納しておくことによって、クライアントサーバ間のネットワーク負荷を軽減する仕組みはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "2相コミットメント"
      },
      {
        "label": "イ",
        "textJa": "グループコミットメント"
      },
      {
        "label": "ウ",
        "textJa": "サーバプロセスのマルチスレッド化"
      },
      {
        "label": "エ",
        "textJa": "ストアドプロシージャ"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。ストアドプロシージャ把常用的一组数据库操作预先保存在DBMS服务器端。客户端调用它时，无须把每条指令和中间结果都在网络上往返传输，因此可减轻客户端与服务器之间的通信负担。ア两阶段提交解决分布式事务如何一致提交；イ组提交侧重合并日志提交；ウ服务器多线程有助于并发处理，但不是“预先在DBMS中保存命令群”的机制。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 12
  },
  {
    "id": "FE-2017-F-AM-27",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 27,
    "topicZh": "SQL 外键与参照约束",
    "stemJa": "SQL文においてFOREIGN KEYとREFERENCESを用いて指定する制約はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "キー制約"
      },
      {
        "label": "イ",
        "textJa": "検査制約"
      },
      {
        "label": "ウ",
        "textJa": "参照制約"
      },
      {
        "label": "エ",
        "textJa": "表明"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案是ウ。FOREIGN KEY指定本表用于引用别的表的列，REFERENCES指定被引用的表或列；数据库据此检查引用关系，例如订单里的客户编号必须指向已有客户，这就是参照约束（参照完整性）。ア“键约束”并未说明跨表引用；イ检查约束通常用CHECK限定数值范围等条件；エ表明（ASSERTION）是更一般的数据库条件声明。读到FOREIGN KEY…REFERENCES，就找跨表的参照约束。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 13
  },
  {
    "id": "FE-2017-F-AM-28",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 28,
    "topicZh": "UML 类图与多重度",
    "stemJa": "UMLを用いて表した図のデータモデルの解釈のうち，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "事業部以外の部門が，部門を管理できる。"
      },
      {
        "label": "イ",
        "textJa": "社員は事業部に所属できる。"
      },
      {
        "label": "ウ",
        "textJa": "所属する社員がいない部門が存在する。"
      },
      {
        "label": "エ",
        "textJa": "部門は，いずれかの事業部が管理している。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案是イ。图中“事業部”到“部門”的空心三角表示事業部是部門的一种，因此“社員属于部門”也允许该部門具体是事業部。所属关系的社員端为1..*，所以每个部門至少有1名社員，ウ错误；管理关系在事業部端为0..1，允许部門没有管理者，エ错误；管理关系的管理者限定为事業部，不能据此推出其他部門也能管理，ア错误。多重度应读关联端标注。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 13,
    "imageAssets": [
      "question-images/fe-2017-f-am-28.jpg"
    ],
    "transcriptionNoteZh": "原卷含图表，已附上 IPA 官方试卷该题的完整裁图；文字为便于阅读的线性转录，图形与原版排版以裁图为准。"
  },
  {
    "id": "FE-2017-F-AM-29",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 29,
    "topicZh": "数据库事务 ACID",
    "stemJa": "RDBMSの機能によって実現されるトランザクションの性質はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "ACID特性"
      },
      {
        "label": "イ",
        "textJa": "関数従属性"
      },
      {
        "label": "ウ",
        "textJa": "候補キーの一意性"
      },
      {
        "label": "エ",
        "textJa": "データ独立性"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。事务是一组需要整体完成的数据库操作。RDBMS通过事务管理支持ACID：原子性表示全做或全不做；一致性表示事务前后遵守约束；隔离性表示并发事务彼此妥善隔离；持久性表示提交后结果能保存。イ函数依赖是关系模式中列之间的依赖；ウ候选键的唯一性是键的性质；エ数据独立性描述应用与数据结构变化的分离。后三项都不是事务的四项核心性质。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 13
  },
  {
    "id": "FE-2017-F-AM-30",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 30,
    "topicZh": "事务回滚与更新前日志",
    "stemJa": "トランザクション処理プログラムが、データベース更新の途中で異常終了した場合、ロールバック処理によってデータベースを復元する。このとき使用する情報はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "最新のスナップショット情報"
      },
      {
        "label": "イ",
        "textJa": "最新のバックアップファイル情報"
      },
      {
        "label": "ウ",
        "textJa": "ログファイルの更新後情報"
      },
      {
        "label": "エ",
        "textJa": "ログファイルの更新前情報"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。事务更新到一半异常结束，需要撤销尚未完成的更改；要还原原值，就读取日志文件中记录的“更新前信息”（before image）。ウ的更新后信息用于重做已提交但尚未写入数据库的更新，方向相反。ア快照和イ备份通常用于较大范围的恢复，不能替代逐项撤销本事务变更所需的更新前记录。解题先判断方向：回滚＝撤销＝找旧值。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 14
  },
  {
    "id": "FE-2017-F-AM-31",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 31,
    "topicZh": "边下载边播放的缓冲时间",
    "stemJa": "符号化速度が192kビット／秒の音声データ2.4Mバイトを，通信速度が128kビット／秒のネットワークを用いてダウンロードしながら途切れることなく再生するためには，再生開始前のデータのバッファリング時間として最低何秒間が必要か。",
    "options": [
      {
        "label": "ア",
        "textJa": "50"
      },
      {
        "label": "イ",
        "textJa": "100"
      },
      {
        "label": "ウ",
        "textJa": "150"
      },
      {
        "label": "エ",
        "textJa": "250"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。音频总量2.4M字节＝19.2M比特。以192k比特/秒播放，需要100秒；以128k比特/秒下载完全部则需150秒。若开始播放时尚未先缓存，播放器会比下载器快，最后会断流。至少提前下载150－100＝50秒，之后100秒播放的末尾刚好下载完成。イ、ウ、エ虽然缓存更久，但题目问最低时间。这里 M 与 k 的比例相同，8比特＝1字节。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 14
  },
  {
    "id": "FE-2017-F-AM-32",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 32,
    "topicZh": "二层交换机与 MAC 地址",
    "stemJa": "ネットワーク機器の一つであるスイッチングハブ(レイヤ2スイッチ)の機能として、適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "LANポートに接続された端末に対して、IPアドレスの動的な割当てを行う。"
      },
      {
        "label": "イ",
        "textJa": "受信したパケットを、宛先MACアドレスが存在するLANポートだけに転送する。"
      },
      {
        "label": "ウ",
        "textJa": "受信したパケットを、全てのLANポートに転送(ブロードキャスト)する。"
      },
      {
        "label": "エ",
        "textJa": "受信したパケットを、ネットワーク層で分割(フラグメンテーション)する。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案是イ。二层交换机依据目的MAC地址和学习到的端口对应关系，把以太网帧送往相应端口；知道目的端口时，无需转发到所有端口。ア动态分配IP地址是DHCP服务的工作；ウ向所有端口转发更接近集线器的行为（交换机遇到未知目的地址等情况也可能泛洪，不能据此把它作为一般功能定义）；エ在网络层分割IP包，不是二层交换机的任务。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 14
  },
  {
    "id": "FE-2017-F-AM-33",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 33,
    "topicZh": "NAT 地址转换",
    "stemJa": "IPv4において、インターネット接続用ルータのNAT機能の説明として、適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "インターネットへのアクセスをキャッシュしておくことによって、その後に同じIPアドレスのWebサイトへアクセスする場合、表示を高速化できる機能である。"
      },
      {
        "label": "イ",
        "textJa": "通信中のIPパケットを検査して、インターネットからの攻撃や侵入を検知する機能である。"
      },
      {
        "label": "ウ",
        "textJa": "特定の端末宛てのIPパケットだけを通過させる機能である。"
      },
      {
        "label": "エ",
        "textJa": "プライベートIPアドレスとグローバルIPアドレスを相互に変換する機能である。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。NAT把私有IP地址与公网IP地址相互转换，让使用私有地址的设备通过路由器与互联网通信；应答回来时再按转换记录送回对应设备。ア是缓存/代理加速的描述；イ检查流量并发现攻击更接近入侵检测；ウ只允许特定目标数据包通过属于访问控制或包过滤。NAT的关键词是“地址转换”，而不是加速、检测或过滤。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 15
  },
  {
    "id": "FE-2017-F-AM-34",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 34,
    "topicZh": "UDP 实时通信",
    "stemJa": "トランスポート層のプロトコルであり，信頼性よりもリアルタイム性が重視される場合に用いられるものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "HTTP"
      },
      {
        "label": "イ",
        "textJa": "IP"
      },
      {
        "label": "ウ",
        "textJa": "TCP"
      },
      {
        "label": "エ",
        "textJa": "UDP"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。UDP 工作在传输层，以较小的协议开销发送数据报，不强制建立连接，也不保证重传与有序交付，适合语音等更看重实时性的场景。HTTP 属应用层，IP 属网络层，两者层次已不符题干；TCP 虽是传输层，但通过确认、重传、顺序控制提高可靠性，会引入相应等待。题目不是说 UDP 一定无延迟，而是在所列协议中选实时性优先的。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 15
  },
  {
    "id": "FE-2017-F-AM-35",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 35,
    "topicZh": "IPv4 子网地址",
    "stemJa": "次のIPアドレスとサブネットマスクをもつPCがある。このPCのネットワークアドレスとして，適切なものはどれか。IPアドレス：10.170.70.19，サブネットマスク：255.255.255.240。",
    "options": [
      {
        "label": "ア",
        "textJa": "10.170.70.0"
      },
      {
        "label": "イ",
        "textJa": "10.170.70.16"
      },
      {
        "label": "ウ",
        "textJa": "10.170.70.31"
      },
      {
        "label": "エ",
        "textJa": "10.170.70.255"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案是イ。掩码最后一字节240＝11110000，意味着该字节前4位是网络位；每个子网有16个地址，边界是0、16、32等。地址最后一字节19落在16～31这一组，按位与 19 AND 240 也得到16，因此网络地址是10.170.70.16。ア是前一个子网；ウ是本子网广播地址；エ是更大范围的末尾地址，都不是本主机的网络地址。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 15
  },
  {
    "id": "FE-2017-F-AM-36",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 36,
    "topicZh": "僵尸网络与 C&C 服务器",
    "stemJa": "ボットネットにおいてC&Cサーバが果たす役割はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "遠隔操作が可能なマルウェアに，情報収集及び攻撃活動を指示する。"
      },
      {
        "label": "イ",
        "textJa": "電子商取引事業者などに，偽のディジタル証明書の発行を命令する。"
      },
      {
        "label": "ウ",
        "textJa": "不正なWebコンテンツのテキスト，画像及びレイアウト情報を一元的に管理する。"
      },
      {
        "label": "エ",
        "textJa": "踏み台となる複数のサーバからの通信を制御し遮断する。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。C&C 是 Command and Control，即命令与控制；攻击者借服务器向已被恶意程序控制的终端下达收集信息或发起攻击的指令。イ说的是向证书相关机构发命令，不是僵尸网络的典型控制功能；ウ更像网页内容管理；エ的“阻断通信”是防御行为，与攻击者操纵受感染设备的角色相反。要抓住题干中的“ボットネット”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 16
  },
  {
    "id": "FE-2017-F-AM-37",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 37,
    "topicZh": "DNS 缓存投毒",
    "stemJa": "DNSキャッシュポイズニングに分類される攻撃内容はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "DNSサーバのソフトウェアのバージョン情報を入手して，DNSサーバのセキュリティホールを特定する。"
      },
      {
        "label": "イ",
        "textJa": "PCが参照するDNSサーバに偽のドメイン情報を注入して，利用者を偽装されたサーバに誘導する。"
      },
      {
        "label": "ウ",
        "textJa": "攻撃対象のサービスを妨害するために，攻撃者がDNSサーバを踏み台に利用して再帰的な問合せを大量に行う。"
      },
      {
        "label": "エ",
        "textJa": "内部情報を入手するために，DNSサーバが保存するゾーン情報をまとめて転送させる。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案是イ。DNS 缓存投毒是把虚假的域名与 IP 对应关系放入被查询的 DNS 缓存，之后用户即使输入正确域名，也可能得到伪造地址并被导向假网站。ア属于版本侦察与漏洞探测；ウ描述借 DNS 大量查询妨碍服务，属于拒绝服务思路；エ描述区域传送泄露内部域名信息。后三者都没有把伪造的解析结果注入缓存。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 16
  },
  {
    "id": "FE-2017-F-AM-38",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 38,
    "topicZh": "RSA 的数学基础",
    "stemJa": "非常に大きな数の素因数分解が困難なことを利用した公開鍵暗号方式はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "AES"
      },
      {
        "label": "イ",
        "textJa": "DH"
      },
      {
        "label": "ウ",
        "textJa": "DSA"
      },
      {
        "label": "エ",
        "textJa": "RSA"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。RSA 公钥密码的经典构造使用两个大素数相乘得到模数；从公钥中的大模数反推素因数在参数足够大时很困难，正是题干所问的依据。AES 是对称密钥加密，并非公钥方式；DH 是密钥交换方案，其经典形式关联离散对数问题；DSA 是数字签名算法，也不是此处所指的基于整数分解的加密方式。看清题干同时限定“公钥”和“素因数分解”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 16
  },
  {
    "id": "FE-2017-F-AM-39",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 39,
    "topicZh": "SQL 注入攻击",
    "stemJa": "SQLインジェクション攻撃の説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "Webアプリケーションに問題があるとき，悪意のある問合せや操作を行う命令文をWebサイトに入力して，データベースのデータを不正に取得したり改ざんしたりする攻撃"
      },
      {
        "label": "イ",
        "textJa": "悪意のあるスクリプトを埋め込んだWebページを訪問者に閲覧させて，別のWebサイトで，その訪問者が意図しない操作を行わせる攻撃"
      },
      {
        "label": "ウ",
        "textJa": "市販されているDBMSの脆弱性を悪用することによって，宿主となるデータベースサーバを探して感染を繰り返し，インターネットのトラフィックを急増させる攻撃"
      },
      {
        "label": "エ",
        "textJa": "訪問者の入力データをそのまま画面に表示するWebサイトを悪用して，悪意のあるスクリプトを訪問者のWebブラウザで実行させる攻撃"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。SQL 注入发生在应用把不可信的输入拼进数据库查询或更新语句时，攻击者构造输入改变原本的 SQL 含义，可能读取或改写数据。イ让用户在另一站点执行非本意操作，属于跨站请求伪造一类；ウ说的是利用 DBMS 漏洞自我传播的蠕虫行为；エ让恶意脚本在访客浏览器运行，属于跨站脚本攻击。判断核心是最终被操纵的对象是否为数据库查询语句。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 17
  },
  {
    "id": "FE-2017-F-AM-40",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 40,
    "topicZh": "数字签名与身份验证",
    "stemJa": "ディジタル署名における署名鍵の使い方と，ディジタル署名を行う目的のうち，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "受信者が署名鍵を使って，暗号文を元のメッセージに戻すことができるようにする。"
      },
      {
        "label": "イ",
        "textJa": "送信者が固定文字列を付加したメッセージを署名鍵を使って暗号化することによって，受信者がメッセージの改ざん部位を特定できるようにする。"
      },
      {
        "label": "ウ",
        "textJa": "送信者が署名鍵を使って署名を作成し，その署名をメッセージに付加することによって，受信者が送信者を確認できるようにする。"
      },
      {
        "label": "エ",
        "textJa": "送信者が署名鍵を使ってメッセージを暗号化することによって，メッセージの内容を関係者以外に分からないようにする。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案是ウ。发送者保管签名用私钥，用它为消息制作签名；接收者用相应的验证公钥检查签名，可验证签名者及消息是否被篡改。ア把签名钥匙当作接收方解密钥匙；イ声称可定位具体篡改位置，签名验证通常只显示验证失败而不定位；エ把签名当作保密加密，数字签名并不自动隐藏消息内容。应区分身份/完整性与机密性。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 17
  },
  {
    "id": "FE-2017-F-AM-41",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 41,
    "topicZh": "蠕虫与特洛伊木马",
    "stemJa": "マルウェアについて，トロイの木馬とワームを比較したとき，ワームの特徴はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "勝手にファイルを暗号化して正常に読めなくする。"
      },
      {
        "label": "イ",
        "textJa": "単独のプログラムとして不正な動作を行う。"
      },
      {
        "label": "ウ",
        "textJa": "特定の条件になるまで活動をせずに待機する。"
      },
      {
        "label": "エ",
        "textJa": "ネットワークやリムーバブルメディアを媒介として自ら感染を広げる。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。蠕虫区别于特洛伊木马的关键是可通过网络或可移动介质主动复制并传播，不必依靠用户反复安装一个伪装程序。ア描述擅自加密文件的勒索软件行为；イ说“独立程序进行恶意动作”，木马也可以如此，不能据此区分；ウ是等待触发条件的行为，可能出现在多种恶意软件中。题目比较两类恶意软件，需选择最有区分度的传播特征。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 18
  },
  {
    "id": "FE-2017-F-AM-42",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 42,
    "topicZh": "CSIRT 事件响应组织",
    "stemJa": "CSIRTの説明として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "IPアドレスの割当て方針の決定，DNSルートサーバの運用監視，DNS管理に関する調整などを世界規模で行う組織である。"
      },
      {
        "label": "イ",
        "textJa": "インターネットに関する技術文書を作成し，標準化のための検討を行う組織である。"
      },
      {
        "label": "ウ",
        "textJa": "企業内・組織内や政府機関に設置され，情報セキュリティインシデントに関する報告を受け取り，調査し，対応活動を行う組織の総称である。"
      },
      {
        "label": "エ",
        "textJa": "情報技術を利用し，宗教的又は政治的な目標を達成するという目的をもつ者や組織の総称である。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案是ウ。CSIRT 是计算机安全事件响应团队，组织遭遇入侵、恶意软件或信息泄露等事件时，负责接收报告、分析调查并协调处置。ア描述全球地址及 DNS 治理相关机构的职能；イ是互联网技术标准文档制定组织的职能；エ描述利用技术实现政治或宗教目标的主体。这些都不是企业或机构内部的安全事件响应团队。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 18
  },
  {
    "id": "FE-2017-F-AM-43",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 43,
    "topicZh": "信息安全风险评估流程",
    "stemJa": "リスクアセスメントを構成するプロセスの組合せはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "リスク特定，リスク評価，リスク受容"
      },
      {
        "label": "イ",
        "textJa": "リスク特定，リスク分析，リスク評価"
      },
      {
        "label": "ウ",
        "textJa": "リスク分析，リスク対応，リスク受容"
      },
      {
        "label": "エ",
        "textJa": "リスク分析，リスク評価，リスク対応"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案是イ。风险评估由风险识别、风险分析和风险评价组成：先找出可能发生什么，再分析其影响与可能性，最后对照准则判断风险等级和优先次序。风险应对是在评估结果之后选择降低、回避或转移等措施；风险接受是对剩余风险作决定。因此ア混入“受容”且漏分析，ウ、エ混入“対応”，都不是评估本身的三段组合。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 18
  },
  {
    "id": "FE-2017-F-AM-44",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 44,
    "topicZh": "数据库通信防窃听",
    "stemJa": "図のように，クライアント上のアプリケーションがデータベース接続プログラム経由でサーバ上のデータベースのデータにアクセスする。アプリケーションとデータベースとの間で送受信されるコマンドや実行結果の漏えいを防止する対策はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "サーバ側のデータベース接続プログラムにアクセスできるクライアントのIPアドレスを必要なものだけに制限する。"
      },
      {
        "label": "イ",
        "textJa": "サーバ側のデータベース接続プログラムを起動・停止するときに必要なパスワードを設定する。"
      },
      {
        "label": "ウ",
        "textJa": "データベース接続プログラムが通信に使用するポート番号をデータベース管理システムでの初期値から変更する。"
      },
      {
        "label": "エ",
        "textJa": "データベース接続プログラム間の通信を暗号化する。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。图中的攻击者在通信路径上窃听，目标是读到数据库命令及查询结果。因此应加密客户端和服务器数据库连接程序之间的通信，使截获的数据无法直接理解。ア的 IP 限制用于控制谁能连接，无法阻止已允许通信被旁听；イ的启动密码保护服务管理操作，不保护传输内容；ウ更改端口号只是改变入口位置，也不提供机密性。根据攻击发生的位置选防护措施。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 19,
    "imageAssets": [
      "question-images/fe-2017-f-am-44.jpg"
    ],
    "transcriptionNoteZh": "原卷含图表，已附上 IPA 官方试卷该题的完整裁图；文字为便于阅读的线性转录，图形与原版排版以裁图为准。"
  },
  {
    "id": "FE-2017-F-AM-45",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 45,
    "topicZh": "渗透测试",
    "stemJa": "コンピュータやネットワークのセキュリティ上の脆弱性を発見するために，システムを実際に攻撃して侵入を試みる手法はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "ウォークスルー"
      },
      {
        "label": "イ",
        "textJa": "ソフトウェアインスペクション"
      },
      {
        "label": "ウ",
        "textJa": "ペネトレーションテスト"
      },
      {
        "label": "エ",
        "textJa": "リグレッションテスト"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案是ウ。渗透测试会在约定范围内模拟真实攻击，尝试利用弱点进入系统，以确认风险是否能被利用。ウォークスルー和软件审查主要通过人员共同检查设计、代码或文档，不等于实际攻击目标系统；回归测试则是在修改后确认既有功能未被破坏。题干的关键动作是“实际攻击并尝试侵入”，对应ペネトレーションテスト。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 19
  },
  {
    "id": "FE-2017-F-AM-46",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 46,
    "topicZh": "UML 顺序图",
    "stemJa": "UML2.0において，オブジェクト間の相互作用を時系列に表す図はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "アクティビティ図"
      },
      {
        "label": "イ",
        "textJa": "コンポーネント図"
      },
      {
        "label": "ウ",
        "textJa": "シーケンス図"
      },
      {
        "label": "エ",
        "textJa": "状態遷移図"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案是ウ。顺序图把对象沿横向排列，消息沿时间方向依次绘出，正适合表示“对象之间的交互按什么先后发生”。活动图描述业务或控制流程；组件图表示软件部件及依赖；状态迁移图表示某对象的状态与转换条件。这三者各有用途，却不以多个对象之间消息的时间顺序为中心。看到“相互作用”和“時系列”就定位到シーケンス図。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 20
  },
  {
    "id": "FE-2017-F-AM-47",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 47,
    "topicZh": "类与实例对象",
    "stemJa": "オブジェクト指向分析を用いてモデリングしたとき，クラスとオブジェクトの関係になる組みはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "公園，ぶらんこ"
      },
      {
        "label": "イ",
        "textJa": "公園，代々木公園"
      },
      {
        "label": "ウ",
        "textJa": "鉄棒，ぶらんこ"
      },
      {
        "label": "エ",
        "textJa": "中之島公園，代々木公園"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案是イ。类是共同特征与行为的抽象定义，对象是符合该定义的具体实例。“公園”是类，“代々木公園”是一个具体公园，构成类与对象的关系。ア的公园与秋千更像整体与组成部分；ウ的单杠与秋千是不同种类的器材；エ列出两个具体公园，都是实例而不是类。判断时问自己：前者能否作为后者所属的类别。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 20
  },
  {
    "id": "FE-2017-F-AM-48",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 48,
    "topicZh": "模块耦合度",
    "stemJa": "モジュール結合度が最も弱くなるものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "一つのモジュールで，できるだけ多くの機能を実現する。"
      },
      {
        "label": "イ",
        "textJa": "二つのモジュール間で必要なデータ項目だけを引数として渡す。"
      },
      {
        "label": "ウ",
        "textJa": "他のモジュールとデータ項目を共有するためにグローバルな領域を使用する。"
      },
      {
        "label": "エ",
        "textJa": "他のモジュールを呼び出すときに，呼び出したモジュールの論理を制御するための引数を渡す。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案是イ。只通过参数传递对方完成任务所需的数据，属于较弱的数据耦合；模块不用知道对方内部实现，也不共享全局状态。ア把许多功能塞进同一模块，讨论的是模块内聚性而非降低模块间耦合；ウ使用全局共享区会让多个模块依赖共同状态；エ传递控制对方逻辑的参数是控制耦合，比单纯传数据联系更紧。低耦合的核心是接口窄且依赖少。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 20
  },
  {
    "id": "FE-2017-F-AM-49",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 49,
    "topicZh": "黑盒测试的局限",
    "stemJa": "ブラックボックステストに関する記述のうち，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "テストデータの作成基準として，命令や分岐の網羅率を使用する。"
      },
      {
        "label": "イ",
        "textJa": "被テストプログラムに冗長なコードがあっても検出できない。"
      },
      {
        "label": "ウ",
        "textJa": "プログラムの内部構造に着目し，必要な部分が実行されたかどうかを検証する。"
      },
      {
        "label": "エ",
        "textJa": "分岐命令やモジュールの数が増えると，テストデータが急増する。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案是イ。黑盒测试只根据规格和输入输出检验外部行为，不查看代码内部，所以即使程序里有不影响结果的多余代码，也可能无法发现。ア的语句与分支覆盖率、ウ的内部结构和执行路径，都是白盒测试的关注点；エ以分支或模块数量推导测试数据的增长，同样依赖内部结构，不是黑盒测试的直接特征。零基础可记为“黑盒看外部、白盒看内部”。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 20
  },
  {
    "id": "FE-2017-F-AM-50",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 50,
    "topicZh": "软件逆向工程",
    "stemJa": "ソフトウェアのリバースエンジニアリングの説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "開発支援ツールなどを用いて，設計情報からソースコードを自動生成する。"
      },
      {
        "label": "イ",
        "textJa": "外部から見たときの振る舞いを変えずに，ソフトウェアの内部構造を変える。"
      },
      {
        "label": "ウ",
        "textJa": "既存のソフトウェアを解析し，その仕様や構造を明らかにする。"
      },
      {
        "label": "エ",
        "textJa": "既存のソフトウェアを分析し理解した上で，ソフトウェア全体を新しく構築し直す。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案是ウ。逆向工程从已有软件出发进行分析，恢复或弄清它的规格、设计和内部结构；方向是“实现→理解”。ア是从设计生成代码的正向开发；イ在外部行为不变的前提下改善内部结构，属于重构；エ先分析再整体重新构建，属于再工程的范围，比单纯逆向分析多了重建步骤。应把“理解现物”和“生成新物”区分开。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 21
  },
  {
    "id": "FE-2017-F-AM-51",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 51,
    "topicZh": "功能点法估算",
    "stemJa": "ファンクションポイント法の説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "開発するプログラムごとのステップ数を積算し，開発規模を見積もる。"
      },
      {
        "label": "イ",
        "textJa": "開発プロジェクトで必要な作業のWBSを作成し，各作業の工数を見積もる。"
      },
      {
        "label": "ウ",
        "textJa": "外部入出力や内部論理ファイル，外部照会，外部インタフェースファイルの個数と特性などから開発規模を見積もる。"
      },
      {
        "label": "エ",
        "textJa": "過去の類似例を探し，その実績や開発するシステムとの差異などを分析・評価して開発規模を見積もる。"
      }
    ],
    "answer": "ウ",
    "explanationZh": "正确答案是ウ。功能点法依据使用者可见的功能来估算规模，计数外部输入、输出、查询、内部逻辑文件和外部接口文件，再考虑各类功能的特性。ア按代码行数估算；イ按工作分解结构逐项估工时；エ参照类似项目的历史实绩。后三者也能用于估算，但没有功能点法特有的“输入输出与逻辑文件等功能数量”依据。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 21
  },
  {
    "id": "FE-2017-F-AM-52",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 52,
    "topicZh": "项目工时估算",
    "stemJa": "全部で100画面から構成されるシステムの画面を作成する。100画面を規模と複雑度で分類したときの内訳は次のとおりである。規模が「小」で複雑度が「単純」の画面数：30，規模が「中」で複雑度が「普通」の画面数：40，規模が「大」で複雑度が「普通」の画面数：20，規模が「大」で複雑度が「複雑」の画面数：10。全ての画面を作成する総工数を，表の作成工数を用いて見積もると何人日になるか。ここで，全部の画面のレビューと修正に5人日を要し，作業の管理にはレビューと修正の工数を含めた作業工数の20％を要するものとする。表の画面当たり作成工数（人日）：小×単純0.4，中×普通0.9，大×普通1.0，大×複雑1.2。",
    "options": [
      {
        "label": "ア",
        "textJa": "80"
      },
      {
        "label": "イ",
        "textJa": "85"
      },
      {
        "label": "ウ",
        "textJa": "101"
      },
      {
        "label": "エ",
        "textJa": "102"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。先按题中各类画面的数量乘每画面工时：30×0.4＝12、40×0.9＝36、20×1.0＝20、10×1.2＝12，制作小计80人日。加上所有画面的评审与修正5人日，作业工时是85。管理工时按“包含评审修正的作业工时”的20%计算，即85×0.2＝17；总计85＋17＝102人日。ア只计制作；イ漏管理；ウ则不是按题设的基数及比例计算。原表其他格未被本题使用，见原卷图。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 22,
    "imageAssets": [
      "question-images/fe-2017-f-am-52.jpg"
    ],
    "transcriptionNoteZh": "原卷含图表，已附上 IPA 官方试卷该题的完整裁图；文字为便于阅读的线性转录，图形与原版排版以裁图为准。"
  },
  {
    "id": "FE-2017-F-AM-53",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 53,
    "topicZh": "关键路径",
    "stemJa": "図に示すプロジェクト活動のクリティカルパスはどれか。図中の作業名と所要日数は，A＝2，B＝3，C＝3，D＝1，E＝1，F＝3，G＝4，H＝3，I＝2，J＝2，K＝2，L＝3である。",
    "options": [
      {
        "label": "ア",
        "textJa": "A→B→E→I→L"
      },
      {
        "label": "イ",
        "textJa": "A→C→D→E→H→K"
      },
      {
        "label": "ウ",
        "textJa": "A→C→F→I→L"
      },
      {
        "label": "エ",
        "textJa": "A→C→G→J→L"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。关键路径是从开始到结束、累计耗时最长且决定最早完工时间的依赖路径。沿原卷网络图逐条计算：ア为2＋3＋1＋2＋3＝11日；イ为2＋3＋1＋1＋3＋2＝12日；ウ为2＋3＋3＋2＋3＝13日；エ为2＋3＋4＋2＋3＝14日。故 A→C→G→J→L 最长，任一关键作业延迟且无赶工时都会推迟完工。节点合流时必须等所有前置作业，不能只看某一箭头长度。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 22,
    "imageAssets": [
      "question-images/fe-2017-f-am-53.jpg"
    ],
    "transcriptionNoteZh": "原卷含图表，已附上 IPA 官方试卷该题的完整裁图；文字为便于阅读的线性转录，图形与原版排版以裁图为准。"
  },
  {
    "id": "FE-2017-F-AM-54",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 54,
    "topicZh": "帕累托图",
    "stemJa": "プロジェクトで発生した課題の傾向を分析するために，ステークホルダ，コスト，スケジュール，品質などの管理項目別の課題件数を棒グラフとして件数が多い順に並べ，この順で累積した課題件数を折れ線グラフとして重ね合わせた図を作成した。この図はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "管理図"
      },
      {
        "label": "イ",
        "textJa": "散布図"
      },
      {
        "label": "ウ",
        "textJa": "特性要因図"
      },
      {
        "label": "エ",
        "textJa": "パレート図"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。帕累托图把各类别的件数按从大到小的柱形排列，并叠加累计件数或累计比例的折线，用于找出主要问题类别。ア的管理图关注指标随时间波动及控制界限；イ的散布图观察两个变量的关系；ウ的特性要因图用鱼骨结构整理可能原因。题干同时出现“降序柱形”和“累积折线”，正是パレート図的定义。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 23
  },
  {
    "id": "FE-2017-F-AM-55",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 55,
    "topicZh": "服务级别管理与 SLA",
    "stemJa": "サービスマネジメントにおいて，サービスレベル管理の要求事項はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "サービス継続及び可用性に対するリスクを評価し，文書化する。"
      },
      {
        "label": "イ",
        "textJa": "提供するサービスのサービスカタログとSLAを作成し，顧客と合意する。"
      },
      {
        "label": "ウ",
        "textJa": "人，技術，情報及び財務に関する資源を考慮して，容量・能力の計画を作成，実施及び維持する。"
      },
      {
        "label": "エ",
        "textJa": "予算に照らして費用を監視及び報告し，財務予測をレビューし，費用を管理する。"
      }
    ],
    "answer": "イ",
    "explanationZh": "正确答案是イ。服务级别管理要明确向客户提供哪些服务及约定达到怎样的服务水平，所以服务目录和与客户达成的 SLA 是核心。ア关于服务连续性和可用性的风险评估；ウ是容量与能力管理；エ是财务管理。它们都属于服务管理可能涉及的工作，但题目专问“服务级别”，要把客户可见的服务承诺与后台容量或费用活动分开。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 23
  },
  {
    "id": "FE-2017-F-AM-56",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 56,
    "topicZh": "备份时间安排",
    "stemJa": "新規システムにおけるデータのバックアップ方法に関する記述のうち，最も適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "業務処理がバックアップ処理と重なると応答時間が長くなる可能性がある場合には，両方の処理が重ならないようにスケジュールを立てる。"
      },
      {
        "label": "イ",
        "textJa": "バックアップ処理時間を短くするためには，バックアップデータをバックアップ元データと同一の記憶媒体内に置く。"
      },
      {
        "label": "ウ",
        "textJa": "バックアップデータからの復旧時間を短くするためには，差分バックアップを採用する。"
      },
      {
        "label": "エ",
        "textJa": "バックアップデータを長期間保存するためには，ランダムアクセスが可能な媒体を使用する。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。备份读取大量数据会占用磁盘、网络及处理资源，若与业务高峰重叠可能拉长用户响应时间，排程错开两者是合理措施。イ把备份放在与原数据同一介质，故障时可能一起丢失，也不能据此保证备份更快；ウ的差分备份是否缩短恢复时间要看与哪种方式比较、备份链和数据量，不能一概而论；エ长期保存重在介质寿命与保管策略，并不取决于能否随机访问。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 23
  },
  {
    "id": "FE-2017-F-AM-57",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 57,
    "topicZh": "雷击浪涌防护",
    "stemJa": "落雷によって発生する過電圧の被害から情報システムを守るための手段として有効なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "サージ防護デバイス（SPD）を介して通信ケーブルとコンピュータを接続する。"
      },
      {
        "label": "イ",
        "textJa": "自家発電装置を設置する。"
      },
      {
        "label": "ウ",
        "textJa": "通信線を，経路が異なる2系統とする。"
      },
      {
        "label": "エ",
        "textJa": "電源設備の制御回路をディジタル化する。"
      }
    ],
    "answer": "ア",
    "explanationZh": "正确答案是ア。雷击产生的瞬态过电压可沿通信线进入设备；SPD 浪涌保护装置可限制或泄放这类尖峰，使连接的电脑受到保护。イ自备发电机主要应对停电，不能消除线路上的过电压；ウ双路径线路提高通信可用性，但两条线都可能带入浪涌；エ把控制电路数字化也不等于具备过压保护。题眼是“过电压”，应选择电气浪涌防护。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 24
  },
  {
    "id": "FE-2017-F-AM-58",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 58,
    "topicZh": "运维审计与职责分离",
    "stemJa": "システム運用業務のオペレーション管理に関する監査で判明した状況のうち，指摘事項として監査報告書に記載すべきものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "運用責任者が，オペレータの作成したオペレーション記録を確認している。"
      },
      {
        "label": "イ",
        "textJa": "運用責任者が，期間を定めてオペレーション記録を保管している。"
      },
      {
        "label": "ウ",
        "textJa": "オペレータが，オペレーション中に起きた例外処理を記録している。"
      },
      {
        "label": "エ",
        "textJa": "オペレータが，日次の運用計画を決定し，自ら承認している。"
      }
    ],
    "answer": "エ",
    "explanationZh": "正确答案是エ。操作员自己决定每日运维计划又自己批准，会使审批失去独立检查作用；同一人兼任申请和批准，属于职责分离不足，应列为审计发现。ア由负责人复核运维记录，イ按期限保管记录，ウ记录异常处理，都能留下可追踪证据并支持监督，题目没有给出其本身违规的条件。审计题需找可明确说明控制失效的做法，而不是把所有操作活动都当作问题。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 24
  },
  {
    "id": "FE-2017-F-AM-59",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 59,
    "topicZh": "系统审计中的访谈证据",
    "stemJa": "システム監査人が実施するヒアリングに関する記述のうち，最も適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "監査業務を経験したことのある被監査部門の管理者をヒアリングの対象者として選ぶ。"
      },
      {
        "label": "イ",
        "textJa": "ヒアリングで被監査部門から得た情報を裏付けるための文書や記録を入手するよう努める。"
      },
      {
        "label": "ウ",
        "textJa": "ヒアリングの中で気が付いた不備事項について，その場で被監査部門に改善を指示する。"
      },
      {
        "label": "エ",
        "textJa": "複数人でヒアリングを行うと記録内容に相違が出ることがあるので，1人のシステム監査人が行う。"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。访谈能帮助审计员了解流程和事实，但受访者的记忆、理解或立场可能影响陈述，因此还应取得制度文件、操作记录等佐证，形成可追溯的审计证据。ア只按是否做过审计选受访者，不能保证覆盖实际执行人员；ウ把审计员变成现场指挥者，混淆独立评价与被审计部门的整改责任；エ没有理由禁止多人访谈，多人还可交叉核对记录。先核实证据，再形成审计意见。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 24
  },
  {
    "id": "FE-2017-F-AM-60",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 60,
    "topicZh": "系统审计工作底稿",
    "stemJa": "監査調書の説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "監査人が行った監査手続の実施記録であり，監査意見の根拠となる。"
      },
      {
        "label": "イ",
        "textJa": "監査人が監査の実施に当たり被監査部門に対して提出する，情報セキュリティに関する誓約書をまとめたものである。"
      },
      {
        "label": "ウ",
        "textJa": "監査人が監査の実施に利用した基準書，ガイドラインをまとめたものである。"
      },
      {
        "label": "エ",
        "textJa": "監査人が正当な注意義務を払ったことを証明するために，監査報告書とともに公表するよう義務付けられたものである。"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。監査調書可理解为系统审计的工作底稿，记录实施了哪些审计程序、取得了什么证据、据此怎样形成判断，因此能支撑最终审计意见。イ描述对被审计部门提交的誓约书，不是工作底稿；ウ只是审计依据的汇编，缺少实际执行和证据记录；エ把内部审计记录误说成必须随报告公开。做题时抓住“程序实施记录”和“意见的依据”这两个核心作用。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 25
  },
  {
    "id": "FE-2017-F-AM-61",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 61,
    "topicZh": "销售活动时间分配计算",
    "stemJa": "ある営業部員の1日の業務活動を分析した結果は，表のとおりである。営業支援システムの導入によって訪問準備時間が1件当たり0.1時間短縮できる。総業務時間と1件当たりの顧客訪問時間を変えずに，1日の顧客訪問件数を6件にするには，“その他業務時間”を何時間削減する必要があるか。",
    "options": [
      {
        "label": "ア",
        "textJa": "0.3"
      },
      {
        "label": "イ",
        "textJa": "0.5"
      },
      {
        "label": "ウ",
        "textJa": "0.7"
      },
      {
        "label": "エ",
        "textJa": "1.0"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ，即减少0.7小时。原来每天访问5件共用5.0小时，故每件访问1.0小时，增加到6件需6.0小时。原来准备每件1.5÷5＝0.3小时，系统使每件减少0.1小时后变成0.2小时，6件共需1.2小时。总工作时间仍为8.0小时，其他业务只能占8.0－6.0－1.2＝0.8小时。原来是1.5小时，所以要削减1.5－0.8＝0.7小时。不能只把准备节省的0.5小时当成答案。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 25,
    "transcriptionNoteZh": "原卷时间分析表保留在图片中：总业务8.0小时、客户访问5.0小时、访问准备1.5小时、其他业务1.5小时、访问5件。",
    "imageAssets": [
      "question-images/fe-2017-f-am-61-p25.jpg"
    ]
  },
  {
    "id": "FE-2017-F-AM-62",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 62,
    "topicZh": "SOA 服务导向架构",
    "stemJa": "SOAを説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "企業改革において既存の組織やビジネスルールを抜本的に見直し，業務フロー，管理機構，情報システムを再構築する手法のこと"
      },
      {
        "label": "イ",
        "textJa": "企業の経営資源を有効に活用して経営の効率を向上させるために，基幹業務を部門ごとではなく統合的に管理するための業務システムのこと"
      },
      {
        "label": "ウ",
        "textJa": "発注者とITアウトソーシングサービス提供者との間で，サービスの品質について合意した文書のこと"
      },
      {
        "label": "エ",
        "textJa": "ビジネスプロセスの構成要素とそれを支援するIT基盤を，ソフトウェア部品であるサービスとして提供するシステムアーキテクチャのこと"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。SOA 是服务导向架构，把可供调用的业务能力和支撑它的 IT 功能按“服务”组织，使不同业务流程可以组合和复用这些服务。比如“核验库存”可作为被订货、退货等流程调用的服务。ア是对业务流程作根本性重组的 BPR；イ是企业资源统一管理的 ERP；ウ是约定服务质量的 SLA。判断词是“以服务形式提供的软件部件及其架构”，不是所有含有服务字样的文件。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 26
  },
  {
    "id": "FE-2017-F-AM-63",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 63,
    "topicZh": "大数据应用场景",
    "stemJa": "ビッグデータを企業が活用している事例はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "カスタマセンタへの問合せに対し，登録済みの顧客情報から連絡先を抽出する。"
      },
      {
        "label": "イ",
        "textJa": "最重要な取引先が公表している財務諸表から，売上利益率を計算する。"
      },
      {
        "label": "ウ",
        "textJa": "社内研修の対象者リスト作成で，人事情報から入社10年目の社員を抽出する。"
      },
      {
        "label": "エ",
        "textJa": "多種多様なソーシャルメディアの大量な書込みを分析し，商品の改善を行う。"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。题目中的“大量”“多种多样”的社交媒体帖子具有规模大、来源和形式多样的特点，分析后用于产品改进，符合大数据应用的典型情境。ア只是从已有客户表按条件检索联系人；イ是从一份财务报表计算比率；ウ是从人事表筛选入职年限。后三者都可能用计算机完成，但题目没有给出大规模、多源或复杂数据处理的特征，不能仅因“用了数据”就选为大数据。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 26
  },
  {
    "id": "FE-2017-F-AM-64",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 64,
    "topicZh": "绿色采购",
    "stemJa": "グリーン調達の説明はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "環境保全活動を実施している企業がその活動内容を広くアピールし，投資家から環境保全のための資金を募ることである。"
      },
      {
        "label": "イ",
        "textJa": "第三者が一定の基準に基づいて環境保全に資する製品を認定する，エコマークなどの環境表示に関する国際規格のことである。"
      },
      {
        "label": "ウ",
        "textJa": "太陽光，バイオマス，風力，地熱などの自然エネルギーによって発電されたグリーン電力を，市場で取引可能にする証書のことである。"
      },
      {
        "label": "エ",
        "textJa": "品質や価格の要件を満たすだけでなく，環境負荷が小さい製品やサービスを，環境負荷の低減に努める事業者から優先して購入することである。"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。绿色采购的动作是“购买”，判断时同时考虑质量、价格以及产品、服务和供应者的环境负荷，优先选择更有利于减轻环境影响的对象。ア讲的是企业宣传环保活动并筹资，不是采购；イ讲环境标志或认证，可能成为采购时的参考，却不是采购行为本身；ウ讲绿色电力证书的交易，也不是绿色采购的总定义。题干看到調達，就先找与购买选择直接相关的表述。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 26
  },
  {
    "id": "FE-2017-F-AM-65",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 65,
    "topicZh": "BI 商业智能",
    "stemJa": "BI（Business Intelligence）を説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "企業内外のデータを蓄積し，分類・加工・分析して活用することによって，企業の意思決定の迅速化を支援する手法"
      },
      {
        "label": "イ",
        "textJa": "企業内の慣行などにとらわれず，業務プロセスを抜本的に再構築することによって，コスト・品質・サービスなどを改善する手法"
      },
      {
        "label": "ウ",
        "textJa": "企業内の業務の流れを可視化し，業務改善サイクルを適用することによって，継続的な業務改善を図る手法"
      },
      {
        "label": "エ",
        "textJa": "企業内の異なるシステムを互いに連結し，データやプロセスの統合を図ることによって，システムを全体として効率よく活用する手法"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。BI（商业智能）把企业内外的数据积累、整理、加工与分析，转成支持经营判断的信息，例如对销售趋势和地区差异作比较，以便更快作决策。イ强调把业务流程根本性重构，属于 BPR；ウ强调业务流程可视化和持续改善，接近 BPM；エ强调不同系统之间的数据与流程整合，接近 EAI。BI 的关键不是“把系统接起来”，而是利用数据分析支持决策。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 27
  },
  {
    "id": "FE-2017-F-AM-66",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 66,
    "topicZh": "开发方案总成本比较",
    "stemJa": "電化製品に搭載する部品を試作するとき，全体のコストが最も安くなる開発方法はどれか。ここで，各工程の工期は，作成工程が6か月，改造工程が3か月，評価工程が2か月とする。また，1人月当たりのコストは，作成工程が60万円，改造工程及び評価工程がそれぞれ100万円とする。ただし，人月コスト，購入費及び委託費の三つ以外のコストは考慮しない。",
    "options": [
      {
        "label": "ア",
        "textJa": "サンプルを購入して社内で改造（購入費2,000万円，委託費0万円，月当たり人数：作成0人・改造4人・評価1人）"
      },
      {
        "label": "イ",
        "textJa": "社外に一括委託（購入費0万円，委託費3,500万円，月当たり人数：作成0人・改造0人・評価0人）"
      },
      {
        "label": "ウ",
        "textJa": "社内資産を改造（購入費0万円，委託費0万円，月当たり人数：作成0人・改造10人・評価3人）"
      },
      {
        "label": "エ",
        "textJa": "社内で新規作成（購入費0万円，委託費0万円，月当たり人数：作成10人・改造0人・評価2人）"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。总成本＝购买费＋委托费＋各工程“每月人数×工期（月）×每人月成本”。ア为2,000＋4×3×100＋1×2×100＝3,400万日元；イ为委托费3,500万；ウ为10×3×100＋3×2×100＝3,600万；エ为10×6×60＋2×2×100＝4,000万。四个总额中3,400万最低。不能只比较购买费或委托费；表中的人数是每月人数，必须乘相应工程月数。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 27,
    "transcriptionNoteZh": "四种方法的购买费、委托费与各工程人数按原卷表重排为选项文字；原始表格仍保留在图片中。",
    "imageAssets": [
      "question-images/fe-2017-f-am-66-p27.jpg"
    ]
  },
  {
    "id": "FE-2017-F-AM-67",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 67,
    "topicZh": "SWOT 外部威胁",
    "stemJa": "SWOT分析において，一般に脅威として位置付けられるものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "競合他社に比べて高い生産効率"
      },
      {
        "label": "イ",
        "textJa": "事業ドメインの高い成長率"
      },
      {
        "label": "ウ",
        "textJa": "市場への強力な企業の参入"
      },
      {
        "label": "エ",
        "textJa": "低いマーケットシェア"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。SWOT 把因素分成内部与外部两轴：内部有优势 S、劣势 W，外部有机会 O、威胁 T。强大企业进入同一市场是本企业难以直接控制的外部变化，会加剧竞争，因此是威胁。ア的高生产效率是企业自身优势；イ的市场高增长率是外部机会；エ的低市场份额是企业目前自身状况，通常归为劣势。先分清因素发生在企业内部还是外部，再判断有利还是不利。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 28
  },
  {
    "id": "FE-2017-F-AM-68",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 68,
    "topicZh": "竞争战略中的市场领导者",
    "stemJa": "企業の競争戦略におけるリーダ戦略はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "市場シェアを奪うことを目標に，製品，サービス，販売促進，流通チャネルなどのあらゆる面での差別化戦略を取る。"
      },
      {
        "label": "イ",
        "textJa": "潜在的な需要がありながら，他の企業が参入してこないような専門特化した市場に，限られた経営資源を集中する。"
      },
      {
        "label": "ウ",
        "textJa": "目標とする企業の戦略を観察し，迅速に模倣することによって，開発や広告のコストを抑制し，市場での存続を図る。"
      },
      {
        "label": "エ",
        "textJa": "利潤，好評判の維持・向上と最適市場シェアの確保を目標として，市場内の全ての顧客をターゲットにした全方位戦略を取る。"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。市场领导者已有较强地位，题目所说的リーダ戦略以维护利润和声誉、保持合适份额为目标，面向市场广泛顾客采取全方位策略。ア以夺取对手份额为目标，接近挑战者；イ把有限资源集中在细分市场，是利基或专业化路线；ウ观察并模仿目标企业，是追随者策略。答题要依据各选项的目标市场和行为来辨认，不是看到“差别化”就认为领导者一定选它。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 28
  },
  {
    "id": "FE-2017-F-AM-69",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 69,
    "topicZh": "供应链管理 SCM",
    "stemJa": "サプライチェーンマネジメントを説明したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "購買，生産，販売及び物流を結ぶ一連の業務を，企業内，企業間で全体最適の視点から見直し，納期短縮や在庫削減を図る。"
      },
      {
        "label": "イ",
        "textJa": "個人がもっているノウハウや経験などの知的資産を組織全体で共有して，創造的な仕事につなげていく。"
      },
      {
        "label": "ウ",
        "textJa": "社員のスキルや行動特性を把握し，人事戦略の視点から適切な人員配置・評価などのマネジメントを行う。"
      },
      {
        "label": "エ",
        "textJa": "多様なチャネルを通して集められた顧客情報を一元化し，活用することによって，顧客との関係を密接にしていく。"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。供应链把采购、生产、销售与物流接成一条从原料到顾客的流程；SCM 从企业内部及企业之间的整体最优出发，协调库存与交期，而不是让单个部门单独优化。イ是知识管理，关注经验和诀窍共享；ウ是人力资源管理，关注人员技能与配置；エ是 CRM，关注统一客户资料和维护客户关系。题眼是跨组织的货物流与业务流，以及缩短交货期、减少库存。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 28
  },
  {
    "id": "FE-2017-F-AM-70",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 70,
    "topicZh": "企业核心技术",
    "stemJa": "コア技術の事例として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "アライアンスを組んでインタフェースなどを策定し，共通で使うことを目的とした技術"
      },
      {
        "label": "イ",
        "textJa": "競合他社がまねできないような，自動車エンジンのアイドリングストップ技術"
      },
      {
        "label": "ウ",
        "textJa": "競合他社と同じCPUコアを採用し，ソフトウェアの移植性を生かす技術"
      },
      {
        "label": "エ",
        "textJa": "製品の早期開発，早期市場投入を目的として，汎用部品を組み合わせて開発する技術"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。核心技术是企业在产品或竞争中赖以形成独特优势的重要技术；题目中的发动机怠速停止技术强调竞争对手难以模仿，符合这一特征。ア是联盟共同制定接口，重点是共同使用和标准化；ウ采用与对手相同的 CPU 核心，重点是兼容与移植；エ组合通用部件，重点是缩短开发与上市时间。这些做法可能有商业价值，但并没有体现企业独有且难以复制的技术能力。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 29
  },
  {
    "id": "FE-2017-F-AM-71",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 71,
    "topicZh": "IoT 的数据采集层",
    "stemJa": "工場の機器メンテナンス業務においてIoTを活用した場合の基本要素とデバイス・サービスの例を整理した。ア～エがa～dのいずれかに該当するとき，aに該当するものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "異常値判定ツール"
      },
      {
        "label": "イ",
        "textJa": "機器の温度センサ"
      },
      {
        "label": "ウ",
        "textJa": "工場内無線通信"
      },
      {
        "label": "エ",
        "textJa": "作業指示用ディスプレイ"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。原表中的 a 对应“データの収集”，即先从工厂设备取得原始状态。温度传感器测量设备温度，属于采集。ウ的工厂内无线通信负责把数据传送出去，对应 b；ア的异常值判定工具分析收到的数据，对应 c；エ的作业指示显示器把分析结果用于维修行动，对应 d。按“采集→传送→解析→利用”的流程逐一安放设备，就不会把感测器和通信网络混淆。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 29,
    "transcriptionNoteZh": "原卷表格把 a、b、c、d 分别对应数据的收集、传送、解析、活用；原表保留在图片中。",
    "imageAssets": [
      "question-images/fe-2017-f-am-71-p29.jpg"
    ]
  },
  {
    "id": "FE-2017-F-AM-72",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 72,
    "topicZh": "MRP 物料需求计划",
    "stemJa": "MRPの特徴はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "顧客の注文を受けてから製品の生産を行う。"
      },
      {
        "label": "イ",
        "textJa": "作業指示票を利用して作業指示，運搬指示をする。"
      },
      {
        "label": "ウ",
        "textJa": "製品の開発，設計，生産準備を同時並行で行う。"
      },
      {
        "label": "エ",
        "textJa": "製品の基準生産計画を基に，部品の手配数量を算出する。"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。MRP 是物料需求计划，它从成品的基准生产计划出发，结合产品由哪些部件组成、已有库存和到货安排，推算各部件需要在何时准备多少。题目只问最能概括的特点，因此“根据基准生产计划计算部件手配数量”正确。ア描述接单后生产的方式；イ侧重用作业指示票推动现场作业；ウ描述开发、设计与生产准备并行。不要把所有与生产有关的方法都等同于 MRP。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 29
  },
  {
    "id": "FE-2017-F-AM-73",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 73,
    "topicZh": "家庭能源管理系统 HEMS",
    "stemJa": "HEMSの説明として，適切なものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "太陽光発電システム及び家庭用燃料電池が発電した電気を，家庭などで利用できるように変換するシステム"
      },
      {
        "label": "イ",
        "textJa": "廃棄物の減量及び資源の有効利用推進のために，一般家庭及び事務所から排出された家電製品の有用な部分をリサイクルするシステム"
      },
      {
        "label": "ウ",
        "textJa": "ヒートポンプを利用して，より少ないエネルギーで大きな熱量を発生させる電気給湯システム"
      },
      {
        "label": "エ",
        "textJa": "複数の家電製品をネットワークでつなぎ，電力の可視化及び電力消費の最適制御を行うシステム"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。HEMS 是家庭能源管理系统，关键是把家里的多个电器或能源设备连到网络，查看用电情况并进行更合理的控制，例如调整设备运行时段。ア只说把发出的电转换为家庭可用电，属于电力转换功能；イ是家电回收；ウ是热泵式热水设备。它们可能与家庭能源有关，却没有同时体现设备连接、用电可视化和整体优化控制这三个题目中的 HEMS 特征。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 30
  },
  {
    "id": "FE-2017-F-AM-74",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 74,
    "topicZh": "深度学习的图像识别应用",
    "stemJa": "車載機器の性能の向上に関する記述のうち，ディープラーニングを用いているものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "車の壁への衝突を加速度センサが検知し，エアバッグを膨らませて搭乗者をけがから守った。"
      },
      {
        "label": "イ",
        "textJa": "システムが大量の画像を取得し処理することによって，歩行者と車をより確実に見分けることができるようになった。"
      },
      {
        "label": "ウ",
        "textJa": "自動でアイドリングストップする装置を搭載することによって，運転経験が豊富な運転者が運転する場合よりも燃費を向上させた。"
      },
      {
        "label": "エ",
        "textJa": "ナビゲーションシステムが，携帯電話回線を通してソフトウェアのアップデートを行い，地図を更新した。"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。深度学习可从大量示例图像中学习特征，用于改善图像分类或识别；题目中的系统处理大量图像后更可靠地区分行人与汽车，符合这一用途。ア依据加速度传感器触发气囊，是预设的安全控制；ウ描述自动怠速停止和节油，没有学习图像特征；エ是经通信线路更新软件地图。仅有传感器、自动控制或网络更新，并不能推断使用了深度学习。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 30
  },
  {
    "id": "FE-2017-F-AM-75",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 75,
    "topicZh": "CIO 的信息化战略职责",
    "stemJa": "CIOが果たすべき主要な役割はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "情報化戦略を立案するに当たって，経営戦略を支援するために，企業全体の情報資源への投資効果を最適化するプランを策定する。"
      },
      {
        "label": "イ",
        "textJa": "情報システム開発・運用に関する状況を把握して，全社情報システムが最適に機能するように具体的に改善点を指示する。"
      },
      {
        "label": "ウ",
        "textJa": "情報システムが企業活動に対して健全に機能しているかどうかを監査することによって，情報システム部門にアドバイスを与える。"
      },
      {
        "label": "エ",
        "textJa": "全社情報システムの最適な運営が行えるように，情報システムに関する問合せやトラブルに関する報告を受け，担当部門に具体的指示を与える。"
      }
    ],
    "answer": "ア",
    "explanationZh": "答案是ア。CIO 是负责企业信息资源与信息化方向的高层角色，要把信息化战略同经营战略对齐，并从全公司角度优化 IT 投资的效果。イ、エ都落在系统日常开发运营与具体故障指挥层面，过于偏执行管理；ウ强调独立审计并向部门给建议，是审计角色而非 CIO 的主要职责。看到“企业整体、经营战略、信息资源投资”应优先识别战略层责任。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 31
  },
  {
    "id": "FE-2017-F-AM-76",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 76,
    "topicZh": "OJT 在岗培训",
    "stemJa": "OJTの特徴はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "一般化された知識や技術に重点を置いた教育が受けられる。"
      },
      {
        "label": "イ",
        "textJa": "上司や先輩が実務に密着して実践的に知識や技術を教育するので，必要な能力が習得できる。"
      },
      {
        "label": "ウ",
        "textJa": "上司や先輩の資質によらず，一定水準の業務知識が身に付けられる。"
      },
      {
        "label": "エ",
        "textJa": "職場から離れて教育に専念できる。"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。OJT 即在岗培训，学习者在实际工作中由上司或前辈指导，边做具体任务边掌握岗位所需的知识和技术，因此与业务情境贴近。ア的普遍理论知识和エ的离开岗位专心学习更接近脱岗培训；ウ声称培训质量不受指导者能力影响，和在岗指导的实际特点不符。做题要抓住“在工作现场”“跟随实际任务”“由有经验者指导”这三点。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 31
  },
  {
    "id": "FE-2017-F-AM-77",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 77,
    "topicZh": "资产负债表",
    "stemJa": "財務諸表のうち，一定時点における企業の資産，負債及び純資産を表示し，企業の財政状態を明らかにするものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "株主資本等変動計算書"
      },
      {
        "label": "イ",
        "textJa": "キャッシュフロー計算書"
      },
      {
        "label": "ウ",
        "textJa": "損益計算書"
      },
      {
        "label": "エ",
        "textJa": "貸借対照表"
      }
    ],
    "answer": "エ",
    "explanationZh": "答案是エ。貸借対照表即资产负债表，描述“某一个时点”的财务状况，列出资产、负债和净资产，基本关系是资产＝负债＋净资产。ア追踪股东权益等在期间内如何变动；イ记录一定期间现金的流入流出；ウ记录一定期间收入和费用并计算损益。区分财务报表时先看题目问的是某时点的存量，还是一段期间的变化；本题明确是一定时点。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 31
  },
  {
    "id": "FE-2017-F-AM-78",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 78,
    "topicZh": "先进先出法的期末存货估值",
    "stemJa": "表から，期末在庫品を先入先出法で評価した場合の期末の在庫評価額は何千円か。",
    "options": [
      {
        "label": "ア",
        "textJa": "132"
      },
      {
        "label": "イ",
        "textJa": "138"
      },
      {
        "label": "ウ",
        "textJa": "150"
      },
      {
        "label": "エ",
        "textJa": "168"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ，即150千日元。可供数量为期初10＋当期进货1＋2＋3＋4＝20个，期末12个，表示期间发出8个。先进先出法把最早进来的期初10个先发出8个，因此期末仍有期初的2个，以及后来进货的1、2、3、4个。期末价值＝2×10＋1×11＋2×12＋3×13＋4×14＝20＋11＋24＋39＋56＝150千日元。不要把“最先进货”当成期末留下最早一批。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 32,
    "transcriptionNoteZh": "原卷表格列出期初10个×10千日元、4月1个×11、6月2个×12、7月3个×13、9月4个×14；期末余12个，原表保留在图片中。",
    "imageAssets": [
      "question-images/fe-2017-f-am-78-p32.jpg"
    ]
  },
  {
    "id": "FE-2017-F-AM-79",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 79,
    "topicZh": "出向与劳动者派遣关系",
    "stemJa": "図は，企業と労働者の関係を表している。企業Bと労働者Cの関係を表す記述として正しいものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "“契約”が請負契約で，企業Aが受託者，企業Bが委託者であるとき，企業Bと労働者Cとの間には，指揮命令関係が生じる。"
      },
      {
        "label": "イ",
        "textJa": "“契約”が出向にかかわる契約で，企業Aが企業Bに労働者Cを出向させたとき，企業Bと労働者Cとの間には指揮命令関係が生じる。"
      },
      {
        "label": "ウ",
        "textJa": "“契約”が労働者派遣契約で，企業Aが派遣元，企業Bが派遣先であるとき，企業Bと労働者Cとの間にも，雇用関係が生じる。"
      },
      {
        "label": "エ",
        "textJa": "“契約”が労働者派遣契約で，企業Aが派遣元，企業Bが派遣先であるとき，企業Bに労働者Cが出向しているといえる。"
      }
    ],
    "answer": "イ",
    "explanationZh": "答案是イ。原图给出 A 与 C 的雇用关系，并让我们判断 B 与 C。出向时，劳动者到 B 的岗位工作，B 对其具体工作形成指挥命令关系，符合イ。ア把请负合同说成委托方 B 直接指挥受托方 A 的劳动者，混淆了承包与直接用工；ウ把劳动者派遣中的 B 与 C 说成当然产生雇用关系，和派遣元 A 雇用、派遣先 B 指挥的基本区分不符；エ又把派遣直接说成出向，两者合同安排不同。此题按原卷给定关系作答。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 32,
    "transcriptionNoteZh": "原卷企业A、企业B、劳动者C之间的箭线与合同示意图保留在同页原图中。",
    "imageAssets": [
      "question-images/fe-2017-f-am-78-p32.jpg"
    ]
  },
  {
    "id": "FE-2017-F-AM-80",
    "kind": "official",
    "year": 2017,
    "periodJa": "秋期",
    "section": "AM",
    "number": 80,
    "topicZh": "特定商取引法与冷静期",
    "stemJa": "訪問販売，通信販売，電話勧誘販売などを対象に，消費者を守るためのクーリングオフなどのルールを定めている法律はどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "商法"
      },
      {
        "label": "イ",
        "textJa": "電子消費者契約法"
      },
      {
        "label": "ウ",
        "textJa": "特定商取引法"
      },
      {
        "label": "エ",
        "textJa": "不正競争防止法"
      }
    ],
    "answer": "ウ",
    "explanationZh": "答案是ウ。题目问的是针对访问销售、通信销售、电话劝诱销售等特定交易形态，为保护消费者规定交易规则的法律，原卷官方答案为特定商取引法。ア商法主要处理商事一般规则；イ电子消费者契约法侧重电子合同中的消费者误操作等问题；エ不正競争防止法针对不正当竞争行为。注意冷静期的适用范围与具体条件因交易类型而异，不能从题干推断所有列举的销售方式都一律可无条件解除合同。",
    "questionUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_qs.pdf",
    "answerUrl": "https://www.ipa.go.jp/shiken/mondai-kaiotu/gmcbt8000000fqpm-att/2017h29a_fe_am_ans.pdf",
    "page": 33
  },
  {
    "id": "FE-ORIGINAL-A-01",
    "kind": "original",
    "year": null,
    "section": "A",
    "number": 1,
    "topicZh": "进制转换",
    "stemJa": "2進数 101101 を 10進数で表したものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "43"
      },
      {
        "label": "イ",
        "textJa": "44"
      },
      {
        "label": "ウ",
        "textJa": "45"
      },
      {
        "label": "エ",
        "textJa": "46"
      }
    ],
    "answer": "ウ",
    "explanationZh": "这是一道本应用自编练习题，不是 IPA 真题。二进制从右到左的位权依次为 1、2、4、8、16、32。101101₂ 中为 1 的位置是 32、8、4、1，所以十进制值为 32＋8＋4＋1＝45，选ウ。其他三个数字都与位权相加的结果不符；尤其不要把最右边的1漏掉，否则会错算为44。解题时先把六个位置的位权写全，再只相加对应为1的位。"
  },
  {
    "id": "FE-ORIGINAL-A-02",
    "kind": "original",
    "year": null,
    "section": "A",
    "number": 2,
    "topicZh": "数据库与 NULL",
    "stemJa": "表 T の列 v に 10，NULL，20 の 3 行が格納されている。次の SQL 文の実行結果はどれか。\n\nSELECT COUNT(*) FROM T WHERE v IS NULL",
    "options": [
      {
        "label": "ア",
        "textJa": "0"
      },
      {
        "label": "イ",
        "textJa": "1"
      },
      {
        "label": "ウ",
        "textJa": "2"
      },
      {
        "label": "エ",
        "textJa": "3"
      }
    ],
    "answer": "イ",
    "explanationZh": "这是一道本应用自编练习题，不是 IPA 真题。WHERE v IS NULL 只留下 v 为 NULL 的那一行；COUNT(*) 统计过滤后的行数，因此结果为1，选イ。ア把 NULL 行错误地忽略了；ウ、エ把不满足条件的 10 或 20 也算入。这里特意使用 COUNT(*)：它数的是行；若写 COUNT(v)，则会忽略 v 为 NULL 的值，含义不同。"
  },
  {
    "id": "FE-ORIGINAL-A-03",
    "kind": "original",
    "year": null,
    "section": "A",
    "number": 3,
    "topicZh": "系统可用率",
    "stemJa": "ある装置の平均故障間隔（MTBF）が 900 時間，平均修理時間（MTTR）が 100 時間である。稼働率は幾らか。",
    "options": [
      {
        "label": "ア",
        "textJa": "0.10"
      },
      {
        "label": "イ",
        "textJa": "0.50"
      },
      {
        "label": "ウ",
        "textJa": "0.90"
      },
      {
        "label": "エ",
        "textJa": "0.99"
      }
    ],
    "answer": "ウ",
    "explanationZh": "这是一道本应用自编练习题，不是 IPA 真题。一个典型循环包含平均正常运行的900小时与平均修理的100小时，总共1000小时；其中可运行时间占900小时。稼働率＝MTBF÷(MTBF＋MTTR)＝900÷1000＝0.90，选ウ。ア算成了停机时间占比；イ与エ都不符合代入后的分数。注意分母需要同时包括正常运行和修理时间。"
  },
  {
    "id": "FE-ORIGINAL-A-04",
    "kind": "original",
    "year": null,
    "section": "A",
    "number": 4,
    "topicZh": "两要素认证",
    "stemJa": "認証において，知識情報と生体情報という異なる二つの要素を組み合わせたものはどれか。",
    "options": [
      {
        "label": "ア",
        "textJa": "パスワードと暗証番号"
      },
      {
        "label": "イ",
        "textJa": "指紋と静脈"
      },
      {
        "label": "ウ",
        "textJa": "パスワードと指紋"
      },
      {
        "label": "エ",
        "textJa": "暗証番号と秘密の質問の答え"
      }
    ],
    "answer": "ウ",
    "explanationZh": "这是一道本应用自编练习题，不是 IPA 真题。题目要求的是两个不同类别：密码属于“知道的东西”（知识因素），指纹属于“自身特征”（生物因素），所以选ウ。ア的密码和 PIN 都是知识因素；イ的指纹与静脉都是生物因素；エ的 PIN 与秘密问题答案也都是知识因素。使用两种方法并不自动等于两要素，关键是因素类别不同。"
  }
];
