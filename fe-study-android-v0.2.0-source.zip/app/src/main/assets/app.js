(function () {
  "use strict";
  const QUESTIONS = Array.isArray(window.FE_QUESTIONS) ? window.FE_QUESTIONS : [];
  const LESSONS = Array.isArray(window.FE_LESSONS) ? window.FE_LESSONS : [];
  const screen = document.getElementById("screen");
  const key = "fe-study-state-v1";
  const byId = new Map(QUESTIONS.map(q => [q.id, q]));
  const ui = { tab: "learn", examSection: "A", lessonId: null, session: null, result: null, image: null,
    filters: { kind: "all", section: "all", year: "all", count: "20" } };

  function h(value) {
    return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"})[c]);
  }
  function readState() {
    try {
      const raw = window.StudyStore ? window.StudyStore.load() : localStorage.getItem(key);
      const parsed = raw ? JSON.parse(raw) : {};
      return { attempts: Array.isArray(parsed.attempts) ? parsed.attempts : [], daily: parsed.daily && typeof parsed.daily === "object" ? parsed.daily : {}, examSection: parsed.examSection === "B" ? "B" : "A" };
    } catch (_) { return { attempts: [], daily: {}, examSection: "A" }; }
  }
  let state = readState();
  ui.examSection = state.examSection;
  function saveState() {
    const raw = JSON.stringify(state);
    try { if (window.StudyStore) window.StudyStore.save(raw); else localStorage.setItem(key, raw); } catch (_) { /* storage unavailable */ }
  }
  function today() {
    const d = new Date();
    return [d.getFullYear(), String(d.getMonth()+1).padStart(2,"0"), String(d.getDate()).padStart(2,"0")].join("-");
  }
  function mastery() {
    const result = new Map();
    for (const a of state.attempts) {
      const s = result.get(a.questionId) || { tried: 0, everWrong: false, streakAfterWrong: 0, lastWrongAt: "", lastAt: "" };
      s.tried += 1; s.lastAt = a.at || "";
      if (!a.correct) { s.everWrong = true; s.streakAfterWrong = 0; s.lastWrongAt = a.at || ""; }
      else if (s.everWrong) s.streakAfterWrong += 1;
      result.set(a.questionId, s);
    }
    return result;
  }
  function examSection(q) { return q.section === "B" ? "B" : "A"; }
  function questionsFor(section) { return QUESTIONS.filter(q => examSection(q) === section); }
  function lessonsFor(section) { return LESSONS.filter(l => (l.examSection || "A") === section); }
  function relatedQuestions(lesson) {
    return questionsFor(lesson.examSection || "A").filter(q => lesson.matches.some(word => (q.topicZh || "").includes(word) || (q.stemJa || "").includes(word)));
  }
  function sectionSwitcher() {
    return `<div class="exam-selector" role="group" aria-label="选择考试科目">${["A","B"].map(section=>`<button data-action="choose-section" data-section="${section}" class="exam-choice ${ui.examSection===section?"active":""}" aria-pressed="${ui.examSection===section}"><strong>科目 ${section}</strong><span>${section==="A"?"基础知识":"算法与信息安全"}</span></button>`).join("")}</div>`;
  }
  function wrongQuestions(section) {
    const status = mastery();
    return QUESTIONS.filter(q => { const s = status.get(q.id); return (!section || examSection(q)===section) && s && s.everWrong && s.streakAfterWrong < 2; });
  }
  function hash(text) {
    let value = 2166136261;
    for (let i=0;i<text.length;i++) { value ^= text.charCodeAt(i); value = Math.imul(value,16777619); }
    return value >>> 0;
  }
  function dailyIds() {
    const date = today();
    const dailyKey = `${date}:${ui.examSection}`;
    if (Array.isArray(state.daily[dailyKey])) return state.daily[dailyKey].filter(id => byId.has(id));
    const pool = questionsFor(ui.examSection);
    const status = mastery();
    const bad = wrongQuestions(ui.examSection).sort((a,b) => (status.get(a.id).lastWrongAt || "").localeCompare(status.get(b.id).lastWrongAt || ""));
    const unseen = pool.filter(q => !status.has(q.id)).sort((a,b) => questionPriority(a)-questionPriority(b) || hash(date+a.id)-hash(date+b.id));
    const seen = pool.filter(q => status.has(q.id) && !bad.some(w => w.id===q.id)).sort((a,b) => (status.get(a.id).lastAt || "").localeCompare(status.get(b.id).lastAt || ""));
    state.daily[dailyKey] = [...bad,...unseen,...seen].slice(0,5).map(q=>q.id);
    saveState();
    return state.daily[dailyKey];
  }
  function stats() {
    const selected = state.attempts.filter(a=>byId.has(a.questionId) && examSection(byId.get(a.questionId))===ui.examSection);
    const attempts = selected.length;
    const correct = selected.filter(a=>a.correct).length;
    return {attempts, accuracy: attempts ? Math.round(correct*100/attempts) : 0, wrong: wrongQuestions(ui.examSection).length};
  }
  function setTab(tab) {
    ui.tab = tab; ui.lessonId = null; ui.result = null; ui.image = null;
    document.querySelectorAll(".nav-item").forEach(button => button.classList.toggle("active", button.dataset.tab === tab));
    render(); window.scrollTo(0,0);
  }
  function questionPriority(q) { return q.kind === "official" && q.section !== "AM" ? 0 : q.kind === "sample" ? 1 : q.kind === "official" ? 2 : 3; }
  function sectionLabel(q) { return q.section === "AM" ? "旧制午前" : `科目 ${q.section}`; }
  function sourceLabel(q) {
    if (q.kind === "sample") return q.sampleSet === "early"
      ? `出典：基本情報技術者試験 科目B試験 サンプル問題（2022年4月） 問${q.number}`
      : `出典：基本情報技術者試験（科目${q.section}試験） サンプル問題セット（2022年12月） 問${q.number}`;
    if (q.kind !== "official") return "原创练习（非真题）";
    if (q.section === "AM") {
      const era = q.year === 2019 && q.periodJa === "春期" ? "平成31年度" : q.year >= 2019 ? `令和${q.year - 2018}年度` : `平成${q.year - 1988}年度`;
      return `出典：${era} ${q.periodJa} 基本情報技術者試験 午前 問${q.number}`;
    }
    return `出典：令和${q.year - 2018}年度 基本情報技術者試験 科目${q.section} 問${q.number}`;
  }
  function safeSourceUrl(url) {
    return /^https:\/\/(?:www\.ipa\.go\.jp|www3\.jitec\.ipa\.go\.jp|www\.fe-siken\.com)\//.test(url || "") ? h(url) : "";
  }
  function safeImageAsset(asset) { return /^question-images\/[a-zA-Z0-9][a-zA-Z0-9_.-]*\.(?:png|jpg|webp)$/.test(asset || "") ? asset : ""; }
  function renderImageViewer() {
    const src = safeImageAsset(ui.image?.src);
    if (!src) return "";
    return `<div class="image-viewer" role="dialog" aria-modal="true" aria-label="查看原卷图片"><div class="image-viewer-toolbar"><strong>IPA 原卷图片</strong><button class="button secondary" data-action="zoom-out" ${ui.image.scale<=1?"disabled":""}>−</button><span>${Math.round(ui.image.scale*100)}%</span><button class="button secondary" data-action="zoom-in" ${ui.image.scale>=4?"disabled":""}>＋</button><button class="button primary" data-action="close-image">关闭</button></div><div class="image-viewer-body"><img src="${h(src)}" alt="${h(ui.image.alt)}" style="width:${ui.image.scale*100}%"></div></div>`;
  }
  function badge(q) {
    const label = q.kind === "official" ? "IPA 官方公开题" : q.kind === "sample" ? "IPA 官方样题 · 非历年真题" : "原创练习 · 非真题";
    return `<span class="chip ${h(q.kind)}">${label}</span>`;
  }
  function renderLearn() {
    if (ui.lessonId) {
      const lesson = LESSONS.find(l=>l.id===ui.lessonId);
      if (!lesson) { ui.lessonId = null; return renderLearn(); }
      const related = relatedQuestions(lesson);
      const topics = Array.isArray(lesson.topics) ? lesson.topics : [];
      const topicCards = topics.map((topic, index) => `<details class="topic-card" ${index===0?"open":""}><summary><span class="topic-number">${String(index+1).padStart(2,"0")}</span><span class="topic-heading"><strong lang="ja">${h(topic.termJa)}</strong><small>${h(topic.meaningZh)}</small></span><span class="chevron">⌄</span></summary><div class="topic-body">${topic.definitionJa?`<div class="japanese-note"><strong>IPA 原文节选</strong><p lang="ja">${h(topic.definitionJa)}</p></div>`:""}${topic.prerequisiteZh?`<div class="topic-prerequisite"><strong>先从这里理解</strong><p>${h(topic.prerequisiteZh)}</p></div>`:""}<div class="topic-explanation"><strong>中文讲解</strong><p>${h(topic.explanationZh)}</p></div>${topic.stepsZh?`<div class="topic-example"><strong>一步一步看</strong>${Array.isArray(topic.stepsZh)?`<ol>${topic.stepsZh.map(step=>`<li>${h(step)}</li>`).join("")}</ol>`:`<p>${h(topic.stepsZh)}</p>`}</div>`:""}${topic.exampleZh?`<div class="topic-example"><strong>例子</strong><p>${h(topic.exampleZh)}</p></div>`:""}${topic.pitfallZh?`<div class="topic-pitfall"><strong>容易弄错的地方</strong><p>${h(topic.pitfallZh)}</p></div>`:""}${safeSourceUrl(topic.sourceUrl)?`<p class="topic-source">${h(topic.sourceTitle)}</p><a class="source-link" href="${safeSourceUrl(topic.sourceUrl)}">查看 IPA 日语资料原文 ↗</a>`:""}</div></details>`).join("");
      return `<button class="back" data-action="back-learn">← 返回学习</button><div class="eyebrow">科目 ${h(lesson.examSection || "A")} · 学习单元</div><h1 class="title">${h(lesson.title)}</h1><p class="lead">${h(lesson.subtitle)}</p><div class="card detail-note"><p>${h(lesson.intro)}</p><ul>${lesson.points.map(p=>`<li>${h(p)}</li>`).join("")}</ul></div>${topics.length?`<div class="section-row"><h2>日语术语 · 中文精讲</h2><small>${topics.length} 个</small></div><p class="source-note">建议从 01 开始依次学习；先看白话铺垫，再看讲解、步骤、例子和易错点。日语术语与规则可在 IPA 资料中核对。例子为本应用独立编写的教学示例。</p>${topicCards}`:""}<div class="card detail-note"><strong>解题提示</strong><p>${h(lesson.tip)}</p></div><button class="button primary wide" data-action="lesson-quiz" data-lesson="${h(lesson.id)}" ${related.length?"":"disabled"}>${related.length?`练习相关题目（${related.length} 道）`:"暂无对应练习题"}</button><p class="source-note">中文讲解由本应用独立编写，不是 IPA 官方解析。题目页另列原题与答案出处。</p>`;
    }
    const s = stats();
    const lessons = lessonsFor(ui.examSection);
    const questions = questionsFor(ui.examSection);
    return `<section class="hero"><div class="eyebrow">你的 FE 学习空间</div><h1>每天进步一点，<br>把知识真正学会。</h1><p>先读日语术语与中文讲解，再用日语原题检验。每个知识点都可以查看资料来源。</p></section>
      ${sectionSwitcher()}
      <p class="lead">${ui.examSection==="A"?"科目 A：先学习计算机、网络、数据库、安全、管理与经营的基础知识。旧制午前题作为单独标记的补充练习。":"科目 B：从变量和伪代码开始，逐行读懂算法，再练习信息安全情境题。建议按单元顺序学习。"}</p>
      <div class="stats"><div class="stat"><strong>${questions.length}</strong><span>科目 ${ui.examSection} 练习题</span></div><div class="stat"><strong>${lessons.reduce((n,l)=>n+(l.topics?.length||0),0)}</strong><span>详细知识点</span></div><div class="stat"><strong>${s.accuracy}%</strong><span>本科目正确率</span></div></div>
      <div class="section-row"><h2>科目 ${ui.examSection} · 知识点学习</h2><small>${lessons.length} 个单元</small></div>
      ${lessons.map((l,index)=>`<button class="card lesson-card" data-action="open-lesson" data-lesson="${h(l.id)}"><span class="lesson-glyph">${String(index+1).padStart(2,"0")}</span><span class="lesson-copy"><strong>${h(l.title)}</strong><span>${h(l.subtitle)}</span><span class="lesson-count">${Array.isArray(l.topics)?l.topics.length:0} 个详细知识点</span></span><span class="chevron">›</span></button>`).join("")}
      <p class="disclaimer">中文讲解与教学例子由本应用独立编写，来源链接供核对日语术语与规则。学习单元用于建立基础，完整考试范围请结合 IPA 大纲核对。</p>`;
  }
  function filteredQuestions() {
    return questionsFor(ui.examSection).filter(q => (ui.filters.kind === "all" || q.kind === ui.filters.kind) && (ui.filters.section === "all" || q.section === ui.filters.section) && (ui.filters.year === "all" || String(q.year) === ui.filters.year));
  }
  function practiceQuestions() {
    const qs = filteredQuestions();
    const limit = ui.filters.count === "all" ? qs.length : Number(ui.filters.count) || 20;
    if (qs.length <= limit) return qs;
    const status = mastery();
    return qs.sort((a,b) => {
      const first = status.get(a.id)?.lastAt || "";
      const second = status.get(b.id)?.lastAt || "";
      return first.localeCompare(second) || questionPriority(a)-questionPriority(b) || hash(today()+a.id)-hash(today()+b.id);
    }).slice(0,limit);
  }
  function renderQuizHome() {
    const qs = filteredQuestions();
    const years = [...new Set(questionsFor(ui.examSection).filter(q=>q.kind!=="original").map(q=>q.year))].sort((a,b)=>b-a);
    const choice = (value, label, current) => `<option value="${value}" ${current===value?"selected":""}>${label}</option>`;
    return `<div class="eyebrow">QUESTION BANK</div><h1 class="title">科目 ${ui.examSection} · 刷题练习</h1>
      ${sectionSwitcher()}
      <p class="lead">${ui.examSection==="A"?"练习基础知识。现行科目 A、官方样题和旧制度午前题都标明来源。":"练习伪代码、算法与信息安全情境。先完整阅读题干，再用中文解析逐步核对思路。"}</p>
      <div class="filters">
        <label class="field">题目类型<select data-filter="kind">${choice("all","全部题目",ui.filters.kind)}${choice("official","官方历年公开题",ui.filters.kind)}${choice("sample","IPA 官方样题",ui.filters.kind)}${choice("original","原创练习",ui.filters.kind)}</select></label>
        ${ui.examSection==="A"?`<label class="field">练习范围<select data-filter="section">${choice("all","全部 A 基础训练",ui.filters.section)}${choice("A","现行科目 A",ui.filters.section)}${choice("AM","旧制度 午前",ui.filters.section)}</select></label>`:""}
        <label class="field">年份<select data-filter="year">${choice("all","全部年份",ui.filters.year)}${years.map(y=>choice(String(y),y===2022?"2022 年官方样题":`${y} 年`,ui.filters.year)).join("")}</select></label>
        <label class="field">每轮题数<select data-filter="count">${choice("10","10 道",ui.filters.count)}${choice("20","20 道",ui.filters.count)}${choice("40","40 道",ui.filters.count)}${choice("all","全部",ui.filters.count)}</select></label>
      </div>
      <div class="card"><strong>当前可练 ${qs.length} 道</strong><p class="source-note">官方历年公开题 ${qs.filter(q=>q.kind==="official").length} 道 · 官方样题 ${qs.filter(q=>q.kind==="sample").length} 道 · 原创练习 ${qs.filter(q=>q.kind==="original").length} 道</p><button class="button primary wide" data-action="start-filtered" ${qs.length?"":"disabled"}>开始练习${qs.length ? `（本轮 ${Math.min(qs.length,ui.filters.count==="all"?qs.length:Number(ui.filters.count))} 道）` : ""}</button></div>
      <p class="source-note">优先抽取尚未练习的题，做完一轮后再开始会接着覆盖其余题目。IPA 公布的机考题只是实际题库的一部分。</p>
      <div class="card external-practice"><strong>更多公开题练习</strong>${ui.examSection==="A"?`<p>過去問道場可在浏览器中练习更多历年题；其站内内容不计入本应用题量。</p><a class="source-link" href="https://www.fe-siken.com/fekakomon.php">打开基本情報技術者過去問道場 ↗</a><br>`:""}<a class="source-link" href="https://www.ipa.go.jp/shiken/mondai-kaiotu/sg_fe/koukai/index.html">查看 IPA 现行科目 ${ui.examSection} 官方公开题 ↗</a><br><a class="source-link" href="https://www.ipa.go.jp/shiken/syllabus/henkou/2022/20221226.html">查看 IPA 官方样题集 ↗</a></div>`;
  }
  function renderWrong() {
    const wrong = wrongQuestions(ui.examSection);
    const status = mastery();
    return `<div class="eyebrow">REVIEW</div><h1 class="title">科目 ${ui.examSection} · 错题复习</h1>${sectionSwitcher()}<p class="lead">做错后进入这里；此后连续答对两次会从待复习列表移出，历史作答仍保留。</p>${wrong.length ? `<div class="section-row"><h2>待复习 ${wrong.length} 道</h2></div><button class="button primary wide" data-action="start-wrong">开始复习</button>${wrong.map(q=>`<div class="card question-list-item"><span class="number">${h(sectionLabel(q))} · ${h(q.number)}</span><span class="list-copy"><strong>${h(q.stemJa)}</strong><small>${h(sourceLabel(q))}</small></span><span class="review-count">还需连对 ${2-status.get(q.id).streakAfterWrong} 次</span></div>`).join("")}` : `<div class="card empty"><span class="icon">✓</span><strong>目前没有待复习错题</strong><span>开始刷题后，做错的题会自动出现在这里。</span></div>`}`;
  }
  function renderDaily() {
    const ids = dailyIds();
    const qs = ids.map(id=>byId.get(id)).filter(Boolean);
    const done = new Set(state.attempts.filter(a=>a.date===today()).map(a=>a.questionId));
    return `<div class="eyebrow">DAILY FIVE</div><h1 class="title">科目 ${ui.examSection} · 每日推荐题目</h1>${sectionSwitcher()}<p class="lead">先复习待巩固错题，再补充尚未做过的题。当天题单固定，重开应用也不会变。</p><span class="daily-date">${h(today())} · ${qs.length} 道</span>${qs.length ? `<div class="card"><strong>今天已完成 ${qs.filter(q=>done.has(q.id)).length} / ${qs.length} 道</strong><p class="source-note">推荐只从已核验题库选取，题量不足时显示实际数量。</p><button class="button primary wide" data-action="start-daily">开始今日练习</button></div>${qs.map((q,i)=>`<div class="card question-list-item"><span class="number">${String(i+1).padStart(2,"0")}</span><span class="list-copy"><strong>${h(q.stemJa)}</strong><small>${h(sourceLabel(q))}</small></span><span class="chip ${done.has(q.id)?"official":""}">${done.has(q.id)?"已作答":"待作答"}</span></div>`).join("")}` : `<div class="card empty"><strong>题目正在核验</strong><span>题库准备好后，每天会从真实题目中挑选练习。</span></div>`}`;
  }
  function startSession(ids, title, fromTab) {
    const valid = ids.filter(id=>byId.has(id));
    if (!valid.length) return;
    ui.session = { ids: valid, index: 0, selected: null, submitted: false, title, fromTab, startAttemptCount: state.attempts.length };
    ui.result = null; ui.tab = fromTab; render(); window.scrollTo(0,0);
  }
  function renderSession() {
    const s = ui.session;
    const q = byId.get(s.ids[s.index]);
    if (!q) { ui.session=null; return renderQuizHome(); }
    const isCorrect = s.selected === q.answer;
    const isIpa = q.kind === "official" || q.kind === "sample";
    const sourceChip = q.kind === "sample" ? `2022 年${q.sampleSet === "early" ? "4" : "12"}月官方样题 · 问 ${q.number}` : q.kind === "official" ? `${q.year} 年${q.periodJa?` ${h(q.periodJa)}`:""} · 问 ${q.number}` : "";
    const questionUrl = safeSourceUrl(q.questionUrl);
    const answerSource = safeSourceUrl(q.answerUrl);
    const answerUrl = answerSource && Number.isInteger(q.answerPage) ? `${answerSource}#page=${q.answerPage}` : answerSource;
    return `<button class="back" data-action="leave-session">← 返回</button>
      <div class="question-head"><div><div class="eyebrow">${h(s.title)}</div><strong>第 ${s.index+1} / ${s.ids.length} 题</strong></div>${badge(q)}</div>
      <div class="progress"><div style="width:${Math.round((s.index+1)*100/s.ids.length)}%"></div></div>
      <div class="chip-row"><span class="chip">${h(sectionLabel(q))}</span><span class="chip">${h(q.topicZh || "综合")}</span>${sourceChip?`<span class="chip">${sourceChip}</span>`:""}</div>
      <div class="stem" lang="ja">${h(q.stemJa)}</div>
      ${q.transcriptionNoteZh?`<p class="source-note">${h(q.transcriptionNoteZh)}</p>`:""}
      ${(q.imageAssets || []).filter(safeImageAsset).map((asset,index)=>`<figure class="question-figure"><button data-action="open-image" data-image="${h(asset)}" data-image-label="${h(sectionLabel(q))} 问${q.number} 原卷图片${index+1}"><img src="${h(asset)}" alt="${h(sectionLabel(q))} 问${q.number} 原卷图片${index+1}"></button><figcaption>IPA 原卷图片 · 点击放大，可横向移动查看</figcaption></figure>`).join("")}
      ${q.options.map(o=>`<button class="option ${s.selected===o.label?"selected":""} ${s.submitted&&o.label===q.answer?"correct":""} ${s.submitted&&s.selected===o.label&&!isCorrect?"wrong":""}" data-action="select-option" data-option="${h(o.label)}" ${s.submitted?"disabled":""}><span class="letter">${h(o.label)}</span><span lang="ja">${h(o.textJa)}</span></button>`).join("")}
      ${s.submitted?`<div class="answer-panel ${isCorrect?"":"bad"}"><strong>${isCorrect?"答对了":"再看一遍思路"} · ${isIpa?"官方答案":"参考答案"} ${h(q.answer)}</strong><p>${h(q.explanationZh)}</p><small>${h(sourceLabel(q))}</small>${isIpa && questionUrl && answerUrl?`<br><a class="source-link" href="${questionUrl}#page=${Number(q.page)||1}">查看 IPA 原题 PDF ↗</a> <a class="source-link" href="${answerUrl}">核对官方答案 ↗</a>`:""}</div><button class="button primary wide" data-action="next-question" style="margin-top:16px">${s.index===s.ids.length-1?"查看本轮结果":"下一题"}</button>`:`<button class="button primary wide" data-action="submit-answer" ${s.selected?"":"disabled"} style="margin-top:18px">确认答案</button>`}`;
  }
  function renderResult() {
    const r = ui.result;
    return `<button class="back" data-action="close-result">← 返回</button><div class="eyebrow">练习完成</div><h1 class="title">这一轮完成了</h1><div class="card empty"><span class="icon">✦</span><strong>答对 ${r.correct} / ${r.total} 道</strong><span>需要再巩固的题已经进入错题复习。</span></div><div class="button-row"><button class="button secondary" data-action="close-result">返回列表</button><button class="button primary" data-action="go-wrong">查看错题</button></div>`;
  }
  function render() {
    if (ui.result && ui.result.fromTab===ui.tab) screen.innerHTML = renderResult();
    else if (ui.session && ui.session.fromTab===ui.tab) screen.innerHTML = renderSession();
    else screen.innerHTML = ui.tab==="learn" ? renderLearn() : ui.tab==="quiz" ? renderQuizHome() : ui.tab==="wrong" ? renderWrong() : renderDaily();
    if (ui.image) screen.innerHTML += renderImageViewer();
  }
  document.querySelectorAll(".nav-item").forEach(b => b.addEventListener("click",()=>setTab(b.dataset.tab)));
  screen.addEventListener("change", event => {
    const filter = event.target.dataset.filter;
    if (filter) { ui.filters[filter] = event.target.value; render(); }
  });
  screen.addEventListener("click", event => {
    const el = event.target.closest("[data-action]");
    if (!el) return;
    const action = el.dataset.action;
    if (action==="choose-section" && ["A","B"].includes(el.dataset.section)) {
      ui.examSection=el.dataset.section; ui.lessonId=null; ui.session=null; ui.result=null; ui.image=null;
      ui.filters.kind="all"; ui.filters.section="all"; ui.filters.year="all";
      state.examSection=ui.examSection; saveState();
      render(); window.scrollTo(0,0);
    }
    else if (action==="open-lesson") { ui.lessonId=el.dataset.lesson; render(); window.scrollTo(0,0); }
    else if (action==="back-learn") { ui.lessonId=null; render(); window.scrollTo(0,0); }
    else if (action==="lesson-quiz") {
      const lesson=LESSONS.find(l=>l.id===el.dataset.lesson);
      const related=relatedQuestions(lesson);
      startSession(related.map(q=>q.id),lesson.title,"learn");
    }
    else if (action==="start-filtered") startSession(practiceQuestions().map(q=>q.id),"刷题练习","quiz");
    else if (action==="start-wrong") startSession(wrongQuestions(ui.examSection).map(q=>q.id),`科目 ${ui.examSection} 错题复习`,"wrong");
    else if (action==="start-daily") startSession(dailyIds(),"每日推荐","daily");
    else if (action==="open-image" && safeImageAsset(el.dataset.image)) { ui.image={src:el.dataset.image,alt:el.dataset.imageLabel || "IPA 原卷图片",scale:1}; render(); }
    else if (action==="close-image") { ui.image=null; render(); }
    else if (action==="zoom-in" && ui.image) { ui.image.scale=Math.min(4,ui.image.scale+0.5); render(); }
    else if (action==="zoom-out" && ui.image) { ui.image.scale=Math.max(1,ui.image.scale-0.5); render(); }
    else if (action==="select-option" && ui.session && !ui.session.submitted) { ui.session.selected=el.dataset.option; render(); }
    else if (action==="submit-answer" && ui.session && ui.session.selected && !ui.session.submitted) {
      const q=byId.get(ui.session.ids[ui.session.index]);
      state.attempts.push({questionId:q.id,selected:ui.session.selected,correct:ui.session.selected===q.answer,at:new Date().toISOString(),date:today()});
      ui.session.submitted=true; saveState(); render();
      document.querySelector(".answer-panel")?.scrollIntoView({behavior:"smooth",block:"nearest"});
    }
    else if (action==="next-question" && ui.session && ui.session.submitted) {
      if (ui.session.index < ui.session.ids.length-1) {ui.session.index++;ui.session.selected=null;ui.session.submitted=false;render();window.scrollTo(0,0);}
      else {
        const completed=state.attempts.slice(ui.session.startAttemptCount);
        ui.result={total:ui.session.ids.length,correct:completed.filter(a=>a.correct).length,fromTab:ui.session.fromTab};
        ui.session=null;render();window.scrollTo(0,0);
      }
    }
    else if (action==="leave-session") {ui.session=null;ui.lessonId=null;render();window.scrollTo(0,0);}
    else if (action==="close-result") {ui.result=null;ui.lessonId=null;render();window.scrollTo(0,0);}
    else if (action==="go-wrong") {ui.result=null;setTab("wrong");}
  });
  window.FE_goBack = function () {
    if (ui.image) { ui.image=null; render(); return true; }
    if (ui.result && ui.result.fromTab===ui.tab) { ui.result=null; ui.lessonId=null; render(); return true; }
    if (ui.session && ui.session.fromTab===ui.tab) { ui.session=null; ui.lessonId=null; render(); return true; }
    if (ui.lessonId && ui.tab==="learn") { ui.lessonId=null; render(); return true; }
    if (ui.tab!=="learn") { setTab("learn"); return true; }
    return false;
  };
  render();
})();




